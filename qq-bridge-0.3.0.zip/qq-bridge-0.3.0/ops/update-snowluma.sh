#!/usr/bin/env bash
# SnowLuma safe updater: pin image version, wait for QQ Hook/OneBot readiness,
# retry a clean recreate once, and roll back automatically if it still fails.
#
# Usage:
#   sudo bash update-snowluma.sh --version v2.2.1
#   sudo bash update-snowluma.sh --rollback
#   sudo bash update-snowluma.sh --version v2.2.1 --dry-run
#
# It does not delete Docker volumes or the SnowLuma data directory.
set -u

DIR="${SNOWLUMA_DIR:-/opt/snowluma}"
COMPOSE="$DIR/docker-compose.yml"
SERVICE="${SNOWLUMA_SERVICE:-snowluma}"
CONTAINER="${SNOWLUMA_CONTAINER:-snowluma}"
VERSION="v2.2.1"
MODE="update"
DRY_RUN=0
FIRST_WAIT=300
SECOND_WAIT=240
ROLLBACK_WAIT=180
LOG_DIR="${SNOWLUMA_UPDATE_LOG_DIR:-/root/updates}"

usage() {
  sed -n '2,14p' "$0"
  exit 0
}

while [ $# -gt 0 ]; do
  case "$1" in
    --version) VERSION="${2:-}"; shift 2 ;;
    --rollback) MODE="rollback"; shift ;;
    --dir) DIR="${2:-}"; COMPOSE="$DIR/docker-compose.yml"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    --help|-h) usage ;;
    *) echo "unknown argument: $1" >&2; exit 2 ;;
  esac
done

if [ "$(id -u)" -ne 0 ]; then
  echo "请用 root 运行（或 sudo）。" >&2
  exit 1
fi
if [ ! -f "$COMPOSE" ]; then
  echo "找不到 compose 文件：$COMPOSE" >&2
  exit 1
fi
if ! command -v docker >/dev/null 2>&1; then
  echo "找不到 docker 命令。" >&2
  exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "需要 docker compose v2。" >&2
  exit 1
fi

mkdir -p "$LOG_DIR"
STAMP="$(date +%Y%m%d-%H%M%S)"
LOG="$LOG_DIR/snowluma-${MODE}-${STAMP}.log"
exec > >(tee -a "$LOG") 2>&1

echo "== SnowLuma $MODE =="
echo "time: $(date -Is)"
echo "dir: $DIR"
echo "compose: $COMPOSE"
echo "log: $LOG"

current_image_line() {
  grep -E '^[[:space:]]*image:[[:space:]]*motricseven7/snowluma:' "$COMPOSE" | head -n1 | sed -E 's/^[[:space:]]*image:[[:space:]]*//'
}

current_image() {
  current_image_line | tr -d '"' | tr -d "'"
}

image_id() {
  docker image inspect "$1" --format '{{.Id}}' 2>/dev/null || true
}

wait_ready() {
  local label="$1" max_seconds="$2" start_epoch start_iso i http login running version
  start_epoch="$(date +%s)"
  start_iso="$(date -u -d "@$start_epoch" +%Y-%m-%dT%H:%M:%SZ)"
  i=0
  while :; do
    i=$((i + 1))
    running="$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null || true)"
    http="$(curl -sS -m 3 -o /dev/null -w '%{http_code}' http://127.0.0.1:3000/ 2>/dev/null || true)"
    login="$(docker logs --since "$start_iso" "$CONTAINER" 2>&1 | grep -cF '[Hook] login detected' || true)"
    version="$(docker exec "$CONTAINER" sh -lc 'grep -m1 "\"version\"" /app/runtime/release.json' 2>/dev/null | tr -d '\n' || true)"
    echo "[$label ${i}] running=${running:-?} http=${http:-?} hook_login=${login:-0} ${version}"
    if [ "$running" = "true" ] && [ "$http" != "000" ] && [ "${login:-0}" -ge 1 ]; then
      if ss -ltn 2>/dev/null | grep -qE ':(3000|3001)[[:space:]]'; then
        return 0
      fi
    fi
    if [ $(( $(date +%s) - start_epoch )) -ge "$max_seconds" ]; then
      return 1
    fi
    sleep 20
  done
}

do_up() {
  echo "== docker compose up -d =="
  docker compose -f "$COMPOSE" up -d
}

rollback_to() {
  local backup="$1"
  echo "== rollback to $backup =="
  cp -a "$backup" "$COMPOSE"
  grep -n 'image:' "$COMPOSE" || true
  do_up
  if wait_ready "rollback" "$ROLLBACK_WAIT"; then
    echo "ROLLBACK_OK"
    return 0
  fi
  echo "ROLLBACK_FAILED" >&2
  return 1
}

if [ "$MODE" = "rollback" ]; then
  BACKUP="$(ls -1t "$DIR"/docker-compose.yml.bak-* 2>/dev/null | head -n1 || true)"
  if [ -z "$BACKUP" ]; then
    echo "找不到 compose 备份，无法自动回滚。" >&2
    exit 1
  fi
  echo "using backup: $BACKUP"
  [ "$DRY_RUN" -eq 1 ] && { echo "DRY_RUN: would restore $BACKUP"; exit 0; }
  rollback_to "$BACKUP"
  exit $?
fi

case "$VERSION" in
  v*|[0-9]*) ;;
  *) echo "版本格式不对：$VERSION" >&2; exit 2 ;;
esac

TARGET_IMAGE="motricseven7/snowluma:${VERSION}"
OLD_LINE="$(current_image_line)"
OLD_IMAGE="$(current_image)"
echo "old image: ${OLD_IMAGE:-<none>}"
echo "target image: $TARGET_IMAGE"

if [ "$OLD_IMAGE" = "$TARGET_IMAGE" ] && [ "$(docker inspect -f '{{.State.Running}}' "$CONTAINER" 2>/dev/null || true)" = "true" ]; then
  already_http="$(curl -sS -m 3 -o /dev/null -w '%{http_code}' http://127.0.0.1:3000/ 2>/dev/null || true)"
  if [ "$already_http" != "000" ] && ss -ltn 2>/dev/null | grep -qE ':(3000|3001)[[:space:]]'; then
    echo "已经是目标镜像且 OneBot 正在监听：$TARGET_IMAGE"
    echo "ALREADY_OK"
    exit 0
  fi
  echo "目标镜像已存在但 OneBot 未监听；继续重建。" >&2
fi

echo "== backup compose =="
COMPOSE_BAK="$DIR/docker-compose.yml.bak-${STAMP}"
cp -a "$COMPOSE" "$COMPOSE_BAK"
echo "$COMPOSE_BAK" > "$LOG_DIR/last-compose-backup.txt"

if ! image_id "$TARGET_IMAGE" | grep -q '^sha256:'; then
  echo "== image not found locally, pulling =="
  if [ "$DRY_RUN" -eq 1 ]; then
    echo "DRY_RUN: would run docker pull $TARGET_IMAGE"
    exit 0
  fi
  docker pull "$TARGET_IMAGE"
fi

echo "== image ids =="
{
  echo "stamp=$STAMP"
  echo "old_image=${OLD_IMAGE:-}"
  echo "old_image_id=$(image_id "${OLD_IMAGE:-}")"
  echo "new_image=$TARGET_IMAGE"
  echo "new_image_id=$(image_id "$TARGET_IMAGE")"
} | tee "$LOG_DIR/snowluma-image-${STAMP}.txt"

echo "== pin compose image =="
if [ "$DRY_RUN" -eq 1 ]; then
  echo "DRY_RUN: would set image to $TARGET_IMAGE"
  exit 0
fi
sed -i -E "s#^([[:space:]]*image:[[:space:]]*)motricseven7/snowluma:.*#\1$TARGET_IMAGE#" "$COMPOSE"
docker compose -f "$COMPOSE" config --quiet
grep -n 'image:' "$COMPOSE" || true

do_up
if wait_ready "first" "$FIRST_WAIT"; then
  echo "UPDATE_OK"
  echo "current image: $(current_image)"
  exit 0
fi

echo "首次启动未就绪，执行一次干净重建（保留数据卷）。"
docker compose -f "$COMPOSE" down || true
do_up
if wait_ready "second" "$SECOND_WAIT"; then
  echo "UPDATE_OK_AFTER_RECREATE"
  echo "current image: $(current_image)"
  exit 0
fi

echo "两次启动均未就绪，自动回滚到更新前 compose。" >&2
rollback_to "$COMPOSE_BAK"
echo "UPDATE_FAILED_ROLLED_BACK" >&2
exit 1
