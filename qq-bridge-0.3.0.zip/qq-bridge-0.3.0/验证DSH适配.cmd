@echo off
rem 验证本机桥接与当前 DSH 版本的协议适配（72 项断言，含真实 DSH 实测）。
rem 需要：DSH 桌面版正在运行（Web 端口 19387）。
rem DSH_INSTALL_MODULES 指向本目录上一级 _dsh_modules（装 dsh-persona@0.2.0-rc.2
rem + js-yaml 供校验脚本加载 DSH 自身 schema；没有它 §1 段无法运行）。
setlocal
cd /d "%~dp0"
set "DSH_PROFILE=desktop"
set "DSH_BASE_URL=http://127.0.0.1:19387"
set "DSH_INSTALL_MODULES=%~dp0..\_dsh_modules\node_modules"
call "%~dp0node.cmd" "scripts\verify-dsh-020-adaptation.mjs"
echo.
echo === 验证结束（全部通过时最后一行是「总计: N 通过, 0 失败」） ===
pause
exit /b %errorlevel%
