import assert from 'node:assert/strict';
import {
  canAutoFollowUp,
  commitmentScopeKey,
  countFollowUpsToday,
  detectAgreement,
  detectExchangeCommitmentCandidates,
  detectOwnerRequest,
  detectPromiseCandidates,
  emptyCommitmentState,
  followUpDueAt,
  followUpRuleFor,
  formatCommitmentsPrompt,
  normalizeCommitmentState,
  normalizeFollowUpSettings,
  pendingCommitments,
  recordCommitments,
  refreshCommitmentFollowUps,
  setCommitmentFollowUpStatus,
  setCommitmentStatus,
  setFollowUpRule
} from '../src/commitments.js';

let passed = 0;
function test(name, fn) {
  fn();
  passed += 1;
  console.log(`ok ${passed} - ${name}`);
}

test('只抓承诺，不抓普通寒暄和问句', () => {
  const candidates = detectPromiseCandidates('等会儿给你留一杯。今天好累啊。你吃了吗？下次帮你问一下。等会儿看情况。');
  assert.equal(candidates.length, 2);
  assert.match(candidates[0].text, /留一杯/);
  assert.match(candidates[1].text, /问一下/);
});

test('记录后按角色隔离', () => {
  let state = emptyCommitmentState();
  const result = recordCommitments(state, { characterId: 'jill', groupId: '123456789', personId: '123', personName: '示例群友', content: '等会儿给你留一杯。', now: 1000 });
  assert.equal(result.added.length, 1);
  assert.equal(pendingCommitments(state, { characterId: 'jill', groupId: '123456789', now: 1000 }).length, 1);
  assert.equal(pendingCommitments(state, { characterId: 'other', groupId: '123456789', now: 1000 }).length, 0);
});

test('同群同句 10 分钟内去重', () => {
  let state = emptyCommitmentState();
  recordCommitments(state, { characterId: 'jill', groupId: '1', content: '等会儿给你带。', now: 1000 });
  recordCommitments(state, { characterId: 'jill', groupId: '1', content: '等会儿给你带。', now: 2000 });
  assert.equal(pendingCommitments(state, { characterId: 'jill', groupId: '1', now: 2000 }).length, 1);
});

test('提示词只出现本群/本人，且不会重复催', () => {
  let state = emptyCommitmentState();
  recordCommitments(state, { characterId: 'jill', groupId: '1', personId: '123', personName: '示例群友', content: '等会儿给你留一杯。', now: 1000 });
  recordCommitments(state, { characterId: 'jill', groupId: '2', personName: '别人', content: '下次帮你问。', now: 1000 });
  const block = formatCommitmentsPrompt(state, { characterId: 'jill', groupId: '1', personId: '123', now: 2000, markInjected: true });
  assert.match(block, /示例群友/);
  assert.match(block, /留一杯/);
  assert.doesNotMatch(block, /别人/);
  assert.doesNotMatch(block, /下次帮你问/);
  const second = formatCommitmentsPrompt(state, { characterId: 'jill', groupId: '1', personId: '123', now: 3000 });
  assert.equal(second, '');
});

test('完成/作废后不再提示，旧格式可归一化', () => {
  let state = emptyCommitmentState();
  const result = recordCommitments(state, { characterId: 'jill', groupId: '1', content: '等会儿给你带。', now: 1000 });
  const id = result.added[0].id;
  assert.equal(setCommitmentStatus(state, { characterId: 'jill', id, status: 'done' }), true);
  assert.equal(pendingCommitments(state, { characterId: 'jill', groupId: '1', now: 2000 }).length, 0);
  const normalized = normalizeCommitmentState({ characters: { jill: [{ id, groupId: '1', text: '等会儿给你带。', createdAt: 1000 }] } });
  assert.equal(normalized.characters.jill.length, 1);
  assert.equal(normalized.characters.jill[0].status, 'pending');
});

test('14 天后过期', () => {
  let state = emptyCommitmentState();
  recordCommitments(state, { characterId: 'jill', groupId: '1', content: '等会儿给你带。', now: 1000 });
  recordCommitments(state, { characterId: 'jill', groupId: '1', content: '明天给你带。', now: 16 * 24 * 60 * 60 * 1000 });
  const pending = pendingCommitments(state, { characterId: 'jill', groupId: '1', now: 16 * 24 * 60 * 60 * 1000 });
  assert.equal(pending.length, 1);
});

test('到期时间：稍后一小时，明天/后天十点，下次不自动', () => {
  const now = new Date(2026, 9, 28, 23, 0, 0).getTime();
  assert.equal(followUpDueAt('稍后', now), now + 60 * 60 * 1000);
  assert.equal(followUpDueAt('明天', now), new Date(2026, 9, 29, 10, 0, 0).getTime());
  assert.equal(followUpDueAt('后天', now), new Date(2026, 9, 30, 10, 0, 0).getTime());
  assert.equal(followUpDueAt('下次', now), 0);
});

test('到点只进入待确认，确认/跳过/过期状态可追踪', () => {
  const now = new Date(2026, 9, 28, 10, 0, 0).getTime();
  const state = emptyCommitmentState();
  const result = recordCommitments(state, { characterId: 'jill', groupId: '123456789', content: '等会儿给你带一杯。', now });
  const item = result.added[0];
  assert.equal(item.followUpStatus, 'waiting');
  assert.equal(refreshCommitmentFollowUps(state, { characterId: 'jill', now: now + 59 * 60 * 1000 }).changed, 0);
  const due = refreshCommitmentFollowUps(state, { characterId: 'jill', now: now + 61 * 60 * 1000 });
  assert.equal(due.changed, 1);
  assert.equal(item.followUpStatus, 'pending_confirmation');
  assert.equal(setCommitmentFollowUpStatus(state, { characterId: 'jill', id: item.id, status: 'sent', now: now + 62 * 60 * 1000 }), true);
  assert.equal(item.followUpSentAt, now + 62 * 60 * 1000);
});

test('主人私聊和群承诺按 scope 隔离', () => {
  const now = 1000;
  const state = emptyCommitmentState();
  const group = recordCommitments(state, { characterId: 'jill', groupId: '1', content: '等会儿给你带。', now });
  const owner = recordCommitments(state, { characterId: 'jill', scopeKey: 'private:345', personId: '345', personName: '主人', content: '等会儿告诉你。', now });
  assert.equal(commitmentScopeKey(group.added[0]), 'group:1');
  assert.equal(commitmentScopeKey(owner.added[0]), 'private:345');
  assert.equal(pendingCommitments(state, { characterId: 'jill', scopeKey: 'group:1', now }).length, 1);
  assert.equal(pendingCommitments(state, { characterId: 'jill', scopeKey: 'private:345', now }).length, 1);
  const block = formatCommitmentsPrompt(state, { characterId: 'jill', scopeKey: 'private:345', now: 2000 });
  assert.match(block, /告诉你/);
  assert.doesNotMatch(block, /带一杯/);
});

test('过期跟进标记为 expired', () => {
  const now = new Date(2026, 9, 28, 10, 0, 0).getTime();
  const state = emptyCommitmentState();
  const result = recordCommitments(state, { characterId: 'jill', groupId: '1', content: '等会儿给你带。', now });
  const item = result.added[0];
  item.dueAt = now - 49 * 60 * 60 * 1000;
  refreshCommitmentFollowUps(state, { characterId: 'jill', now });
  assert.equal(item.followUpStatus, 'expired');
});

test('点酒/马上这类动作也能识别，并算出短到点时间', () => {
  const now = new Date(2026, 9, 28, 10, 0, 0).getTime();
  const candidates = detectPromiseCandidates('好，给你点一杯。我马上给你拿。');
  assert.ok(candidates.some((item) => /点一杯/.test(item.text)));
  assert.ok(candidates.some((item) => item.dueHint === '马上'));
  assert.equal(followUpDueAt('马上', now), now + 15 * 60 * 1000);
  const state = emptyCommitmentState();
  const result = recordCommitments(state, { characterId: 'jill', groupId: '1', content: '好，给你点一杯。', now });
  assert.equal(result.added.length, 1);
  assert.ok(result.added[0].dueAt > now);
});

test('自动跟进默认关闭，授权后受场景/全局/免打扰限制', () => {
  const now = new Date(2026, 9, 28, 10, 0, 0).getTime();
  const state = emptyCommitmentState();
  const result = recordCommitments(state, { characterId: 'jill', groupId: '123456789', content: '等会儿给你点一杯。', now });
  const item = result.added[0];
  item.dueAt = now - 1000;
  item.followUpStatus = 'pending_confirmation';
  assert.equal(canAutoFollowUp(state, { characterId: 'jill', item, now }).ok, false);
  assert.equal(followUpRuleFor(state, { characterId: 'jill', scopeKey: 'group:123456789' }).mode, 'off');
  assert.equal(setFollowUpRule(state, { characterId: 'jill', scopeKey: 'group:123456789', mode: 'observe', maxPerDay: 1 }), true);
  assert.equal(canAutoFollowUp(state, { characterId: 'jill', item, now }).reason, 'observe');
  assert.equal(setFollowUpRule(state, { characterId: 'jill', scopeKey: 'group:123456789', mode: 'auto', maxPerDay: 1 }), true);
  assert.equal(canAutoFollowUp(state, { characterId: 'jill', item, now }).ok, true);
  item.followUpStatus = 'sent';
  item.followUpSentAt = now;
  assert.equal(countFollowUpsToday(state, { characterId: 'jill', scopeKey: 'group:123456789', now }), 1);
  assert.equal(canAutoFollowUp(state, { characterId: 'jill', item, now }).ok, false);
});

test('自动跟进设置归一化与免打扰', () => {
  const settings = normalizeFollowUpSettings({ quietHours: { start: '25:90', end: '7:5' }, globalMaxPerDay: 99 });
  assert.equal(settings.quietHours.start, '23:59');
  assert.equal(settings.quietHours.end, '07:05');
  assert.equal(settings.globalMaxPerDay, 10);
  const state = emptyCommitmentState();
  state.followUpSettings = normalizeFollowUpSettings({ quietHours: { start: '23:00', end: '08:00' } });
  const night = new Date(2026, 9, 28, 23, 30, 0).getTime();
  const result = recordCommitments(state, { characterId: 'jill', groupId: '123456789', content: '等会儿给你点一杯。', now: night });
  const item = result.added[0];
  item.dueAt = night - 1000;
  item.followUpStatus = 'pending_confirmation';
  setFollowUpRule(state, { characterId: 'jill', scopeKey: 'group:123456789', mode: 'auto', maxPerDay: 1 });
  assert.equal(canAutoFollowUp(state, { characterId: 'jill', item, now: night }).reason, 'quiet');
});

test('对话级识别：对方请求 + 角色答应', () => {
  const request = detectOwnerRequest('明天提醒我。');
  assert.ok(request);
  assert.equal(request.dueHint, '明天');
  assert.equal(detectOwnerRequest('我明天提醒你。'), null);
  assert.equal(detectAgreement('会的。'), true);
  assert.equal(detectAgreement('不行，明天没空。'), false);
  const candidates = detectExchangeCommitmentCandidates({ ownerText: '明天提醒我。', jillText: '会的。' });
  assert.equal(candidates.length, 1);
  assert.equal(candidates[0].sourceType, 'owner-request');
  assert.match(candidates[0].text, /提醒我/);
});

test('记录对话级承诺并写入提示词', () => {
  const now = new Date(2026, 9, 28, 23, 33, 0).getTime();
  const state = emptyCommitmentState();
  const result = recordCommitments(state, {
    characterId: 'jill',
    scopeKey: 'private:345',
    personId: '345',
    personName: '主人',
    ownerText: '明天提醒我。',
    content: '会的。',
    now
  });
  assert.equal(result.added.length, 1);
  assert.equal(result.added[0].sourceType, 'owner-request');
  assert.equal(result.added[0].dueHint, '明天');
  assert.ok(result.added[0].dueAt > now);
  const block = formatCommitmentsPrompt(state, { characterId: 'jill', scopeKey: 'private:345', now: now + 1000 });
  assert.match(block, /答应过主人/);
  assert.match(block, /明天提醒我/);
});

test('同一轮请求只记一条，后续补充句不重复建提醒', () => {
  const now = 1000;
  const state = emptyCommitmentState();
  recordCommitments(state, {
    characterId: 'jill', scopeKey: 'private:345', personId: '345', personName: '主人',
    ownerText: '明天提醒我。', content: '会的。', now
  });
  recordCommitments(state, {
    characterId: 'jill', scopeKey: 'private:345', personId: '345', personName: '主人',
    ownerText: '明天提醒我。', content: '明天买完，跟你报个数。', now: now + 1000
  });
  const pending = pendingCommitments(state, { characterId: 'jill', scopeKey: 'private:345', now: now + 2000 });
  assert.equal(pending.length, 1);
  assert.equal(pending[0].sourceType, 'owner-request');
});

test('对方只说“记得”时，仍能记录角色随后的具体计划', () => {
  const now = 1000;
  const state = emptyCommitmentState();
  const result = recordCommitments(state, {
    characterId: 'jill',
    scopeKey: 'private:345',
    personId: '345',
    personName: '主人',
    ownerText: '我现在希望你真的能记得。',
    content: '明天买完，跟你报个数。',
    now
  });
  assert.equal(result.added.length, 1);
  assert.equal(result.added[0].text, '明天买完，跟你报个数。');
  assert.equal(result.added[0].dueHint, '明天');
});

test('对话级不把拒绝或角色自己的话误记成承诺', () => {
  const state = emptyCommitmentState();
  const rejected = recordCommitments(state, {
    characterId: 'jill', scopeKey: 'private:345', ownerText: '明天提醒我。', content: '不行，明天我很忙。', now: 1000
  });
  assert.equal(rejected.added.length, 0);
  const reversed = recordCommitments(state, {
    characterId: 'jill', scopeKey: 'private:345', ownerText: '我明天提醒你。', content: '好啊。', now: 1000
  });
  assert.equal(reversed.added.length, 0);
});

console.log(`✅ 承诺记忆测试通过（${passed} 项）`);
