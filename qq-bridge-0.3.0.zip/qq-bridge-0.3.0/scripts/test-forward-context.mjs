import assert from 'node:assert/strict';
import { formatForwardContent, formatForwardFailure, buildForwardContextBlock, FORWARD_CONTEXT_MAX_CHARS } from '../src/forward-context.js';

function node(name, text, extra = []) {
  return {
    data: {
      name,
      content: [{ type: 'text', data: { text } }, ...extra]
    }
  };
}

const data = {
  messages: [
    node('小明', '周六去不去旧城区？', [{ type: 'image', data: { file: 'x.jpg' } }]),
    node('阿岚', '我可能晚点，先别等我。'),
    node('小明', '行，那七点见。')
  ]
};

const text = formatForwardContent('fwd_test_1', data);
assert.match(text, /共 3 条/);
assert.match(text, /小明：周六去不去旧城区？\s*\[图片\]/);
assert.match(text, /阿岚：我可能晚点/);
assert.match(text, /七点见/);

const many = { messages: Array.from({ length: 30 }, (_, i) => node(`人${i + 1}`, `第${i + 1}条消息`)) };
const truncated = formatForwardContent('fwd_test_2', many);
assert.match(truncated, /只展开前 20 条/);
assert.match(truncated, /第20条消息/);
assert.doesNotMatch(truncated, /第21条消息/);
assert.ok(truncated.length < FORWARD_CONTEXT_MAX_CHARS + 100);

const empty = formatForwardContent('fwd_empty', { messages: [] });
assert.match(empty, /读取失败/);

const fail = formatForwardFailure('fwd_bad');
assert.match(fail, /读取失败/);
assert.match(fail, /不要编造/);

const block = buildForwardContextBlock([text, fail]);
assert.match(block, /聊天记录（已自动展开）/);
assert.match(block, /fwd_bad/);
assert.equal(buildForwardContextBlock([]), '');

console.log('✅ 聊天记录上下文测试通过（展开/截断/失败提示）');
