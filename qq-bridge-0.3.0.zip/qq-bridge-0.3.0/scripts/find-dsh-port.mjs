#!/usr/bin/env node
// 桌面版 DSH 端口发现 CLI。
//
// 用途：桌面版 DSH 每次启动随机换端口，桥接配置里的 dsh.baseUrl 会失效。
// 这个脚本按「显式配置 → 缓存 → 扫描本机监听端口」的顺序找到 DSH，
// 可选把结果写回 config.json。供 `启动.cmd` 或手动排障使用。
//
// 用法：
//   node scripts/find-dsh-port.mjs               探测并打印
//   node scripts/find-dsh-port.mjs --write       探测成功后写回 config.json
//   node scripts/find-dsh-port.mjs --json        以 JSON 输出（供脚本调用）
//   node scripts/find-dsh-port.mjs --base-url http://127.0.0.1:59626
//                                                只验证指定地址，不扫描
//   node scripts/find-dsh-port.mjs --timeout 1200
//                                                单次 HTTP 探测超时（默认 800ms）
//
// 退出码：0 = 找到；2 = 没找到；3 = 参数错误；4 = 写配置失败
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  normalizeDshBaseUrl,
  persistDshBaseUrl,
  probeDshBaseUrl,
  resolveDshBaseUrl
} from '../src/dsh-port.js';

const ROOT = path.resolve(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
const STATE_DIR = path.join(ROOT, 'state');
const CFG_PATH = path.join(ROOT, 'config.json');

function usage() {
  console.error('用法: node scripts/find-dsh-port.mjs [--write] [--json] [--base-url URL] [--timeout 800]');
}

function parseArgs(argv) {
  const out = { write: false, json: false, baseUrl: '', timeoutMs: 800 };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--write') out.write = true;
    else if (arg === '--json') out.json = true;
    else if (arg === '--base-url') out.baseUrl = String(argv[++i] ?? '');
    else if (arg === '--timeout') out.timeoutMs = Math.max(100, Number(argv[++i]) || 800);
    else if (arg === '--help' || arg === '-h') { usage(); process.exit(0); }
    else { console.error(`未知参数: ${arg}`); usage(); process.exit(3); }
  }
  return out;
}

/** 读 config.json 里现有的 dsh.baseUrl；文件缺失/损坏不阻塞（返回空串）。 */
function readConfiguredBaseUrl() {
  try {
    const text = fs.readFileSync(CFG_PATH, 'utf8').replace(/^\uFEFF/, '');
    const cfg = JSON.parse(text);
    return String(cfg?.dsh?.baseUrl ?? '');
  } catch {
    return '';
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const log = args.json ? () => {} : (line) => console.error(`[dsh-port] ${line}`);

  let result;
  if (args.baseUrl) {
    const baseUrl = normalizeDshBaseUrl(args.baseUrl);
    if (!baseUrl) {
      console.error(`[dsh-port] 非法地址: ${args.baseUrl}`);
      process.exit(3);
    }
    const probe = await probeDshBaseUrl(baseUrl, { timeoutMs: args.timeoutMs });
    result = probe.ok
      ? { baseUrl, source: 'manual', port: Number(new URL(baseUrl).port) || 0, probed: 1, elapsedMs: probe.elapsedMs }
      : { baseUrl: '', source: 'none', port: 0, probed: 1, elapsedMs: probe.elapsedMs, reason: probe.error || `HTTP ${probe.status}` };
  } else {
    result = await resolveDshBaseUrl({
      configured: readConfiguredBaseUrl(),
      stateDir: STATE_DIR,
      timeoutMs: args.timeoutMs,
      log
    });
  }

  let written = null;
  if (result.baseUrl && args.write) {
    try {
      written = persistDshBaseUrl(CFG_PATH, result.baseUrl);
    } catch (error) {
      console.error(`[dsh-port] 写回 config.json 失败: ${error?.message ?? error}`);
      process.exit(4);
    }
  }

  if (args.json) {
    process.stdout.write(`${JSON.stringify({ ok: Boolean(result.baseUrl), ...result, written }, null, 2)}\n`);
    process.exit(result.baseUrl ? 0 : 2);
  }

  if (!result.baseUrl) {
    console.error(`[dsh-port] 未找到 DSH：${result.reason || '未知原因'}`);
    console.error('[dsh-port] 请先打开 DSH 桌面版并保持窗口开着，然后重试。');
    process.exit(2);
  }

  console.log(`DSH 地址: ${result.baseUrl}`);
  console.log(`来源: ${result.source}（探测 ${result.probed} 个端口，用时 ${result.elapsedMs}ms）`);
  if (written) {
    console.log(written.updated
      ? `已写回 config.json: ${written.from || '(空)'} -> ${written.to}`
      : `config.json 已是该地址，无需修改`);
  }
  process.exit(0);
}

main().catch((error) => {
  console.error(`[dsh-port] 未预期错误: ${error?.stack || error?.message || error}`);
  process.exit(2);
});
