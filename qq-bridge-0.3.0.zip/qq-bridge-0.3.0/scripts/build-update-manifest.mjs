#!/usr/bin/env node
// 生成自动更新清单 latest.json（发布流程的一部分，不手写）。
//
// 用法：
//   node scripts/build-update-manifest.mjs --zip dist/qq-bridge-0.3.0.zip --notes "## 更新内容..."
//   node scripts/build-update-manifest.mjs --notes-file notes.md --dsh-min 0.2.0-rc.2 --dsh-max 0.2.1
//
// 默认值：版本取 package.json；zip 取 dist/qq-bridge-<version>.zip；
//         输出 dist/latest.json；说明优先 --notes / --notes-file，否则从 CHANGELOG.md 提取。
// 发布：把 zip 与 latest.json 一起上传到**公开的发布仓库**（默认 Derpyu520/qq-bridge-releases）；
// 源码仓库可以保持私有，朋友只需要能访问发布仓库的 Release 附件。
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(path.dirname(fileURLToPath(import.meta.url))));

export function parseArgs(argv = process.argv.slice(2)) {
  const out = {
    zip: '', out: '', notes: '', notesFile: '',
    repo: '', tag: '', dshMin: '0.2.0-rc.2', dshMax: '0.2.1',
    dataSchema: 1, minDataSchema: 1, releasedAt: '',
    requiresDshRestart: false, assetUrl: '', help: false
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const take = () => String(argv[++i] ?? '');
    if (arg === '--zip') out.zip = take();
    else if (arg === '--out') out.out = take();
    else if (arg === '--notes') out.notes = take();
    else if (arg === '--notes-file') out.notesFile = take();
    else if (arg === '--repo') out.repo = take();
    else if (arg === '--tag') out.tag = take();
    else if (arg === '--dsh-min') out.dshMin = take();
    else if (arg === '--dsh-max') out.dshMax = take();
    else if (arg === '--data-schema') out.dataSchema = Number(take()) || 1;
    else if (arg === '--min-data-schema') out.minDataSchema = Number(take()) || 1;
    else if (arg === '--released-at') out.releasedAt = take();
    else if (arg === '--requires-dsh-restart') out.requiresDshRestart = true;
    else if (arg === '--asset-url') out.assetUrl = take();
    else if (arg === '--help' || arg === '-h') out.help = true;
    else throw new Error(`未知参数：${arg}`);
  }
  return out;
}

/** 从 CHANGELOG 里提取某个版本的说明（到下一个二级标题为止）。 */
export function extractChangelogNotes(text, version) {
  const source = String(text || '');
  const escaped = String(version).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`^##\\s+(?:\\[?v?${escaped}\\]?)(?:\\s|$).*$`, 'm');
  const m = re.exec(source);
  if (!m) return '';
  const start = m.index;
  const rest = source.slice(start);
  const next = rest.slice(1).search(/^##\s+/m);
  const section = next >= 0 ? rest.slice(0, next + 1) : rest;
  return section.split('\n').slice(1).join('\n').trim();
}

export function buildManifest({
  version,
  zipPath,
  notes = '',
  repo = 'Derpyu520/qq-bridge-releases',
  tag = '',
  dshMin = '0.2.0-rc.2',
  dshMax = '0.2.1',
  dataSchema = 1,
  minDataSchema = 1,
  releasedAt = '',
  requiresDshRestart = false,
  assetUrl = ''
} = {}) {
  const ver = String(version || '').trim();
  if (!/^\d+\.\d+\.\d+(?:-r\d+)?$/.test(ver)) throw new Error(`非法版本号：${ver}`);
  const line = ver.replace(/-r\d+$/, '');
  if (!zipPath || !fs.existsSync(zipPath)) throw new Error(`zip 不存在：${zipPath || '(未指定)'}`);
  const buffer = fs.readFileSync(zipPath);
  const sha256 = createHash('sha256').update(buffer).digest('hex');
  const asset = path.basename(zipPath);
  const releaseTag = tag || `v${ver}`;
  const resolvedAssetUrl = String(assetUrl || '').trim() || `https://github.com/${repo}/releases/download/${releaseTag}/${asset}`;
  const entry = {
    line,
    version: ver,
    tag: releaseTag,
    releasedAt: releasedAt || new Date().toISOString().slice(0, 10),
    asset,
    assetUrl: resolvedAssetUrl,
    sha256,
    size: buffer.length,
    dshCompat: { min: String(dshMin || ''), max: String(dshMax || '') },
    dataSchema: Number(dataSchema) || 1,
    minDataSchema: Number(minDataSchema) || 1,
    requiresDshRestart: requiresDshRestart === true,
    notes: String(notes || '').trim() || `## 更新内容\n\n- 版本 ${ver}`
  };
  return {
    schema: 1,
    updatedAt: new Date().toISOString(),
    recommended: entry,
    lines: { [line]: entry }
  };
}

export function main(argv = process.argv.slice(2)) {
  let args;
  try {
    args = parseArgs(argv);
  } catch (error) {
    console.error(`[manifest] ${error.message}`);
    return 2;
  }
  if (args.help) {
    console.log('用法: node scripts/build-update-manifest.mjs [--zip <path>] [--out <path>] [--notes "…"] [--notes-file <path>] [--repo owner/name] [--tag vX] [--dsh-min a] [--dsh-max b] [--data-schema N] [--min-data-schema N] [--requires-dsh-restart]');
    return 0;
  }
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const version = String(pkg.version || '').trim();
  const zipPath = args.zip ? path.resolve(args.zip) : path.join(ROOT, 'dist', `qq-bridge-${version}.zip`);
  const outPath = args.out ? path.resolve(args.out) : path.join(ROOT, 'dist', 'latest.json');

  let notes = args.notes;
  if (!notes && args.notesFile) {
    try { notes = fs.readFileSync(path.resolve(args.notesFile), 'utf8'); } catch (error) {
      console.error(`[manifest] 读取说明文件失败：${error.message}`);
      return 2;
    }
  }
  if (!notes) {
    try {
      const changelog = fs.readFileSync(path.join(ROOT, 'CHANGELOG.md'), 'utf8');
      notes = extractChangelogNotes(changelog, version);
    } catch {}
  }

  let manifest;
  try {
    manifest = buildManifest({
      version,
      zipPath,
      notes,
      repo: args.repo || 'Derpyu520/qq-bridge-releases',
      tag: args.tag,
      dshMin: args.dshMin,
      dshMax: args.dshMax,
      dataSchema: args.dataSchema,
      minDataSchema: args.minDataSchema,
      releasedAt: args.releasedAt,
      requiresDshRestart: args.requiresDshRestart,
      assetUrl: args.assetUrl
    });
  } catch (error) {
    console.error(`[manifest] 生成失败：${error.message}`);
    return 1;
  }
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
  console.log(`[manifest] 已生成 ${path.relative(ROOT, outPath)}：v${version}（${(manifest.recommended.size / 1024 / 1024).toFixed(2)} MB，sha256 ${manifest.recommended.sha256.slice(0, 12)}…）`);
  console.log('[manifest] 发布时把 zip 与 latest.json 一起上传到 GitHub Release 附件。');
  return 0;
}

const invokedDirectly = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  process.exit(main());
}
