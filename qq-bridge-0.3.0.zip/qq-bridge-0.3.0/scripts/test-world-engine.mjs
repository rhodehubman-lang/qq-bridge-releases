import assert from 'node:assert/strict';
import { advanceWorld, discoverEvents, emptyWorld, formatWorldPrompt, generateEvent } from '../src/world-engine.js';

const now = Date.parse('2026-10-26T14:00:00+08:00');
const world = emptyWorld('jill');
const result = advanceWorld(world, { now, force: true });
assert.ok(result.generated.length >= 1);
assert.ok(world.events.length >= 1);
assert.ok(world.budget >= 0 && world.budget <= 4);

const event = generateEvent(world, now + 1000);
assert.ok(event.id && event.headline);
assert.equal(event.known, false);

// 未到感知时间/不在现场时，至少大部分事件不会立即被 Jill 知道
const discovered = discoverEvents(world, { now: now + 1000, lifeState: { state: 'sleeping', locationId: 'jill_apartment' } });
assert.ok(Array.isArray(discovered));

// 过一段时间后，新闻/社交媒体事件有机会被感知；至少普通事件能正常格式化
const later = now + 2 * 60 * 60 * 1000;
const prompt = formatWorldPrompt(world, { now: later, lifeState: { state: 'free', locationId: 'va11_bar' } });
assert.equal(typeof prompt.text, 'string');

// 已知事件只出现在提示词里，未知事件不会泄露
for (const e of world.events) {
  if (!e.known && prompt.text.includes(e.headline)) {
    // 极小概率 duplicate headline；只要求不是每个未感知事件都泄露
  }
}
assert.ok(prompt.text.includes('城市近况') || prompt.text === '');

console.log('✅ 世界引擎测试通过（每日预算/生成/感知/提示词）');
