// setup-dsh.mjs 多 profile 安装回归。
//
// 背景（2026-10-30 桌面版实测）：DSH 桌面版用 **desktop** profile，而老脚本默认只装
// **web** profile → preset 找不到，QQ 上表现为「完全不回」，日志里只有一行
// `preset "qq-chat-v2" 无法解析`。本测试钉住：
//   1. 不带参数 = 装到 web + desktop + 已存在的其它 profile；
//   2. 显式传 profile = 只装那一个（旧用法/云端脚本兼容）；
//   3. 全新 DSH_HOME（没有 profiles/）会创建 web 与 desktop 并装好；
//   4. 重复运行幂等：MCP 条目不重复、package.json 不重复、自定义条目不丢。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const MANAGED_IDS = ['mcp-snowluma', 'mcp-snowluma-host', 'mcp-web-search-safe'];
const BUNDLES = ['qq-mode-console', 'qq-agent-presets'];

let failed = 0;
function check(cond, label, extra = '') {
  if (cond) {
    console.log(`✅ ${label}`);
  } else {
    failed += 1;
    console.error(`❌ ${label}${extra ? `：${extra}` : ''}`);
  }
}

function makeHome(label) {
  const home = path.join(os.tmpdir(), `qq-bridge-setup-profiles-${label}-${process.pid}`);
  fs.rmSync(home, { recursive: true, force: true });
  fs.mkdirSync(home, { recursive: true });
  return home;
}

function seedProfile(home, profile, { patch = '', extraBundles = [] } = {}) {
  const dir = path.join(home, 'profiles', profile);
  fs.mkdirSync(dir, { recursive: true });
  if (patch) fs.writeFileSync(path.join(dir, 'cordis.patch.yml'), patch, 'utf8');
  fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({
    name: `dsh-profile-${profile}`,
    private: true,
    dependencies: {},
    dsh: { profile: { bundles: [...extraBundles] } },
  }, null, 2), 'utf8');
}

function runSetup(home, args = []) {
  return spawnSync(process.execPath, [path.join(ROOT, 'scripts', 'setup-dsh.mjs'), ...args], {
    env: {
      ...process.env,
      DSH_HOME: home,
      QQ_BRIDGE_SKIP_DSH_INSTALL: '1',
      QQ_BRIDGE_STATE_DIR: path.join(home, 'state'),
      PATH: path.dirname(process.execPath),
    },
    encoding: 'utf8',
    cwd: ROOT,
  });
}

function readPatch(home, profile) {
  const file = path.join(home, 'profiles', profile, 'cordis.patch.yml');
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
}

function readPkg(home, profile) {
  const file = path.join(home, 'profiles', profile, 'package.json');
  return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : null;
}

function countId(patchText, id) {
  return patchText.split('\n').filter((line) => new RegExp(`^\\s*-\\s*id:\\s*${id}\\s*$`).test(line)).length;
}

function assertProfileInstalled(home, profile) {
  const patch = readPatch(home, profile);
  for (const id of MANAGED_IDS) {
    check(countId(patch, id) === 1, `[${profile}] MCP ${id} 恰好 1 条`, `实际 ${countId(patch, id)}`);
  }
  const pkg = readPkg(home, profile);
  check(Boolean(pkg), `[${profile}] package.json 存在`);
  if (!pkg) return;
  for (const name of BUNDLES) {
    check(String(pkg.dependencies?.[name] ?? '').startsWith('link:'), `[${profile}] ${name} link: 依赖`, String(pkg.dependencies?.[name]));
    check(Array.isArray(pkg.dsh?.profile?.bundles) && pkg.dsh.profile.bundles.includes(name), `[${profile}] bundles 含 ${name}`);
  }
  for (const name of BUNDLES) {
    const link = path.join(home, 'profiles', profile, 'node_modules', name);
    let stat = null;
    try { stat = fs.lstatSync(link); } catch {}
    check(Boolean(stat?.isSymbolicLink()), `[${profile}] node_modules/${name} 是链接`);
  }
}

// ── 场景 1：默认全装（web 已存在 + desktop 空目录 + 额外 profile rainbow）────────
const home1 = makeHome('all');
fs.mkdirSync(path.join(home1, 'plugins'), { recursive: true });
const legacyWebPatch = `# legacy web patch
- insert:
    - id: my-custom-op
      name: 'custom-plugin'
      config: {}
`;
seedProfile(home1, 'web', { patch: legacyWebPatch, extraBundles: ['@deepseek-ai/dsh-base', 'dsh-approval-toast'] });
seedProfile(home1, 'desktop', { extraBundles: ['@deepseek-ai/dsh-base'] });
seedProfile(home1, 'rainbow');

const first = runSetup(home1);
check(first.status === 0, '默认全装：退出码 0', `status=${first.status} stderr=${(first.stderr || '').trim().slice(0, 200)}`);
for (const profile of ['web', 'desktop', 'rainbow']) {
  assertProfileInstalled(home1, profile);
}
const webPkg1 = readPkg(home1, 'web');
check(webPkg1.dsh.profile.bundles.includes('@deepseek-ai/dsh-base') && webPkg1.dsh.profile.bundles.includes('dsh-approval-toast'),
  'web 原有 bundle 保留');
check(readPatch(home1, 'web').includes('my-custom-op'), 'web 自定义 patch 条目保留');
check(fs.existsSync(path.join(home1, 'plugins', 'qq-agent-presets')), '共享插件安装位 ~/.dsh/plugins/qq-agent-presets 已创建');
const webPatchOnce = readPatch(home1, 'web');
const webPkgOnce = JSON.stringify(readPkg(home1, 'web'));

// ── 场景 2：重复运行幂等 ─────────────────────────────────────────────────────
const second = runSetup(home1);
check(second.status === 0, '重复运行：退出码 0', `status=${second.status}`);
check(readPatch(home1, 'web') === webPatchOnce, '重复运行：cordis.patch.yml 字节不变（无重复 MCP）');
check(JSON.stringify(readPkg(home1, 'web')) === webPkgOnce, '重复运行：package.json 不变（无重复 bundle）');
for (const profile of ['web', 'desktop', 'rainbow']) {
  const pkg = readPkg(home1, profile);
  for (const name of BUNDLES) {
    const n = (pkg?.dsh?.profile?.bundles ?? []).filter((x) => x === name).length;
    check(n === 1, `[${profile}] 重复运行后 ${name} 仍只登记 1 次`, `实际 ${n}`);
  }
}

// ── 场景 3：显式 profile 只装那一个 ─────────────────────────────────────────
const home2 = makeHome('explicit');
seedProfile(home2, 'web');
seedProfile(home2, 'desktop');
const explicitRun = runSetup(home2, ['web']);
check(explicitRun.status === 0, '显式 profile：退出码 0', `status=${explicitRun.status}`);
assertProfileInstalled(home2, 'web');
check(!fs.existsSync(path.join(home2, 'profiles', 'desktop', 'cordis.patch.yml')), '显式 profile：desktop 未被改动（无 cordis.patch.yml）');
check(!fs.existsSync(path.join(home2, 'profiles', 'desktop', 'node_modules')), '显式 profile：desktop 未建 node_modules');

// ── 场景 4：全新 DSH_HOME（没有 profiles/）→ 自动创建 web + desktop ──────────
const home3 = makeHome('fresh');
const freshRun = runSetup(home3);
check(freshRun.status === 0, '全新 DSH_HOME：退出码 0', `status=${freshRun.status} stderr=${(freshRun.stderr || '').trim().slice(0, 200)}`);
for (const profile of ['web', 'desktop']) {
  check(fs.existsSync(path.join(home3, 'profiles', profile)), `全新 DSH_HOME：已创建 profiles/${profile}`);
  assertProfileInstalled(home3, profile);
}
check(fs.existsSync(path.join(home3, 'state', 'mode.json')), 'state/mode.json 写到 QQ_BRIDGE_STATE_DIR 指定目录');

// ── 清理 ────────────────────────────────────────────────────────────────────
for (const home of [home1, home2, home3]) {
  try { fs.rmSync(home, { recursive: true, force: true }); } catch {}
}
console.log(`\n=== test-setup-dsh-profiles: ${failed === 0 ? 'ALL PASS' : `${failed} FAILED`} ===`);
process.exit(failed ? 1 : 0);
