// 控制台更新接口回归（逻辑层，不启 HTTP 服务）。
import { EventEmitter } from 'node:events';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  detectLauncher,
  handleUpdateApply,
  handleUpdateCheck,
  handleUpdateRollback,
  handleUpdateStatus,
  readUpdateSettings,
  saveUpdateSettings
} from '../src/update-api.js';
import { sha256Hex } from '../src/update-engine.js';
import { readUpdateState } from '../src/update-service.js';

let pass = 0;
let fail = 0;
function check(cond, label, extra = '') {
  if (cond) { pass += 1; console.log(`✅ ${label}`); }
  else { fail += 1; console.error(`❌ ${label}${extra ? `：${extra}` : ''}`); }
}
const tmpRoots = [];
function tempRoot(label) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), `qqb-update-api-${label}-`));
  tmpRoots.push(dir);
  return dir;
}
function writeJson(root, rel, obj) {
  const p = path.join(root, rel);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, `${JSON.stringify(obj, null, 2)}\n`, 'utf8');
}

const zipBuffer = Buffer.from('fake-zip-payload-abcdefghij');
const zipSha = sha256Hex(zipBuffer);
function manifest() {
  const entry = {
    line: '0.3.0', version: '0.3.0-r2', tag: 'v0.3.0-r2',
    asset: 'qq-bridge-0.3.0-r2.zip',
    assetUrl: 'https://example.com/qq-bridge-0.3.0-r2.zip',
    sha256: zipSha, size: zipBuffer.length,
    dshCompat: { min: '0.2.0-rc.2', max: '0.2.1' },
    notes: '## 更新内容\n- 修复', dataSchema: 1, minDataSchema: 1,
    requiresDshRestart: false
  };
  return { schema: 1, updatedAt: '2026-11-02T00:00:00+08:00', recommended: entry, lines: { '0.3.0': entry } };
}
function fakeFetch({ counter = { json: 0, zip: 0 } } = {}) {
  const fn = async (url) => {
    if (String(url).includes('.zip')) {
      counter.zip += 1;
      return { ok: true, status: 200, arrayBuffer: async () => zipBuffer.buffer.slice(zipBuffer.byteOffset, zipBuffer.byteOffset + zipBuffer.byteLength) };
    }
    counter.json += 1;
    return { ok: true, status: 200, text: async () => JSON.stringify(manifest()) };
  };
  fn.counter = counter;
  return fn;
}

// ── 1. 设置读写 ─────────────────────────────────────────────────────────────
const root1 = tempRoot('settings');
writeJson(root1, 'config.json', { ownerQQ: 1, updates: { autoCheck: false } });
const settings1 = readUpdateSettings(root1);
check(settings1.autoCheck === false && settings1.enabled === true, '设置：读取 config.json updates');
const saved = saveUpdateSettings(root1, { enabled: false, checkIntervalHours: 12 });
check(saved.enabled === false && saved.checkIntervalHours === 12, '设置：保存并归一化');
const cfgAfter = JSON.parse(fs.readFileSync(path.join(root1, 'config.json'), 'utf8'));
check(cfgAfter.updates.enabled === false && cfgAfter.ownerQQ === 1, '设置：写回 config.json 且不动其它字段');
check(readUpdateSettings(root1).enabled === false, '设置：重启后读回一致');

// ── 2. 启动器检测 ───────────────────────────────────────────────────────────
const root2 = tempRoot('launcher');
check(detectLauncher(root2) === '启动.cmd', '启动器：缺省 启动.cmd');
fs.writeFileSync(path.join(root2, '启动.cmd'), '@echo off\n', 'utf8');
check(detectLauncher(root2) === '启动.cmd', '启动器：存在 启动.cmd');
const root2b = tempRoot('launcher2');
fs.writeFileSync(path.join(root2b, 'start.bat'), '@echo off\n', 'utf8');
check(detectLauncher(root2b) === 'start.bat', '启动器：回退 start.bat');

// ── 3. status / check ───────────────────────────────────────────────────────
const root3 = tempRoot('check');
writeJson(root3, 'config.json', { updates: {} });
const status = await handleUpdateStatus({ projectRoot: root3, currentVersion: '0.3.0-r1' });
check(status.ok === true && status.currentVersion === '0.3.0-r1' && status.phase === 'idle', 'status：返回版本与状态');
const checkOut = await handleUpdateCheck({ projectRoot: root3, currentVersion: '0.3.0-r1', fetchImpl: fakeFetch() });
check(checkOut.status === 'available' && checkOut.target?.version === '0.3.0-r2', 'check：发现新版本', checkOut.status);
check(checkOut.target?.notes.includes('更新内容'), 'check：返回更新说明');
check(readUpdateState(root3).phase === 'available', 'check：写入 state/update.json');

// ── 4. apply：下载 → 拉起 helper → 计划退出 ─────────────────────────────────
const root4 = tempRoot('apply');
writeJson(root4, 'config.json', { updates: {} });
fs.writeFileSync(path.join(root4, '启动.cmd'), '@echo off\n', 'utf8');
let launched = null;
let exitScheduled = 0;
const applyOut = await handleUpdateApply({
  projectRoot: root4,
  currentVersion: '0.3.0-r1',
  fetchImpl: fakeFetch(),
  launchImpl: (opts) => { launched = opts; return { ok: true, pid: 999 }; },
  scheduleExitImpl: () => { exitScheduled += 1; },
  log: () => {}
});
check(applyOut.ok === true && applyOut.status === 'applying' && applyOut.version === '0.3.0-r2', 'apply：返回 applying', applyOut.error);
check(launched?.toVersion === '0.3.0-r2' && launched?.launcherName === '启动.cmd', 'apply：拉起 helper 参数正确');
check(launched?.zipPath && fs.existsSync(launched.zipPath), 'apply：zip 已下载并校验');
check(launched?.backupBeforeUpdate === true, 'apply：默认要求备份');
check(exitScheduled === 1, 'apply：已安排桥接退出');


const root4c = tempRoot('apply-helper-crash');
writeJson(root4c, 'config.json', { updates: {} });
fs.writeFileSync(path.join(root4c, '启动.cmd'), '@echo off\n', 'utf8');
const crashedChild = new EventEmitter();
let exitWhenCrashed = 0;
const crashPromise = handleUpdateApply({
  projectRoot: root4c,
  currentVersion: '0.3.0-r1',
  fetchImpl: fakeFetch(),
  launchImpl: () => ({ ok: true, pid: 112, child: crashedChild }),
  scheduleExitImpl: () => { exitWhenCrashed += 1; },
  log: () => {}
});
setTimeout(() => crashedChild.emit('error', new Error('spawn EACCES')), 50);
const crashOut = await crashPromise;
check(crashOut.ok === false && /helper 启动失败/.test(crashOut.error || ''), 'apply：helper 启动失败 → 不退出桥接并报错', crashOut.error);
check(exitWhenCrashed === 0, 'apply：helper 启动失败时未安排桥接退出');
check(readUpdateState(root4c).phase === 'failed', 'apply：helper 启动失败写入 failed 状态');

const root5 = tempRoot('apply-uptodate');
writeJson(root5, 'config.json', { updates: {} });
const upOut = await handleUpdateApply({
  projectRoot: root5,
  currentVersion: '0.3.0-r2',
  fetchImpl: fakeFetch(),
  launchImpl: () => { throw new Error('不应拉起 helper'); },
  scheduleExitImpl: () => { throw new Error('不应退出'); },
  log: () => {}
});
check(upOut.ok === true && upOut.status === 'up-to-date', 'apply：已最新时不安装、不退出');

const root6 = tempRoot('apply-disabled');
writeJson(root6, 'config.json', { updates: { enabled: false } });
const disabledOut = await handleUpdateApply({ projectRoot: root6, currentVersion: '0.3.0-r1', fetchImpl: fakeFetch(), log: () => {} });
check(disabledOut.ok === false && /关闭/.test(disabledOut.error), 'apply：更新关闭时拒绝');

// ── 5. rollback ─────────────────────────────────────────────────────────────
const root7 = tempRoot('rollback');
writeJson(root7, 'config.json', { updates: {} });
fs.mkdirSync(path.join(root7, '_backups', 'update', '0.3.0-20260101-000000'), { recursive: true });
let rollbackLaunch = null;
let rollbackExit = 0;
const rb = handleUpdateRollback({
  projectRoot: root7,
  launchImpl: (opts) => { rollbackLaunch = opts; return { ok: true, pid: 7 }; },
  scheduleExitImpl: () => { rollbackExit += 1; },
  log: () => {}
});
check(rb.ok === true && rb.status === 'applying', 'rollback：拉起回滚 helper', rb.error);
check(rollbackLaunch?.rollback === true, 'rollback：helper 收到 rollback 模式');
check(rollbackExit === 1, 'rollback：已安排桥接退出');

const root8 = tempRoot('rollback-empty');
writeJson(root8, 'config.json', { updates: {} });
const rbEmpty = handleUpdateRollback({ projectRoot: root8, launchImpl: () => { throw new Error('不应拉起'); }, scheduleExitImpl: () => {}, log: () => {} });
check(rbEmpty.ok === false && /没有可用/.test(rbEmpty.error), 'rollback：无备份时拒绝');

for (const dir of tmpRoots) fs.rmSync(dir, { recursive: true, force: true });
console.log(`\n=== test-update-api: ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail ? 1 : 0);
