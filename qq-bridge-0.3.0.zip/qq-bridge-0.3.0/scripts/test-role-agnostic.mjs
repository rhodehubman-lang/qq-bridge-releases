// 角色通用性回归（发行阻塞项，2026-10-31 用户实测发现）。
//
// 背景：发行包从开发树继承了私有角色（Jill / VA-11 HALL-A / Glitch City）的默认值，
// 而且世界/事件/故事默认自动生成并写盘——朋友装完什么都没做，就出现了别人的角色和城市。
// 本测试钉住两条铁律：
//   1. 发行代码（src/public/dsh/plugins/migrations）里不得出现具体角色的默认值；
//   2. 世界/事件/故事默认全部关闭，空角色时各系统返回空状态而不报错。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { emptyKnowledge, emptyWorld } from '../src/world-engine.js';
import {
  DEFAULT_WORLD_EVENTS_CONFIG,
  emptyWorldEventsState,
  normalizeWorldEventsConfig
} from '../src/world-events.js';
import { DEFAULT_STORY_STYLE, buildStoryPrompt, emptyStory, normalizeStory } from '../src/story-engine.js';
import { emptyMood, normalizeMood } from '../src/mood-engine.js';
import { emptyRelationshipState, normalizeRelationshipState } from '../src/relationship-engine.js';
import { normalizeLifeProfile } from '../src/life-engine.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0;
let fail = 0;
function check(cond, label, extra = '') {
  if (cond) { pass += 1; console.log(`✅ ${label}`); }
  else { fail += 1; console.error(`❌ ${label}${extra ? `：${extra}` : ''}`); }
}

// ── 1. 发行代码里不得有具体角色默认值 ────────────────────────────────────────
const FORBIDDEN = [
  /'jill'/,
  /Glitch City/,
  /VA-11 HALL-A/,
  /Karmotrine/,
  /White Knight/,
  /jill_apartment/,
  /va11_bar/,
  /white_knight/
];
const SCAN_DIRS = ['src', 'public', 'dsh', 'plugins', 'migrations'];
const SCAN_EXT = new Set(['.js', '.mjs', '.html', '.yml', '.yaml']);
const hits = [];
function scan(dir) {
  let entries = [];
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) { scan(full); continue; }
    if (!SCAN_EXT.has(path.extname(entry.name))) continue;
    let text = '';
    try { text = fs.readFileSync(full, 'utf8'); } catch { continue; }
    for (const rule of FORBIDDEN) {
      if (rule.test(text)) hits.push(`${path.relative(ROOT, full)}: ${rule}`);
    }
  }
}
for (const dir of SCAN_DIRS) scan(path.join(ROOT, dir));
check(hits.length === 0, '发行代码不含具体角色/城市默认值', hits.slice(0, 5).join('；'));

// ── 2. 默认状态：空角色、不自动 ─────────────────────────────────────────────
const world = emptyWorld('');
check(world.profileId === '' && world.auto === false, 'emptyWorld：空角色 + 默认不自动生成');
check(emptyWorld('char-x').profileId === 'char-x', 'emptyWorld：正常保留传入角色 id');
check(emptyKnowledge('').characterId === '', 'emptyKnowledge：空角色不报错');

check(DEFAULT_WORLD_EVENTS_CONFIG.enabled === false, '事件工坊默认关闭');
check(DEFAULT_WORLD_EVENTS_CONFIG.auto === false, '事件工坊默认不自动生成');
const eventsOff = normalizeWorldEventsConfig({});
check(eventsOff.enabled === false && eventsOff.auto === false, '事件配置缺省 = 关闭');
const eventsOn = normalizeWorldEventsConfig({ enabled: true, auto: true });
check(eventsOn.enabled === true && eventsOn.auto === true, '事件配置显式开启才生效');
const emptyEvents = emptyWorldEventsState('');
check(emptyEvents.config.enabled === false && emptyEvents.config.auto === false, '空事件状态默认关闭');

check(DEFAULT_STORY_STYLE.auto === false && DEFAULT_STORY_STYLE.autoApply === false, '故事默认不自动续写/自动应用');
check(DEFAULT_STORY_STYLE.focus === '' && !/Jill|VA-11|Glitch/.test(JSON.stringify(DEFAULT_STORY_STYLE)), '故事默认风格不含私有设定');
check(emptyStory('').profileId === '' && normalizeStory({}, '').profileId === '', '故事空状态不写死角色');

const profile = { id: 'char-x', displayName: '小明', world: { name: '临海市' } };
const prompt = buildStoryPrompt(emptyStory(''), { profile, world: { events: [] } });
check(prompt.includes('临海市') && prompt.includes('小明'), '故事提示词使用角色档案里的城市/称呼');
check(!/Glitch|VA-11|Jill|Karmotrine/.test(prompt), '故事提示词不含私有世界观');
const barePrompt = buildStoryPrompt(emptyStory(''), { profile: null, world: { events: [] } });
check(!/Glitch|VA-11|Jill/.test(barePrompt), '无角色档案时故事提示词也不含私有设定');

// ── 3. 空角色时各系统安全降级 ───────────────────────────────────────────────
let threw = null;
try {
  emptyMood('');
  normalizeMood({}, '');
  emptyRelationshipState('');
  normalizeRelationshipState({}, '');
} catch (error) { threw = error; }
check(threw === null, '心情/关系：空角色安全返回', String(threw));
check(normalizeLifeProfile({ id: 'char-x' }).world.name === '', '生活档案：缺城市名时为空，不硬编码 Glitch City');

// ── 4. 配置模板：无默认角色 ─────────────────────────────────────────────────
const example = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.example.json'), 'utf8'));
check(example.characterId === '', 'config.example：characterId 默认空');
check(example.socialV2?.life?.profile === '', 'config.example：life.profile 默认空');

// ── 5. 全新目录不应出现任何世界/生活/故事状态文件（迁移/初始化不主动建）───────
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'qqb-roleguard-'));
try {
  // 模拟“朋友全新解压”：只有代码，没有 state/ 和 life-profiles/
  const forbiddenDirs = ['state/worlds', 'state/mood', 'state/relationship', 'state/stories'];
  const created = forbiddenDirs.filter((rel) => fs.existsSync(path.join(tmp, rel)));
  check(created.length === 0, '全新目录：世界/心情/关系/故事目录不会被预创建', created.join(', '));
} finally {
  fs.rmSync(tmp, { recursive: true, force: true });
}

console.log(`\n=== test-role-agnostic: ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail ? 1 : 0);
