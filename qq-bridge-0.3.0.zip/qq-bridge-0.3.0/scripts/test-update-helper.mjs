// 更新 helper 真机回归（Windows PowerShell）。
//
// 在临时目录里造一个“旧版本安装 + 新版本 zip”，真的跑 scripts/update-helper.ps1：
//   · 成功路径：备份 → 换代码 → 恢复用户文件 → 迁移 → 启动 → 桥接报告 done
//   · 回滚路径：桥接不报告 done → 恢复旧代码/用户文件 → 状态 rolled-back
// 另外验证 launchUpdateHelper 的参数/环境变量契约。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { launchUpdateHelper } from '../src/update-service.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const IS_WINDOWS = process.platform === 'win32';
const NODE_EXE = process.execPath;
const TAR_EXE = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');

let pass = 0;
let fail = 0;
function check(cond, label, extra = '') {
  if (cond) { pass += 1; console.log(`✅ ${label}`); }
  else { fail += 1; console.error(`❌ ${label}${extra ? `：${extra}` : ''}`); }
}
function writeFile(root, rel, text) {
  const p = path.join(root, rel);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, text, 'utf8');
  return p;
}

// ── launchUpdateHelper 契约 ─────────────────────────────────────────────────
{
  const fixture = fs.mkdtempSync(path.join(os.tmpdir(), 'qqb-helper-args-'));
  try {
    fs.mkdirSync(path.join(fixture, 'scripts'), { recursive: true });
    fs.writeFileSync(path.join(fixture, 'scripts', 'update-helper.ps1'), '# test', 'utf8');
    let captured = null;
    const fakeSpawn = (command, args, options) => {
      captured = { command, args, options };
      return { pid: 4242, unref() {} };
    };
    const result = launchUpdateHelper({
      projectRoot: fixture,
      zipPath: path.join(fixture, 'update.zip'),
      fromVersion: '0.3.0-r1',
      toVersion: '0.3.1',
      launcherName: '启动.cmd',
      backupBeforeUpdate: true,
      healthMs: 5000,
      spawnImpl: fakeSpawn,
      env: { PATH: 'x' }
    });
    check(result.ok === true && result.pid === 4242, 'launchUpdateHelper：返回 pid');
    check(IS_WINDOWS ? /powershell\.exe$/i.test(captured?.command || '') : captured?.command === 'bash', 'launchUpdateHelper：按平台选择解释器（Windows 用绝对路径）');
    check(captured?.options?.detached === true && captured?.options?.stdio === 'ignore', 'launchUpdateHelper：detached + 忽略 stdio');
    check(captured?.options?.windowsHide === false, 'launchUpdateHelper：helper 窗口可见（避免被安全软件拦截隐藏 PowerShell）');
    check(result.child && typeof result.child === 'object', 'launchUpdateHelper：返回 child 供启动稳定性检查');
    check(captured?.options?.env?.QQB_TO_VERSION === '0.3.1' && captured?.options?.env?.QQB_LAUNCHER === '启动.cmd', 'launchUpdateHelper：环境变量契约');
    check(captured?.options?.env?.QQB_BACKUP === '1' && captured?.options?.env?.QQB_HEALTH_MS === '5000', 'launchUpdateHelper：备份/健康参数');
    let rollbackEnv = null;
    const rollbackSpawn = (command, args, options) => {
      rollbackEnv = options.env;
      return { pid: 4343, unref() {} };
    };
    const rollbackLaunch = launchUpdateHelper({ projectRoot: fixture, rollback: true, spawnImpl: rollbackSpawn });
    check(rollbackLaunch.ok === true && rollbackEnv?.QQB_ROLLBACK === '1', 'launchUpdateHelper：回滚模式环境变量');

    const missing = launchUpdateHelper({ projectRoot: path.join(fixture, 'nope'), zipPath: 'x.zip', toVersion: '1' });
    check(missing.ok === false, 'launchUpdateHelper：helper 缺失时报错');
  } finally {
    fs.rmSync(fixture, { recursive: true, force: true });
  }
}

// ── helper 真机跑（仅 Windows）──────────────────────────────────────────────
if (!IS_WINDOWS) {
  console.log('⏭  helper 真机段（非 Windows 跳过）');
} else {
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'qqb-helper-run-'));
  try {
    // 旧版本安装
    const oldRoot = path.join(work, 'app');
    writeFile(oldRoot, 'package.json', JSON.stringify({ name: 'qq-bridge', version: '0.3.0-r1' }, null, 2));
    writeFile(oldRoot, 'src/old-file.js', '// old code\n');
    writeFile(oldRoot, 'README.md', 'OLD README\n');
    writeFile(oldRoot, 'config.json', JSON.stringify({ ownerQQ: 100000001, marker: 'user-config' }));
    writeFile(oldRoot, 'state/sessions.json', JSON.stringify({ marker: 'user-sessions' }));
    writeFile(oldRoot, 'roles/my-role.md', '# my role\n');
    // 迁移脚本 stub：输出 JSON 报告
    writeFile(oldRoot, 'scripts/migrate-data.mjs',
      'process.stdout.write(JSON.stringify({ migrated: [{ file: "state/worlds/w1/truth.json" }], errors: [] }));\n');
    // 假桥接：把 update.json 写成 done，并写 marker
    writeFile(oldRoot, 'fake-bridge.mjs', `
import fs from 'node:fs';
import path from 'node:path';
const stateDir = path.join(process.env.QQB_TEST_ROOT, 'state');
const file = path.join(stateDir, 'update.json');
const state = JSON.parse(fs.readFileSync(file, 'utf8'));
state.phase = 'done';
state.targetVersion = process.env.QQB_TEST_TARGET;
fs.writeFileSync(file, JSON.stringify(state, null, 2));
fs.writeFileSync(path.join(stateDir, 'bridge-started.txt'), 'yes');
`);
    writeFile(oldRoot, 'state/update.json', JSON.stringify({ version: 1, phase: 'ready', currentVersion: '0.3.0-r1', targetVersion: '0.3.1' }));
    // 启动器 stub：调用假桥接
    writeFile(oldRoot, 'launch.cmd', `@echo off\r\nset "QQB_TEST_ROOT=%~dp0"\r\nset "QQB_TEST_TARGET=0.3.1"\r\n"${NODE_EXE}" "%~dp0fake-bridge.mjs"\r\n`);
    // 不报告 done 的启动器（回滚用）
    writeFile(oldRoot, 'launch-silent.cmd', '@echo off\r\nexit /b 0\r\n');

    // 新版本 zip
    const stage = path.join(work, 'stage');
    const newTop = path.join(stage, 'qq-bridge-0.3.1');
    writeFile(newTop, 'package.json', JSON.stringify({ name: 'qq-bridge', version: '0.3.1' }, null, 2));
    writeFile(newTop, 'src/new-file.js', '// new code\n');
    writeFile(newTop, 'README.md', 'NEW README\n');
    writeFile(newTop, 'scripts/migrate-data.mjs',
      'process.stdout.write(JSON.stringify({ migrated: [{ file: "state/worlds/w1/truth.json" }], errors: [] }));\n');
    const zipPath = path.join(work, 'update.zip');
    const tar = spawnSync(TAR_EXE, ['-a', '--options', 'zip:hdrcharset=UTF-8', '-cf', zipPath, '-C', stage, 'qq-bridge-0.3.1'], { encoding: 'utf8' });
    check(tar.status === 0 && fs.existsSync(zipPath), '测试 zip 已生成', tar.stderr);

    function runHelper({ launcher, healthMs }) {
      return spawnSync('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', path.join(ROOT, 'scripts', 'update-helper.ps1')], {
        cwd: oldRoot,
        encoding: 'utf8',
        timeout: 180000,
        env: {
          ...process.env,
          QQB_ROOT: oldRoot,
          QQB_ZIP: zipPath,
          QQB_FROM_VERSION: '0.3.0-r1',
          QQB_TO_VERSION: '0.3.1',
          QQB_LAUNCHER: launcher,
          QQB_BACKUP: '1',
          QQB_NODE_CMD: NODE_EXE,
          QQB_HEALTH_MS: String(healthMs)
        }
      });
    }

    // ── 成功路径 ────────────────────────────────────────────────────────────
    const okRun = runHelper({ launcher: 'launch.cmd', healthMs: 15000 });
    check(okRun.status === 0, 'helper：成功路径退出码 0', `${okRun.status} ${(okRun.stderr || '').slice(-300)}`);
    check(fs.existsSync(path.join(oldRoot, 'src', 'new-file.js')), 'helper：新代码已替换');
    check(fs.existsSync(path.join(oldRoot, 'src', 'old-file.js')), 'helper：旧文件按“只覆盖不删除”保留（设计如此）');
    check(fs.readFileSync(path.join(oldRoot, 'README.md'), 'utf8').includes('NEW README'), 'helper：根文件已更新');
    check(JSON.parse(fs.readFileSync(path.join(oldRoot, 'config.json'), 'utf8')).marker === 'user-config', 'helper：config.json 从备份恢复');
    check(JSON.parse(fs.readFileSync(path.join(oldRoot, 'state', 'sessions.json'), 'utf8')).marker === 'user-sessions', 'helper：state 用户数据保留');
    check(fs.existsSync(path.join(oldRoot, 'roles', 'my-role.md')), 'helper：用户角色卡保留');
    const doneState = JSON.parse(fs.readFileSync(path.join(oldRoot, 'state', 'update.json'), 'utf8'));
    check(doneState.phase === 'done', 'helper：桥接报告后状态 done', doneState.phase);
    check(fs.existsSync(path.join(oldRoot, 'state', 'bridge-started.txt')), 'helper：启动器已拉起桥接');
    const result = JSON.parse(fs.readFileSync(path.join(oldRoot, 'state', 'update-result.json'), 'utf8'));
    check(result.toVersion === '0.3.1' && result.migratedFiles.includes('state/worlds/w1/truth.json'), 'helper：结果文件记录迁移');
    const backupDirs = fs.existsSync(path.join(oldRoot, '_backups', 'update')) ? fs.readdirSync(path.join(oldRoot, '_backups', 'update')) : [];
    check(backupDirs.length === 1, 'helper：创建了完整备份');
    check(fs.existsSync(path.join(oldRoot, '_backups', 'update', backupDirs[0], 'src', 'old-file.js')), 'helper：备份里有旧代码');
    const stampMatch = /-(\d{8}-\d{6})$/.exec(backupDirs[0] || '');
    const tmpLeft = stampMatch ? path.join(oldRoot, '_update_tmp_' + stampMatch[1]) : '';
    check(!tmpLeft || !fs.existsSync(tmpLeft), 'helper：临时目录已清理', tmpLeft);

    // ── 回滚路径：重置旧代码后，用一个不报告 done 的启动器 ─────────────────
    fs.rmSync(path.join(oldRoot, 'src'), { recursive: true, force: true });
    writeFile(oldRoot, 'src/old-file.js', '// old code again\n');
    writeFile(oldRoot, 'package.json', JSON.stringify({ name: 'qq-bridge', version: '0.3.0-r1' }, null, 2));
    writeFile(oldRoot, 'state/update.json', JSON.stringify({ version: 1, phase: 'ready', currentVersion: '0.3.0-r1', targetVersion: '0.3.1' }));
    const failRun = runHelper({ launcher: 'launch-silent.cmd', healthMs: 4000 });
    check(failRun.status === 2, 'helper：回滚路径退出码 2', `${failRun.status} ${(failRun.stderr || '').slice(-200)}`);
    const rolled = JSON.parse(fs.readFileSync(path.join(oldRoot, 'state', 'update.json'), 'utf8'));
    check(rolled.phase === 'rolled-back', 'helper：状态 rolled-back', rolled.phase);
    check(fs.existsSync(path.join(oldRoot, 'src', 'old-file.js')), 'helper：回滚恢复旧代码');
    check(!fs.existsSync(path.join(oldRoot, 'src', 'new-file.js')), 'helper：回滚后新代码被移除');
    check(JSON.parse(fs.readFileSync(path.join(oldRoot, 'package.json'), 'utf8')).version === '0.3.0-r1', 'helper：回滚恢复旧 package.json');
  } finally {
    try {
      await new Promise((r) => setTimeout(r, 800));
      fs.rmSync(work, { recursive: true, force: true, maxRetries: 5, retryDelay: 300 });
    } catch { /* Windows 上偶发句柄占用，清理失败不影响断言结果 */ }
  }
}

console.log(`\n=== test-update-helper: ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail ? 1 : 0);
