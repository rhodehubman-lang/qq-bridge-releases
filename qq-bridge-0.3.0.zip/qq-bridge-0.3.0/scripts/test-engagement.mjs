import assert from 'node:assert/strict';
import {
  emptyEngagementState,
  normalizeEngagementState,
  getEngagementEntry,
  noteJillMessage,
  observeIncoming,
  shouldSuppressEngagementWake,
  formatEngagementPrompt,
  resetEngagementEntry,
  engagementSettingsFor,
  setEngagementSettings,
  resetCharacterEngagement
} from '../src/engagement.js';

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`ok ${passed} - ${name}`);
  } catch (error) {
    console.error(`not ok - ${name}`);
    throw error;
  }
}

test('短回复在主人私聊里累计降温，连续两次进入收住', () => {
  const state = emptyEngagementState();
  const now = Date.now();
  noteJillMessage(state, { characterId: 'Jill', key: 'private:1', now });
  let entry = observeIncoming(state, {
    characterId: 'Jill', key: 'private:1', kind: 'private', isOwner: true,
    text: '嗯', now: now + 1000
  });
  assert.equal(entry.level, 'cooling');
  noteJillMessage(state, { characterId: 'Jill', key: 'private:1', now: now + 2000 });
  entry = observeIncoming(state, {
    characterId: 'Jill', key: 'private:1', kind: 'private', isOwner: true,
    text: '哦', now: now + 3000
  });
  assert.equal(entry.level, 'stop');
  assert.equal(entry.score >= 2, true);
});

test('群聊里没有点到 Jill 的闲聊不记为冷场', () => {
  const state = emptyEngagementState();
  const now = Date.now();
  noteJillMessage(state, { characterId: 'Jill', key: 'group:1', now });
  const entry = observeIncoming(state, {
    characterId: 'Jill', key: 'group:1', kind: 'group', isOwner: false,
    addressedToSelf: false, text: '嗯', now: now + 1000
  });
  assert.equal(entry.level, 'normal');
  assert.equal(entry.score, 0);
});

test('群里被点到后的短回复会计入冷场', () => {
  const state = emptyEngagementState();
  const now = Date.now();
  noteJillMessage(state, { characterId: 'Jill', key: 'group:1', now });
  const entry = observeIncoming(state, {
    characterId: 'Jill', key: 'group:1', kind: 'group', isOwner: false,
    addressedToSelf: true, text: '行', now: now + 1000
  });
  assert.equal(entry.level, 'cooling');
});

test('明确拒绝会直接进入 stop', () => {
  const state = emptyEngagementState();
  const now = Date.now();
  noteJillMessage(state, { characterId: 'Jill', key: 'private:1', now });
  const entry = observeIncoming(state, {
    characterId: 'Jill', key: 'private:1', kind: 'private', isOwner: true,
    text: '别说了，我不想聊这个', now: now + 1000
  });
  assert.equal(entry.level, 'stop');
});

test('热情回复会清零', () => {
  const state = emptyEngagementState();
  const now = Date.now();
  noteJillMessage(state, { characterId: 'Jill', key: 'private:1', now });
  observeIncoming(state, {
    characterId: 'Jill', key: 'private:1', kind: 'private', isOwner: true,
    text: '嗯', now: now + 1000
  });
  const entry = observeIncoming(state, {
    characterId: 'Jill', key: 'private:1', kind: 'private', isOwner: true,
    text: '哈哈这个有意思，展开说说？', now: now + 2000
  });
  assert.equal(entry.level, 'normal');
  assert.equal(entry.score, 0);
});

test('收住状态只拦截非直接唤醒', () => {
  const state = emptyEngagementState();
  const now = Date.now();
  noteJillMessage(state, { characterId: 'Jill', key: 'private:1', now });
  observeIncoming(state, {
    characterId: 'Jill', key: 'private:1', kind: 'private', isOwner: true,
    text: '别说了', now: now + 1000
  });
  const entry = getEngagementEntry(state, { characterId: 'Jill', key: 'private:1' });
  assert.equal(entry.level, 'stop');
  assert.equal(shouldSuppressEngagementWake(entry, 'anyMessage'), true);
  assert.equal(shouldSuppressEngagementWake(entry, 'proactiveCheck'), true);
  assert.equal(shouldSuppressEngagementWake(entry, 'atMention'), false);
  assert.equal(shouldSuppressEngagementWake(entry, 'private', { isOwner: true }), false);
});

test('不同角色、不同会话互不影响', () => {
  const state = emptyEngagementState();
  const now = Date.now();
  noteJillMessage(state, { characterId: 'Jill', key: 'group:1', now });
  observeIncoming(state, {
    characterId: 'Jill', key: 'group:1', kind: 'group', addressedToSelf: true,
    text: '别说了', now: now + 1000
  });
  const otherRole = getEngagementEntry(state, { characterId: '示例群友', key: 'group:1' });
  const otherGroup = getEngagementEntry(state, { characterId: 'Jill', key: 'group:2' });
  assert.equal(otherRole.level, 'normal');
  assert.equal(otherGroup.level, 'normal');
});

test('状态归一化保留角色与会话，坏数据被丢弃', () => {
  const state = normalizeEngagementState({
    settings: { groupStopScore: 99 },
    characters: {
      Jill: { 'group:1': { score: '4', level: 'stop', key: 'group:1' }, '': {} },
      '': { 'group:1': {} }
    }
  });
  assert.equal(state.settings.groupStopScore, 8);
  assert.equal(state.characters.Jill['group:1'].score, 4);
  assert.equal(Boolean(state.characters['']), false);
});

test('提示词只给分寸，不暴露系统判断', () => {
  const stop = formatEngagementPrompt({ level: 'stop' }, { kind: 'group' });
  const cooling = formatEngagementPrompt({ level: 'cooling' }, { kind: 'private' });
  assert.match(stop, /聊天的分寸/);
  assert.match(stop, /不要再追问/);
  assert.doesNotMatch(stop, /冷场|系统判断/);
  assert.match(cooling, /最多轻轻接一句/);
});

test('reset 能清掉指定会话', () => {
  const state = emptyEngagementState();
  noteJillMessage(state, { characterId: 'Jill', key: 'group:1' });
  assert.equal(resetEngagementEntry(state, { characterId: 'Jill', key: 'group:1' }), true);
  assert.equal(getEngagementEntry(state, { characterId: 'Jill', key: 'group:1' }).score, 0);
});

test('角色阈值覆盖全局，且只影响当前角色', () => {
  const state = emptyEngagementState();
  setEngagementSettings(state, {
    characterId: 'Jill',
    patch: { privateStopScore: 4, decayMs: 60 * 60 * 1000 }
  });
  assert.equal(engagementSettingsFor(state, 'Jill').privateStopScore, 4);
  assert.equal(engagementSettingsFor(state, '示例群友').privateStopScore, 2);

  const now = Date.now();
  noteJillMessage(state, { characterId: 'Jill', key: 'private:1', now });
  let entry = null;
  for (let i = 0; i < 3; i += 1) {
    noteJillMessage(state, { characterId: 'Jill', key: 'private:1', now: now + 1000 + i * 1000 });
    entry = observeIncoming(state, {
      characterId: 'Jill', key: 'private:1', kind: 'private', isOwner: true,
      text: '嗯', now: now + 1500 + i * 1000
    });
  }
  assert.equal(entry.level, 'cooling');
  assert.equal(engagementSettingsFor(state, '示例群友').enabled, true);
});

test('恢复全局默认后会按新阈值重算已有状态', () => {
  const state = emptyEngagementState();
  setEngagementSettings(state, { characterId: 'Jill', patch: { privateStopScore: 8 } });
  const now = Date.now();
  noteJillMessage(state, { characterId: 'Jill', key: 'private:1', now });
  for (let i = 0; i < 2; i += 1) {
    noteJillMessage(state, { characterId: 'Jill', key: 'private:1', now: now + 1000 + i * 1000 });
    observeIncoming(state, {
      characterId: 'Jill', key: 'private:1', kind: 'private', isOwner: true,
      text: '嗯', now: now + 1500 + i * 1000
    });
  }
  assert.equal(getEngagementEntry(state, { characterId: 'Jill', key: 'private:1' }).level, 'cooling');
  setEngagementSettings(state, { characterId: 'Jill', reset: true });
  assert.equal(getEngagementEntry(state, { characterId: 'Jill', key: 'private:1' }).level, 'stop');
});

test('清空当前角色状态不会删除别的角色', () => {
  const state = emptyEngagementState();
  noteJillMessage(state, { characterId: 'Jill', key: 'group:1' });
  noteJillMessage(state, { characterId: '示例群友', key: 'group:1' });
  const count = resetCharacterEngagement(state, { characterId: 'Jill' });
  assert.equal(count, 1);
  assert.equal(getEngagementEntry(state, { characterId: 'Jill', key: 'group:1' }).score, 0);
  assert.equal(getEngagementEntry(state, { characterId: '示例群友', key: 'group:1' }).lastAiAt > 0, true);
});

console.log(`\n${passed} tests passed`);
