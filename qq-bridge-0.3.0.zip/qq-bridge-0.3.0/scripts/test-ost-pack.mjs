import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { formatOstPrompt, loadOstPack, normalizeOstPack, ostFilePath } from '../src/ost-pack.js';

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`ok ${passed} - ${name}`);
  } catch (error) {
    console.error(`not ok ${passed + 1} - ${name}`);
    throw error;
  }
}

test('normalizes tracks and drops empty titles', () => {
  const pack = normalizeOstPack({
    title: '  Test Pack  ',
    tracks: [
      { title: '  Last Call  ', mood: ' late ', memory: ' 关店前 ' },
      { title: '' },
      null
    ]
  }, 'Jill');
  assert.equal(pack.title, 'Test Pack');
  assert.equal(pack.tracks.length, 1);
  assert.equal(pack.tracks[0].title, 'Last Call');
  assert.equal(pack.tracks[0].memory, '关店前');
});

test('prompt contains memories but not a playlist command', () => {
  const pack = normalizeOstPack({ title: 'VA-11', tracks: [
    { title: 'Every Day Is Night', memory: '下班路上' },
    { title: 'Last Call', memory: '关店前' }
  ] }, 'Jill');
  const prompt = formatOstPrompt(pack, { maxChars: 1000, maxTracks: 1 });
  assert.match(prompt, /音乐记忆/);
  assert.match(prompt, /Every Day Is Night/);
  assert.match(prompt, /下班路上/);
  assert.doesNotMatch(prompt, /Last Call/);
  assert.match(prompt, /不要一次背曲目表/);
});

test('loads only the requested role file', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ost-pack-'));
  try {
    fs.writeFileSync(ostFilePath(dir, 'Jill'), JSON.stringify({ title: 'Jill Music', tracks: [{ title: 'Snowfall' }] }));
    fs.writeFileSync(ostFilePath(dir, 'Other'), JSON.stringify({ title: 'Other Music', tracks: [{ title: 'Wrong Song' }] }));
    const jill = loadOstPack(dir, 'Jill');
    const missing = loadOstPack(dir, 'Nobody');
    assert.equal(jill.title, 'Jill Music');
    assert.equal(jill.tracks[0].title, 'Snowfall');
    assert.equal(missing, null);
    assert.doesNotMatch(formatOstPrompt(jill), /Wrong Song/);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

console.log(`✅ OST 记忆包测试通过（${passed} 项）`);
