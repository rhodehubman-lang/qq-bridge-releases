// 桌面版 DSH 端口自动发现回归（纯函数 + 注入式发现流程；不碰真实网络/真实进程）。
//
// 背景：DSH 桌面版每次启动随机换端口（实测 60186 / 59626 / 52984），
// 桥接配置写死必然失效。本测试钉住：
//   1) netstat / tasklist / ss / ps 输出解析；
//   2) DSH 探测指纹（401 + "dsh web authentication required"）；
//   3) 解析优先级：显式配置 → 缓存 → 扫描；
//   4) 缓存读写与损坏容错；
//   5) 写回 config.json 只改 dsh.baseUrl、保留 BOM、幂等。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  DSH_AUTH_MARKER,
  DSH_PORT_CACHE_VERSION,
  isLikelyDshProcessName,
  normalizeDshBaseUrl,
  parseNetstatListeners,
  parsePsNames,
  parseSsListeners,
  parseTasklistCsv,
  persistDshBaseUrl,
  pickCandidatePorts,
  probeDshBaseUrl,
  readDshPortCache,
  resolveDshBaseUrl,
  writeDshPortCache
} from '../src/dsh-port.js';

let pass = 0;
let fail = 0;
function assert(cond, label) {
  if (cond) { pass += 1; console.log(`✅ ${label}`); }
  else { fail += 1; console.error(`❌ ${label}`); }
}

// ── 1. baseUrl 归一化 ────────────────────────────────────────────────────────
assert(normalizeDshBaseUrl('59626') === 'http://127.0.0.1:59626', '纯端口 → http://127.0.0.1:port');
assert(normalizeDshBaseUrl('127.0.0.1:59626') === 'http://127.0.0.1:59626', '裸 host:port 补 scheme');
assert(normalizeDshBaseUrl('http://127.0.0.1:59626/') === 'http://127.0.0.1:59626', '去掉尾斜杠');
assert(normalizeDshBaseUrl('http://127.0.0.1:3080') === 'http://127.0.0.1:3080', '标准地址原样');
assert(normalizeDshBaseUrl('') === '' && normalizeDshBaseUrl(null) === '', '空输入返回空串');
assert(normalizeDshBaseUrl('not a url') === '', '非法输入返回空串');

// ── 2. Windows netstat 解析 ─────────────────────────────────────────────────
const netstatFixture = [
  '',
  '活动连接',
  '',
  '  协议  本地地址          外部地址        状态           PID',
  '  TCP    127.0.0.1:59626        0.0.0.0:0              LISTENING       6864',
  '  TCP    127.0.0.1:3080         0.0.0.0:0              LISTENING       44764',
  '  TCP    [::1]:60186            [::]:0                 LISTENING       9000',
  '  TCP    127.0.0.1:59626        127.0.0.1:51234        ESTABLISHED     6864',
  '  UDP    127.0.0.1:1900         *:*                                    1234',
  '  TCP    0.0.0.0:135            0.0.0.0:0              LISTENING       1000',
  ''
].join('\r\n');
const listeners = parseNetstatListeners(netstatFixture);
assert(listeners.length === 4, `netstat：只保留 TCP LISTENING（实际 ${listeners.length} 条）`);
assert(listeners.some((x) => x.port === 59626 && x.pid === 6864), 'netstat：解析 IPv4 端口与 PID');
assert(listeners.some((x) => x.port === 60186 && x.pid === 9000), 'netstat：解析 IPv6 [::1] 端口');
assert(!listeners.some((x) => x.port === 59626 && x.pid === 6864 && x.address === '127.0.0.1:51234'), 'netstat：ESTABLISHED 行不被当作监听');
assert(!listeners.some((x) => x.port === 1900), 'netstat：UDP 行跳过');

// ── 3. tasklist CSV 解析 ────────────────────────────────────────────────────
const tasklistFixture = [
  '"DeepSeek Harness.exe","6864","Console","1","223,884 K"',
  '"node.exe","9808","Console","1","35,168 K"',
  '"electron.exe","9000","Console","1","110,276 K"',
  ''
].join('\r\n');
const pidNames = parseTasklistCsv(tasklistFixture);
assert(pidNames.get(6864) === 'DeepSeek Harness.exe', 'tasklist：解析进程名');
assert(pidNames.get(9808) === 'node.exe', 'tasklist：解析 node 进程');
assert(pidNames.size === 3, 'tasklist：解析全部行（内存列含逗号不破坏字段）');

// ── 4. Linux ss / ps 解析 ───────────────────────────────────────────────────
const ssFixture = [
  'State  Recv-Q Send-Q Local Address:Port  Peer Address:Port Process',
  'LISTEN 0      4096   127.0.0.1:59626       0.0.0.0:*     users:(("node",pid=1234,fd=21))',
  'LISTEN 0      128    [::1]:3080            [::]:*        users:(("dsh",pid=5678,fd=9))',
  'ESTAB 0      0       127.0.0.1:59626       127.0.0.1:4321',
  ''
].join('\n');
const ssListeners = parseSsListeners(ssFixture);
assert(ssListeners.length === 2, `ss：只保留 LISTEN（实际 ${ssListeners.length} 条）`);
assert(ssListeners.some((x) => x.port === 59626 && x.pid === 1234), 'ss：解析端口与 pid');
assert(ssListeners.some((x) => x.port === 3080 && x.pid === 5678), 'ss：解析 IPv6 监听');

const psFixture = ['  1234 node', '  5678 dsh', '  9999 chrome', ''].join('\n');
const psNames = parsePsNames(psFixture);
assert(psNames.get(1234) === 'node' && psNames.get(5678) === 'dsh', 'ps：解析 pid 与进程名');

// ── 5. 进程名判定 ───────────────────────────────────────────────────────────
assert(isLikelyDshProcessName('DeepSeek Harness.exe'), '进程名：DeepSeek Harness.exe 命中');
assert(isLikelyDshProcessName('deepseek-harness'), '进程名：deepseek-harness 命中');
assert(isLikelyDshProcessName('dsh-desktop'), '进程名：dsh-desktop 命中');
assert(isLikelyDshProcessName('dsh.exe'), '进程名：dsh.exe 命中');
// Helper 进程仍属 DSH 家族：这里只是「候选排序提示」，判宽一点更安全（真正的判定靠 HTTP 指纹）。
assert(isLikelyDshProcessName('DeepSeek Harness Helper'), '进程名：Helper 进程算 DSH 相关（仅排序提示）');
assert(!isLikelyDshProcessName('node.exe'), '进程名：node.exe 不命中');
assert(!isLikelyDshProcessName('DeepSeek Chat.exe'), '进程名：无关名字不误判');

// ── 6. 候选排序 ─────────────────────────────────────────────────────────────
const ordered = pickCandidatePorts(
  [
    { port: 3100, pid: 9808 },
    { port: 59626, pid: 6864 },
    { port: 135, pid: 1000 },
    { port: 59626, pid: 6865 }, // 重复端口
    { port: 5099, pid: 10264 }
  ],
  new Map([[6864, 'DeepSeek Harness.exe'], [9808, 'node.exe'], [1000, 'svchost.exe'], [10264, 'SnowLuma.exe']])
);
assert(ordered[0] === 59626, '排序：DSH 进程的端口排最前');
assert(ordered.length === 4, '排序：端口去重');
assert(ordered[ordered.length - 1] === 135, '排序：低端口垫底');

// ── 7. HTTP 探测指纹 ────────────────────────────────────────────────────────
function fakeFetchFactory({ markerPorts = [], status = 401 } = {}) {
  return async (url) => {
    const port = Number(/:(\d+)\//.exec(url)?.[1] || 0);
    const isMarker = markerPorts.includes(port);
    return {
      status: isMarker ? status : 200,
      text: async () => (isMarker ? `${DSH_AUTH_MARKER}; reopen the URL printed by dsh web.` : '<html>not dsh</html>')
    };
  };
}
const probeHit = await probeDshBaseUrl('http://127.0.0.1:59626', { fetchImpl: fakeFetchFactory({ markerPorts: [59626] }) });
assert(probeHit.ok === true && probeHit.status === 401, '探测：401 + 固定文案 → 判定为 DSH');
const probeMiss = await probeDshBaseUrl('http://127.0.0.1:5099', { fetchImpl: fakeFetchFactory({ markerPorts: [59626] }) });
assert(probeMiss.ok === false, '探测：普通网页 → 不是 DSH');
const probeThrow = await probeDshBaseUrl('http://127.0.0.1:59626', { fetchImpl: async () => { throw new Error('ECONNREFUSED'); } });
assert(probeThrow.ok === false && /ECONNREFUSED/.test(probeThrow.error), '探测：连接失败被吞成 ok:false');

// ── 8. 缓存读写与容错 ───────────────────────────────────────────────────────
const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-port-test-'));
const stateDir = path.join(tmpRoot, 'state');
writeDshPortCache(stateDir, { baseUrl: 'http://127.0.0.1:59626', source: 'discover' });
const cached = readDshPortCache(stateDir);
assert(cached && cached.baseUrl === 'http://127.0.0.1:59626' && cached.port === 59626, '缓存：写入后可读');
fs.writeFileSync(path.join(stateDir, 'dsh-port.json'), '{broken json', 'utf8');
assert(readDshPortCache(stateDir) === null, '缓存：损坏文件返回 null 而不是抛错');
fs.writeFileSync(path.join(stateDir, 'dsh-port.json'), JSON.stringify({ version: 999, baseUrl: 'http://127.0.0.1:1' }), 'utf8');
assert(readDshPortCache(stateDir) === null, '缓存：版本不符返回 null');

// ── 9. 解析优先级（config → cache → discover）────────────────────────────────
const execWin = async (command) => {
  if (command === 'netstat') return netstatFixture;
  if (command === 'tasklist') return tasklistFixture;
  return '';
};
const marker59626 = fakeFetchFactory({ markerPorts: [59626] });

// 9.1 显式配置可用：不扫描
let execCalls = 0;
const execSpy = async (command, args, opts) => { execCalls += 1; return execWin(command, args, opts); };
const rConfig = await resolveDshBaseUrl({
  configured: 'http://127.0.0.1:59626',
  stateDir: '',
  platform: 'win32',
  exec: execSpy,
  fetchImpl: marker59626
});
assert(rConfig.source === 'config' && rConfig.baseUrl === 'http://127.0.0.1:59626', '优先级：显式配置可用 → 不扫描');
assert(execCalls === 0, '优先级：配置命中时零进程调用');

// 9.2 配置失效 + 缓存可用
writeDshPortCache(path.join(tmpRoot, 'state2'), { baseUrl: 'http://127.0.0.1:59626' });
const rCache = await resolveDshBaseUrl({
  configured: 'http://127.0.0.1:3080',
  stateDir: path.join(tmpRoot, 'state2'),
  platform: 'win32',
  exec: execSpy,
  fetchImpl: marker59626
});
assert(rCache.source === 'cache' && rCache.baseUrl === 'http://127.0.0.1:59626', '优先级：配置失效 → 用缓存');

// 9.3 配置/缓存都失效 → 扫描命中并写缓存
const rDiscover = await resolveDshBaseUrl({
  configured: 'http://127.0.0.1:3080',
  stateDir: path.join(tmpRoot, 'state3'),
  platform: 'win32',
  exec: execWin,
  fetchImpl: fakeFetchFactory({ markerPorts: [59626] })
});
assert(rDiscover.source === 'discover' && rDiscover.baseUrl === 'http://127.0.0.1:59626', '优先级：都失效 → 扫描命中');
assert(readDshPortCache(path.join(tmpRoot, 'state3'))?.baseUrl === 'http://127.0.0.1:59626', '发现：命中后写入缓存');

// 9.4 扫描不到 → 明确失败原因
const rNone = await resolveDshBaseUrl({
  configured: 'http://127.0.0.1:3080',
  stateDir: path.join(tmpRoot, 'state4'),
  platform: 'win32',
  exec: execWin,
  fetchImpl: fakeFetchFactory({ markerPorts: [] }),
  totalTimeoutMs: 3000
});
assert(rNone.baseUrl === '' && rNone.source === 'none' && rNone.reason, '失败：返回空地址 + reason（不静默）');

// ── 10. 写回 config.json ────────────────────────────────────────────────────
const cfgPath = path.join(tmpRoot, 'config.json');
const original = {
  dsh: { baseUrl: 'http://127.0.0.1:3080', model: 'deepseek-flash' },
  snowluma: { accessToken: 'keep-me' },
  ownerQQ: 100000001
};
fs.writeFileSync(cfgPath, JSON.stringify(original, null, 2), 'utf8');
const w1 = persistDshBaseUrl(cfgPath, 'http://127.0.0.1:59626');
const after1 = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
assert(w1.updated === true && after1.dsh.baseUrl === 'http://127.0.0.1:59626', '写回：更新 dsh.baseUrl');
assert(after1.dsh.model === 'deepseek-flash' && after1.snowluma.accessToken === 'keep-me' && after1.ownerQQ === 100000001, '写回：其它字段原样保留');
const w2 = persistDshBaseUrl(cfgPath, 'http://127.0.0.1:59626');
assert(w2.updated === false, '写回：同值幂等不写盘');

// BOM 保留
const bomPath = path.join(tmpRoot, 'config-bom.json');
fs.writeFileSync(bomPath, `\uFEFF${JSON.stringify(original, null, 2)}`, 'utf8');
persistDshBaseUrl(bomPath, 'http://127.0.0.1:60000');
const bomText = fs.readFileSync(bomPath, 'utf8');
assert(bomText.charCodeAt(0) === 0xFEFF, '写回：保留 UTF-8 BOM');
assert(JSON.parse(bomText.replace(/^\uFEFF/, '')).dsh.baseUrl === 'http://127.0.0.1:60000', '写回：BOM 文件仍可解析');

// 非法地址拒绝
let threw = false;
try { persistDshBaseUrl(cfgPath, 'not a url'); } catch { threw = true; }
assert(threw, '写回：非法地址抛错（不写坏配置）');

// ── 收尾 ────────────────────────────────────────────────────────────────────
fs.rmSync(tmpRoot, { recursive: true, force: true });
console.log(`\n=== test-dsh-port: ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail ? 1 : 0);
