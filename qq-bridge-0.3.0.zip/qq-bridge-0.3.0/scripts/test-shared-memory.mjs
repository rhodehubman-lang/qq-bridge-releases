// 跨会话共享记忆（shared-memory-store）单元测试。
// 运行：node scripts/test-shared-memory.mjs
import assert from 'node:assert/strict';
import {
  SHARED_MEMORY_VERSION,
  appendSharedMemory,
  compressSharedMemory,
  emptySharedMemory,
  forgetSharedMemory,
  formatSharedMemoryForPrompt,
  normalizeSharedMemory,
  parseSessionKey,
  pruneSharedMemory,
  querySharedMemory,
  rankMemoryEntries,
  summarizeSharedMemory,
  tokenizeForSearch
} from '../src/core/shared-memory-store.js';

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`✅ ${name}`);
  } catch (error) {
    console.error(`❌ ${name}`);
    console.error(error);
    process.exitCode = 1;
  }
}

test('emptySharedMemory 结构正确', () => {
  const state = emptySharedMemory();
  assert.equal(state.version, SHARED_MEMORY_VERSION);
  assert.deepEqual(state.entries, []);
});

test('normalizeSharedMemory 丢弃坏条目', () => {
  const state = normalizeSharedMemory({
    version: 1,
    entries: [
      { scope: 'global', content: '全局事实' },
      { scope: 'user', scopeId: '123', content: '用户事实', visibility: 'public' },
      { scope: 'group', scopeId: '456', content: '群事实' },
      { scope: 'bad', content: 'x' },
      { scope: 'user', scopeId: 'abc', content: 'x' },
      { scope: 'global', content: '' },
      null
    ]
  });
  assert.equal(state.entries.length, 3);
  assert.equal(state.entries[0].scope, 'global');
  assert.equal(state.entries[1].visibility, 'public');
  assert.equal(state.entries[2].scopeId, '456');
});

test('parseSessionKey 规范化并拒绝坏 key', () => {
  assert.deepEqual(parseSessionKey('group:00123'), {
    key: 'group:123', kind: 'group', id: '123', groupId: '123', uin: ''
  });
  assert.deepEqual(parseSessionKey('private:456'), {
    key: 'private:456', kind: 'private', id: '456', groupId: '', uin: '456'
  });
  assert.equal(parseSessionKey('group:abc'), null);
  assert.equal(parseSessionKey('room:1'), null);
  assert.equal(parseSessionKey(''), null);
});

test('appendSharedMemory 三层都能写入，并去重', () => {
  const state = emptySharedMemory();
  const g = appendSharedMemory(state, { scope: 'global', content: 'Jill 是调酒师' });
  assert.equal(g.ok, true);
  assert.equal(state.entries.length, 1);
  const dup = appendSharedMemory(state, { scope: 'global', content: '  Jill  是调酒师 ' });
  assert.equal(dup.ok, true);
  assert.equal(dup.deduped, true);
  assert.equal(state.entries.length, 1);
  const u = appendSharedMemory(state, {
    scope: 'user', scopeId: '345', subjectName: '示例主人', content: '示例主人 喜欢甜酒', visibility: 'public'
  });
  assert.equal(u.ok, true);
  const grp = appendSharedMemory(state, { scope: 'group', scopeId: '987654321', content: '示例群二周末开黑' });
  assert.equal(grp.ok, true);
  const bad = appendSharedMemory(state, { scope: 'user', content: '缺 scopeId' });
  assert.equal(bad.ok, false);
});

test('appendSharedMemory 截断超长内容，并保留重要性', () => {
  const state = emptySharedMemory();
  const long = '字'.repeat(500);
  const r = appendSharedMemory(state, { scope: 'global', content: long, importance: 9, tags: ['a', 'b', 'a'] }, { entryMaxChars: 50 });
  assert.equal(r.ok, true);
  assert.equal(state.entries[0].content.length, 50);
  assert.equal(state.entries[0].importance, 5);
  assert.deepEqual(state.entries[0].tags, ['a', 'b']);
});

test('querySharedMemory 按 scope / 关键词过滤', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'global', content: 'Jill 爱喝啤酒' });
  appendSharedMemory(state, { scope: 'user', scopeId: '345', content: '示例主人 喜欢甜酒' });
  appendSharedMemory(state, { scope: 'group', scopeId: '894', content: '群里聊过 Minecraft' });
  assert.equal(querySharedMemory(state, { scope: 'global' }).length, 1);
  assert.equal(querySharedMemory(state, { scopes: [{ scope: 'user', scopeId: '345' }] }).length, 1);
  appendSharedMemory(state, { scope: 'user', scopeId: '888', content: '别人的公开事实', visibility: 'public' });
  assert.equal(querySharedMemory(state, { scopes: [{ scope: 'user', scopeId: '345' }], includePublicUserMemories: true }).length, 2);
  assert.equal(querySharedMemory(state, { query: '甜酒' }).length, 1);
  assert.equal(querySharedMemory(state, { query: '不存在' }).length, 0);
});

test('私聊注入：全局 + 该用户 + 别人标 public 的用户记忆，不含群记忆', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'global', content: '全局记忆' });
  appendSharedMemory(state, { scope: 'user', scopeId: '345', subjectName: '示例主人', content: '示例主人 喜欢甜酒', visibility: 'private' });
  appendSharedMemory(state, { scope: 'user', scopeId: '999', content: '别人的秘密' });
  appendSharedMemory(state, { scope: 'user', scopeId: '888', subjectName: '示例主人', content: '示例主人吃青椒要去虎皮', visibility: 'public' });
  appendSharedMemory(state, { scope: 'group', scopeId: '894', content: '群里的秘密' });
  const text = formatSharedMemoryForPrompt(state, { kind: 'private', uin: '345' }, { promptMaxChars: 2000 });
  assert.match(text, /全局记忆/);
  assert.match(text, /示例主人 喜欢甜酒/);
  assert.match(text, /示例主人吃青椒要去虎皮/);
  assert.doesNotMatch(text, /别人的秘密/);
  assert.doesNotMatch(text, /群里的秘密/);
});

test('群聊注入：全局 + 本群 + public 用户记忆（public=所有会话可见）', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'global', content: '全局记忆' });
  appendSharedMemory(state, { scope: 'group', scopeId: '894', content: '本群话题' });
  appendSharedMemory(state, { scope: 'user', scopeId: '345', subjectName: '示例主人', content: '示例主人 的公开事实', visibility: 'public' });
  appendSharedMemory(state, { scope: 'user', scopeId: '345', content: '示例主人 的私密事实', visibility: 'private' });
  appendSharedMemory(state, { scope: 'user', scopeId: '777', content: '不在场者的事实', visibility: 'public' });
  const text = formatSharedMemoryForPrompt(state, {
    kind: 'group', groupId: '894', participants: [{ uin: '345', name: '示例主人' }]
  }, { promptMaxChars: 3000 });
  assert.match(text, /全局记忆/);
  assert.match(text, /本群话题/);
  assert.match(text, /示例主人 的公开事实/);
  assert.match(text, /不在场者的事实/);
  assert.doesNotMatch(text, /示例主人 的私密事实/);
});

test('私聊来源授权：只暴露 shared/public，private 原文不出私聊', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'user', scopeId: '888', subjectName: '小肥鱼', content: '小肥鱼喜欢吃青椒', visibility: 'private' });
  appendSharedMemory(state, { scope: 'user', scopeId: '888', subjectName: '小肥鱼', content: '小肥鱼喜欢被叫鱼老师', visibility: 'shared' });
  const hidden = formatSharedMemoryForPrompt(state, { kind: 'group', groupId: '894' }, { promptMaxChars: 2000 });
  assert.doesNotMatch(hidden, /小肥鱼喜欢被叫鱼老师/);
  const shown = formatSharedMemoryForPrompt(state, { kind: 'group', groupId: '894' }, {
    promptMaxChars: 2000,
    allowedCrossSources: ['private:888'],
    sourceNames: { 'private:888': '小肥鱼' }
  });
  assert.match(shown, /小肥鱼喜欢被叫鱼老师/);
  assert.match(shown, /私聊授权/);
  assert.doesNotMatch(shown, /小肥鱼喜欢吃青椒/);
});

test('formatSharedMemoryForPrompt 遵守字符上限', () => {
  const state = emptySharedMemory();
  for (let i = 0; i < 20; i += 1) {
    appendSharedMemory(state, { scope: 'global', content: `记忆条目 ${i} ${'x'.repeat(80)}` });
  }
  const text = formatSharedMemoryForPrompt(state, { kind: 'private', uin: '1' }, { promptMaxChars: 300, globalLimit: 20 });
  assert.ok(text.length <= 300, `expected <=300, got ${text.length}`);
  assert.match(text, /跨会话记忆/);
});

test('跨群 public 记忆可见，private 群记忆不外泄', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'global', content: '全局记忆' });
  appendSharedMemory(state, { scope: 'group', scopeId: '894', content: '本群私密事' });
  appendSharedMemory(state, { scope: 'group', scopeId: '894', content: '本群公开梗', visibility: 'public' });
  appendSharedMemory(state, { scope: 'group', scopeId: '111', content: '别的群公开梗', visibility: 'public' });
  appendSharedMemory(state, { scope: 'group', scopeId: '111', content: '别的群私密事' });
  const text = formatSharedMemoryForPrompt(state, { kind: 'group', groupId: '894' }, { promptMaxChars: 3000 });
  assert.match(text, /本群公开梗/);
  assert.match(text, /别的群公开梗/);
  assert.match(text, /跨群公开/);
  assert.doesNotMatch(text, /别的群私密事/);
  const privateText = formatSharedMemoryForPrompt(state, { kind: 'private', uin: '345' }, { promptMaxChars: 3000 });
  assert.match(privateText, /别的群公开梗/);
  assert.doesNotMatch(privateText, /别的群私密事/);
});

test('tokenizeForSearch 切出中文单字/二元组与英文词', () => {
  const tokens = tokenizeForSearch('周五打 Minecraft 游戏');
  assert.ok(tokens.includes('周五'));
  assert.ok(tokens.includes('周'));
  assert.ok(tokens.includes('minecraft'));
  assert.ok(tokens.includes('游戏'));
});

test('BM25 相关度排序：queryText 能挑出相关记忆', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'global', content: '今天天气很好', importance: 5 });
  appendSharedMemory(state, { scope: 'global', content: '我们周五打 Minecraft', importance: 3 });
  const ranked = rankMemoryEntries(state.entries, 'Minecraft 周五');
  assert.equal(ranked[0].content, '我们周五打 Minecraft');
  const text = formatSharedMemoryForPrompt(state, { kind: 'private', uin: '1' }, { promptMaxChars: 2000, globalLimit: 1, queryText: 'Minecraft 周五' });
  assert.match(text, /Minecraft/);
});

test('querySharedMemory 支持中文二元组/同义词命中', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'user', scopeId: '345', content: '示例主人 喜欢甜酒' });
  assert.equal(querySharedMemory(state, { query: '甜味' }).length, 1);
  assert.equal(querySharedMemory(state, { query: '不存在的东西' }).length, 0);
});

test('compressSharedMemory 合并高度相似条目', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'global', content: '周五打 Minecraft 游戏' });
  appendSharedMemory(state, { scope: 'global', content: '周五打 Minecraft 游戏！' });
  const stats = compressSharedMemory(state, { maxPerScope: 40, keepPerScope: 30, similarityThreshold: 0.8 });
  assert.ok(stats.merged >= 1);
  assert.equal(state.entries.length, 1);
});

test('compressSharedMemory 超量时生成自动摘要并降低碎片', () => {
  const state = emptySharedMemory();
  for (let i = 0; i < 45; i += 1) {
    appendSharedMemory(state, { scope: 'group', scopeId: '894', content: `群事件编号 ${i} 记录`, importance: 3 });
  }
  const stats = compressSharedMemory(state, { maxPerScope: 20, keepPerScope: 10, similarityThreshold: 0.95 });
  assert.ok(stats.digests >= 1);
  assert.ok(state.entries.length <= 12, `expected <=12, got ${state.entries.length}`);
  assert.ok(state.entries.some((e) => (e.tags || []).includes('自动摘要')));
});

test('访问矩阵授权的跨群 private 记忆可见，未授权不可见', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'group', scopeId: '894', content: '本群私密事' });
  appendSharedMemory(state, { scope: 'group', scopeId: '111', content: '被授权的别群私密事' });
  appendSharedMemory(state, { scope: 'group', scopeId: '222', content: '未授权的别群私密事' });
  appendSharedMemory(state, { scope: 'group', scopeId: '333', content: '别群公开事', visibility: 'public' });
  const text = formatSharedMemoryForPrompt(state, { kind: 'group', groupId: '894' }, {
    promptMaxChars: 3000,
    allowedCrossGroupIds: ['111'],
    crossGroupNames: { 111: '四兄弟群' }
  });
  assert.match(text, /被授权的别群私密事/);
  assert.match(text, /四兄弟群/);
  assert.match(text, /别群公开事/);
  assert.doesNotMatch(text, /未授权的别群私密事/);
  const plain = formatSharedMemoryForPrompt(state, { kind: 'group', groupId: '894' }, { promptMaxChars: 3000 });
  assert.doesNotMatch(plain, /被授权的别群私密事/);
  assert.match(plain, /别群公开事/);
});

test('角色隔离：提示词/查询只带当前角色与全局记忆，不同角色互不可见', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'user', scopeId: '345', characterId: 'Jill', content: 'Jill 的私人记忆' });
  appendSharedMemory(state, { scope: 'user', scopeId: '345', characterId: '示例群友', content: '示例群友的私人记忆' });
  appendSharedMemory(state, { scope: 'global', scopeId: '', characterId: '*', content: '所有角色都知道的事' });
  const jillText = formatSharedMemoryForPrompt(state, { kind: 'private', uin: '345' }, { promptMaxChars: 3000, characterId: 'Jill' });
  assert.match(jillText, /Jill 的私人记忆/);
  assert.match(jillText, /所有角色都知道的事/);
  assert.doesNotMatch(jillText, /示例群友的私人记忆/);
  const otherText = formatSharedMemoryForPrompt(state, { kind: 'private', uin: '345' }, { promptMaxChars: 3000, characterId: '示例群友' });
  assert.match(otherText, /示例群友的私人记忆/);
  assert.doesNotMatch(otherText, /Jill 的私人记忆/);
  const queried = querySharedMemory(state, { scopes: [{ scope: 'user', scopeId: '345' }], characterId: 'Jill', limit: 20 });
  assert.deepEqual(queried.map((e) => e.content), ['Jill 的私人记忆']);
});

test('角色隔离：压缩不会跨角色合并', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'user', scopeId: '345', characterId: 'Jill', content: '同一个人的同一件事' });
  appendSharedMemory(state, { scope: 'user', scopeId: '345', characterId: '示例群友', content: '同一个人的同一件事' });
  compressSharedMemory(state, { maxPerScope: 40, keepPerScope: 30 });
  assert.equal(state.entries.length, 2);
});

test('forgetSharedMemory 按 id / scope / 内容删除', () => {
  const state = emptySharedMemory();
  const a = appendSharedMemory(state, { scope: 'global', content: 'A记忆' });
  appendSharedMemory(state, { scope: 'group', scopeId: '894', content: 'B群事' });
  appendSharedMemory(state, { scope: 'user', scopeId: '345', content: 'C用户事' });
  assert.equal(forgetSharedMemory(state, { id: a.entry.id }), 1);
  assert.equal(state.entries.length, 2);
  assert.equal(forgetSharedMemory(state, { scope: 'group', scopeId: '894', query: 'B群事' }), 1);
  assert.equal(forgetSharedMemory(state, { scope: 'user', scopeId: '345' }), 1);
  assert.equal(state.entries.length, 0);
});

test('pruneSharedMemory 清理过期条目，保留高重要性', () => {
  const now = Date.now();
  const state = emptySharedMemory();
  state.entries = [
    { id: 'old-low', scope: 'global', scopeId: '', content: '旧低重要', importance: 2, createdAt: now - 100 * 86400000, updatedAt: now - 100 * 86400000 },
    { id: 'old-high', scope: 'global', scopeId: '', content: '旧高重要', importance: 5, createdAt: now - 100 * 86400000, updatedAt: now - 100 * 86400000 },
    { id: 'fresh', scope: 'global', scopeId: '', content: '新鲜', importance: 3, createdAt: now, updatedAt: now }
  ];
  pruneSharedMemory(state, { now, ttlDays: 30 });
  assert.deepEqual(state.entries.map((e) => e.id).sort(), ['fresh', 'old-high']);
});

test('summarizeSharedMemory 统计各层', () => {
  const state = emptySharedMemory();
  appendSharedMemory(state, { scope: 'global', content: '全局事' });
  appendSharedMemory(state, { scope: 'user', scopeId: '1', content: '用户事' });
  appendSharedMemory(state, { scope: 'group', scopeId: '2', content: '群事' });
  assert.deepEqual(summarizeSharedMemory(state), { total: 3, counts: { global: 1, user: 1, group: 1 } });
});

console.log('');
console.log(`通过 ${passed} 个测试${process.exitCode ? '（有失败）' : ''}`);
