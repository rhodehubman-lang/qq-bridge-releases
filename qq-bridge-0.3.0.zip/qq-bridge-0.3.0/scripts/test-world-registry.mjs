import assert from 'node:assert/strict';
import { emptyRegistry, ensureProfileWorld, createWorld, assignCharacter, worldByProfile } from '../src/world-registry.js';

const r = emptyRegistry();
const w1 = ensureProfileWorld(r, 'jill', { name: 'Jill', worldName: 'Glitch City' });
assert.equal(w1.id, 'jill');
assert.equal(w1.name, 'Glitch City');
assert.equal(r.characters.jill, 'jill');

const w2 = createWorld(r, '另一座城市');
assert.ok(w2.id);
assignCharacter(r, 'xiaojingyu', w2.id);
assert.equal(worldByProfile(r, 'xiaojingyu').id, w2.id);

// 两个角色可以共享同一个世界
assignCharacter(r, 'jill', w2.id);
assert.equal(worldByProfile(r, 'jill').id, w2.id);
assert.ok(r.worlds[w2.id].members.includes('jill'));
assert.ok(r.worlds[w2.id].members.includes('xiaojingyu'));

console.log('✅ 世界注册表测试通过（独立城市/多城市/共享成员）');
