# Create desktop shortcuts for the QQ bridge (ASCII-only script; all names/paths come via env).
# Called by scripts/install.mjs. Kept ASCII on purpose: PowerShell 5.1 reads .ps1 in the
# system ANSI codepage unless it has a BOM, so Chinese literals here would be mojibake.
$ErrorActionPreference = 'Stop'

$desktop = $env:QQB_DESKTOP_DIR
if ([string]::IsNullOrWhiteSpace($desktop)) {
    $desktop = [Environment]::GetFolderPath('Desktop')
}
$root = $env:QQB_ROOT
if ([string]::IsNullOrWhiteSpace($root)) { throw 'QQB_ROOT is required' }
if (-not (Test-Path -LiteralPath $root)) { throw "QQB_ROOT does not exist: $root" }
if (-not (Test-Path -LiteralPath $desktop)) {
    New-Item -ItemType Directory -Path $desktop -Force | Out-Null
}

$shell = New-Object -ComObject WScript.Shell

$lnkPath = Join-Path $desktop ($env:QQB_LNK_NAME + '.lnk')
$shortcut = $shell.CreateShortcut($lnkPath)
$shortcut.TargetPath = Join-Path $root $env:QQB_LNK_TARGET
$shortcut.WorkingDirectory = $root
$shortcut.Description = 'Start the QQ bridge (keep the window open)'
$shortcut.Save()

$urlPath = Join-Path $desktop ($env:QQB_URL_NAME + '.url')
$urlContent = "[InternetShortcut]`r`nURL=" + $env:QQB_URL + "`r`n"
Set-Content -LiteralPath $urlPath -Value $urlContent -Encoding ASCII

Write-Output ("shortcuts ok: " + $lnkPath + " | " + $urlPath)
