// 更新清单生成器回归（latest.json）。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { buildManifest, extractChangelogNotes, parseArgs } from '../scripts/build-update-manifest.mjs';
import { normalizeManifest } from '../src/update-engine.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0;
let fail = 0;
function check(cond, label, extra = '') {
  if (cond) { pass += 1; console.log(`✅ ${label}`); }
  else { fail += 1; console.error(`❌ ${label}${extra ? `：${extra}` : ''}`); }
}
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'qqb-manifest-'));
try {
  const zipPath = path.join(tmp, 'qq-bridge-0.3.0.zip');
  fs.writeFileSync(zipPath, Buffer.from('fake release zip content for manifest test'));

  // ── 1. CHANGELOG 提取 ────────────────────────────────────────────────────
  const changelog = `# 变更记录\n\n## 0.3.0 — 自动更新\n\n- 自动更新器\n- 桌面版适配\n\n## 0.2.0-r4\n\n- 旧内容\n`;
  const notes = extractChangelogNotes(changelog, '0.3.0');
  check(notes.includes('自动更新器') && notes.includes('桌面版适配'), 'CHANGELOG：提取对应版本说明', notes.slice(0, 80));
  check(!notes.includes('旧内容'), 'CHANGELOG：不串到下一个版本');
  check(extractChangelogNotes(changelog, '9.9.9') === '', 'CHANGELOG：版本不存在返回空');

  // ── 2. buildManifest ────────────────────────────────────────────────────
  const manifest = buildManifest({
    version: '0.3.0',
    zipPath,
    notes,
    repo: 'Derpyu520/qq-bridge',
    dshMin: '0.2.0-rc.2',
    dshMax: '0.2.1',
    dataSchema: 2,
    minDataSchema: 1,
    requiresDshRestart: true
  });
  check(manifest.schema === 1 && manifest.recommended.version === '0.3.0', 'manifest：基础字段');
  check(manifest.recommended.asset === 'qq-bridge-0.3.0.zip', 'manifest：asset 文件名');
  check(manifest.recommended.assetUrl === 'https://github.com/Derpyu520/qq-bridge/releases/download/v0.3.0/qq-bridge-0.3.0.zip', 'manifest：GitHub 附件地址');
  check(manifest.recommended.size === fs.statSync(zipPath).size, 'manifest：size 与 zip 一致');
  check(/^[0-9a-f]{64}$/.test(manifest.recommended.sha256), 'manifest：sha256 合法');
  check(manifest.recommended.requiresDshRestart === true, 'manifest：requiresDshRestart');
  check(manifest.lines['0.3.0']?.version === '0.3.0', 'manifest：lines 版本线条目');
  const localManifest = buildManifest({ version: '0.3.0', zipPath, assetUrl: 'http://127.0.0.1:3399/x.zip' });
  check(localManifest.recommended.assetUrl === 'http://127.0.0.1:3399/x.zip', 'manifest：assetUrl 可覆盖（本地演练源）');
  const argsAsset = parseArgs(['--asset-url', 'http://127.0.0.1:3399/x.zip']);
  check(argsAsset.assetUrl === 'http://127.0.0.1:3399/x.zip', '参数解析：--asset-url');

  const normalized = normalizeManifest(manifest);
  check(normalized.ok === true, 'manifest：能被更新器校验通过', normalized.error);
  let threw = false;
  try { buildManifest({ version: 'bad-version', zipPath }); } catch { threw = true; }
  check(threw, 'manifest：非法版本抛错');
  threw = false;
  try { buildManifest({ version: '0.3.0', zipPath: path.join(tmp, 'missing.zip') }); } catch { threw = true; }
  check(threw, 'manifest：zip 不存在抛错');

  // ── 3. 参数解析 ─────────────────────────────────────────────────────────
  const args = parseArgs(['--zip', 'a.zip', '--out', 'b.json', '--notes-file', 'n.md', '--repo', 'x/y', '--tag', 'v0.3.0', '--dsh-min', '0.2.0', '--dsh-max', '0.2.2', '--data-schema', '2', '--min-data-schema', '1', '--requires-dsh-restart']);
  check(args.zip === 'a.zip' && args.out === 'b.json' && args.notesFile === 'n.md', '参数解析：路径');
  check(args.repo === 'x/y' && args.tag === 'v0.3.0' && args.dataSchema === 2 && args.requiresDshRestart === true, '参数解析：版本/兼容/开关');
  let bad = false;
  try { parseArgs(['--nope']); } catch { bad = true; }
  check(bad, '参数解析：未知参数抛错');

  // ── 4. CLI 集成：默认输出 dist/latest.json（用 --out 指到临时目录）────────
  const outPath = path.join(tmp, 'latest.json');
  const notesFile = path.join(tmp, 'notes.md');
  fs.writeFileSync(notesFile, '## 更新内容\n\n- CLI 测试', 'utf8');
  const cli = spawnSync(process.execPath, [
    path.join(ROOT, 'scripts', 'build-update-manifest.mjs'),
    '--zip', zipPath, '--out', outPath, '--notes-file', notesFile, '--repo', 'x/y'
  ], { encoding: 'utf8', timeout: 30000 });
  check(cli.status === 0, 'CLI：退出码 0', (cli.stderr || '').slice(0, 200));
  const cliManifest = JSON.parse(fs.readFileSync(outPath, 'utf8'));
  check(cliManifest.recommended.notes.includes('CLI 测试'), 'CLI：写入说明文件内容');
  check(cliManifest.recommended.assetUrl.includes('/x/y/releases/download/'), 'CLI：repo 参数生效');
} finally {
  fs.rmSync(tmp, { recursive: true, force: true });
}
console.log(`\n=== test-update-manifest: ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail ? 1 : 0);
