import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { renumberStory } from '../src/story-engine.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const file = path.resolve(process.argv[2] || path.join(here, '..', 'state', 'worlds', 'jill', 'story.json'));
const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
const before = (Array.isArray(raw.chapters) ? raw.chapters : []).map((c) => ({ id: c.id, chapter: c.chapter, title: c.title }));
const fixed = renumberStory(raw);
const after = (fixed.chapters || []).map((c) => ({ id: c.id, chapter: c.chapter, title: c.title }));
const pending = fixed.pending ? { id: fixed.pending.id, chapter: fixed.pending.chapter, title: fixed.pending.title } : null;
const changed = JSON.stringify(before) !== JSON.stringify(after) || Number(raw.pending?.chapter || 0) !== Number(fixed.pending?.chapter || 0);
if (changed) {
  const backup = `${file}.bak-${Date.now()}`;
  fs.copyFileSync(file, backup);
  fs.writeFileSync(file, JSON.stringify(fixed, null, 2));
  console.log(JSON.stringify({ ok: true, file, backup, before, after, pending }, null, 2));
} else {
  console.log(JSON.stringify({ ok: true, file, changed: false, before, after, pending }, null, 2));
}
