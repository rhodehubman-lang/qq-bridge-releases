#!/usr/bin/env node
// 本地假更新源（仅开发/演练用）：把目录里的 latest.json + zip 以 http 提供。
//
// 用途：没有新版可发时，也能在 VM/本机演练完整更新链路：
//   1. 把新版本 zip 与 latest.json 放进一个目录
//   2. node scripts/dev-update-server.mjs --dir <目录> --port 3399
//   3. config.json → updates.customManifestUrl = http://127.0.0.1:3399/latest.json
//   4. 控制台出现「发现新版本」→ 点更新
//
// 安全：只监听 127.0.0.1；只读；拒绝路径穿越；未知扩展名也按二进制返回。
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(path.dirname(fileURLToPath(import.meta.url))));

export function parseArgs(argv = process.argv.slice(2)) {
  const out = { dir: '', port: 3399, host: '127.0.0.1' };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const take = () => String(argv[++i] ?? '');
    if (arg === '--dir') out.dir = take();
    else if (arg === '--port') out.port = Number(take()) || 3399;
    else if (arg === '--host') out.host = take();
    else if (arg === '--help' || arg === '-h') out.help = true;
    else throw new Error(`未知参数：${arg}`);
  }
  return out;
}

export function createServer(dir) {
  const root = path.resolve(dir);
  const mime = { '.json': 'application/json; charset=utf-8', '.zip': 'application/zip', '.md': 'text/markdown; charset=utf-8' };
  return http.createServer((req, res) => {
    try {
      const url = new URL(req.url || '/', 'http://127.0.0.1');
      const rel = decodeURIComponent(url.pathname).replace(/^\/+/, '');
      const file = path.resolve(root, rel);
      if (!file.startsWith(root + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
        res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
        res.end('not found');
        return;
      }
      const data = fs.readFileSync(file);
      res.writeHead(200, {
        'content-type': mime[path.extname(file).toLowerCase()] || 'application/octet-stream',
        'content-length': data.length,
        'cache-control': 'no-store'
      });
      res.end(data);
      console.log(`[dev-update-server] ${req.method} ${url.pathname} -> 200 (${data.length} bytes)`);
    } catch (error) {
      res.writeHead(500, { 'content-type': 'text/plain; charset=utf-8' });
      res.end(String(error?.message || error));
    }
  });
}

function main() {
  let args;
  try { args = parseArgs(); } catch (error) { console.error(`[dev-update-server] ${error.message}`); process.exit(2); }
  if (args.help) {
    console.log('用法: node scripts/dev-update-server.mjs --dir <目录> [--port 3399]');
    return;
  }
  const dir = args.dir ? path.resolve(args.dir) : '';
  if (!dir || !fs.existsSync(dir)) {
    console.error(`[dev-update-server] 目录不存在：${dir || '(未指定 --dir)'}`);
    process.exit(2);
  }
  if (!fs.existsSync(path.join(dir, 'latest.json'))) {
    console.error('[dev-update-server] 目录里没有 latest.json（先用 build-update-manifest.mjs 生成）');
    process.exit(2);
  }
  const server = createServer(dir);
  server.listen(args.port, '127.0.0.1', () => {
    console.log(`[dev-update-server] serving ${dir}`);
    console.log(`[dev-update-server] http://127.0.0.1:${args.port}/latest.json`);
    console.log('[dev-update-server] 把 config.json 的 updates.customManifestUrl 指到上面这个地址，然后重启桥接。Ctrl+C 退出。');
  });
}

const invokedDirectly = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) main();
