import assert from 'node:assert/strict';
import {
  DEFAULT_TOKEN_BUDGET,
  normalizeTokenBudget,
  parsePeakWindows,
  budgetWindowStart,
  budgetDayKey,
  nextResetAt,
  isPeakAt,
  budgetStage,
  effectiveReasoningEffort,
  formatBudgetPrompt,
  formatBudgetNoticeText,
  formatBudgetNoticePrompt,
  formatHardCapDirectPrompt,
  hardCapAllowsDirect
} from '../src/token-budget.js';

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`ok ${passed} - ${name}`);
  } catch (error) {
    console.error(`not ok ${passed + 1} - ${name}`);
    throw error;
  }
}

test('默认预算是 5 元、工作日两个高峰段', () => {
  const b = normalizeTokenBudget({});
  assert.equal(b.dailyLimitCny, 5);
  assert.equal(b.peakDays, 'weekdays');
  assert.equal(b.peakWindows.length, 2);
  assert.equal(b.softPercent, 65);
  assert.equal(b.warnPercent, 85);
});

test('高峰时段文本可解析并拒绝坏行', () => {
  assert.deepEqual(parsePeakWindows('09:00-12:00\n14:00~18:00\nbad'), [
    { start: '09:00', end: '12:00' },
    { start: '14:00', end: '18:00' }
  ]);
});

test('高峰判断支持工作日/周末/每天', () => {
  const base = normalizeTokenBudget({});
  const monday10 = new Date(2026, 9, 26, 10, 0);
  const saturday10 = new Date(2026, 9, 31, 10, 0);
  assert.equal(isPeakAt(base, monday10), true);
  assert.equal(isPeakAt(base, saturday10), false);
  const weekend = normalizeTokenBudget({ ...base, peakDays: 'weekend' });
  assert.equal(isPeakAt(weekend, saturday10), true);
  const everyday = normalizeTokenBudget({ ...base, peakDays: 'everyday' });
  assert.equal(isPeakAt(everyday, saturday10), true);
});

test('重置时间偏移会改变日窗口', () => {
  const b = normalizeTokenBudget({ resetTime: '04:00' });
  const now = new Date(2026, 9, 28, 3, 30);
  const start = budgetWindowStart(b, now);
  assert.equal(new Date(start).getDate(), 27);
  assert.equal(new Date(start).getHours(), 4);
  assert.equal(budgetDayKey(b, now), '2026-10-27');
  assert.equal(new Date(nextResetAt(b, now)).getDate(), 28);
});

test('三段阈值与下线', () => {
  const b = normalizeTokenBudget({ dailyLimitCny: 10, softPercent: 60, warnPercent: 85 });
  const now = new Date(2026, 9, 26, 20, 0);
  assert.equal(budgetStage(b, 1, now).stage, 'normal');
  assert.equal(budgetStage(b, 6, now).stage, 'saver');
  assert.equal(budgetStage(b, 8.5, now).stage, 'warning');
  assert.equal(budgetStage(b, 10, now).stage, 'offline');
});

test('高峰会自动进入省钱模式，手动暂停优先', () => {
  const b = normalizeTokenBudget({ peakDays: 'everyday', peakWindows: [{ start: '09:00', end: '18:00' }] });
  const now = new Date(2026, 9, 26, 10, 0);
  assert.equal(budgetStage(b, 1, now).stage, 'saver');
  const paused = normalizeTokenBudget({ ...b, runtime: { paused: true } });
  assert.equal(budgetStage(paused, 1, now).stage, 'offline');
});

test('省钱模式降低思考强度，正常模式保持原值', () => {
  const b = normalizeTokenBudget({ saver: { reasoningEffort: 'low' } });
  assert.equal(effectiveReasoningEffort(b, 'normal', 'max'), 'max');
  assert.equal(effectiveReasoningEffort(b, 'saver', 'max'), 'low');
  assert.equal(effectiveReasoningEffort(b, 'warning', 'max'), 'low');
});

test('省钱提示不暴露预算术语，警告提示包含回归时间', () => {
  const b = normalizeTokenBudget({ resetTime: '07:00' });
  const status = budgetStage(b, 1, new Date(2026, 9, 26, 10, 0));
  const saver = formatBudgetPrompt(b, status);
  assert.match(saver, /省电模式/);
  assert.doesNotMatch(saver, /token|额度|预算|管理员/);
  const warn = formatBudgetNoticePrompt(b, status, 'warn');
  assert.match(warn, /07:00/);
  assert.match(warn, /不要向对方解释|费用/);
});

test('通知方式与固定文案可配置，{time} 会替换', () => {
  const b = normalizeTokenBudget({
    notices: {
      mode: 'fixed',
      mustSpeak: false,
      softText: '我先慢一点。',
      warnText: '我先去歇会儿，{time} 左右回来。'
    }
  });
  assert.equal(b.notices.mode, 'fixed');
  assert.equal(b.notices.mustSpeak, false);
  const status = { nextResetAt: new Date(2026, 9, 29, 7, 30).getTime() };
  assert.match(formatBudgetNoticeText(b, status, 'soft'), /我先慢一点/);
  assert.match(formatBudgetNoticeText(b, status, 'warn'), /07:30 左右回来/);
  const prompt = formatBudgetNoticePrompt(b, status, 'soft');
  assert.match(prompt, /也可以选择沉默/);
  const must = normalizeTokenBudget({ notices: { mustSpeak: true } });
  assert.match(formatBudgetNoticePrompt(must, status, 'soft'), /必须发一条/);
});

test('硬上限只停主动行为，直呼/私聊仍可回复', () => {
  for (const reason of ['private', 'atMention', 'nameMention', 'atMention:foo']) {
    assert.equal(hardCapAllowsDirect(reason), true, reason);
  }
  for (const reason of ['probability', 'proactiveCheck', 'question', 'ownerTask', 'crossGroupReport']) {
    assert.equal(hardCapAllowsDirect(reason), false, reason);
  }
  const b = normalizeTokenBudget({ notices: { offlineText: '额度没了，{time} 恢复；@我还会回。' } });
  const status = { stage: 'offline', nextResetAt: new Date(2026, 9, 30, 0, 0).getTime() };
  assert.match(formatBudgetNoticeText(b, status, 'offline'), /00:00 恢复/);
  const prompt = formatHardCapDirectPrompt(b, status);
  assert.match(prompt, /只做直接回复/);
  assert.match(prompt, /1–2 句/);
  assert.equal(formatHardCapDirectPrompt(b, { stage: 'normal' }), '');
  assert.equal(normalizeTokenBudget({ runtime: { offlineNotified: true } }).runtime.offlineNotified, true);
});

test('非法数值被夹回安全范围', () => {
  const b = normalizeTokenBudget({ dailyLimitCny: -1, softPercent: 99, warnPercent: 50, peakWindows: [{ start: '99:99', end: 'x' }] });
  assert.equal(b.dailyLimitCny, 0.1);
  assert.equal(b.softPercent, 95);
  assert.ok(b.warnPercent > b.softPercent);
  assert.deepEqual(b.peakWindows, []);
});

console.log(`\n✅ 省钱预算测试通过（${passed} 项）`);
