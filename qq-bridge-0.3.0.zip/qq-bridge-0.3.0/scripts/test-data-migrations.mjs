// 数据迁移框架回归（纯文件操作，离线可跑）。
//
// 背景：大型更新（如城市革新）会改数据模型，更新器不能只恢复文件、还必须把旧数据
// 逐级迁移到新 schema；本测试钉住：版本探测、迁移链、幂等、dry-run、迁移前备份、
// 未知字段保留、失败不写坏文件、迁移日志。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import {
  DATASETS,
  DATASETS as REAL_DATASETS,
  describeDataState,
  expandPattern,
  planAll,
  planChain,
  runMigrations,
  scanDataFiles
} from '../src/data-migration.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0;
let fail = 0;
function check(cond, label, extra = '') {
  if (cond) { pass += 1; console.log(`✅ ${label}`); }
  else { fail += 1; console.error(`❌ ${label}${extra ? `：${extra}` : ''}`); }
}
const readJson = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
function writeJson(root, rel, obj) {
  const p = path.join(root, rel);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, `${JSON.stringify(obj, null, 2)}\n`, 'utf8');
  return p;
}

// 测试用数据集：world-truth 当前版本 3，用来验证 1→2→3 的迁移链。
const testDatasets = [
  { id: 'world-truth', label: '世界/城市真值', pattern: 'state/worlds/*/truth.json', current: 3, readVersion: (d) => Number(d?.version) || 1 },
  { id: 'world-registry', label: '世界注册表', pattern: 'state/world-registry.json', current: 1, readVersion: (d) => Number(d?.version) || 1 }
];
const m1 = {
  id: 'm1', name: 'v1→v2', dataset: 'world-truth', from: 1, to: 2,
  apply: (data) => ({ ...data, city: { name: data.cityName || '' }, legacy: { ...(data.legacy || {}), cityName: data.cityName } })
};
const m2 = {
  id: 'm2', name: 'v2→v3', dataset: 'world-truth', from: 2, to: 3,
  apply: (data) => ({ ...data, cities: [data.city], customNote: data.userNote || '' })
};

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'qqb-migrate-'));
try {
  // ── 1. 通配符展开与扫描 ──────────────────────────────────────────────────
  const truthPath = writeJson(tmp, 'state/worlds/w1/truth.json', {
    version: 1, profileId: 'p1', cityName: '朋友的旧城市', userNote: '我写的设定', weather: { old: true }, unknownKeep: [1, 2, 3]
  });
  writeJson(tmp, 'state/worlds/w1/characters/hero.json', { version: 1, characterId: 'hero', knownEvents: {} });
  writeJson(tmp, 'state/world-registry.json', { version: 1, worlds: {}, characters: {} });
  writeJson(tmp, 'life-profiles/a.json', { version: 1, id: 'a' });

  const expanded = expandPattern(tmp, 'state/worlds/*/truth.json');
  check(expanded.length === 1 && expanded[0] === truthPath, 'expandPattern：单层通配命中 truth.json');
  const chars = expandPattern(tmp, 'state/worlds/*/characters/*.json');
  check(chars.length === 1, 'expandPattern：多级通配命中 characters/*.json');

  const scanned = scanDataFiles(tmp, testDatasets);
  check(scanned.length === 2, `scanDataFiles：识别 ${scanned.length} 个测试数据集文件`, scanned.map((f) => f.relPath).join(', '));
  const truthFile = scanned.find((f) => f.dataset === 'world-truth');
  check(truthFile.version === 1 && truthFile.current === 3, 'scanDataFiles：读取版本与目标版本');

  // 损坏文件不致命，记错误
  writeJson(tmp, 'state/worlds/w2/truth.json', { version: 1 });
  fs.writeFileSync(path.join(tmp, 'state/worlds/w2/truth.json'), '{broken', 'utf8');
  const brokenScan = scanDataFiles(tmp, testDatasets).find((f) => f.relPath.includes('w2/truth.json'));
  check(Boolean(brokenScan.error), 'scanDataFiles：损坏 JSON 标记错误而不是抛错');

  // ── 2. 迁移链规划 ───────────────────────────────────────────────────────
  const chain = planChain(truthFile, [m1, m2], testDatasets);
  check(chain.ok && chain.steps.length === 2 && chain.steps[0].id === 'm1' && chain.steps[1].id === 'm2', 'planChain：v1→v3 两级链');
  const noChain = planChain(truthFile, [m2], testDatasets);
  check(!noChain.ok && /缺少迁移/.test(noChain.error), 'planChain：缺级时明确报错', noChain.error);
  const currentFile = { ...truthFile, version: 3 };
  check(planChain(currentFile, [m1, m2], testDatasets).steps.length === 0, 'planChain：已是当前版本 → 空链');

  // ── 3. dry-run 不改文件 ─────────────────────────────────────────────────
  const beforeText = fs.readFileSync(truthPath, 'utf8');
  const dry = runMigrations({ root: tmp, migrations: [m1, m2], apply: false, datasets: testDatasets });
  check(dry.dryRun === true && dry.pending.length === 1, 'dry-run：报告待迁移');
  check(fs.readFileSync(truthPath, 'utf8') === beforeText, 'dry-run：文件未被改动');

  // ── 4. apply：迁移 + 备份 + 日志 + 未知字段保留 ─────────────────────────
  const backupRoot = path.join(tmp, '_backups', 'data', 'test-run');
  const applied = runMigrations({ root: tmp, migrations: [m1, m2], apply: true, backupRoot, datasets: testDatasets });
  check(applied.migrated.length === 1, 'apply：迁移 1 个文件', JSON.stringify(applied.errors));
  const after = readJson(truthPath);
  check(after.version === 3, 'apply：版本升到 3');
  check(Array.isArray(after.cities) && after.cities[0].name === '朋友的旧城市', 'apply：城市数据搬到新结构');
  check(after.unknownKeep?.[2] === 3, 'apply：未知字段原样保留');
  check(after.customNote === '我写的设定', 'apply：用户自定义内容保留');
  check(after.legacy?.cityName === '朋友的旧城市', 'apply：旧字段保留在 legacy 下');
  const backupFile = path.join(backupRoot, 'state/worlds/w1/truth.json');
  check(fs.existsSync(backupFile), 'apply：迁移前备份文件存在');
  check(readJson(backupFile).version === 1, 'apply：备份是迁移前的原版');
  const logFile = path.join(tmp, 'state/migration-log.json');
  const logData = fs.existsSync(logFile) ? readJson(logFile) : { entries: [] };
  check(logData.entries.some((e) => e.file === 'state/worlds/w1/truth.json' && e.to === 3), 'apply：迁移日志记录 from/to');

  // ── 5. 幂等：第二次运行不再改动 ─────────────────────────────────────────
  const afterText = fs.readFileSync(truthPath, 'utf8');
  const again = runMigrations({ root: tmp, migrations: [m1, m2], apply: true, backupRoot, datasets: testDatasets });
  check(again.pending.length === 0 && again.migrated.length === 0, '幂等：第二次运行无待迁移文件');
  check(fs.readFileSync(truthPath, 'utf8') === afterText, '幂等：文件字节不变');

  // ── 6. 失败安全：迁移抛错时不写坏文件 ───────────────────────────────────
  writeJson(tmp, 'state/worlds/w3/truth.json', { version: 1, cityName: 'x' });
  const twoStepDatasets = [{ ...testDatasets[0], current: 2 }];
  const boom = { id: 'boom', dataset: 'world-truth', from: 1, to: 2, apply: () => { throw new Error('故意失败'); } };
  const boomRun = runMigrations({ root: tmp, migrations: [boom], apply: true, backupRoot, datasets: twoStepDatasets });
  const boomFile = path.join(tmp, 'state/worlds/w3/truth.json');
  check(boomRun.errors.some((e) => /故意失败/.test(e.error)), '失败：迁移抛错被收集');
  check(readJson(boomFile).version === 1, '失败：原文件未被写坏');
  const tmpFiles = fs.readdirSync(path.dirname(boomFile)).filter((f) => f.includes('.tmp'));
  check(tmpFiles.length === 0, '失败：没有残留临时文件');

  // 返回值不是对象也要拦
  const badShape = { id: 'bad', dataset: 'world-truth', from: 1, to: 2, apply: () => [] };
  const badRun = runMigrations({ root: tmp, migrations: [badShape], apply: true, backupRoot, datasets: twoStepDatasets });
  check(badRun.errors.some((e) => /不是对象/.test(e.error)), '失败：迁移返回非对象被拒绝');

  // ── 7. describeDataState ────────────────────────────────────────────────
  const desc = describeDataState(tmp, testDatasets);
  check(desc.datasets['world-truth'].files === 3, 'describeDataState：统计文件数');
  check(desc.datasets['world-truth'].pending === 1, 'describeDataState：统计待迁移数（w3 仍是 v1）');
  check(desc.datasets['world-truth'].broken === 1, 'describeDataState：损坏文件单独计数（w2）');

  // ── 8. 真实数据家族配置完好（防止改框架时误改 pattern）──────────────────
  check(REAL_DATASETS.length >= 4, '真实数据集至少 4 个家族');
  check(REAL_DATASETS.find((d) => d.id === 'world-truth').pattern === 'state/worlds/*/truth.json', '真实 world-truth pattern 正确');
  check(REAL_DATASETS.find((d) => d.id === 'life-profile').pattern === 'life-profiles/*.json', '真实 life-profile pattern 正确');

  // ── 9. CLI 冒烟（真实数据集：临时目录里都是当前版本 → 无需迁移）────────────
  const cliRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'qqb-migrate-cli-'));
  writeJson(cliRoot, 'state/world-registry.json', { version: 1, worlds: {}, characters: {} });
  const cli = spawnSync(process.execPath, [path.join(ROOT, 'scripts', 'migrate-data.mjs'), '--json', '--root', cliRoot], { encoding: 'utf8', timeout: 30000 });
  let cliJson = null;
  try { cliJson = JSON.parse(cli.stdout); } catch {}
  check(cli.status === 0 && cliJson && cliJson.dryRun === true, 'CLI：--json dry-run 退出码 0 且输出可解析', (cli.stderr || '').slice(0, 200));
  fs.rmSync(cliRoot, { recursive: true, force: true });
} finally {
  fs.rmSync(tmp, { recursive: true, force: true });
}

console.log(`\n=== test-data-migrations: ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail ? 1 : 0);
