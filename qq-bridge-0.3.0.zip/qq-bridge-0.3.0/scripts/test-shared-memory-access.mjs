// 跨会话记忆访问矩阵单元测试。
// 运行：node scripts/test-shared-memory-access.mjs
import assert from 'node:assert/strict';
import {
  allowedCrossSources,
  canReadSource,
  defaultAccessPolicy,
  emptyAccessState,
  getAccessPolicy,
  isOwnerPrivate,
  listAccessPolicies,
  normalizeAccessState,
  setAccessPolicy
} from '../src/shared-memory-access.js';

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`✅ ${name}`);
  } catch (error) {
    console.error(`❌ ${name}`);
    console.error(error);
    process.exitCode = 1;
  }
}

const OWNER = '100000001';

test('默认：管理员私聊 all，普通群/私聊 none', () => {
  assert.deepEqual(defaultAccessPolicy(`private:${OWNER}`, { ownerQQ: OWNER }), { mode: 'all', sources: [] });
  assert.deepEqual(defaultAccessPolicy('group:987654321', { ownerQQ: OWNER }), { mode: 'none', sources: [] });
  assert.deepEqual(defaultAccessPolicy('private:111', { ownerQQ: OWNER }), { mode: 'none', sources: [] });
  assert.equal(isOwnerPrivate(`private:${OWNER}`, OWNER), true);
  assert.equal(isOwnerPrivate('private:111', OWNER), false);
});

test('normalizeAccessState 兼容旧 groups 字段并丢弃坏 key/坏策略', () => {
  const state = normalizeAccessState({
    version: 1,
    conversations: {
      'group:00123': { mode: 'all', groups: ['456'] },
      'private:100000001': { mode: 'selected', sources: ['group:987654321', 'group:987654321', 'private:100000002'] },
      'bad-key': { mode: 'all' },
      'group:9': { mode: 'nope' }
    }
  });
  assert.deepEqual(Object.keys(state.conversations).sort(), ['group:123', 'private:100000001']);
  assert.deepEqual(state.conversations['group:123'], { mode: 'all', sources: [] });
  assert.deepEqual(state.conversations['private:100000001'], {
    mode: 'selected',
    sources: ['group:987654321', 'private:100000002']
  });
});

test('setAccessPolicy 校验并写入 sources', () => {
  const state = emptyAccessState();
  const bad = setAccessPolicy(state, 'bad', { mode: 'all' });
  assert.equal(bad.ok, false);
  const ok = setAccessPolicy(state, 'group:987654321', {
    mode: 'selected',
    sources: ['group:123456789', 'group:123456789', 'private:100000002']
  });
  assert.equal(ok.ok, true);
  assert.deepEqual(ok.policy, { mode: 'selected', sources: ['group:123456789', 'private:100000002'] });
  assert.deepEqual(getAccessPolicy(state, 'group:987654321', { ownerQQ: OWNER }), {
    mode: 'selected',
    sources: ['group:123456789', 'private:100000002']
  });
});

test('canReadSource 单向：A 能读 B，B 不一定能读 A', () => {
  const state = emptyAccessState();
  setAccessPolicy(state, 'group:987654321', { mode: 'selected', sources: ['group:123456789', 'private:100000002'] });
  assert.equal(canReadSource(state, 'group:987654321', 'group:123456789', { ownerQQ: OWNER }), true);
  assert.equal(canReadSource(state, 'group:987654321', 'private:100000002', { ownerQQ: OWNER }), true);
  assert.equal(canReadSource(state, 'group:123456789', 'group:987654321', { ownerQQ: OWNER }), false);
  assert.equal(canReadSource(state, 'group:987654321', 'group:987654321', { ownerQQ: OWNER }), true); // 本会话
  assert.equal(canReadSource(state, `private:${OWNER}`, 'group:123456789', { ownerQQ: OWNER }), true); // owner 默认 all
});

test('allowedCrossSources 排除本会话，并支持 all/selected/none', () => {
  const known = ['group:987654321', 'group:123456789', 'private:100000002'];
  assert.deepEqual(allowedCrossSources(emptyAccessState(), 'group:987654321', known, { ownerQQ: OWNER }), []);
  const state = emptyAccessState();
  setAccessPolicy(state, 'group:987654321', { mode: 'all' });
  assert.deepEqual(allowedCrossSources(state, 'group:987654321', known, { ownerQQ: OWNER }), ['group:123456789', 'private:100000002']);
  setAccessPolicy(state, 'group:987654321', { mode: 'selected', sources: ['private:100000002'] });
  assert.deepEqual(allowedCrossSources(state, 'group:987654321', known, { ownerQQ: OWNER }), ['private:100000002']);
  assert.deepEqual(allowedCrossSources(state, `private:${OWNER}`, known, { ownerQQ: OWNER }), known);
});

test('listAccessPolicies 合并已知会话与显式策略', () => {
  const state = emptyAccessState();
  setAccessPolicy(state, 'group:987654321', { mode: 'all' });
  const list = listAccessPolicies(state, ['group:987654321', 'private:100000001'], { ownerQQ: OWNER });
  assert.deepEqual(list.map((x) => x.key).sort(), ['group:987654321', 'private:100000001']);
  const group = list.find((x) => x.key === 'group:987654321');
  const owner = list.find((x) => x.key === 'private:100000001');
  assert.equal(group.policy.mode, 'all');
  assert.equal(owner.policy.mode, 'all');
});

console.log('');
console.log(`通过 ${passed} 个测试${process.exitCode ? '（有失败）' : ''}`);
