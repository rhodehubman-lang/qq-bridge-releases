#!/usr/bin/env node
// OneBot 可达性预检：启动桥接前确认 SnowLuma 的 HTTP API 端口是通的。
//
// 为什么需要：桥接连不上 SnowLuma 时日志里是 "SnowLuma 连接断开 / 自愈失败"，
// 朋友看到的却是"机器人不回话"，很难自己定位到「SnowLuma 没启动」。
// 这里用一个 2 秒的 HTTP 探测给出明确中文提示（只提示，不阻塞启动）。
//
// 退出码：0 = 可达；1 = 不可达（提示后仍让 启动.cmd 继续起桥接）；
//         2 = 读不到 config.json（让用户先跑 安装.cmd）。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(path.dirname(fileURLToPath(import.meta.url))));
const CFG_PATH = process.env.QQB_CONFIG_PATH || path.join(ROOT, 'config.json');

/** 读取 config.json 里的 SnowLuma HTTP 地址；读不到返回 {ok:false, reason}。 */
export function readOneBotHttpUrl(cfgPath = CFG_PATH) {
  let text;
  try {
    text = fs.readFileSync(cfgPath, 'utf8').replace(/^\uFEFF/, '');
  } catch {
    return { ok: false, reason: 'missing-config' };
  }
  let cfg;
  try {
    cfg = JSON.parse(text);
  } catch (error) {
    return { ok: false, reason: `config-json-error: ${error.message}` };
  }
  const raw = String(cfg?.snowluma?.httpUrl ?? '').trim();
  if (!raw) return { ok: false, reason: 'no-http-url' };
  try {
    const url = new URL(raw);
    if (!/^https?:$/.test(url.protocol)) return { ok: false, reason: 'bad-protocol' };
    return { ok: true, url: url.toString() };
  } catch {
    return { ok: false, reason: 'bad-url' };
  }
}

/**
 * 探测 OneBot HTTP 端点。
 * 用 GET /get_status（OneBot v11 标准接口）：有 token 的端点会回 401/403，
 * 说明**服务在**但需要鉴权——对预检来说同样算"可达"。
 * @returns {Promise<{reachable:boolean, status?:number, error?:string, elapsedMs:number}>}
 */
export async function probeOneBot({ url, timeoutMs = 2000, fetchImpl = globalThis.fetch } = {}) {
  const startedAt = Date.now();
  if (typeof fetchImpl !== 'function') return { reachable: false, error: 'fetch unavailable', elapsedMs: 0 };
  const base = String(url || '').replace(/\/$/, '');
  try {
    const response = await fetchImpl(`${base}/get_status`, {
      method: 'GET',
      redirect: 'manual',
      signal: AbortSignal.timeout(Math.max(200, Number(timeoutMs) || 2000)),
      headers: { 'user-agent': 'qq-bridge/onebot-preflight' }
    });
    // 401/403 = 服务在，只是要 token；其余 2xx/4xx 也说明端口有人服务。
    return { reachable: true, status: response.status, elapsedMs: Date.now() - startedAt };
  } catch (error) {
    return { reachable: false, error: String(error?.message || error), elapsedMs: Date.now() - startedAt };
  }
}

async function main() {
  const read = readOneBotHttpUrl();
  if (!read.ok) {
    if (read.reason === 'missing-config') {
      console.log('[预检] 还没有 config.json，请先运行「安装.cmd」。');
      process.exit(2);
    }
    console.log(`[预检] config.json 里的 snowluma.httpUrl 不可用（${read.reason}），请先运行「安装.cmd」或手动填写。`);
    process.exit(1);
  }
  const result = await probeOneBot({ url: read.url });
  if (result.reachable) {
    console.log(`[预检] SnowLuma OneBot 可达：${read.url}（HTTP ${result.status}，${result.elapsedMs}ms）`);
    process.exit(0);
  }
  console.log(`[预检] ⚠️ 连不上 SnowLuma（${read.url}）：${result.error || '未知错误'}`);
  console.log('[预检] 请先启动 SnowLuma（launcher.bat），等它显示 listening 且 QQ 在线后，再重新双击「启动QQ桥接」。');
  process.exit(1);
}

const invokedDirectly = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  main().catch((error) => {
    console.error(`[预检] 未预期错误：${error?.stack || error?.message || error}`);
    process.exit(1);
  });
}
