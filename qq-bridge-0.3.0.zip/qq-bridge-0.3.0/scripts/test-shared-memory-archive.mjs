import assert from 'node:assert/strict';
import {
  emptyArchive,
  normalizeArchive,
  archiveExcess,
  searchArchive,
  summarizeArchive
} from '../src/shared-memory-archive.js';
import { emptySharedMemory, appendSharedMemory } from '../src/core/shared-memory-store.js';

function makeActive() {
  const state = emptySharedMemory();
  for (let i = 0; i < 25; i += 1) {
    appendSharedMemory(state, {
      scope: 'group',
      scopeId: '100',
      characterId: 'jill',
      content: `旧城区雨夜记忆 ${i}`,
      importance: i === 3 ? 5 : 3,
      source: { key: 'group:100', kind: 'group', id: '100', name: '测试群' }
    });
  }
  appendSharedMemory(state, {
    scope: 'global',
    characterId: '*',
    content: '全局记忆：Glitch City 永远在下雨',
    importance: 4
  });
  return state;
}

function testCapacity() {
  const active = makeActive();
  const archive = emptyArchive();
  const stats = archiveExcess(active, archive, { maxPerCharacter: 20, maxAgeDays: 365, now: Date.now() });
  assert.equal(stats.moved, 5);
  assert.equal(active.entries.length, 21); // 20* jill + 1 global
  assert.equal(archive.entries.length, 5);
  assert.ok(archive.entries.every((e) => e.characterId === 'jill'));
  assert.ok(archive.entries.every((e) => e.archivedAt > 0));
}

function testAgeAndImportance() {
  const active = makeActive();
  const archive = emptyArchive();
  const old = Date.now() - 200 * 24 * 60 * 60 * 1000;
  for (const entry of active.entries) entry.updatedAt = old;
  const stats = archiveExcess(active, archive, { maxPerCharacter: 100, maxAgeDays: 180, now: Date.now() });
  // importance=5 的条目不按年龄归档
  assert.ok(stats.moved >= 24);
  assert.ok(active.entries.some((e) => e.importance === 5));
}

function testSearch() {
  const active = makeActive();
  const archive = emptyArchive();
  archiveExcess(active, archive, { maxPerCharacter: 10, maxAgeDays: 365, now: Date.now() });
  const hits = searchArchive(archive, { characterId: 'jill', query: '旧城区 雨夜', limit: 5 });
  assert.ok(hits.length > 0);
  assert.match(hits[0].content, /旧城区/);
  const summary = summarizeArchive(archive);
  assert.equal(summary.total, archive.entries.length);
  assert.ok(summary.counts.jill > 0);
}

function testNormalize() {
  const archive = normalizeArchive({ entries: [{ id: 'x', scope: 'global', content: '测试', archivedAt: 123, archiveReason: 'capacity' }] });
  assert.equal(archive.entries.length, 1);
  assert.equal(archive.entries[0].archivedAt, 123);
  assert.equal(archive.entries[0].archiveReason, 'capacity');
}

testCapacity();
testAgeAndImportance();
testSearch();
testNormalize();
console.log('✅ 冷存档测试通过（容量/年龄/检索/规范化）');
