// 更新服务层回归（下载器 + 状态机；网络全部注入假 fetch）。
//
// 钉住：清单获取与缓存、URL 安全、状态机容错、下载校验（sha256/size）、
// 失败不留半成品、prepareUpdate 只写 ready 状态等 helper 执行。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {
  assertSafeUpdateUrl,
  buildUpdateMirrorCandidates,
  checkForUpdatesNow,
  downloadUpdateZip,
  emptyUpdateState,
  fetchManifest,
  normalizeUpdateState,
  prepareUpdate,
  readUpdateState,
  resolveManifestUrl,
  stagingZipPath,
  updateStateFile,
  writeUpdateState
} from '../src/update-service.js';
import { sha256Hex } from '../src/update-engine.js';

let pass = 0;
let fail = 0;
function check(cond, label, extra = '') {
  if (cond) { pass += 1; console.log(`✅ ${label}`); }
  else { fail += 1; console.error(`❌ ${label}${extra ? `：${extra}` : ''}`); }
}
const tmpRoots = [];
function tempRoot(label) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), `qqb-update-${label}-`));
  tmpRoots.push(dir);
  return dir;
}

// ── 假 zip 与清单 ───────────────────────────────────────────────────────────
const zipBuffer = Buffer.from('fake-release-zip-bytes-0123456789');
const zipSha = sha256Hex(zipBuffer);

function makeManifest(overrides = {}) {
  return {
    schema: 1,
    updatedAt: '2026-11-02T12:00:00+08:00',
    recommended: {
      line: '0.3.0', version: '0.3.0-r2', tag: 'v0.3.0-r2',
      asset: 'qq-bridge-0.3.0-r2.zip',
      assetUrl: 'https://example.com/qq-bridge-0.3.0-r2.zip',
      sha256: zipSha, size: zipBuffer.length,
      dshCompat: { min: '0.2.0-rc.2', max: '0.2.1' },
      requiresDshRestart: false,
      notes: '## 更新内容\n- 测试',
      dataSchema: 1, minDataSchema: 1,
      ...(overrides.entry || {})
    },
    lines: {
      '0.3.0': {
        line: '0.3.0', version: '0.3.0-r2', tag: 'v0.3.0-r2',
        asset: 'qq-bridge-0.3.0-r2.zip',
        assetUrl: 'https://example.com/qq-bridge-0.3.0-r2.zip',
        sha256: zipSha, size: zipBuffer.length,
        dshCompat: { min: '0.2.0-rc.2', max: '0.2.1' },
        dataSchema: 1, minDataSchema: 1,
        ...(overrides.entry || {})
      }
    }
  };
}

function fakeFetchFactory({ manifest = makeManifest(), manifestStatus = 200, manifestText = null, zip = zipBuffer, zipStatus = 200, counter = { manifest: 0, zip: 0 } } = {}) {
  return async (url) => {
      if (String(url).includes('latest.json') || String(url).endsWith('.json')) {
        counter.manifest += 1;
        return {
          ok: manifestStatus >= 200 && manifestStatus < 300,
          status: manifestStatus,
          text: async () => (manifestText != null ? manifestText : JSON.stringify(manifest))
        };
      }
      counter.zip += 1;
      return {
        ok: zipStatus >= 200 && zipStatus < 300,
        status: zipStatus,
        arrayBuffer: async () => zip.buffer.slice(zip.byteOffset, zip.byteOffset + zip.byteLength)
      };
  };
}

// ── 1. 更新源 URL ───────────────────────────────────────────────────────────
check(resolveManifestUrl({ repo: 'a/b' }) === 'https://github.com/a/b/releases/latest/download/latest.json', '默认清单地址指向 GitHub Release 附件');
check(resolveManifestUrl({ customManifestUrl: 'https://x.example/latest.json' }) === 'https://x.example/latest.json', '自定义清单地址优先');
check(assertSafeUpdateUrl('https://example.com/a.zip').ok === true, 'URL：https 通过');
check(assertSafeUpdateUrl('http://127.0.0.1:9999/a.json').ok === true, 'URL：本地回环 http 允许（测试）');
check(assertSafeUpdateUrl('http://example.com/a.zip').ok === false, 'URL：公网 http 拒绝');
check(assertSafeUpdateUrl('ftp://example.com/a.zip').ok === false, 'URL：非 http(s) 拒绝');
check(assertSafeUpdateUrl('not a url').ok === false, 'URL：非法字符串拒绝');

// ── 1.5 镜像候选 ───────────────────────────────────────────────────────────
const candidates = buildUpdateMirrorCandidates('https://github.com/a/b/releases/download/v1/x.zip', ['https://ghproxy.net/']);
check(candidates[0] === 'https://github.com/a/b/releases/download/v1/x.zip', '镜像候选：直连优先');
check(candidates[1] === 'https://ghproxy.net/https://github.com/a/b/releases/download/v1/x.zip', '镜像候选：GitHub 加前缀');
const localCandidates = buildUpdateMirrorCandidates('https://example.com/x.zip', ['https://ghproxy.net/']);
check(localCandidates.length === 1, '镜像候选：非 GitHub 源不套镜像');

// ── 2. 状态机 ───────────────────────────────────────────────────────────────
const root1 = tempRoot('state');
const initial = readUpdateState(root1);
check(initial.phase === 'idle' && initial.version === 1, '状态：初始 idle');
const written = writeUpdateState(root1, { phase: 'available', targetVersion: '0.3.0-r2', currentVersion: '0.3.0-r1' });
check(fs.existsSync(updateStateFile(root1)), '状态：写入 state/update.json');
check(written.phase === 'available' && readUpdateState(root1).targetVersion === '0.3.0-r2', '状态：读回一致');
fs.writeFileSync(updateStateFile(root1), '{broken', 'utf8');
check(readUpdateState(root1).phase === 'idle', '状态：损坏文件安全回退 idle');
check(normalizeUpdateState({ phase: 'hacked', size: -5, migratedFiles: 'x' }).phase === 'idle', '状态：非法 phase/size 被纠正');
check(normalizeUpdateState({ restoredFiles: ['a', 1, 'b'] }).restoredFiles.join(',') === 'a,1,b', '状态：恢复文件清单容错');

// ── 2.5 清单镜像回退 ──────────────────────────────────────────────────────
{
  const root = tempRoot('manifest-mirror');
  const seen = [];
  const mirrorFetch = async (url) => {
    seen.push(String(url));
    if (String(url).startsWith('https://github.com/')) throw new Error('fetch failed');
    return { ok: true, status: 200, text: async () => JSON.stringify(makeManifest()) };
  };
  const result = await fetchManifest({ settings: { repo: 'a/b' }, projectRoot: root, fetchImpl: mirrorFetch });
  check(result.ok === true && result.url.includes('ghproxy'), '清单：直连失败后走镜像', result.error);
  check(seen.length >= 2, '清单：确实尝试过多个候选');
}

// ── 3. 清单获取与缓存 ───────────────────────────────────────────────────────
const root2 = tempRoot('manifest');
const counter = { manifest: 0, zip: 0 };
const fake = fakeFetchFactory({ counter });
const settings = { repo: 'a/b', checkIntervalHours: 6 };
const first = await fetchManifest({ settings, projectRoot: root2, fetchImpl: fake });
check(first.ok === true && first.manifest.recommended.version === '0.3.0-r2', '清单：拉取并校验通过', first.error);
check(counter.manifest === 1, '清单：第一次真实请求');
const second = await fetchManifest({ settings, projectRoot: root2, fetchImpl: fake });
check(second.ok === true && second.cached === true && counter.manifest === 1, '清单：缓存期内不重复请求');
const forced = await fetchManifest({ settings, projectRoot: root2, force: true, fetchImpl: fake });
check(forced.ok === true && forced.cached === false && counter.manifest === 2, '清单：force 跳过缓存');
const disabled = await fetchManifest({ settings: { enabled: false }, fetchImpl: fake });
check(disabled.ok === false && disabled.disabled === true, '清单：更新关闭时直接返回 disabled');
const badJson = await fetchManifest({ settings, fetchImpl: fakeFetchFactory({ manifestText: '{oops' }) });
check(badJson.ok === false, '清单：非法 JSON 拒绝');
const httpManifest = await fetchManifest({ settings: { customManifestUrl: 'http://example.com/latest.json' }, fetchImpl: fake });
check(httpManifest.ok === false, '清单：公网 http 源拒绝');
const bigManifest = await fetchManifest({ settings, fetchImpl: fakeFetchFactory({ manifestText: 'x'.repeat(3 * 1024 * 1024) }) });
check(bigManifest.ok === false, '清单：超大响应拒绝');

// ── 4. 检查更新决策 + 状态写入 ──────────────────────────────────────────────
const root3 = tempRoot('check');
const checkFake = fakeFetchFactory();
const available = await checkForUpdatesNow({
  projectRoot: root3, currentVersion: '0.3.0-r1', currentDshVersion: '0.2.1-rc.5',
  currentDataSchema: 1, settings: { repo: 'a/b' }, fetchImpl: checkFake
});
check(available.status === 'available' && available.state.phase === 'available', '检查：发现新版本 → available', available.status);
check(available.state.targetVersion === '0.3.0-r2' && available.state.sha256 === zipSha, '检查：状态记录目标版本与 sha256');
const upToDate = await checkForUpdatesNow({
  projectRoot: root3, currentVersion: '0.3.0-r2', currentDshVersion: '0.2.1-rc.5',
  settings: { repo: 'a/b' }, fetchImpl: checkFake
});
check(upToDate.status === 'up-to-date' && upToDate.state.phase === 'up-to-date', '检查：同版本 → up-to-date');
const crossLineManifest = makeManifest({ entry: { line: '0.4.0', version: '0.4.0-r1' } });
const root4 = tempRoot('cross');
const crossLine = await checkForUpdatesNow({
  projectRoot: root4, currentVersion: '0.3.0-r1', currentDshVersion: '0.2.1-rc.5',
  settings: { repo: 'a/b' }, fetchImpl: fakeFetchFactory({ manifest: crossLineManifest })
});
check(crossLine.status === 'refused' && crossLine.state.phase === 'failed' && /版本线/.test(crossLine.state.error), '检查：跨版本线拒绝并记录原因', crossLine.status);

// ── 5. 下载校验 ─────────────────────────────────────────────────────────────
const root5 = tempRoot('download');
const target = makeManifest().recommended;
const download = await downloadUpdateZip({ projectRoot: root5, target, fetchImpl: fakeFetchFactory() });
check(download.ok === true && fs.existsSync(download.zipPath), '下载：成功落盘', download.error);
check(download.sha256 === zipSha && download.size === zipBuffer.length, '下载：sha256/大小校验通过');
check(!fs.existsSync(`${download.zipPath}.part`), '下载：无 .part 残留');

const root6 = tempRoot('download-bad');
const badSha = await downloadUpdateZip({ projectRoot: root6, target: { ...target, sha256: 'f'.repeat(64) }, fetchImpl: fakeFetchFactory() });
check(badSha.ok === false && /sha256/.test(badSha.error), '下载：sha256 不符拒绝', badSha.error);
check(!fs.existsSync(stagingZipPath(root6, target.version)), '下载：校验失败不留 zip');

const badSize = await downloadUpdateZip({ projectRoot: root6, target: { ...target, size: zipBuffer.length + 1 }, fetchImpl: fakeFetchFactory() });
check(badSize.ok === false && /大小/.test(badSize.error), '下载：大小不符拒绝');

const tooBig = await downloadUpdateZip({ projectRoot: root6, target, maxBytes: 10, fetchImpl: fakeFetchFactory() });
check(tooBig.ok === false && /过大/.test(tooBig.error), '下载：超过上限拒绝');

const httpZip = await downloadUpdateZip({ projectRoot: root6, target: { ...target, assetUrl: 'http://example.com/x.zip' }, fetchImpl: fakeFetchFactory() });
check(httpZip.ok === false, '下载：公网 http 包拒绝');

// ── 5.5 下载镜像回退 ───────────────────────────────────────────────────────
{
  const root = tempRoot('download-mirror');
  const seen = [];
  const mirrorDownload = async (url) => {
    seen.push(String(url));
    if (String(url).startsWith('https://github.com/')) return { ok: false, status: 502 };
    return { ok: true, status: 200, arrayBuffer: async () => zipBuffer.buffer.slice(zipBuffer.byteOffset, zipBuffer.byteOffset + zipBuffer.byteLength) };
  };
  const ghTarget = { ...makeManifest().recommended, assetUrl: 'https://github.com/a/b/releases/download/v1/x.zip' };
  const result = await downloadUpdateZip({ projectRoot: root, target: ghTarget, fetchImpl: mirrorDownload });
  check(result.ok === true, '下载：直连失败后走镜像', result.error);
  check(seen.length >= 2, '下载：确实尝试过多个候选');
}

// ── 6. prepareUpdate：下载 → ready（不动代码）───────────────────────────────
const root7 = tempRoot('prepare');
const prepared = await prepareUpdate({
  projectRoot: root7, target: makeManifest().recommended, currentVersion: '0.3.0-r1', backupBeforeUpdate: true, fetchImpl: fakeFetchFactory()
});
check(prepared.ok === true, '准备更新：成功', prepared.error);
const readyState = readUpdateState(root7);
check(readyState.phase === 'ready' && readyState.zipPath === prepared.zipPath, '准备更新：状态 ready + zipPath');
check(readyState.backupBeforeUpdate === true, '准备更新：记录备份开关');
check(fs.existsSync(readyState.zipPath), '准备更新：zip 文件存在');
const root8 = tempRoot('prepare-fail');
const prepFail = await prepareUpdate({
  projectRoot: root8, target: { ...makeManifest().recommended, sha256: 'f'.repeat(64) }, fetchImpl: fakeFetchFactory()
});
check(prepFail.ok === false && readUpdateState(root8).phase === 'failed', '准备更新：失败写 failed 状态');

// ── 7. 跳过版本 ─────────────────────────────────────────────────────────────
writeUpdateState(root7, { skipVersion: '0.3.0-r2' });
check(readUpdateState(root7).skipVersion === '0.3.0-r2', '状态：记录跳过版本');

// ── 清理 ────────────────────────────────────────────────────────────────────
for (const dir of tmpRoots) fs.rmSync(dir, { recursive: true, force: true });
console.log(`\n=== test-update-service: ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail ? 1 : 0);
