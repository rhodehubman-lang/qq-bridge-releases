import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const html = fs.readFileSync(new URL('../public/console.html', import.meta.url), 'utf8');
const scripts = [];
const re = /<script([^>]*)>([\s\S]*?)<\/script>/gi;
for (const match of html.matchAll(re)) {
  const attrs = match[1] || '';
  if (/\ssrc\s*=/i.test(attrs)) continue;
  scripts.push(match[2]);
}
assert.ok(scripts.length > 0, 'console.html should contain inline script');
for (const [index, source] of scripts.entries()) {
  new vm.Script(source, { filename: `console-inline-${index + 1}.js` });
}
console.log(`console inline scripts: ${scripts.length} block(s) parsed`);
