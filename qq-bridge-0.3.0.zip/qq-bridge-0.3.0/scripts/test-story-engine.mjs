import assert from 'node:assert/strict';
import { emptyStory, buildStoryPrompt, parseStoryOutput, applyCanonToWorld, normalizeCanonUpdates, renumberStory } from '../src/story-engine.js';
import { emptyWorld } from '../src/world-engine.js';

const story = emptyStory('jill');
const prompt = buildStoryPrompt(story, { now: Date.parse('2026-10-26T14:00:00+08:00') });
assert.match(prompt, /Glitch City/);
assert.match(prompt, /JSON/);

const parsed = parseStoryOutput(JSON.stringify({
  title: '雨里的第七码头',
  chapter: 1,
  story: 'Jill 擦完最后一个杯子，雨还在下。',
  summary: 'Jill 在雨里想起旧事。',
  canon_updates: [{
    type: 'event',
    headline: '轻轨 7 号线遭袭',
    detail: '旧城区交通瘫痪。',
    severity: 4,
    locations: ['light_rail'],
    effects: { commuteExtraMinutes: 45, shiftDelayMinutes: 30 }
  }]
}), 1);
assert.equal(parsed.title, '雨里的第七码头');
assert.equal(parsed.canonUpdates.length, 1);
assert.equal(parsed.canonUpdates[0].effects.commuteExtraMinutes, 45);

const world = emptyWorld('jill');
const added = applyCanonToWorld(world, parsed);
assert.equal(added.length, 1);
assert.equal(world.events.length, 1);
assert.equal(world.events[0].known, true);
assert.equal(world.events[0].channel, 'story');

assert.equal(normalizeCanonUpdates([{ type: 'event', headline: '  ' }]).length, 0);

const legacy = {
  chapters: [
    { id: 'a', at: 3, chapter: 1, title: 'A' },
    { id: 'b', at: 1, chapter: 1, title: 'B' },
    { id: 'c', at: 2, chapter: 2, title: 'C' },
    { id: 'p', at: 4, chapter: 1, title: 'P' }
  ],
  pending: { id: 'p', at: 4, chapter: 1, title: 'P' }
};
const fixed = renumberStory(legacy);
assert.deepEqual(fixed.chapters.map((c) => [c.id, c.chapter]), [['b', 1], ['c', 2], ['a', 3]]);
assert.equal(fixed.pending.chapter, 4);
const prompt3 = buildStoryPrompt({ ...emptyStory('jill'), chapters: fixed.chapters, pending: null });
assert.match(prompt3, /本章是第 4 章/);
assert.match(prompt3, /"chapter":4/);

const parsedWrongNumber = parseStoryOutput(JSON.stringify({
  title: '编号测试',
  chapter: 1,
  story: '测试正文',
  summary: '测试摘要'
}), 4);
assert.equal(parsedWrongNumber.chapter, 4);
console.log('✅ 故事引擎测试通过（提示词/解析/canon 应用/章节重编号）');
