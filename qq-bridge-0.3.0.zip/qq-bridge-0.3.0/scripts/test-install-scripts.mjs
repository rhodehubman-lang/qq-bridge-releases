// P3 安装/启动脚本回归。
//
// 覆盖：
//   1) 「安装.cmd」「启动.cmd」编码契约：UTF-8 无 BOM + CRLF（cmd 按 ANSI 读 UTF-8 会乱码）；
//   2) 两个 .cmd 的关键调用链存在（install.mjs / find-dsh-port --write / check-onebot / start.bat）；
//   3) install.mjs 纯函数：参数解析、config 复制、快捷方式计划、依赖命令；
//   4) check-onebot 纯函数：config 读取异常分支 + HTTP 探测（注入 fetch，不碰真实网络）；
//   5) install.mjs --dry-run 冒烟：真的跑一遍，确认不改文件；
//   6) 安装.cmd --dry-run 冒烟（Windows）：验证中文路径/UTF-8 批处理能跑通；
//   7) 桌面快捷方式创建（Windows，PowerShell/COM，环境不支持时 SKIP 而不是假失败）。
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import {
  autoConfigureSnowLuma,
  createInstallLogger,
  createShortcuts,
  dependencyCommand,
  ensureConfigFile,
  parseInstallArgs,
  shortcutPlan
} from '../scripts/install.mjs';
import { probeOneBot, readOneBotHttpUrl } from '../scripts/check-onebot.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const IS_WINDOWS = process.platform === 'win32';
let pass = 0;
let fail = 0;
function check(cond, label, extra = '') {
  if (cond) { pass += 1; console.log(`✅ ${label}`); }
  else { fail += 1; console.error(`❌ ${label}${extra ? `：${extra}` : ''}`); }
}
function skip(label, reason) { console.log(`⏭  ${label}（跳过：${reason}）`); }

// ── 1. 两个 .cmd 的编码契约 ──────────────────────────────────────────────────
for (const name of ['安装.cmd', '启动.cmd']) {
  const file = path.join(ROOT, name);
  check(fs.existsSync(file), `存在 ${name}`);
  if (!fs.existsSync(file)) continue;
  const buf = fs.readFileSync(file);
  check(buf[0] !== 0xEF && buf[1] !== 0xBB && buf[2] !== 0xBF, `${name} 无 UTF-8 BOM（cmd 不认 BOM）`);
  const lf = buf.toString('latin1').match(/(?<!\r)\n/g)?.length ?? 0;
  check(lf === 0, `${name} 使用 CRLF（发现 ${lf} 个裸 LF）`);
  check(buf.toString('utf8').includes('chcp 65001'), `${name} 开头切换 UTF-8 代码页`);
}

// ── 2. 调用链 ───────────────────────────────────────────────────────────────
const installer = fs.readFileSync(path.join(ROOT, '安装.cmd'), 'utf8');
check(installer.includes('scripts\\install.mjs'), '安装.cmd 调用 scripts\\install.mjs');
check(installer.includes('node.cmd'), '安装.cmd 使用 node.cmd（无系统 Node 也能跑）');
const launcher = fs.readFileSync(path.join(ROOT, '启动.cmd'), 'utf8');
for (const needle of ['find-dsh-port.mjs', '--write', 'check-onebot.mjs', 'start.bat']) {
  check(launcher.includes(needle), `启动.cmd 包含 ${needle}`);
}

// ── 2.5 node.cmd 的运行时发现（2026-10-31 VM 首装失败点）────────────────────
// 桌面版把 Node 运行时放在安装目录里，不在 ~/.dsh/dsh-runtimes；干净 Windows 上
// 也没有系统 Node。shim 必须覆盖这两种位置，找不到时返回 127 并给人话提示。
{
  const shim = path.join(ROOT, 'node.cmd');
  const buf = fs.readFileSync(shim);
  const text = buf.toString('latin1');
  check(buf[0] !== 0xEF, 'node.cmd 无 UTF-8 BOM');
  check((text.match(/(?<!\r)\n/g)?.length ?? 0) === 0, 'node.cmd 使用 CRLF');
  check(text.includes('DeepSeek Harness'), 'node.cmd 覆盖 DSH 桌面版安装目录');
  check(text.includes('dsh-runtimes'), 'node.cmd 覆盖 ~/.dsh 运行时');
  if (IS_WINDOWS) {
    const okRun = spawnSync(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', `call "${shim}" --version`], {
      cwd: ROOT, encoding: 'utf8', windowsVerbatimArguments: true
    });
    check(okRun.status === 0 && /^v\d+\./m.test(okRun.stdout || ''), 'node.cmd 能启动 Node',
      `status=${okRun.status} ${(okRun.stderr || '').trim().slice(0, 120)}`);
    // 负向：把所有候选位置清空，应返回 127 并提示（而不是空输出或 0）。
    const empty = fs.mkdtempSync(path.join(os.tmpdir(), 'qqb-empty-'));
    const bin = path.join(empty, 'bin');
    fs.mkdirSync(bin);
    const negRun = spawnSync(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', `call "${shim}" --version`], {
      cwd: ROOT, encoding: 'utf8', windowsVerbatimArguments: true,
      env: {
        SystemRoot: process.env.SystemRoot || 'C:\\Windows',
        ComSpec: process.env.ComSpec || 'C:\\Windows\\System32\\cmd.exe',
        PATH: bin, LOCALAPPDATA: empty, PROGRAMFILES: empty, USERPROFILE: empty,
        TEMP: empty, TMP: empty
      }
    });
    check(negRun.status === 127, 'node.cmd 找不到 Node 时返回 127', `status=${negRun.status}`);
    check(`${negRun.stdout}${negRun.stderr}`.includes('[node.cmd]'), 'node.cmd 找不到 Node 时有提示');
    fs.rmSync(empty, { recursive: true, force: true });
  } else {
    skip('node.cmd 运行时冒烟', '非 Windows');
  }
}

// ── 3. install.mjs 纯函数 ───────────────────────────────────────────────────
const parsed = parseInstallArgs(['--dry-run', '--no-deps', '--no-shortcuts', '--desktop-dir', 'D:/tmp/x', '--log', 'D:/tmp/install.log']);
check(parsed.dryRun && parsed.noDeps && parsed.noShortcuts && parsed.desktopDir === 'D:/tmp/x', '参数解析');
check(parsed.logPath === 'D:/tmp/install.log', '参数解析：--log');
const parsedEq = parseInstallArgs(['--log=D:/tmp/eq.log']);
check(parsedEq.logPath === 'D:/tmp/eq.log', '参数解析：--log= 形式');
let threw = false;
try { parseInstallArgs(['--nonsense']); } catch { threw = true; }
check(threw, '未知参数抛错');

const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'qqb-install-test-'));
fs.writeFileSync(path.join(tmpRoot, 'config.example.json'), '{"dsh":{}}\n', 'utf8');

// 安装日志镜像：控制台照常、文件是 UTF-8 逐行中文（不经过 PowerShell 管道）
const logFile = path.join(tmpRoot, 'install.log');
const logger = createInstallLogger(logFile);
logger('第一条');
logger('第二条');
const logText = fs.readFileSync(logFile, 'utf8');
check(logText.includes('[安装] 第一条') && logText.includes('[安装] 第二条'), '日志镜像：逐行写入 UTF-8');
check(logText.split('\n')[0].startsWith('[安装]'), '日志镜像：每行带前缀');
const cfg1 = ensureConfigFile(tmpRoot);
check(cfg1.created === true && fs.existsSync(path.join(tmpRoot, 'config.json')), 'config.json 从模板创建');
const cfg2 = ensureConfigFile(tmpRoot);
check(cfg2.created === false, 'config.json 已存在时不动');
fs.rmSync(path.join(tmpRoot, 'config.json'));
const dryCfg = ensureConfigFile(tmpRoot, { dryRun: true });
check(dryCfg.wouldCreate === true && !fs.existsSync(path.join(tmpRoot, 'config.json')), 'dry-run 不落盘 config.json');

const plan = shortcutPlan(ROOT);
check(plan.length === 2 && plan[0].target.endsWith('启动.cmd') && plan[1].url.startsWith('http://127.0.0.1:'), '快捷方式计划');
check(dependencyCommand(ROOT).includes('install'), `依赖命令可用（${dependencyCommand(ROOT)}）`);

// ── 4. check-onebot 纯函数 ──────────────────────────────────────────────────
const cfgPath = path.join(tmpRoot, 'cb.json');
check(readOneBotHttpUrl(cfgPath).reason === 'missing-config', '预检：缺 config 识别为 missing-config');
fs.writeFileSync(cfgPath, '{broken', 'utf8');
check(String(readOneBotHttpUrl(cfgPath).reason).startsWith('config-json-error'), '预检：损坏 config 报解析错误');
fs.writeFileSync(cfgPath, JSON.stringify({ snowluma: {} }), 'utf8');
check(readOneBotHttpUrl(cfgPath).reason === 'no-http-url', '预检：缺 httpUrl 识别');
fs.writeFileSync(cfgPath, JSON.stringify({ snowluma: { httpUrl: 'http://127.0.0.1:3000' } }), 'utf8');
const read = readOneBotHttpUrl(cfgPath);
check(read.ok && read.url === 'http://127.0.0.1:3000/', '预检：合法 httpUrl 解析');

const okProbe = await probeOneBot({ url: 'http://127.0.0.1:3000', fetchImpl: async () => ({ status: 401, text: async () => '' }) });
check(okProbe.reachable === true && okProbe.status === 401, '预检：401 视为服务可达');
const downProbe = await probeOneBot({ url: 'http://127.0.0.1:3000', fetchImpl: async () => { throw new Error('ECONNREFUSED'); } });
check(downProbe.reachable === false && /ECONNREFUSED/.test(downProbe.error), '预检：连接失败判不可达');

// ── 4.5 SnowLuma 自动发现（注入 discoverImpl，不碰真实网络）────────────────
const slCfg = path.join(tmpRoot, 'sl.json');
fs.writeFileSync(slCfg, JSON.stringify({
  snowluma: { wsUrl: 'ws://127.0.0.1:3001', httpUrl: 'http://127.0.0.1:3000', accessToken: '' }
}), 'utf8');
const autoOk = await autoConfigureSnowLuma({
  root: tmpRoot,
  cfgPath: slCfg,
  log: () => {},
  discoverImpl: async () => ({
    ok: true, baseUrl: 'http://127.0.0.1:4100/', token: 'tok-123',
    self: { nickname: '测试号', user_id: 12345 }
  })
});
const slAfter = JSON.parse(fs.readFileSync(slCfg, 'utf8'));
check(autoOk.ok === true, '自动发现：返回成功');
check(slAfter.snowluma.accessToken === 'tok-123', '自动发现：写回 accessToken');
check(slAfter.snowluma.httpUrl === 'http://127.0.0.1:4100', '自动发现：写回 HTTP 地址（去尾斜杠）');
check(slAfter.snowluma.wsUrl === 'ws://127.0.0.1:3001', '自动发现：无 WS 信息时保留原 wsUrl');
const autoFail = await autoConfigureSnowLuma({
  root: tmpRoot,
  cfgPath: slCfg,
  log: () => {},
  discoverImpl: async () => ({ ok: false, error: 'ECONNREFUSED' })
});
check(autoFail.ok === false, '自动发现失败：不抛错');
check(JSON.parse(fs.readFileSync(slCfg, 'utf8')).snowluma.accessToken === 'tok-123', '自动发现失败：不破坏已写入的配置');
const autoMissing = await autoConfigureSnowLuma({ root: tmpRoot, cfgPath: path.join(tmpRoot, 'no-such-config.json'), log: () => {} });
check(autoMissing.ok === false && autoMissing.reason === 'config-unreadable', '自动发现：config 不可读时安全失败');

// ── 5. install.mjs --dry-run 冒烟（真实进程，不改文件）──────────────────────
const configFile = path.join(ROOT, 'config.json');
const before = fs.existsSync(configFile) ? fs.statSync(configFile) : null;
const dryLog = path.join(tmpRoot, 'dry-run.log');
const run = spawnSync(process.execPath, [path.join(ROOT, 'scripts', 'install.mjs'), '--dry-run', '--no-deps', '--no-shortcuts', '--log', dryLog], {
  cwd: ROOT, encoding: 'utf8', timeout: 30000,
});
check(run.status === 0, 'install.mjs --dry-run 退出码 0', `${run.status} ${(run.stderr || '').trim().slice(0, 300)}`);
check((run.stdout || '').includes('[dry-run]'), 'install.mjs --dry-run 有 dry-run 标记');
check(fs.existsSync(dryLog) && fs.readFileSync(dryLog, 'utf8').includes('[安装] 安装目录'), 'install.mjs --log 写出 UTF-8 中文日志');
const after = fs.existsSync(configFile) ? fs.statSync(configFile) : null;
check(
  (before && after && before.mtimeMs === after.mtimeMs && before.size === after.size) || (!before && !after),
  'install.mjs --dry-run 未改动 config.json'
);

// ── 6. 安装.cmd --dry-run 冒烟（Windows，验证中文路径 + UTF-8 批处理）────────
if (IS_WINDOWS) {
  const bat = path.join(ROOT, '安装.cmd');
  const r = spawnSync(process.env.ComSpec || 'cmd.exe', [
    '/d', '/s', '/c', `call "${bat}" --dry-run --no-deps --no-shortcuts`
  ], { cwd: ROOT, encoding: 'utf8', timeout: 60000, windowsVerbatimArguments: true });
  const out = `${r.stdout || ''}${r.stderr || ''}`;
  check(r.status === 0, '安装.cmd --dry-run 退出码 0', `${r.status} ${out.slice(-200)}`);
  check(out.includes('[安装]'), '安装.cmd 输出中文提示（UTF-8 批处理正常）');
  check(out.includes('[dry-run]'), '安装.cmd 透传了 dry-run 参数');
} else {
  skip('安装.cmd 冒烟', '非 Windows');
}

// ── 7. 桌面快捷方式（Windows，环境不支持时 SKIP）────────────────────────────
if (IS_WINDOWS) {
  const desktop = fs.mkdtempSync(path.join(os.tmpdir(), 'qqb-desktop-'));
  const result = createShortcuts({ root: ROOT, desktopDir: desktop });
  if (result.ok) {
    check(fs.existsSync(path.join(desktop, '启动QQ桥接.lnk')), '创建桌面 .lnk 快捷方式');
    const urlFile = path.join(desktop, 'QQ桥接控制台.url');
    check(fs.existsSync(urlFile), '创建控制台 .url 快捷方式');
    if (fs.existsSync(urlFile)) {
      check(fs.readFileSync(urlFile, 'utf8').includes('http://127.0.0.1:3100/'), '.url 指向控制台');
    }
  } else {
    skip('桌面快捷方式创建', `PowerShell/COM 不可用：${result.reason}`);
  }
  fs.rmSync(desktop, { recursive: true, force: true });
} else {
  skip('桌面快捷方式', '非 Windows');
}

fs.rmSync(tmpRoot, { recursive: true, force: true });
console.log(`\n=== test-install-scripts: ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail ? 1 : 0);
