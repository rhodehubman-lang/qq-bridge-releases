import assert from 'node:assert/strict';
import {
  buildWorldEventsPrompt,
  classifyWorldEvents,
  emptyWorldEventsState,
  normalizeWorldEventItem,
  normalizeWorldEventsConfig,
  normalizeWorldEventsState,
  parseWorldEventsOutput
} from '../src/world-events.js';

const now = Date.parse('2026-10-28T08:00:00+08:00');

const config = normalizeWorldEventsConfig({ time: '25:99', maxOutputTokens: 99999, auto: false });
assert.equal(config.time, '08:00');
assert.equal(config.maxOutputTokens, 4000);
assert.equal(config.auto, false);

const empty = emptyWorldEventsState('glitch');
assert.equal(empty.worldId, 'glitch');
assert.deepEqual(empty.pending, []);

const output = parseWorldEventsOutput(`模型输出如下：
\`\`\`json
{"events":[
  {"headline":"旧城区地铁站临时关闭","detail":"站台挤满了人，官方只说信号故障。","type":"transit","channel":"news","severity":3,"major":true,"locations":["old_town"],"effects":{"commuteExtraMinutes":999}},
  {"headline":"点唱机又卡带了","detail":"Dana 踢了机器两脚，然后放回最后一瓶 Karmine。","type":"bar","channel":"local","severity":1,"major":false,"locations":["va11_bar"],"effects":{"moodDelta":-99}}
]}
\`\`\``);
assert.equal(output.length, 2);
assert.equal(output[0].major, true);
assert.equal(output[0].effects.commuteExtraMinutes, 180);
assert.equal(output[1].effects.moodDelta, -10);
assert.equal(output[0].known, false);
assert.equal(output[0].source, 'llm');

// 模型全给小事时，自动把最重的一条升为大事，保证审核入口
const promoted = classifyWorldEvents([
  { headline: '雨下了一整天', detail: '窗外的霓虹被雨水泡开。', type: 'weather', severity: 1 },
  { headline: '广告屏又换了', detail: '新广告的笑脸比真人还真。', type: 'city', severity: 2 }
]);
assert.equal(promoted.filter((item) => item.major).length, 1);

assert.throws(() => parseWorldEventsOutput('没有 JSON'), /没有 JSON|JSON 解析/);
assert.throws(() => parseWorldEventsOutput('{"events":[]}'), /缺少|没有有效/);

const prompt = buildWorldEventsPrompt({
  world: { name: 'Glitch City' },
  profile: { roleName: 'Jill', locations: [{ id: 'va11_bar', name: 'VA-11 HALL-A' }] },
  now,
  recentEvents: [{ headline: '旧新闻' }]
});
assert.match(prompt, /1 条大事件/);
assert.match(prompt, /JSON/);
assert.match(prompt, /不改变角色的硬日程/);
assert.match(prompt, /旧新闻/);

const state = normalizeWorldEventsState({
  config: { enabled: false },
  pending: [{ headline: '待审事件', detail: '这是一条足够长的待审核事件描述。', severity: 4 }]
}, 'glitch');
assert.equal(state.config.enabled, false);
assert.equal(state.pending.length, 1);
assert.equal(state.pending[0].status, 'pending');

const event = normalizeWorldEventItem({ headline: '太短', detail: '短' });
assert.equal(event, null);

console.log('✅ 世界事件测试通过（提示词/解析/大小事件/归档字段）');
