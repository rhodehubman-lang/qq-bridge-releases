#!/usr/bin/env node
// 手动/定时备份命令行。只操作固定用户数据，不含 node_modules、日志、备份自身。
//
// 用法：
//   node scripts/backup.mjs                      立即备份一次
//   node scripts/backup.mjs --label manual       带标签
//   node scripts/backup.mjs --list               列出备份
//   node scripts/backup.mjs --restore <名字> --confirm RESTORE
//   node scripts/backup.mjs --json               输出 JSON（给外部调度用）

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  createBackup,
  listBackups,
  readBackupSettings,
  restoreBackup,
  formatBytes
} from '../src/backup.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

function usage() {
  console.error('用法：node scripts/backup.mjs [--label 名称] [--list] [--restore 备份目录|名字 --confirm RESTORE] [--json]');
}

function parseArgs(argv) {
  const out = { label: 'manual', list: false, restore: '', confirm: '', json: false };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--list') out.list = true;
    else if (arg === '--json') out.json = true;
    else if (arg === '--label') out.label = argv[++i] ?? '';
    else if (arg === '--restore') out.restore = argv[++i] ?? '';
    else if (arg === '--confirm') out.confirm = argv[++i] ?? '';
    else if (arg === '--help' || arg === '-h') { usage(); process.exit(0); }
    else { console.error(`未知参数：${arg}`); usage(); process.exit(2); }
  }
  return out;
}

const args = parseArgs(process.argv.slice(2));
const settings = readBackupSettings(ROOT);

try {
  if (args.list) {
    const list = await listBackups(ROOT, settings);
    if (args.json) {
      console.log(JSON.stringify({ ok: true, backups: list }, null, 2));
    } else if (!list.length) {
      console.log('还没有备份。');
    } else {
      console.log(`共 ${list.length} 份备份：`);
      for (const item of list) {
        console.log(`- ${item.name}  ${item.createdAt}  ${formatBytes(item.bytes)}  ${item.files} 文件  ${item.path}`);
      }
    }
    process.exit(0);
  }

  if (args.restore) {
    const list = await listBackups(ROOT, settings);
    const match = list.find((x) => x.name === args.restore)
      ?? list.find((x) => x.path === args.restore)
      ?? (fs.existsSync(args.restore) ? { name: path.basename(args.restore), path: path.resolve(args.restore) } : null);
    if (!match) {
      console.error(`找不到备份：${args.restore}`);
      process.exit(1);
    }
    const result = await restoreBackup(ROOT, match.path, {
      confirm: args.confirm,
      settings
    });
    if (args.json) console.log(JSON.stringify(result, null, 2));
    else {
      console.log(`已恢复：${result.restored.join(', ')}`);
      console.log(`恢复前自动备份：${result.emergencyBackup}`);
    }
    process.exit(0);
  }

  const result = await createBackup(ROOT, { label: args.label, settings });
  if (args.json) {
    console.log(JSON.stringify({
      ok: true,
      name: result.name,
      path: result.path,
      bytes: result.manifest.stats.bytes,
      files: result.manifest.stats.files,
      pruned: result.pruned.removed
    }, null, 2));
  } else {
    console.log(`备份完成：${result.name}`);
    console.log(`位置：${result.path}`);
    console.log(`大小：${formatBytes(result.manifest.stats.bytes)}，${result.manifest.stats.files} 个文件`);
    if (result.pruned.removed.length) console.log(`已清理旧备份：${result.pruned.removed.join(', ')}`);
  }
} catch (error) {
  console.error(`备份失败：${error?.message ?? error}`);
  process.exit(1);
}
