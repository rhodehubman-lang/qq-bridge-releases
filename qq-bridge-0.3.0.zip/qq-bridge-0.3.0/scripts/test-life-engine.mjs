// 生活引擎单元测试：固定时钟，不依赖当前时间。
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  applyLifePlan,
  calendarForProfile,
  dayTypeFor,
  formatLifePrompt,
  normalizeLifeProfile,
  resolveLifeState,
  validateLifeProfile
} from '../src/life-engine.js';

const profile = JSON.parse(fs.readFileSync(new URL('../life-profiles/jill.json', import.meta.url), 'utf8'));
const at = (iso) => Date.parse(iso);

let passed = 0;
function test(name, fn) {
  try { fn(); passed += 1; console.log(`✅ ${name}`); }
  catch (error) { console.error(`❌ ${name}`); console.error(error); process.exitCode = 1; }
}

test('档案校验：Jill 的默认档案合法', () => {
  const result = validateLifeProfile(profile);
  assert.equal(result.ok, true, result.errors.join('; '));
  assert.equal(result.profile.id, 'jill');
  assert.equal(result.profile.schedule.shift.start, '09:00');
});

test('上5休2：周一到周五上班，周末休息', () => {
  assert.equal(dayTypeFor(profile, '2026-10-26'), 'work'); // 周一
  assert.equal(dayTypeFor(profile, '2026-10-30'), 'work'); // 周五
  assert.equal(dayTypeFor(profile, '2026-10-31'), 'rest'); // 周六
  assert.equal(dayTypeFor(profile, '2026-11-01'), 'rest'); // 周日
  assert.equal(dayTypeFor(profile, '2026-11-02'), 'work'); // 下周一
});

test('日历预览：7 天显示 5 上 2 休', () => {
  const days = calendarForProfile(profile, '2026-10-26', 7);
  assert.deepEqual(days.map((x) => x.dayType), ['work', 'work', 'work', 'work', 'work', 'rest', 'rest']);
});

test('工作日 07:45：刚起床，在家', () => {
  const state = resolveLifeState(profile, {}, at('2026-10-27T07:45:00+08:00'));
  assert.equal(state.state, 'waking');
  assert.equal(state.locationId, 'jill_apartment');
  assert.match(state.activity, /刚醒/);
});

test('工作日 08:45：通勤路上', () => {
  const state = resolveLifeState(profile, {}, at('2026-10-27T08:45:00+08:00'));
  assert.equal(state.state, 'commute');
  assert.equal(state.locationId, '__commute__');
});

test('工作日 10:00：在酒吧上班', () => {
  const state = resolveLifeState(profile, {}, at('2026-10-27T10:00:00+08:00'));
  assert.equal(state.state, 'working');
  assert.equal(state.locationId, 'va11_bar');
});

test('工作日 19:00：下班自由时间，默认在家', () => {
  const state = resolveLifeState(profile, {}, at('2026-10-27T19:00:00+08:00'));
  assert.equal(state.state, 'free');
  assert.equal(state.locationId, 'jill_apartment');
  assert.match(state.activity, /唱片|书|自由/);
});

test('深夜 23:30：睡觉', () => {
  const state = resolveLifeState(profile, {}, at('2026-10-27T23:30:00+08:00'));
  assert.equal(state.state, 'sleeping');
  assert.equal(state.locationId, 'jill_apartment');
});

test('休息日 10:00：自由时间，不去上班', () => {
  const state = resolveLifeState(profile, {}, at('2026-10-31T10:00:00+08:00'));
  assert.equal(state.dayType, 'rest');
  assert.equal(state.state, 'free');
  assert.equal(state.locationId, 'jill_apartment');
});

test('自由时段可以 AI 选择地点并持久化；上班时不能改', () => {
  const evening = at('2026-10-27T19:00:00+08:00');
  const plan = applyLifePlan(profile, {}, { locationId: 'old_town', activity: '在旧城区闲逛' }, evening);
  assert.equal(plan.ok, true);
  assert.equal(plan.state.state, 'free');
  assert.equal(plan.state.locationId, 'old_town');
  assert.equal(plan.state.activity, '在旧城区闲逛');
  const again = resolveLifeState(profile, plan.persisted, evening);
  assert.equal(again.locationId, 'old_town');
  const bad = applyLifePlan(profile, plan.persisted, { locationId: 'va11_bar', activity: '摸鱼' }, at('2026-10-27T10:00:00+08:00'));
  assert.equal(bad.ok, false);
  const badPlace = applyLifePlan(profile, plan.persisted, { locationId: 'moon', activity: '看月亮' }, evening);
  assert.equal(badPlace.ok, false);
});

test('提示词包含时间、状态、地点、行为规则，并明确不要解释日程', () => {
  const state = resolveLifeState(profile, {}, at('2026-10-27T10:00:00+08:00'));
  const text = formatLifePrompt(profile, state);
  assert.match(text, /2026-10-27 10:00 周二/);
  assert.match(text, /上班中/);
  assert.match(text, /VA-11 HALL-A/);
  assert.match(text, /行为规则/);
  assert.match(text, /不要主动解释/);
});

test('日期例外覆盖：指定 2026-10-27 休息', () => {
  const modified = normalizeLifeProfile({ ...profile, schedule: { ...profile.schedule, overrides: { '2026-10-27': 'rest' } } });
  assert.equal(dayTypeFor(modified, '2026-10-27'), 'rest');
  const state = resolveLifeState(modified, {}, at('2026-10-27T10:00:00+08:00'));
  assert.equal(state.state, 'free');
});

console.log('');
console.log(`通过 ${passed} 个测试${process.exitCode ? '（有失败）' : ''}`);
