#!/usr/bin/env bash
# QQ Bridge update helper (Linux). Same env contract as update-helper.ps1:
#   QQB_ROOT, QQB_ZIP, QQB_FROM_VERSION, QQB_TO_VERSION, QQB_LAUNCHER,
#   QQB_BACKUP (1/0), QQB_NODE (node binary, default: node), QQB_HEALTH_MS
# Exit codes: 0 done, 2 rolled back, 3 failed before touching anything.
set -u

log() { echo "[update-helper] $(date +%H:%M:%S) $*"; }

root=${QQB_ROOT:-}
zip_path=${QQB_ZIP:-}
from_version=${QQB_FROM_VERSION:-unknown}
to_version=${QQB_TO_VERSION:-}
launcher=${QQB_LAUNCHER:-}
do_backup=${QQB_BACKUP:-1}
node_bin=${QQB_NODE:-node}
health_ms=${QQB_HEALTH_MS:-120000}

if [ -z "$root" ] || [ ! -d "$root" ]; then log "QQB_ROOT invalid"; exit 3; fi
if [ -z "$zip_path" ] || [ ! -f "$zip_path" ]; then log "QQB_ZIP missing"; exit 3; fi
if [ -z "$to_version" ]; then log "QQB_TO_VERSION missing"; exit 3; fi

state_dir="$root/state"
state_file="$state_dir/update.json"
result_file="$state_dir/update-result.json"
lock_file="$state_dir/bridge.lock"
stamp=$(date +%Y%m%d-%H%M%S)
backup_root="$root/_backups/update"
backup_dir="$backup_root/$from_version-$stamp"
tmp_root="$root/_update_tmp_$stamp"
log_file="$backup_dir/helper.log"

code_dirs="src public scripts dsh plugins ops docs assets migrations"
code_files="README.md README.en.md CHANGELOG.md LICENSE RULES.md config.example.json package.json package-lock.json pnpm-lock.yaml node.cmd pnpm.cmd start.bat restart.bat"
user_items="config.json state roles life-profiles osts audio"

append_log() {
  if [ -d "$backup_dir" ]; then echo "$1" >> "$log_file"; fi
}
log2() { log "$*"; append_log "[update-helper] $(date +%H:%M:%S) $*"; }

write_state() {
  "$node_bin" -e '
    const fs = require("fs");
    const path = require("path");
    const file = process.env.STATE_FILE;
    let state = {};
    try { state = JSON.parse(fs.readFileSync(file, "utf8")); } catch {}
    const patch = JSON.parse(process.env.PATCH_JSON);
    Object.assign(state, patch, { at: Date.now() });
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(state, null, 2) + "\n", "utf8");
  ' 2>/dev/null || true
}

stop_bridge() {
  if [ ! -f "$lock_file" ]; then return; fi
  pid=$(tr -d ' \r\n' < "$lock_file" 2>/dev/null || true)
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    log2 "waiting bridge (pid $pid) to exit..."
    for i in $(seq 1 150); do sleep 0.2; kill -0 "$pid" 2>/dev/null || break; done
    if kill -0 "$pid" 2>/dev/null; then log2 "terminating bridge $pid"; kill -9 "$pid" 2>/dev/null || true; sleep 0.5; fi
  fi
  rm -f "$lock_file"
}

backup_current() {
  mkdir -p "$backup_dir"
  for d in $code_dirs; do [ -e "$root/$d" ] && cp -a "$root/$d" "$backup_dir/"; done
  for f in $code_files; do [ -e "$root/$f" ] && cp -a "$root/$f" "$backup_dir/"; done
  for u in $user_items; do [ -e "$root/$u" ] && cp -a "$root/$u" "$backup_dir/"; done
  [ -n "$launcher" ] && [ -e "$root/$launcher" ] && cp -a "$root/$launcher" "$backup_dir/"
  log2 "backup created: $backup_dir"
}

extract_new_zip() {
  top="qq-bridge-$to_version"
  if command -v unzip >/dev/null 2>&1; then
    unzip -Z1 "$zip_path" | while read -r name; do
      case "$name" in
        "$top"/*) ;;
        *) log2 "unexpected zip layout: $name"; exit 3 ;;
      esac
      case "$name" in ../*|/*|*..*) log2 "unsafe zip entry: $name"; exit 3 ;; esac
    done
    rm -rf "$tmp_root"; mkdir -p "$tmp_root"
    unzip -q "$zip_path" -d "$tmp_root" || { log2 "unzip failed"; exit 3; }
  elif command -v tar >/dev/null 2>&1; then
    rm -rf "$tmp_root"; mkdir -p "$tmp_root"
    tar -xf "$zip_path" -C "$tmp_root" || { log2 "tar extract failed"; exit 3; }
  else
    log2 "no unzip/tar available"; exit 3
  fi
  if [ ! -d "$tmp_root/$top" ]; then log2 "extracted root missing: $tmp_root/$top"; exit 3; fi
  echo "$tmp_root/$top"
}

replace_code() {
  src=$1
  for d in $code_dirs; do [ -d "$src/$d" ] && cp -a "$src/$d" "$root/"; done
  for f in $code_files; do [ -f "$src/$f" ] && cp -a "$src/$f" "$root/"; done
  [ -n "$launcher" ] && [ -f "$src/$launcher" ] && cp -a "$src/$launcher" "$root/"
  log2 "code replaced from new zip"
}

restore_user_items() {
  for u in $user_items; do
    if [ -e "$backup_dir/$u" ]; then
      rm -rf "${root:?}/$u"
      cp -a "$backup_dir/$u" "$root/"
    fi
  done
  log2 "user files restored from backup"
}

restore_all() {
  for d in $code_dirs; do
    if [ -e "$backup_dir/$d" ]; then rm -rf "${root:?}/$d"; cp -a "$backup_dir/$d" "$root/"; fi
  done
  for f in $code_files; do [ -e "$backup_dir/$f" ] && cp -a "$backup_dir/$f" "$root/"; done
  [ -n "$launcher" ] && [ -e "$backup_dir/$launcher" ] && cp -a "$backup_dir/$launcher" "$root/"
  restore_user_items
  log2 "rollback: code + user files restored from backup"
}

run_migrations() {
  script="$root/scripts/migrate-data.mjs"
  [ -f "$script" ] || { log2 "migrate-data.mjs missing, skip"; return 0; }
  log2 "running data migrations..."
  out=$("$node_bin" "$script" --apply --json 2>&1)
  code=$?
  if [ $code -ne 0 ]; then log2 "migration failed: $out"; return 1; fi
  log2 "migrations done"
  return 0
}

file_hash() {
  if [ -f "$1" ]; then sha256sum "$1" | awk '{print $1}'; fi
}

maybe_install_deps() {
  old_pkg=$(file_hash "$backup_dir/package.json")
  new_pkg=$(file_hash "$root/package.json")
  old_lock=$(file_hash "$backup_dir/pnpm-lock.yaml")
  new_lock=$(file_hash "$root/pnpm-lock.yaml")
  if [ "$old_pkg" = "$new_pkg" ] && [ "$old_lock" = "$new_lock" ]; then log2 "dependency files unchanged"; return 0; fi
  if [ -f "$root/pnpm.cmd" ]; then
    log2 "pnpm.cmd present on Linux, skip"; return 0
  fi
  if command -v pnpm >/dev/null 2>&1; then
    log2 "installing dependencies..."
    (cd "$root" && pnpm install) || { log2 "pnpm install failed"; return 1; }
  else
    log2 "pnpm not found, skip dependency install"
  fi
}

start_launcher() {
  [ -n "$launcher" ] || { log2 "no launcher configured"; return 1; }
  [ -e "$root/$launcher" ] || { log2 "launcher missing: $launcher"; return 1; }
  ( cd "$root" && nohup sh "./$launcher" >/dev/null 2>&1 & ) || true
  log2 "launcher started: $launcher"
}

wait_done() {
  deadline=$(( $(date +%s) + health_ms / 1000 ))
  while [ "$(date +%s)" -lt "$deadline" ]; do
    sleep 1
    phase=$("$node_bin" -e 'const fs=require("fs");try{process.stdout.write(JSON.parse(fs.readFileSync(process.env.STATE_FILE,"utf8")).phase||"")}catch{}' 2>/dev/null || true)
    if [ "$phase" = "done" ]; then return 0; fi
    if [ "$phase" = "failed" ]; then return 1; fi
  done
  return 1
}

rollback() {
  reason=$1
  log2 "ROLLBACK: $reason"
  stop_bridge 2>/dev/null || true
  restore_all 2>/dev/null || log2 "rollback restore failed"
  STATE_FILE="$state_file" PATCH_JSON="{\"phase\":\"rolled-back\",\"error\":\"$reason\"}" write_state
  start_launcher 2>/dev/null || true
  exit 2
}

# manual rollback mode (triggered from console)
if [ "${QQB_ROLLBACK:-0}" = "1" ]; then
  latest=$(ls -1 "$backup_root" 2>/dev/null | sort | tail -n 1)
  if [ -z "$latest" ]; then log2 "no backup available"; exit 3; fi
  backup_dir="$backup_root/$latest"
  log2 "manual rollback from: $backup_dir"
  stop_bridge
  restore_all
  STATE_FILE="$state_file" PATCH_JSON="{\"phase\":\"rolled-back\",\"error\":\"manual rollback\"}" write_state
  start_launcher || true
  exit 2
fi

export STATE_FILE="$state_file"
STATE_FILE="$state_file" PATCH_JSON="{\"phase\":\"applying\",\"fromVersion\":\"$from_version\",\"targetVersion\":\"$to_version\",\"backupDir\":\"$backup_root\"}" write_state

stop_bridge
if [ "$do_backup" = "1" ]; then backup_current; else log2 "backup disabled"; fi
src=$(extract_new_zip) || exit 3
replace_code "$src"
restore_user_items
run_migrations || rollback "migration failed"
maybe_install_deps || rollback "dependency install failed"

restored=""
for u in $user_items; do [ -e "$backup_dir/$u" ] && restored="$restored $u"; done
"$node_bin" -e '
  const fs = require("fs");
  const data = {
    fromVersion: process.env.FROM,
    toVersion: process.env.TO,
    backupDir: process.env.BACKUP,
    restoredFiles: String(process.env.RESTORED || "").trim().split(/\s+/).filter(Boolean),
    migratedFiles: [],
    finishedAt: Date.now()
  };
  fs.mkdirSync(require("path").dirname(process.env.RESULT), { recursive: true });
  fs.writeFileSync(process.env.RESULT, JSON.stringify(data, null, 2) + "\n");
' FROM="$from_version" TO="$to_version" BACKUP="$backup_dir" RESTORED="$restored" RESULT="$result_file" 2>/dev/null || true

log2 "starting new bridge..."
start_launcher || rollback "cannot start launcher"
if wait_done; then
  log2 "update done"
  rm -rf "$tmp_root"
  exit 0
fi
rollback "new bridge did not report done in time"
