# QQ Bridge update helper (Windows / PowerShell 5.1+).
#
# Runs as a detached process AFTER the bridge exits. It owns the risky part:
#   stop old bridge -> full backup -> extract new zip -> replace code whitelist
#   -> restore user files from backup -> run data migrations -> pnpm install if lock changed
#   -> start new bridge -> wait until the bridge itself reports "done" -> otherwise roll back.
#
# All Chinese file names / paths arrive through environment variables (this file stays ASCII
# so PowerShell 5.1 never mis-decodes it). Contract:
#   QQB_ROOT          project root
#   QQB_ZIP           downloaded+verified zip path
#   QQB_FROM_VERSION  current version (for messages)
#   QQB_TO_VERSION    target version (zip top folder must be qq-bridge-<toVersion>)
#   QQB_LAUNCHER      launcher file name (e.g. the desktop launcher .cmd)
#   QQB_BACKUP        "1" to keep a full backup (default 1)
#   QQB_NODE_CMD      optional override for node.cmd (tests use the real node.exe)
#   QQB_HEALTH_MS     optional health wait in ms (default 120000; tests lower it)
#
# Exit codes: 0 done, 2 rolled back, 3 failed before touching anything.

$ErrorActionPreference = 'Stop'

function Get-EnvOr($Name, $Default) {
    $v = [Environment]::GetEnvironmentVariable($Name)
    if ([string]::IsNullOrWhiteSpace($v)) { return $Default }
    return $v
}

$root = Get-EnvOr 'QQB_ROOT' ''
$zipPath = Get-EnvOr 'QQB_ZIP' ''
$fromVersion = Get-EnvOr 'QQB_FROM_VERSION' ''
$toVersion = Get-EnvOr 'QQB_TO_VERSION' ''
$launcherName = Get-EnvOr 'QQB_LAUNCHER' ''
$doBackup = (Get-EnvOr 'QQB_BACKUP' '1') -ne '0'
$healthMs = 120000
try { $healthMs = [int](Get-EnvOr 'QQB_HEALTH_MS' '120000') } catch {}

if (-not $root -or -not (Test-Path -LiteralPath $root)) { Write-Error "QQB_ROOT invalid"; exit 3 }
if (-not $zipPath -or -not (Test-Path -LiteralPath $zipPath)) { Write-Error "QQB_ZIP missing"; exit 3 }
if (-not $toVersion) { Write-Error "QQB_TO_VERSION missing"; exit 3 }

$stateDir = Join-Path $root 'state'
$stateFile = Join-Path $stateDir 'update.json'
$lockFile = Join-Path $stateDir 'bridge.lock'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupRoot = Join-Path $root '_backups\update'
$backupDir = Join-Path $backupRoot ("$fromVersion-$stamp")
$tmpRoot = Join-Path $root ("_update_tmp_" + $stamp)
$logFile = Join-Path $backupDir 'helper.log'
$resultFile = Join-Path $stateDir 'update-result.json'

$CODE_DIRS = @('src', 'public', 'scripts', 'dsh', 'plugins', 'ops', 'docs', 'assets', 'migrations')
$CODE_FILES = @('README.md', 'README.en.md', 'CHANGELOG.md', 'LICENSE', 'RULES.md',
    'config.example.json', 'package.json', 'package-lock.json', 'pnpm-lock.yaml',
    'node.cmd', 'pnpm.cmd', 'start.bat', 'restart.bat')
$USER_ITEMS = @('config.json', 'state', 'roles', 'life-profiles', 'osts', 'audio')

function Log([string]$Message) {
    $line = "[update-helper] " + (Get-Date -Format 'HH:mm:ss') + " " + $Message
    Write-Host $line
    try {
        if (Test-Path -LiteralPath $backupDir) {
            Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
        }
    } catch {}
}

function Read-State {
    try {
        if (Test-Path -LiteralPath $stateFile) {
            return (Get-Content -LiteralPath $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json)
        }
    } catch {}
    return $null
}

function Write-State([hashtable]$Patch) {
    $state = Read-State
    if (-not $state) { $state = [pscustomobject]@{ version = 1; phase = 'idle' } }
    foreach ($k in $Patch.Keys) {
        if ($state.PSObject.Properties.Name -contains $k) { $state.$k = $Patch[$k] }
        else { $state | Add-Member -NotePropertyName $k -NotePropertyValue $Patch[$k] -Force }
    }
    $state | Add-Member -NotePropertyName at -NotePropertyValue ([DateTimeOffset]::Now.ToUnixTimeMilliseconds()) -Force
    $json = $state | ConvertTo-Json -Depth 8
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    New-Item -ItemType Directory -Force -Path $stateDir | Out-Null
    [System.IO.File]::WriteAllText($stateFile, $json, $utf8)
}

function Write-Result([hashtable]$Data) {
    $json = $Data | ConvertTo-Json -Depth 8
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    New-Item -ItemType Directory -Force -Path $stateDir | Out-Null
    [System.IO.File]::WriteAllText($resultFile, $json, $utf8)
}

function Stop-Bridge {
    if (-not (Test-Path -LiteralPath $lockFile)) { return }
    $pidText = ''
    try { $pidText = (Get-Content -LiteralPath $lockFile -Raw).Trim() } catch {}
    $bridgePid = 0
    if ([int]::TryParse($pidText, [ref]$bridgePid) -and $bridgePid -gt 0) {
        $proc = Get-Process -Id $bridgePid -ErrorAction SilentlyContinue
        if ($proc) {
            Log "waiting bridge (pid $bridgePid) to exit..."
            for ($i = 0; $i -lt 150; $i++) {
                Start-Sleep -Milliseconds 200
                if (-not (Get-Process -Id $bridgePid -ErrorAction SilentlyContinue)) { break }
            }
            if (Get-Process -Id $bridgePid -ErrorAction SilentlyContinue) {
                Log "bridge still alive, terminating pid $bridgePid"
                Stop-Process -Id $bridgePid -Force -ErrorAction SilentlyContinue
                Start-Sleep -Milliseconds 500
            }
        }
    }
    Remove-Item -LiteralPath $lockFile -Force -ErrorAction SilentlyContinue
}

function Copy-ItemIfExists($Source, $Destination) {
    if (-not (Test-Path -LiteralPath $Source)) { return }
    Copy-Item -LiteralPath $Source -Destination $Destination -Recurse -Force
}

function Backup-Current {
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null
    foreach ($d in $CODE_DIRS) { Copy-ItemIfExists (Join-Path $root $d) $backupDir }
    foreach ($f in $CODE_FILES) { Copy-ItemIfExists (Join-Path $root $f) $backupDir }
    foreach ($u in $USER_ITEMS) { Copy-ItemIfExists (Join-Path $root $u) $backupDir }
    if ($launcherName) { Copy-ItemIfExists (Join-Path $root $launcherName) $backupDir }
    Log "backup created: $backupDir"
}

function Extract-NewZip {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $top = "qq-bridge-" + $toVersion
    $arc = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
    try {
        foreach ($entry in $arc.Entries) {
            $name = $entry.FullName.Replace('\', '/')
            if ($name -eq '') { continue }
            if ($name.Contains('..') -or $name.StartsWith('/') -or $name -match '^[A-Za-z]:') {
                throw "unsafe zip entry: $name"
            }
            if (-not ($name.StartsWith($top + '/'))) {
                throw "unexpected zip layout: $name (expected $top/...)"
            }
        }
    } finally { $arc.Dispose() }
    if (Test-Path -LiteralPath $tmpRoot) { Remove-Item -LiteralPath $tmpRoot -Recurse -Force }
    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $tmpRoot)
    $src = Join-Path $tmpRoot $top
    if (-not (Test-Path -LiteralPath $src)) { throw "extracted root missing: $src" }
    return $src
}

function Replace-Code($Src) {
    foreach ($d in $CODE_DIRS) {
        $s = Join-Path $Src $d
        if (Test-Path -LiteralPath $s) { Copy-Item -LiteralPath $s -Destination $root -Recurse -Force }
    }
    foreach ($f in $CODE_FILES) {
        $s = Join-Path $Src $f
        if (Test-Path -LiteralPath $s) { Copy-Item -LiteralPath $s -Destination $root -Force }
    }
    if ($launcherName) {
        $s = Join-Path $Src $launcherName
        if (Test-Path -LiteralPath $s) { Copy-Item -LiteralPath $s -Destination $root -Force }
    }
    Log "code replaced from new zip"
}

function Restore-UserItems {
    foreach ($u in $USER_ITEMS) {
        $b = Join-Path $backupDir $u
        if (Test-Path -LiteralPath $b) {
            $dest = Join-Path $root $u
            Copy-Item -LiteralPath $b -Destination $dest -Recurse -Force
        }
    }
    Log "user files restored from backup"
}

function Restore-CodeOnly {
    foreach ($d in $CODE_DIRS) {
        $b = Join-Path $backupDir $d
        $dest = Join-Path $root $d
        if (Test-Path -LiteralPath $b) {
            if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
            Copy-Item -LiteralPath $b -Destination $root -Recurse -Force
        }
    }
    foreach ($f in $CODE_FILES) {
        $b = Join-Path $backupDir $f
        if (Test-Path -LiteralPath $b) { Copy-Item -LiteralPath $b -Destination $root -Force }
    }
    if ($launcherName) {
        $b = Join-Path $backupDir $launcherName
        if (Test-Path -LiteralPath $b) { Copy-Item -LiteralPath $b -Destination $root -Force }
    }
}

function Restore-All {
    if (-not (Test-Path -LiteralPath $backupDir)) { throw 'no backup to restore' }
    Restore-CodeOnly
    foreach ($u in $USER_ITEMS) {
        $b = Join-Path $backupDir $u
        $dest = Join-Path $root $u
        if (Test-Path -LiteralPath $b) {
            if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Recurse -Force }
            Copy-Item -LiteralPath $b -Destination $root -Recurse -Force
        }
    }
    Log "rollback: code + user files restored from backup"
}

function Get-NodeCmd {
    $override = Get-EnvOr 'QQB_NODE_CMD' ''
    if ($override) { return $override }
    return (Join-Path $root 'node.cmd')
}

function Run-Migrations {
    $node = Get-NodeCmd
    $script = Join-Path $root 'scripts\migrate-data.mjs'
    if (-not (Test-Path -LiteralPath $script)) {
        Log 'migrate-data.mjs not found, skip migrations'
        return @()
    }
    Log 'running data migrations...'
    $out = & $node $script '--apply' '--json' 2>&1 | Out-String
    $code = $LASTEXITCODE
    if ($code -ne 0) { throw "migration failed (exit $code): $out" }
    $migrated = @()
    try {
        $parsed = $out | ConvertFrom-Json
        if ($parsed.migrated) { $migrated = @($parsed.migrated | ForEach-Object { $_.file }) }
    } catch {}
    if ($migrated.Count -gt 0) { Log ("migrations applied: " + ($migrated -join ', ')) }
    else { Log 'no data migrations needed' }
    return $migrated
}

function FileHashOf($RelPath) {
    $p = Join-Path $root $RelPath
    if (-not (Test-Path -LiteralPath $p)) { return '' }
    try { return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash } catch { return '' }
}

function Maybe-InstallDeps {
    $pkgChanged = (FileHashOf 'package.json') -ne (Get-BackupHash 'package.json')
    $lockChanged = (FileHashOf 'pnpm-lock.yaml') -ne (Get-BackupHash 'pnpm-lock.yaml')
    if (-not ($pkgChanged -or $lockChanged)) { Log 'dependency files unchanged, skip install'; return }
    $pnpm = Join-Path $root 'pnpm.cmd'
    if (-not (Test-Path -LiteralPath $pnpm)) { Log 'pnpm.cmd missing, skip dependency install'; return }
    Log 'dependency files changed, running pnpm.cmd install...'
    $out = & $pnpm 'install' 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0) { throw "pnpm install failed: $out" }
    Log 'dependencies installed'
}

function Get-BackupHash($RelPath) {
    $p = Join-Path $backupDir $RelPath
    if (-not (Test-Path -LiteralPath $p)) { return '' }
    try { return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash } catch { return '' }
}

function Start-Launcher {
    if (-not $launcherName) { throw 'no launcher configured' }
    $launcherPath = Join-Path $root $launcherName
    if (-not (Test-Path -LiteralPath $launcherPath)) { throw "launcher missing: $launcherPath" }
    $quoted = 'call "' + $launcherPath + '"'
    Start-Process -FilePath 'cmd.exe' -ArgumentList '/d', '/c', $quoted -WorkingDirectory $root | Out-Null
    Log "launcher started: $launcherName"
}

function Wait-BridgeDone {
    $deadline = (Get-Date).AddMilliseconds($healthMs)
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 1000
        $state = Read-State
        if ($state -and $state.phase -eq 'done') { return $true }
        if ($state -and $state.phase -eq 'failed') {
            Log ("bridge reported failure: " + $state.error)
            return $false
        }
    }
    Log 'health check timed out waiting for bridge done'
    return $false
}

function Invoke-Rollback([string]$Reason) {
    Log ("ROLLBACK: " + $Reason)
    try { Stop-Bridge } catch {}
    try {
        Restore-All
        try { Maybe-InstallDeps } catch { Log ("dependency restore failed: " + $_.Exception.Message) }
        Write-State @{ phase = 'rolled-back'; error = $Reason; backupDir = $backupDir }
        Start-Launcher
    } catch {
        Log ("rollback itself failed: " + $_.Exception.Message)
    }
    exit 2
}

# ---- manual rollback mode (triggered from console) --------------------------
function Invoke-ManualRollback {
    try {
        $dirs = @(Get-ChildItem -LiteralPath $backupRoot -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending)
        if ($dirs.Count -eq 0) { throw 'no backup available' }
        $script:backupDir = $dirs[0].FullName
        Log ("manual rollback from: " + $backupDir)
        Stop-Bridge
        Restore-All
        Write-State @{ phase = 'rolled-back'; error = 'manual rollback'; backupDir = $backupDir }
        Start-Launcher
        exit 2
    } catch {
        Log ("manual rollback failed: " + $_.Exception.Message)
        exit 3
    }
}

$rollbackMode = (Get-EnvOr 'QQB_ROLLBACK' '0') -eq '1'
if ($rollbackMode) { Invoke-ManualRollback }

# ---- main ------------------------------------------------------------------
try {
    Write-State @{ phase = 'applying'; fromVersion = $fromVersion; targetVersion = $toVersion; backupDir = $backupRoot }
    Stop-Bridge
    if ($doBackup) { Backup-Current } else { Log 'backup disabled by request' }
    $src = Extract-NewZip
    Replace-Code $src
    Restore-UserItems
    $migrated = @()
    try { $migrated = @(Run-Migrations) } catch { Invoke-Rollback ("migration failed: " + $_.Exception.Message) }
    try { Maybe-InstallDeps } catch { Invoke-Rollback ("dependency install failed: " + $_.Exception.Message) }
    $restored = @()
    if (Test-Path -LiteralPath $backupDir) {
        foreach ($u in $USER_ITEMS) {
            $b = Join-Path $backupDir $u
            if (Test-Path -LiteralPath $b) { $restored += $u }
        }
    }
    Write-Result @{
        fromVersion = $fromVersion
        toVersion = $toVersion
        backupDir = $backupDir
        restoredFiles = $restored
        migratedFiles = $migrated
        finishedAt = [DateTimeOffset]::Now.ToUnixTimeMilliseconds()
    }
    Log 'starting new bridge...'
    Start-Launcher
    if (Wait-BridgeDone) {
        Log 'update done (bridge reported healthy)'
        try { Remove-Item -LiteralPath $tmpRoot -Recurse -Force -ErrorAction SilentlyContinue } catch {}
        exit 0
    }
    Invoke-Rollback 'new bridge did not report done in time'
} catch {
    Invoke-Rollback ("unexpected error: " + $_.Exception.Message)
}
