import assert from 'node:assert/strict';
import {
  applyRelationshipSignal,
  buildRelationshipConsolidationPrompt,
  decayRelationships,
  emptyRelationshipState,
  ensurePerson,
  formatRelationshipPrompt,
  formatRelationshipSummary,
  mergeRelationshipConsolidation,
  normalizeRelationshipState,
  normalizeSummaryChars,
  parseRelationshipConsolidation,
  pruneRelationships
} from '../src/relationship-engine.js';

let passed = 0;
function test(name, fn) {
  try { fn(); passed += 1; console.log(`ok ${passed} - ${name}`); }
  catch (error) { console.error(`not ok ${passed + 1} - ${name}`); throw error; }
}

test('empty state is per character', () => {
  const state = emptyRelationshipState('Jill');
  assert.equal(state.characterId, 'Jill');
  assert.deepEqual(state.people, {});
});

test('signals raise familiarity and store scoped interaction', () => {
  const state = emptyRelationshipState('Jill');
  const person = ensurePerson(state, '100000001', { displayName: '示例主人', relation: 'owner' });
  applyRelationshipSignal(person, { text: '谢谢你，辛苦了', scope: 'private:100000001', isOwner: true, at: 1000 });
  assert.equal(person.relation, 'owner');
  assert.ok(person.familiarity > 5);
  assert.equal(person.recentInteractions.length, 1);
  assert.equal(person.recentInteractions[0].scope, 'private:100000001');
  assert.ok(person.warmth > 30);
});

test('prompt filters notes by group scope and never prints numbers', () => {
  const state = emptyRelationshipState('Jill');
  const person = ensurePerson(state, '123456789', { displayName: '阿甲' });
  person.notes = [
    { text: 'A 群的事', scope: 'group:111', at: 1 },
    { text: 'B 群的事', scope: 'group:222', at: 2 },
    { text: '通用观察', scope: 'global', at: 3 }
  ];
  const block = formatRelationshipPrompt(person, { scope: 'group:111' });
  assert.match(block, /A 群的事/);
  assert.doesNotMatch(block, /B 群的事/);
  assert.match(block, /通用观察/);
  assert.doesNotMatch(block, /熟悉度：\d/);
});

test('consolidation parser rejects junk and accepts JSON', () => {
  assert.equal(parseRelationshipConsolidation('不是 JSON'), null);
  const parsed = parseRelationshipConsolidation('```json\n{"notes":["喜欢安静"],"preferences":["夜班"],"boundaries":[],"shared_moments":["一起修过机器"]}\n```');
  assert.deepEqual(parsed.notes, ['喜欢安静']);
  assert.deepEqual(parsed.preferences, ['夜班']);
});

test('merge is scoped and deduplicated', () => {
  const state = emptyRelationshipState('Jill');
  const person = ensurePerson(state, '123456789', {});
  mergeRelationshipConsolidation(person, 'group:111', { notes: ['喜欢安静'], preferences: [], boundaries: [], sharedMoments: [] });
  mergeRelationshipConsolidation(person, 'group:111', { notes: ['喜欢安静', '会先道歉'], preferences: [], boundaries: [], sharedMoments: [] });
  assert.equal(person.notes.length, 2);
  assert.equal(person.notes[0].scope, 'group:111');
});

test('prompt builder contains no raw private chat data beyond passed interactions', () => {
  const state = emptyRelationshipState('Jill');
  const person = ensurePerson(state, '123456789', { displayName: '阿甲' });
  const prompt = buildRelationshipConsolidationPrompt({
    roleName: 'Jill',
    person,
    scope: 'group:111',
    interactions: [{ text: '今天也在加班' }]
  });
  assert.match(prompt, /今天也在加班/);
  assert.match(prompt, /只输出一个 JSON/);
});

test('decay lowers tension but not familiarity', () => {
  const state = emptyRelationshipState('Jill');
  const person = ensurePerson(state, '123456789', {});
  person.tension = 80;
  person.lastSeenAt = Date.now() - 10 * 86400000;
  decayRelationships(state);
  assert.ok(person.tension < 80);
  assert.ok(person.familiarity >= 5);
});

test('prune keeps pinned people', () => {
  const state = emptyRelationshipState('Jill');
  state.people = {};
  for (let i = 0; i < 4; i += 1) {
    const p = ensurePerson(state, String(100000000 + i), {});
    p.lastSeenAt = i;
    p.pinned = i === 0;
  }
  pruneRelationships(state, 2);
  assert.equal(Object.keys(state.people).length, 2);
  assert.ok(state.people['100000000']);
});

test('normalization drops malformed people and keeps version', () => {
  const state = normalizeRelationshipState({ people: { bad: {}, '123456789': { familiarity: 999 } } }, 'Jill');
  assert.equal(state.version, 1);
  assert.equal(Object.keys(state.people).length, 1);
  assert.equal(state.people['123456789'].familiarity, 100);
});

test('summary length is per-role and clamped', () => {
  const state = emptyRelationshipState('Jill');
  assert.equal(state.settings.summaryMaxChars, 320);
  assert.equal(normalizeSummaryChars(200), 200);
  assert.equal(normalizeSummaryChars(10), 120);
  assert.equal(normalizeSummaryChars(2000), 800);
  const loaded = normalizeRelationshipState({ settings: { summaryMaxChars: 500 } }, 'Jill');
  assert.equal(loaded.settings.summaryMaxChars, 500);
});

test('consolidation prompt asks for a bounded summary and keeps existing view', () => {
  const state = emptyRelationshipState('Jill');
  const person = ensurePerson(state, '123456789', {});
  person.summary = '他话不多，但会认真听。';
  const prompt = buildRelationshipConsolidationPrompt({
    roleName: 'Jill',
    person,
    scope: 'group:111',
    interactions: [{ text: '今天也在加班' }],
    summaryMaxChars: 420,
    currentSummary: person.summary
  });
  assert.match(prompt, /"summary"/);
  assert.match(prompt, /120–420/);
  assert.match(prompt, /他话不多/);
});

test('parsed summary is merged and full view is owner-private only', () => {
  const state = emptyRelationshipState('Jill');
  const person = ensurePerson(state, '123456789', {});
  const parsed = parseRelationshipConsolidation(JSON.stringify({
    summary: '他平时嘴硬，但遇到麻烦会先来找我。'.repeat(10),
    notes: ['喜欢安静'],
    preferences: [],
    boundaries: [],
    shared_moments: []
  }), 3, 120);
  assert.equal(parsed.summary.length, 120);
  mergeRelationshipConsolidation(person, 'group:111', parsed, { summaryMaxChars: 120 });
  const ownerView = formatRelationshipPrompt(person, { scope: 'private:100000001', includeSummary: true });
  const groupView = formatRelationshipPrompt(person, { scope: 'group:111', includeSummary: false });
  assert.match(ownerView, /整体看法/);
  assert.doesNotMatch(groupView, /整体看法/);
  assert.equal(formatRelationshipSummary(person).summary, parsed.summary);
});

console.log(`\n✅ 关系引擎测试通过（${passed} 项）`);
