// 定时记忆摘要（memory-summary）单元测试。
// 运行：node scripts/test-memory-summary.mjs
import assert from 'node:assert/strict';
import {
  buildMemorySummaryPrompt,
  filterMemorySummaryItems,
  parseMemorySummaryOutput
} from '../src/memory-summary.js';

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`✅ ${name}`);
  } catch (error) {
    console.error(`❌ ${name}`);
    console.error(error);
    process.exitCode = 1;
  }
}

const messages = [
  { sender: '示例主人', userId: '100000001', text: '我们周五打 Minecraft 吧，晚上八点' },
  { sender: '崆峒', userId: '3447692482', text: '行，我记下了', isSelf: true },
  { sender: 'A君', userId: '111', text: '示例主人 喜欢甜酒' }
];

test('buildMemorySummaryPrompt 包含会话、消息、Q号', () => {
  const prompt = buildMemorySummaryPrompt({ key: 'group:987654321', messages });
  assert.match(prompt, /group:987654321/);
  assert.match(prompt, /Minecraft/);
  assert.match(prompt, /100000001/);
  assert.match(prompt, /只输出 JSON/);
  assert.doesNotMatch(prompt, /我记下了/); // 自己的消息不喂给摘要器
});

test('parseMemorySummaryOutput 解析纯 JSON / 围栏 / 前后废话', () => {
  assert.equal(parseMemorySummaryOutput('[{"content":"x"}]').length, 1);
  assert.equal(parseMemorySummaryOutput('```json\n[{"content":"y"}]\n```').length, 1);
  assert.equal(parseMemorySummaryOutput('好的：\n[{"content":"z"}]\n以上').length, 1);
  assert.deepEqual(parseMemorySummaryOutput('不是 JSON'), []);
  assert.deepEqual(parseMemorySummaryOutput(''), []);
});

test('parseMemorySummaryOutput 限制最大条数', () => {
  const items = [{ content: 'a' }, { content: 'b' }, { content: 'c' }];
  assert.equal(parseMemorySummaryOutput(JSON.stringify(items), { maxMemories: 2 }).length, 2);
});

test('群聊过滤：允许本群/在场成员，拒绝全局与不在场用户', () => {
  const raw = [
    { scope: 'group', content: '周五打 Minecraft' },
    { scope: 'user', scopeId: '100000001', content: '示例主人 喜欢甜酒' },
    { scope: 'user', scopeId: '999', content: '不在场的人' },
    { scope: 'global', content: '全局事' },
    { scope: 'group', content: '密码是 123456' }
  ];
  const out = filterMemorySummaryItems(raw, {
    key: 'group:987654321',
    participants: [{ uin: '100000001', name: '示例主人' }]
  });
  assert.equal(out.length, 2);
  assert.equal(out[0].scope, 'group');
  assert.equal(out[0].scopeId, '987654321');
  assert.equal(out[1].scope, 'user');
  assert.equal(out[1].scopeId, '100000001');
  assert.equal(out[1].visibility, 'private');
  assert.equal(out[1].subjectName, '示例主人');
});

test('私聊过滤：只保留当前聊天对象，第三方/群/全局都丢弃', () => {
  const raw = [
    { scope: 'group', content: '群事', scopeId: '987654321' },
    { scope: 'user', scopeId: '100000001', content: '示例主人 喜欢甜酒' },
    { scope: 'user', scopeId: '999', content: '第三方的秘密' },
    { scope: 'global', content: '全局事' }
  ];
  const out = filterMemorySummaryItems(raw, { key: 'private:100000001' });
  assert.equal(out.length, 1);
  assert.equal(out[0].scope, 'user');
  assert.equal(out[0].scopeId, '100000001');
  assert.equal(out[0].visibility, 'private');
});

test('过滤“测试机器人记忆”这类元对话', () => {
  const out = filterMemorySummaryItems([
    { scope: 'user', scopeId: '100000001', content: '示例主人 会特意测试我能不能记住别的群的事，我确实没印象，他说我的问题并道歉' },
    { scope: 'user', scopeId: '100000001', content: '示例主人 喜欢甜酒' }
  ], { key: 'private:100000001' });
  assert.equal(out.length, 1);
  assert.match(out[0].content, /甜酒/);
});

test('保守模式：非敏感印象/梗才自动降为 shared，public 不自动出现', () => {
  const out = filterMemorySummaryItems([
    { scope: 'user', content: '示例主人 喜欢被大家叫 示例主人', visibility: 'shared' },
    { scope: 'group', content: '群友常约着开黑', visibility: 'public' },
    { scope: 'user', content: '示例主人 的家庭住址在某某路', visibility: 'shared' }
  ], { key: 'private:100000001' });
  // 私聊只留当前用户条目；地址被敏感信息过滤。
  assert.equal(out.length, 1);
  assert.equal(out[0].visibility, 'shared');
  assert.equal(out[0].content, '示例主人 喜欢被大家叫 示例主人');
});

test('过滤敏感信息与空内容，并限制条数', () => {
  const raw = [
    { content: '' },
    { content: '我的地址在某某路' },
    { content: '我的 token 是 abc' },
    { scope: 'group', content: '第一条有效记忆' },
    { scope: 'group', content: '第二条有效记忆' },
    { scope: 'group', content: '第三条有效记忆' },
    { scope: 'group', content: '第四条有效记忆' }
  ];
  const out = filterMemorySummaryItems(raw, { key: 'group:987654321', maxMemories: 2 });
  assert.equal(out.length, 2);
});

console.log('');
console.log(`通过 ${passed} 个测试${process.exitCode ? '（有失败）' : ''}`);
