import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { createGifStoryboard, DEFAULT_GIF_STORYBOARD } from '../src/gif-storyboard.js';

const require = createRequire(import.meta.url);
const here = path.dirname(fileURLToPath(import.meta.url));
const candidates = [
  process.env.SHARP_PATH,
  'sharp',
  '/usr/lib/node_modules/@deepseek-ai/dsh/node_modules/sharp',
  '/usr/local/lib/node_modules/@deepseek-ai/dsh/node_modules/sharp'
].filter(Boolean);

let sharp = null;
for (const candidate of candidates) {
  try {
    sharp = require(candidate);
    if (sharp) break;
  } catch {}
}

if (!sharp) {
  console.log('SKIP: sharp 不可用，跳过 GIF 故事板集成测试');
  process.exit(0);
}

const gifPath = process.argv[2] || path.join(here, 'fixtures', 'test-animated.gif');
const gif = fs.readFileSync(gifPath);
const staticPng = await sharp({ create: { width: 32, height: 32, channels: 3, background: '#222222' } }).png().toBuffer();

const result = await createGifStoryboard(gif, sharp, DEFAULT_GIF_STORYBOARD);
assert.ok(result, 'animated gif should produce a storyboard');
assert.ok(Buffer.isBuffer(result.buffer) && result.buffer.length > 1000);
assert.match(result.mimeType, /^image\//);
assert.ok(result.frames >= 2 && result.frames <= 6);
assert.ok(result.width > 0 && result.height > 0);

const output = path.join('/tmp', 'gif-storyboard-test.jpg');
fs.writeFileSync(output, result.buffer);
const staticResult = await createGifStoryboard(staticPng, sharp, DEFAULT_GIF_STORYBOARD);
assert.equal(staticResult, null, 'static image should not produce a storyboard');

console.log(`✅ GIF 故事板测试通过（${result.pages} 帧，抽 ${result.frames} 帧，${result.width}x${result.height}，${result.buffer.length} bytes）`);
console.log(`输出：${output}`);
