import assert from 'node:assert/strict';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {
  DEFAULT_BACKUP_SETTINGS,
  createBackup,
  listBackups,
  pruneBackups,
  restoreBackup,
  normalizeBackupSettings
} from '../src/backup.js';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'qq-bridge-backup-test-'));
const app = path.join(tmp, 'app');
const backupRoot = path.join(tmp, 'backups');

try {
  fs.mkdirSync(path.join(app, 'state'), { recursive: true });
  fs.mkdirSync(path.join(app, 'roles'), { recursive: true });
  fs.writeFileSync(path.join(app, 'config.json'), '{"ownerQQ":"10001"}', 'utf8');
  fs.writeFileSync(path.join(app, 'state', 'session.json'), '{"id":"one"}', 'utf8');
  fs.writeFileSync(path.join(app, 'roles', 'Jill.md'), '# Jill', 'utf8');

  const settings = { ...DEFAULT_BACKUP_SETTINGS, backupRoot, keep: 2 };
  const first = await createBackup(app, { label: 'first', settings });
  assert.equal(first.ok, true);
  assert.equal(fs.existsSync(path.join(first.path, 'config.json')), true);
  assert.equal(fs.readFileSync(path.join(first.path, 'state', 'session.json'), 'utf8'), '{"id":"one"}');
  const firstManifest = JSON.parse(fs.readFileSync(path.join(first.path, 'manifest.json'), 'utf8'));
  assert.equal(firstManifest.version, 1);
  assert.equal(firstManifest.items.find((x) => x.path === 'state')?.exists, true);
  assert.equal(firstManifest.items.find((x) => x.path === 'config.json')?.exists, true);

  fs.writeFileSync(path.join(app, 'state', 'session.json'), '{"id":"two"}', 'utf8');
  await new Promise((resolve) => setTimeout(resolve, 5));
  const second = await createBackup(app, { label: 'second', settings });
  await new Promise((resolve) => setTimeout(resolve, 5));
  const third = await createBackup(app, { label: 'third', settings });

  const list = await listBackups(app, settings);
  assert.equal(list.length, 2);
  assert.equal(list[0].name, third.name);
  assert.equal(list[1].name, second.name);

  fs.writeFileSync(path.join(app, 'state', 'session.json'), '{"id":"corrupt"}', 'utf8');
  const restored = await restoreBackup(app, second.path, { confirm: 'RESTORE', settings });
  assert.equal(restored.ok, true);
  assert.equal(restored.restored.includes('state'), true);
  assert.equal(fs.readFileSync(path.join(app, 'state', 'session.json'), 'utf8'), '{"id":"two"}');

  const afterRestore = await listBackups(app, settings);
  assert.equal(afterRestore.length, 3);
  assert.equal(afterRestore.some((x) => x.label === 'pre-restore'), true);

  await assert.rejects(
    () => createBackup(app, { label: 'bad', settings: { ...settings, backupRoot: path.join(app, 'inside') } }),
    /备份目录不能放在项目目录内/
  );
  await assert.rejects(
    () => restoreBackup(app, second.path, { confirm: 'nope', settings }),
    /RESTORE/
  );

  const normalized = normalizeBackupSettings({ keep: 999, autoDaily: false, backupRoot });
  assert.equal(normalized.keep, 60);
  assert.equal(normalized.autoDaily, false);

  const pruned = await pruneBackups(app, { ...settings, keep: 1 });
  assert.equal(pruned.kept, 1);
  const finalList = await listBackups(app, settings);
  assert.equal(finalList.length, 1);

  console.log('✅ 备份模块测试通过（创建/列表/保留/恢复/路径保护）');
} finally {
  await fsp.rm(tmp, { recursive: true, force: true }).catch(() => {});
}
