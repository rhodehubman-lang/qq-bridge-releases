#!/usr/bin/env node
// Build a clean source distribution without local state, credentials, personal roles or one-off artifacts.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const version = String(pkg.version || '0.0.0');
const DIST = path.join(ROOT, 'dist');
const STAGE = path.join(DIST, `qq-bridge-${version}`);

const COPY_DIRS = ['src', 'public', 'scripts', 'dsh', 'plugins', 'ops', 'docs', 'assets', 'migrations', 'roles'];
const COPY_FILES = [
  'README.md', 'README.en.md', 'CHANGELOG.md', 'LICENSE', 'RULES.md',
  'config.example.json', 'package.json', 'package-lock.json', 'pnpm-lock.yaml',
  'node.cmd', 'pnpm.cmd', 'start.bat', 'restart.bat',
  '安装.cmd', '启动.cmd',
  '安装或修复DSH端.cmd', '启动QQ桥接.cmd', '验证DSH适配.cmd'
];

function copyDir(src, dest) {
  if (!fs.existsSync(src)) return;
  fs.cpSync(src, dest, { recursive: true, preserveTimestamps: true });
}

fs.rmSync(STAGE, { recursive: true, force: true });
fs.mkdirSync(STAGE, { recursive: true });

for (const name of COPY_DIRS) {
  copyDir(path.join(ROOT, name), path.join(STAGE, name));
}
for (const name of COPY_FILES) {
  const src = path.join(ROOT, name);
  if (fs.existsSync(src)) fs.copyFileSync(src, path.join(STAGE, name));
}

// Personal role cards, life profiles and OST memory packs must never ship.
// 默认人格卡：发行版保留（2026-10-31 用户要求）。这些是**可选的公开示例人格**，
// 不是某个人的私有角色卡；带个人信息的角色卡仍然只在本地。
for (const [dir, keep] of [
  ['roles', new Set(['README.md', '傲娇助手.md', '小鲸鱼.md', '示例群友.md'])],
  ['life-profiles', new Set(['README.md'])],
  ['osts', new Set(['README.md'])],
]) {
  const target = path.join(STAGE, dir);
  if (!fs.existsSync(target)) continue;
  for (const name of fs.readdirSync(target)) {
    if (!keep.has(name)) fs.rmSync(path.join(target, name), { recursive: true, force: true });
  }
}

// Local-only/private artifacts that are intentionally gitignored must not ship either.
const PRIVATE_PATHS = [
  'scripts/privacy-rules.json',
  'scripts/fixtures/test-animated.gif',
  'scripts/cleanup-probe-sessions.mjs',
  'scripts/cleanup-probe-workspaces.mjs',
  'scripts/cleanup-test-sessions.mjs',
  'scripts/debug-whitelist.mjs',
  'scripts/diag-archive.mjs',
  'scripts/fix-probe-workspace-title.mjs',
  'scripts/patch-qq-chat-v2-collect-memory.mjs',
  'scripts/patch-qq-chat-v2-presleep.mjs',
  'scripts/patch-qq-chat-v2-stickers.mjs',
  'scripts/patch-web-mcp-timeout.mjs',
  'assets/project-intro.mp4',
  'docs/audits',
  'docs/design',
  'docs/legacy',
  'docs/research',
  'docs/qq-bridge-PUBLISH_PLAN.md',
  'docs/qq-bridge-SECURITY_AUDIT.md',
  'docs/guides/PROJECT_GUIDE.md'
];
for (const rel of PRIVATE_PATHS) {
  const target = path.join(STAGE, rel);
  if (fs.existsSync(target)) fs.rmSync(target, { recursive: true, force: true });
}

// Defense in depth: even if a fixture/document was missed, genericize known local identifiers
// in the copied release without touching the private source tree.
const TEXT_REPLACEMENTS = [
  ['100000001', '100000001'],
  ['123456789', '123456789'],
  ['987654321', '987654321'],
  ['100000002', '100000002'],
  ['示例主人', '示例主人'],
  ['示例主人', '示例主人'],
  ['示例主人', '示例主人'],
  ['示例群一', '示例群一'],
  ['示例群二', '示例群二']
];
const TEXT_EXT = new Set(['.md', '.js', '.mjs', '.json', '.html', '.yml', '.yaml', '.txt']);
// roles/ 下的默认人格卡不做脱敏：小鲸鱼卡里的"示例主人"是机器人昵称（群友玩梗），
// 被替换成"示例主人"会把人设改坏；卡里也已确认没有 QQ 号/群名/手机号等个人信息。
const SANITIZE_SKIP_DIRS = new Set(['roles']);
function sanitizeTree(dir, rel = '') {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, ent.name);
    const relPath = rel ? `${rel}/${ent.name}` : ent.name;
    if (ent.isDirectory()) {
      if (SANITIZE_SKIP_DIRS.has(relPath)) continue;
      sanitizeTree(p, relPath);
      continue;
    }
    if (!TEXT_EXT.has(path.extname(ent.name))) continue;
    const before = fs.readFileSync(p, 'utf8');
    let after = before;
    for (const [from, to] of TEXT_REPLACEMENTS) after = after.split(from).join(to);
    if (after !== before) fs.writeFileSync(p, after, 'utf8');
  }
}
sanitizeTree(STAGE);

const zip = path.join(DIST, `qq-bridge-${version}.zip`);
fs.rmSync(zip, { force: true });
// 中文文件名必须带 UTF-8 标记，否则 Windows 解压后名字会乱码、安装.cmd 找不到
// （2026-10-31 VM 实测失败）。两条路都踩过坑：
//   · PowerShell 5.1 的 Compress-Archive 按 ANSI/GBK 写名字且不带 UTF-8 标记；
//   · .NET ZipFile.CreateFromDirectory 在这台机器上同样产出非法 UTF-8 名字。
// Windows 10+ 自带的 bsdtar（libarchive）加 `zip:hdrcharset=UTF-8` 是实测唯一正确的。
const tarExe = process.platform === 'win32'
  ? path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe')
  : 'tar';
if (process.platform === 'win32' && !fs.existsSync(tarExe)) {
  console.error(`压缩失败：找不到 ${tarExe}（Windows 10 1803+ 自带；请在系统盘 Program Files 同级目录确认）`);
  process.exit(1);
}
const archive = spawnSync(tarExe, [
  '-a', '--options', 'zip:hdrcharset=UTF-8',
  '-cf', zip, '-C', DIST, `qq-bridge-${version}`
], { stdio: 'inherit' });
if (archive.status !== 0) {
  console.error('压缩失败：tar 打包返回非 0 退出码');
  process.exit(archive.status || 1);
}

// 回归网：zip 里必须能按 UTF-8 找到中文文件名（防止编码问题再次回归）。
const zipBytes = fs.readFileSync(zip);
for (const required of ['安装.cmd', '启动.cmd', 'scripts/install.mjs']) {
  if (!zipBytes.includes(Buffer.from(required, 'utf8'))) {
    console.error(`压缩校验失败：zip 里按 UTF-8 找不到 ${required}（中文文件名编码坏了，解压后会乱码）`);
    process.exit(1);
  }
}

const size = fs.statSync(zip).size;
console.log(`release: ${path.relative(ROOT, zip)} (${(size / 1024 / 1024).toFixed(2)} MB)`);
console.log(`stage:   ${path.relative(ROOT, STAGE)}`);
