import assert from 'node:assert/strict';
import {
  DEFAULT_GROUP_POLICY,
  formatGroupPolicyPrompt,
  isProactiveAllowedByPolicy,
  isWakeAllowedByPolicy,
  normalizeGroupPolicy,
  normalizeGroupPolicyState,
  policyForGroup,
  setGroupPolicy
} from '../src/group-policy.js';
import {
  buildGroupBriefs,
  buildImpressionPrompt,
  buildOwnerCrossGroupContext,
  canSendOwnerReport,
  detectUrgentGroupEvent,
  formatCrossGroupDigest,
  formatImpressionContext,
  latestImpressions,
  normalizeCrossGroupConfig,
  normalizeCrossGroupState,
  parseImpression,
  recordOwnerReport
} from '../src/cross-group.js';
import {
  formatOwnerTaskPrompt,
  formatOwnerTasksContext,
  normalizeOwnerTask,
  normalizeOwnerTaskState,
  ownerTaskMatchesMessage,
  ownerTaskTimeDue,
  upsertOwnerTask
} from '../src/owner-tasks.js';

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`ok ${passed} - ${name}`);
  } catch (error) {
    console.error(`not ok ${passed + 1} - ${name}`);
    throw error;
  }
}

test('group policy defaults and state normalization', () => {
  const state = normalizeGroupPolicyState({
    groups: {
      '123456': { name: '测试群', mode: 'quiet', avoidTopics: ['政治'] },
      bad: { mode: 'active' }
    }
  });
  assert.equal(state.defaults.mode, 'normal');
  assert.equal(state.groups['123456'].mode, 'quiet');
  assert.deepEqual(state.groups['123456'].avoidTopics, ['政治']);
  assert.equal(state.groups.bad, undefined);
});

test('group policy inheritance and reset', () => {
  const state = normalizeGroupPolicyState({ defaults: { mode: 'active', proactive: false } });
  const policy = policyForGroup(state, '123456');
  assert.equal(policy.mode, 'active');
  assert.equal(policy.proactive, false);
  setGroupPolicy(state, '123456', { mode: 'mention-only' });
  assert.equal(policyForGroup(state, '123456').mode, 'mention-only');
  delete state.groups['123456'];
  assert.equal(policyForGroup(state, '123456').mode, 'active');
  assert.equal(policyForGroup(state, 'bad'), null);
});

test('group policy gates wake and proactive', () => {
  assert.equal(isWakeAllowedByPolicy({ ...DEFAULT_GROUP_POLICY, mode: 'off' }, 'atMention', { isOwner: true }), false);
  assert.equal(isWakeAllowedByPolicy({ ...DEFAULT_GROUP_POLICY, mode: 'mention-only' }, 'keyword'), false);
  assert.equal(isWakeAllowedByPolicy({ ...DEFAULT_GROUP_POLICY, mode: 'mention-only' }, 'atMention'), true);
  assert.equal(isWakeAllowedByPolicy({ ...DEFAULT_GROUP_POLICY, mode: 'normal' }, 'message', { atNight: true }), false);
  assert.equal(isProactiveAllowedByPolicy({ ...DEFAULT_GROUP_POLICY, mode: 'quiet' }), false);
  assert.equal(isProactiveAllowedByPolicy({ ...DEFAULT_GROUP_POLICY, mode: 'normal', proactive: true }), true);
});

test('group policy prompt exposes only local rules', () => {
  const text = formatGroupPolicyPrompt(normalizeGroupPolicy({
    mode: 'quiet',
    topicHints: '聊游戏和日常',
    avoidTopics: ['剧透']
  }), { groupName: '示例群二', groupId: '987654321' });
  assert.match(text, /示例群二/);
  assert.match(text, /剧透/);
  assert.doesNotMatch(text, /示例群一/);
});

test('cross-group config normalizes clocks and keywords', () => {
  const cfg = normalizeCrossGroupConfig({
    maxReportsPerDay: 99,
    quietHours: { start: '25:00', end: '7:30' },
    dailyDigest: { time: '9:05' },
    urgent: { keywords: '急,救命，急' }
  });
  assert.equal(cfg.maxReportsPerDay, 20);
  assert.equal(cfg.quietHours.start, '23:00');
  assert.equal(cfg.quietHours.end, '07:30');
  assert.equal(cfg.dailyDigest.time, '09:05');
  assert.deepEqual(cfg.urgent.keywords, ['急', '救命']);
});

test('owner report respects quiet hours and daily cap', () => {
  const cfg = normalizeCrossGroupConfig({ maxReportsPerDay: 1 });
  const atNight = new Date('2026-10-27T23:30:00+08:00');
  assert.equal(canSendOwnerReport(normalizeCrossGroupState({}), cfg, atNight).ok, false);
  const day = new Date('2026-10-27T21:00:00+08:00');
  const state = recordOwnerReport(normalizeCrossGroupState({}), cfg, { kind: 'urgent', now: day, groups: ['987654321'] });
  assert.equal(canSendOwnerReport(state, cfg, new Date('2026-10-27T21:05:00+08:00')).reason, 'daily report limit');
});

test('group briefs and digest keep group identity', () => {
  const conversations = new Map([
    ['group:987654321', { lastIncomingAt: 1000, recentMessages: [{ sender: '示例主人', text: '今晚打游戏', time: 1000 }] }],
    ['group:123456789', { lastIncomingAt: 2000, recentMessages: [{ sender: '阿岚', text: '明天见', time: 2000 }] }],
    ['private:100000001', { lastIncomingAt: 3000, recentMessages: [{ sender: '主人', text: '私聊不该出现', time: 3000 }] }]
  ]);
  const briefs = buildGroupBriefs(conversations, new Map([['987654321', '示例群二'], ['123456789', '示例群一']]), { now: 3000, limit: 6 });
  assert.equal(briefs.length, 2);
  assert.equal(briefs[0].groupName, '示例群一');
  const digest = formatCrossGroupDigest(briefs, { since: 0, now: 3000 });
  assert.match(digest, /示例群二/);
  assert.match(digest, /示例群一/);
  assert.doesNotMatch(digest, /私聊不该出现/);
  const ownerOnly = buildOwnerCrossGroupContext(briefs, { now: 3000 });
  assert.match(ownerOnly, /别的群/);
  assert.match(ownerOnly, /示例群一/);
});

test('urgent detection only reports group events', () => {
  const event = { message: [{ type: 'at', data: { qq: '100000001' } }] };
  assert.equal(detectUrgentGroupEvent({ event, plainContent: '在吗', ownerQQ: '100000001' }).reason, 'owner-mentioned');
  assert.equal(detectUrgentGroupEvent({ event: {}, plainContent: '出事了，快来看', ownerQQ: '100000001', keywords: ['出事了'] }).keyword, '出事了');
  assert.equal(detectUrgentGroupEvent({ event: {}, plainContent: '普通聊天', ownerQQ: '100000001' }), null);
});

test('owner tasks normalize, upsert and match', () => {
  const state = normalizeOwnerTaskState({ tasks: [{ title: '提醒交房租', type: 'time', time: '22:30', target: 'owner', instruction: '提醒本月房租' }] });
  assert.equal(state.tasks.length, 1);
  assert.equal(state.tasks[0].target, 'owner');
  const task = normalizeOwnerTask({ type: 'keyword', keywords: ['加班', '下班'], groupIds: ['987654321'], target: 'group:987654321' });
  assert.equal(task.target, '987654321');
  assert.equal(ownerTaskMatchesMessage(task, { groupId: '987654321', text: '今天又加班', now: new Date('2026-10-27T20:00:00+08:00') }), true);
  assert.equal(ownerTaskMatchesMessage(task, { groupId: '987654321', text: '普通聊天', now: new Date('2026-10-27T20:00:00+08:00') }), false);
  assert.equal(ownerTaskMatchesMessage(task, { groupId: '123456789', text: '今天又加班', now: new Date('2026-10-27T20:00:00+08:00') }), false);
  upsertOwnerTask(state, task);
  assert.equal(state.tasks.length, 2);
  assert.match(formatOwnerTaskPrompt(task, { now: new Date('2026-10-27T20:00:00+08:00') }), /管理员安排/);
  assert.match(formatOwnerTasksContext(state, { key: 'group:987654321' }), /加班|房租/);
  assert.equal(formatOwnerTasksContext(state, { key: 'group:123456789' }), '');
});

test('owner task context and reports carry character attribution', () => {
  const state = normalizeOwnerTaskState({ tasks: [
    { title: 'Jill 提醒', characterId: 'jill', target: 'owner' },
    { title: '另一个角色提醒', characterId: 'other', target: 'owner' }
  ] });
  assert.equal(formatOwnerTasksContext(state, { key: 'private:100000001', characterId: 'jill' }).includes('Jill 提醒'), true);
  assert.equal(formatOwnerTasksContext(state, { key: 'private:100000001', characterId: 'jill' }).includes('另一个角色提醒'), false);
  assert.equal(formatOwnerTasksContext(state, { key: 'private:100000001', characterId: 'other' }).includes('Jill 提醒'), false);

  const cfg = normalizeCrossGroupConfig({});
  const cross = recordOwnerReport(normalizeCrossGroupState({}), cfg, {
    kind: 'digest', now: new Date('2026-10-27T21:00:00+08:00'), characterId: 'jill', groups: ['987654321']
  });
  assert.equal(cross.reports.at(-1).characterId, 'jill');
  assert.equal(cross.digestCharacterId, 'jill');
});

test('cross-group impressions are role-scoped and stay fragmentary', () => {
  const cfg = normalizeCrossGroupConfig({ impressions: { intervalMinutes: 5, minMessages: 999, maxChars: 9999 } });
  assert.equal(cfg.impressions.intervalMinutes, 10);
  assert.equal(cfg.impressions.minMessages, 40);
  assert.equal(cfg.impressions.maxChars, 800);

  const prompt = buildImpressionPrompt({
    roleName: 'Jill',
    groupName: '示例群一',
    messages: [{ sender: '示例主人', text: '明天把鱼带过来' }, { sender: '阿岚', text: '别又忘了' }],
    maxChars: 240
  });
  assert.match(prompt, /第一人称/);
  assert.match(prompt, /示例群一/);
  assert.match(prompt, /明天把鱼带过来/);

  assert.equal(parseImpression('- “群里又在聊鱼。”'), '群里又在聊鱼。');
  assert.equal(parseImpression('A 说：鱼没死。B 说：只是游得慢。'), '');
  const now = Date.now();
  const impressions = [
    { at: now - 1000, characterId: 'jill', groupId: '1', groupName: '一群', text: '旧的' },
    { at: now - 500, characterId: 'jill', groupId: '1', groupName: '一群', text: '新的' },
    { at: now - 500, characterId: 'other', groupId: '2', groupName: '二群', text: '别人的' },
    { at: now - 40 * 24 * 60 * 60 * 1000, characterId: 'jill', groupId: '3', groupName: '三群', text: '过期' }
  ];
  const mine = latestImpressions(impressions, { characterId: 'jill', now, maxAgeMs: 7 * 24 * 60 * 60 * 1000 });
  assert.equal(mine.length, 2);
  assert.equal(mine.some((item) => item.text === '别人的'), false);
  const context = formatImpressionContext(mine, { now, maxChars: 2000 });
  assert.match(context, /不是本轮任务/);
  assert.match(context, /新的/);
  assert.doesNotMatch(context, /旧的/);
  assert.doesNotMatch(context, /别人的/);
});

test('time task is due only once per matching minute', () => {
  const task = normalizeOwnerTask({ title: '午间提醒', type: 'time', time: '12:00' });
  assert.equal(ownerTaskTimeDue(task, new Date('2026-10-27T12:00:30+08:00')), true);
  task.lastTriggeredDay = '2026-10-27';
  assert.equal(ownerTaskTimeDue(task, new Date('2026-10-27T12:00:30+08:00')), false);
  assert.equal(ownerTaskTimeDue(task, new Date('2026-10-27T12:01:00+08:00')), false);
});

console.log(`\n${passed} tests passed`);
