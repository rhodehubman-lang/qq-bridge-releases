// 更新器引擎纯函数回归（不联网、不写盘）。
//
// 更新器一旦出错就是朋友的安装报废，所以清单/版本/兼容性/白名单/zip 安全/校验
// 全部先在这里钉死，再谈控制台和 helper。
import {
  DEFAULT_UPDATE_MIRRORS,
  DEFAULT_UPDATE_SETTINGS,
  assertSafeZipEntries,
  checkDshCompat,
  checkForUpdate,
  compareDshVersions,
  compareVersions,
  formatBytes,
  isCodePath,
  isNewerVersion,
  isProtectedPath,
  normalizeManifest,
  normalizeUpdateSettings,
  parseDshVersion,
  parseVersion,
  planCodeReplacement,
  sha256Hex,
  verifyDownload
} from '../src/update-engine.js';

let pass = 0;
let fail = 0;
function check(cond, label, extra = '') {
  if (cond) { pass += 1; console.log(`✅ ${label}`); }
  else { fail += 1; console.error(`❌ ${label}${extra ? `：${extra}` : ''}`); }
}

// ── 1. 版本解析与比较 ───────────────────────────────────────────────────────
const v241 = parseVersion('0.2.4-r1');
check(v241 && v241.major === 0 && v241.minor === 2 && v241.patch === 4 && v241.rev === 1 && v241.line === '0.2.4', 'parseVersion：带 -rN');
check(parseVersion('0.2.0').rev === 0, 'parseVersion：无 -r 视为 r0');
check(parseVersion('v0.2.0') === null && parseVersion('0.2') === null, 'parseVersion：非法格式返回 null');
check(compareVersions('0.2.0-r4', '0.2.0-r5') === -1, 'compareVersions：r4 < r5');
check(compareVersions('0.2.0', '0.2.0-r4') === -1, 'compareVersions：无 -r 比 r4 旧');
check(compareVersions('0.3.0', '0.2.9') === 1, 'compareVersions：跨 minor');
check(compareVersions('0.2.1-r1', '0.2.1-r1') === 0, 'compareVersions：相等');
check(isNewerVersion('0.2.0-r5', '0.2.0-r4') === true && isNewerVersion('0.2.0-r4', '0.2.0-r4') === false, 'isNewerVersion');

// ── 2. DSH 兼容性 ───────────────────────────────────────────────────────────
const dsh = parseDshVersion('0.2.1-rc.5');
check(dsh && dsh.major === 0 && dsh.minor === 2 && dsh.patch === 1 && dsh.pre === 5, 'parseDshVersion：rc.5');
check(compareDshVersions('0.2.1-rc.5', '0.2.0-rc.2') === 1, 'compareDshVersions：0.2.1-rc.5 > 0.2.0-rc.2');
check(compareDshVersions('0.2.1-rc.5', '0.2.1') === -1, 'compareDshVersions：rc < 正式版');
check(compareDshVersions('0.2.2', '0.2.1') === 1, 'compareDshVersions：0.2.2 > 0.2.1');
check(checkDshCompat('0.2.1-rc.5', { min: '0.2.0-rc.2', max: '0.2.1' }) === 'ok', 'checkDshCompat：0.2.1-rc.5 在范围内');
check(checkDshCompat('0.2.0-rc.1', { min: '0.2.0-rc.2', max: '0.2.1' }) === 'too-old', 'checkDshCompat：太旧');
check(checkDshCompat('0.2.2', { min: '0.2.0-rc.2', max: '0.2.1' }) === 'too-new', 'checkDshCompat：太新');
check(checkDshCompat('', { min: '0.2.0', max: '0.2.1' }) === 'unknown', 'checkDshCompat：读不到版本');

// ── 3. 清单校验 ─────────────────────────────────────────────────────────────
const validManifestRaw = {
  schema: 1,
  updatedAt: '2026-11-02T12:00:00+08:00',
  recommended: {
    line: '0.3.0', version: '0.3.0', tag: 'v0.3.0', releasedAt: '2026-11-02',
    asset: 'qq-bridge-0.3.0.zip',
    assetUrl: 'https://github.com/Derpyu520/qq-bridge/releases/download/v0.3.0/qq-bridge-0.3.0.zip',
    sha256: 'a'.repeat(64), size: 1700000,
    dshCompat: { min: '0.2.0-rc.2', max: '0.2.1' },
    requiresDshRestart: true,
    notes: '## 更新内容\n- 测试',
    dataSchema: 1, minDataSchema: 1
  },
  lines: {
    '0.3.0': {
      line: '0.3.0', version: '0.3.0', tag: 'v0.3.0',
      asset: 'qq-bridge-0.3.0.zip',
      assetUrl: 'https://github.com/Derpyu520/qq-bridge/releases/download/v0.3.0/qq-bridge-0.3.0.zip',
      sha256: 'a'.repeat(64), size: 1700000, dshCompat: { min: '0.2.0-rc.2', max: '0.2.1' },
      dataSchema: 1, minDataSchema: 1
    }
  }
};
const good = normalizeManifest(validManifestRaw);
check(good.ok === true, 'normalizeManifest：合法清单通过', good.error);
check(good.ok && good.manifest.recommended.version === '0.3.0' && good.manifest.recommended.sha256 === 'a'.repeat(64), 'normalizeManifest：字段归一化');
check(good.ok && good.manifest.recommended.requiresDshRestart === true, 'normalizeManifest：requiresDshRestart');

function badManifest(mutator) {
  const copy = JSON.parse(JSON.stringify(validManifestRaw));
  mutator(copy);
  return normalizeManifest(copy);
}
check(badManifest((m) => { m.schema = 2; }).ok === false, 'normalizeManifest：schema 不支持');
check(badManifest((m) => { m.recommended.sha256 = 'abc'; }).ok === false, 'normalizeManifest：sha256 非法');
check(badManifest((m) => { m.recommended.asset = '../evil.zip'; }).ok === false, 'normalizeManifest：asset 含路径');
check(badManifest((m) => { m.recommended.assetUrl = 'http://example.com/x.zip'; }).ok === false, 'normalizeManifest：http 源拒绝');
check(badManifest((m) => { m.recommended.assetUrl = 'http://127.0.0.1:3399/x.zip'; }).ok === true, 'normalizeManifest：本地回环 http 允许（演练源）');
check(badManifest((m) => { m.recommended.size = 0; }).ok === false, 'normalizeManifest：size 非法');
check(badManifest((m) => { m.recommended.version = 'v0.3.0'; }).ok === false, 'normalizeManifest：版本格式非法');
check(badManifest((m) => { m.lines['0.2.0'] = { ...m.recommended, line: '0.2.0', version: '0.2.0-r5', sha256: 'b'.repeat(64) }; }).ok === true, 'normalizeManifest：多版本线通过');

// ── 4. 更新决策 ─────────────────────────────────────────────────────────────
const manifestOk = normalizeManifest(validManifestRaw);
const upToDate = checkForUpdate({ manifest: manifestOk, currentVersion: '0.3.0', currentDshVersion: '0.2.1-rc.5' });
check(upToDate.status === 'up-to-date', 'checkForUpdate：同版本 → up-to-date');
const available = checkForUpdate({ manifest: manifestOk, currentVersion: '0.2.0-r4', currentDshVersion: '0.2.1-rc.5' });
check(available.status === 'refused' && available.code === 'cross-line', 'checkForUpdate：跨线拒绝（0.2.0→0.3.0）', available.code);
const sameLineManifest = normalizeManifest({
  ...validManifestRaw,
  recommended: { ...validManifestRaw.recommended, line: '0.2.0', version: '0.2.0-r5' },
  lines: { '0.2.0': { ...validManifestRaw.lines['0.3.0'], line: '0.2.0', version: '0.2.0-r5' } }
});
const sameLine = checkForUpdate({ manifest: sameLineManifest, currentVersion: '0.2.0-r4', currentDshVersion: '0.2.1-rc.5' });
check(sameLine.status === 'available' && sameLine.target.version === '0.2.0-r5', 'checkForUpdate：同线可更新');
const dshOld = checkForUpdate({ manifest: sameLineManifest, currentVersion: '0.2.0-r4', currentDshVersion: '0.1.7' });
check(dshOld.status === 'refused' && dshOld.code === 'dsh-too-old', 'checkForUpdate：DSH 太旧拒绝');
const dataOld = checkForUpdate({ manifest: sameLineManifest, currentVersion: '0.2.0-r4', currentDshVersion: '0.2.1', currentDataSchema: 0 });
check(dataOld.status === 'refused' && dataOld.code === 'data-too-old', 'checkForUpdate：数据 schema 太旧拒绝');
const unknownDsh = checkForUpdate({ manifest: sameLineManifest, currentVersion: '0.2.0-r4', currentDshVersion: '' });
check(unknownDsh.status === 'available' && unknownDsh.warnings.length > 0, 'checkForUpdate：DSH 版本未知 → 可更新但带警告');
const invalidManifest = checkForUpdate({ manifest: { ok: false, error: 'x' }, currentVersion: '0.2.0-r4' });
check(invalidManifest.status === 'invalid', 'checkForUpdate：坏清单 → invalid');

// ── 5. 白名单与 zip 安全 ────────────────────────────────────────────────────
check(isCodePath('src/bridge.js') && isCodePath('scripts/install.mjs') && isCodePath('migrations/index.mjs'), 'isCodePath：代码目录');
check(isCodePath('README.md') && isCodePath('安装.cmd') && isCodePath('node.cmd'), 'isCodePath：根文件');
check(!isCodePath('state/sessions.json') && !isCodePath('config.json') && !isCodePath('roles/x.md'), 'isCodePath：数据文件不算代码');
check(!isCodePath('../evil.js') && !isCodePath('node_modules/x.js'), 'isCodePath：穿越/node_modules 拒绝');
check(isProtectedPath('state') && isProtectedPath('state/worlds/w1/truth.json') && isProtectedPath('config.json') && isProtectedPath('roles'), 'isProtectedPath：数据路径');
const plan = planCodeReplacement(['src/bridge.js', 'README.md', 'state/x.json', 'roles/a.md', 'weird.txt']);
check(plan.files.length === 2 && plan.skippedProtected.length === 2 && plan.skippedOther.length === 1, 'planCodeReplacement：只换白名单代码');

const safe = assertSafeZipEntries(['qq-bridge-0.3.0/src/bridge.js', 'qq-bridge-0.3.0/state/']);
check(safe.ok === true && safe.entries.length === 1, 'assertSafeZipEntries：正常条目通过');
for (const bad of ['../evil.js', 'C:/evil.js', '/abs/evil.js', 'a\\b.js', 'a/../../b.js', '']) {
  const result = assertSafeZipEntries([bad]);
  check(result.ok === false, `assertSafeZipEntries：拒绝 ${JSON.stringify(bad)}`);
}

// ── 6. 下载校验 ─────────────────────────────────────────────────────────────
const buf = Buffer.from('abc');
check(sha256Hex(buf) === 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad', 'sha256Hex：已知向量');
check(verifyDownload({ buffer: buf, sha256: sha256Hex(buf), size: 3 }).ok === true, 'verifyDownload：正确');
check(verifyDownload({ buffer: buf, sha256: sha256Hex(buf), size: 4 }).ok === false, 'verifyDownload：大小不符拒绝');
check(verifyDownload({ buffer: buf, sha256: 'b'.repeat(64), size: 3 }).ok === false, 'verifyDownload：sha 不符拒绝');
check(formatBytes(1536) === '1.5 KB' && formatBytes(3 * 1024 * 1024) === '3.00 MB', 'formatBytes');

// ── 7. 更新设置 ─────────────────────────────────────────────────────────────
const defaults = normalizeUpdateSettings(null);
check(defaults.repo === DEFAULT_UPDATE_SETTINGS.repo && defaults.enabled === true && defaults.backupBeforeUpdate === true, 'normalizeUpdateSettings：默认值');
check(Array.isArray(defaults.mirrors) && defaults.mirrors.length >= 1 && defaults.mirrors.every((m) => m.startsWith('https://')), 'normalizeUpdateSettings：默认镜像列表');
check(normalizeUpdateSettings({ mirrors: ['ftp://x', 'bad', 'https://m.example/'] }).mirrors[0] === 'https://m.example/', 'normalizeUpdateSettings：mirrors 过滤非法值并补尾部斜杠');
const custom = normalizeUpdateSettings({ enabled: false, repo: 'bad/repo/name', checkIntervalHours: 0, backupBeforeUpdate: false });
check(custom.enabled === false && custom.repo === DEFAULT_UPDATE_SETTINGS.repo && custom.checkIntervalHours === 6 && custom.backupBeforeUpdate === false, 'normalizeUpdateSettings：非法值被忽略/回退', JSON.stringify(custom));

console.log(`\n=== test-update-engine: ${pass} 通过 / ${fail} 失败 ===`);
process.exit(fail ? 1 : 0);
