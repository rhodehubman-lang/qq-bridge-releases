import assert from 'node:assert/strict';
import {
  applyConversationMood,
  applyWorldMood,
  decayMood,
  emptyMood,
  formatMoodPrompt,
  lifeMoodBaseline,
  moodLabel
} from '../src/mood-engine.js';

const now = Date.parse('2026-10-26T23:00:00+08:00');
const sleeping = { state: 'sleeping', locationId: 'jill_apartment' };
const free = { state: 'free', locationId: 'jill_apartment' };
const b1 = lifeMoodBaseline(sleeping, now);
const b2 = lifeMoodBaseline(free, now);
assert.ok(b2.energy > b1.energy);
assert.ok(b2.socialOpenness > b1.socialOpenness);

const mood = emptyMood('jill');
mood.updatedAt = now - 3 * 3600 * 1000;
const before = mood.energy;
decayMood(mood, sleeping, now);
assert.ok(mood.energy < before);

const positive = applyConversationMood({ ...mood, lastMessageAt: 0 }, '谢谢你，晚安', now);
assert.ok(positive.valence >= mood.valence);
const negative = applyConversationMood({ ...mood, lastMessageAt: 0 }, '滚，别来烦我', now);
assert.ok(negative.tension > mood.tension);

const event = { id: 'evt_test', headline: '旧城区发生枪战', effects: { moodDelta: -3 } };
applyWorldMood(negative, [event], now);
assert.ok(negative.appliedEventIds.includes('evt_test'));
assert.equal(typeof moodLabel(negative), 'string');
assert.match(formatMoodPrompt(negative), /【你现在的状态】/);

console.log('✅ 心情引擎测试通过（基线/衰减/对话微调/世界事件/提示词）');
