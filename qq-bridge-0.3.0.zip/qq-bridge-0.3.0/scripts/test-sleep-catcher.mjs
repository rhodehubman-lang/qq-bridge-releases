import assert from 'node:assert/strict';
import {
  DEFAULT_SLEEP_CATCHER_SETTINGS,
  normalizeSleepCatcherSettings,
  detectGoodnight,
  detectCannotSleep,
  findPrivateGoodnight,
  decideSleepCatch,
  formatSleepCatchPrompt
} from '../src/sleep-catcher.js';

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`ok ${passed} - ${name}`);
  } catch (error) {
    console.error(`not ok ${passed + 1} - ${name}`);
    throw error;
  }
}

const owner = '100000001';
const now = 1790000000000;

test('默认设置是开启、只抓主人、轻点一句', () => {
  const settings = normalizeSleepCatcherSettings({});
  assert.equal(settings.enabled, true);
  assert.equal(settings.intensity, 'light');
  assert.equal(settings.goodnightMaxAgeMinutes, 360);
  assert.equal(settings.ignoreCannotSleep, true);
  assert.deepEqual(settings.disabledGroups, []);
});

test('时间参数被夹回安全范围，群号只保留数字', () => {
  const settings = normalizeSleepCatcherSettings({
    goodnightMaxAgeMinutes: 1,
    reappearWindowMinutes: 999,
    cooldownMinutes: -5,
    customHint: '  再熬夜就把你抓回来  ',
    disabledGroups: ['12345678', 'bad', '12345678', 987654321]
  });
  assert.equal(settings.goodnightMaxAgeMinutes, 10);
  assert.equal(settings.reappearWindowMinutes, 120);
  assert.equal(settings.cooldownMinutes, 0);
  assert.equal(settings.customHint, '再熬夜就把你抓回来');
  assert.deepEqual(settings.disabledGroups.sort(), ['12345678', '987654321']);
});

test('识别晚安和睡不着', () => {
  assert.equal(detectGoodnight('晚安，明天见'), true);
  assert.equal(detectGoodnight('我去睡了'), true);
  assert.equal(detectGoodnight('今天吃什么'), false);
  assert.equal(detectCannotSleep('失眠了，睡不着'), true);
  assert.equal(detectCannotSleep('刚醒，起来喝水'), true);
  assert.equal(detectCannotSleep('我睡了'), false);
});

test('只找主人私聊里有效期内的晚安', () => {
  const messages = [
    { userId: '999', text: '晚安', time: now - 1000, isSelf: false },
    { userId: owner, text: '晚安', time: now - 60 * 60 * 1000, isSelf: false },
    { userId: owner, text: '我睡了', time: now - 7 * 60 * 60 * 1000, isSelf: false }
  ];
  const found = findPrivateGoodnight(messages, { ownerQQ: owner, now, maxAgeMs: 6 * 60 * 60 * 1000 });
  assert.ok(found);
  assert.equal(found.text, '晚安');
});

test('主人再次出现且没有说不困时，允许抓一次', () => {
  const result = decideSleepCatch({
    settings: DEFAULT_SLEEP_CATCHER_SETTINGS,
    groupId: '123456789',
    isOwner: true,
    ownerMessage: { userId: owner, text: '我怎么还醒着', time: now },
    goodnight: { userId: owner, text: '晚安', time: now - 60 * 60 * 1000 },
    now,
    ownerTexts: ['晚安']
  });
  assert.equal(result.wake, true);
  assert.equal(result.reason, 'owner-after-goodnight');
});

test('关闭、冷却、群关闭、非主人、群 off 都不抓', () => {
  const base = {
    groupId: '123456789',
    isOwner: true,
    ownerMessage: { userId: owner, text: '又出来了', time: now },
    goodnight: { userId: owner, text: '晚安', time: now - 60 * 1000 },
    now
  };
  assert.equal(decideSleepCatch({ ...base, settings: { ...DEFAULT_SLEEP_CATCHER_SETTINGS, enabled: false } }).wake, false);
  assert.equal(decideSleepCatch({ ...base, settings: DEFAULT_SLEEP_CATCHER_SETTINGS, cooldownAt: now - 10 * 60 * 1000 }).wake, false);
  assert.equal(decideSleepCatch({ ...base, settings: { ...DEFAULT_SLEEP_CATCHER_SETTINGS, disabledGroups: ['123456789'] } }).wake, false);
  assert.equal(decideSleepCatch({ ...base, isOwner: false, settings: DEFAULT_SLEEP_CATCHER_SETTINGS }).wake, false);
  assert.equal(decideSleepCatch({ ...base, settings: DEFAULT_SLEEP_CATCHER_SETTINGS, groupPolicyMode: 'off' }).wake, false);
});

test('主人说失眠/刚醒时不抓', () => {
  const result = decideSleepCatch({
    settings: DEFAULT_SLEEP_CATCHER_SETTINGS,
    groupId: '123456789',
    isOwner: true,
    ownerMessage: { userId: owner, text: '失眠了，睡不着', time: now },
    goodnight: { userId: owner, text: '晚安', time: now - 60 * 1000 },
    now,
    ownerTexts: ['失眠了，睡不着']
  });
  assert.equal(result.wake, false);
  assert.equal(result.reason, 'cannot-sleep');
});

test('提示词分轻点/调侃，并带自定义说法', () => {
  const light = formatSleepCatchPrompt({ ...DEFAULT_SLEEP_CATCHER_SETTINGS, customHint: '再熬夜就把你抓回来' }, {
    goodnightAt: now, ownerLabel: '主人'
  });
  assert.match(light, /轻轻点一句/);
  assert.match(light, /再熬夜就把你抓回来/);
  assert.doesNotMatch(light, /示例主人/);
  const tease = formatSleepCatchPrompt({ ...DEFAULT_SLEEP_CATCHER_SETTINGS, intensity: 'tease' }, { goodnightAt: now, ownerLabel: '主人' });
  assert.match(tease, /明显调侃/);
});
