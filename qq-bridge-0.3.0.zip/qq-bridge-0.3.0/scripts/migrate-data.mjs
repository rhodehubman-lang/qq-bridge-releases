#!/usr/bin/env node
// 数据迁移 CLI：更新器在「恢复用户文件」之后调用；也可以手动跑。
//
// 用法：
//   node scripts/migrate-data.mjs                只检查（dry-run，不改任何文件）
//   node scripts/migrate-data.mjs --apply        执行迁移（每个文件写前自动备份）
//   node scripts/migrate-data.mjs --json         机器可读输出（给更新器/控制台）
//   node scripts/migrate-data.mjs --root <目录>  指定项目根（测试用）
//   node scripts/migrate-data.mjs --backup-dir <目录>  指定备份目录
//
// 退出码：0 = 成功/无需迁移；1 = 有迁移错误（已迁移的文件已备份）；2 = 参数错误。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { runMigrations, describeDataState } from '../src/data-migration.js';
import { MIGRATIONS } from '../migrations/index.mjs';

const ROOT = path.resolve(path.dirname(path.dirname(fileURLToPath(import.meta.url))));

export function parseArgs(argv = process.argv.slice(2)) {
  const out = { apply: false, json: false, root: '', backupDir: '' };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--apply') out.apply = true;
    else if (arg === '--json') out.json = true;
    else if (arg === '--root') out.root = String(argv[++i] ?? '');
    else if (arg === '--backup-dir') out.backupDir = String(argv[++i] ?? '');
    else if (arg === '--help' || arg === '-h') out.help = true;
    else throw new Error(`未知参数：${arg}`);
  }
  return out;
}

async function main(argv = process.argv.slice(2)) {
  let args;
  try {
    args = parseArgs(argv);
  } catch (error) {
    console.error(`[数据迁移] ${error.message}`);
    return 2;
  }
  if (args.help) {
    console.log('用法: node scripts/migrate-data.mjs [--apply] [--json] [--root <目录>] [--backup-dir <目录>]');
    return 0;
  }
  const root = args.root ? path.resolve(args.root) : ROOT;
  if (!fs.existsSync(root)) {
    console.error(`[数据迁移] 根目录不存在：${root}`);
    return 2;
  }

  const report = runMigrations({
    root,
    migrations: MIGRATIONS,
    apply: args.apply,
    backupRoot: args.backupDir ? path.resolve(args.backupDir) : null,
    log: args.json ? () => {} : (line) => console.log(`[数据迁移] ${line}`),
  });
  const state = describeDataState(root);

  if (args.json) {
    process.stdout.write(`${JSON.stringify({ root, ...report, datasets: state.datasets }, null, 2)}\n`);
    return report.errors.length ? 1 : 0;
  }

  const targetText = Object.entries(state.datasets)
    .filter(([, value]) => value.files > 0)
    .map(([id, value]) => `${id}=v${value.current}`)
    .join(', ');
  console.log(`[数据迁移] 扫描 ${report.scanned} 个数据文件${targetText ? `（目标版本：${targetText}）` : ''}`);
  if (!report.pending.length && !report.errors.length) {
    console.log('[数据迁移] ✅ 所有数据文件都已是当前版本，无需迁移');
    return 0;
  }
  if (report.dryRun) {
    for (const item of report.pending) console.log(`[数据迁移] 待迁移 ${item.file}：v${item.from} → v${item.to}（${item.steps.join(' → ')}）`);
    console.log('[数据迁移] dry-run：不会改任何文件；加 --apply 执行');
  } else {
    for (const item of report.migrated) console.log(`[数据迁移] ✅ 已迁移 ${item.file}：v${item.from} → v${item.to}`);
    if (report.backupDir) console.log(`[数据迁移] 迁移前备份：${report.backupDir}`);
    if (report.migrated.length) console.log(`[数据迁移] ✅ 完成：迁移 ${report.migrated.length} 个文件，跳过 ${report.skipped} 个`);
  }
  if (report.errors.length) {
    for (const error of report.errors) console.error(`[数据迁移] ❌ ${error.file}：${error.error}`);
    console.error(`[数据迁移] 有 ${report.errors.length} 个错误；已迁移的文件都有备份，可手动回滚`);
    return 1;
  }
  return 0;
}

const invokedDirectly = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (invokedDirectly) {
  main().then((code) => process.exit(code)).catch((error) => {
    console.error(`[数据迁移] 未预期错误：${error?.stack || error?.message || error}`);
    process.exit(1);
  });
}
