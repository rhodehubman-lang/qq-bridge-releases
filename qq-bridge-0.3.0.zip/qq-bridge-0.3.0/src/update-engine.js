// 自动更新引擎（纯函数部分）：版本解析/比较、latest.json 清单校验、兼容性判定、
// 代码白名单、zip 安全检查、sha256 校验。所有 IO（下载/写盘/拉起 helper）在别处，
// 这样更新逻辑可以离线单测——更新器一旦出错就是朋友的安装报废，必须钉死。
import { createHash } from 'node:crypto';

export const UPDATE_SETTINGS_VERSION = 1;

/** 国内网络访问 GitHub Releases 经常失败；镜像前缀按顺序兜底（下载仍会校验 sha256）。 */
export const DEFAULT_UPDATE_MIRRORS = Object.freeze([
  'https://ghproxy.net/',
  'https://gh-proxy.com/'
]);

/** 默认更新设置（写入 config.json 的 updates 段）。 */
export const DEFAULT_UPDATE_SETTINGS = Object.freeze({
  enabled: true,
  // 源码仓库可以私有；更新清单/附件放在独立的公开发布仓库。
  repo: 'Derpyu520/qq-bridge-releases',
  autoCheck: true,
  checkIntervalHours: 6,
  channel: 'auto',
  allowPrerelease: false,
  customManifestUrl: '',
  keepCodeBackups: 3,
  backupBeforeUpdate: true,
  mirrors: [...DEFAULT_UPDATE_MIRRORS],
});

// ── 版本 ────────────────────────────────────────────────────────────────────
//
// 格式：MAJOR.MINOR.PATCH[-rN]。无 -rN 视为 r0（0.2.0 比 0.2.0-r4 旧）。
// 版本线 line = MAJOR.MINOR.PATCH；默认只在同一条线内更新。
export function parseVersion(text) {
  const raw = String(text ?? '').trim();
  const m = /^(\d+)\.(\d+)\.(\d+)(?:-r(\d+))?$/.exec(raw);
  if (!m) return null;
  const major = Number(m[1]);
  const minor = Number(m[2]);
  const patch = Number(m[3]);
  const rev = m[4] === undefined ? 0 : Number(m[4]);
  return { raw, major, minor, patch, rev, line: `${major}.${minor}.${patch}` };
}

const asParsed = (v) => (typeof v === 'string' ? parseVersion(v) : v);

export function compareVersions(a, b) {
  const left = asParsed(a);
  const right = asParsed(b);
  if (!left || !right) throw new Error(`无法比较版本：${String(a)} / ${String(b)}`);
  for (const key of ['major', 'minor', 'patch', 'rev']) {
    if (left[key] !== right[key]) return left[key] > right[key] ? 1 : -1;
  }
  return 0;
}

export function isNewerVersion(candidate, current) {
  return compareVersions(candidate, current) > 0;
}

// ── DSH 版本（宽松比较：0.2.1-rc.5 / 0.2.0 / 0.2.1）────────────────────────
export function parseDshVersion(text) {
  const raw = String(text ?? '').trim();
  const m = /^(\d+)\.(\d+)\.(\d+)(?:[-.]?(?:rc|beta|alpha)\.?(\d+))?/i.exec(raw);
  if (!m) return null;
  return {
    raw,
    major: Number(m[1]),
    minor: Number(m[2]),
    patch: Number(m[3]),
    pre: m[4] === undefined ? null : Number(m[4]),
  };
}

export function compareDshVersions(a, b) {
  const left = typeof a === 'string' ? parseDshVersion(a) : a;
  const right = typeof b === 'string' ? parseDshVersion(b) : b;
  if (!left || !right) throw new Error(`无法比较 DSH 版本：${String(a)} / ${String(b)}`);
  for (const key of ['major', 'minor', 'patch']) {
    if (left[key] !== right[key]) return left[key] > right[key] ? 1 : -1;
  }
  // 同号：预发布 < 正式版
  if (left.pre === null && right.pre !== null) return 1;
  if (left.pre !== null && right.pre === null) return -1;
  if (left.pre !== null && right.pre !== null && left.pre !== right.pre) return left.pre > right.pre ? 1 : -1;
  return 0;
}

/**
 * DSH 兼容判定。min 可以带预发布（0.2.0-rc.2），max 按数值/正式版上限处理：
 * 例如 max=0.2.1 时 0.2.1-rc.5 也允许（rc 在正式版之前，仍属同一线）。
 * @returns {'ok'|'too-old'|'too-new'|'unknown'}
 */
export function checkDshCompat(currentDshVersion, dshCompat = {}) {
  const current = parseDshVersion(currentDshVersion);
  if (!current) return 'unknown';
  const min = parseDshVersion(dshCompat.min);
  const max = parseDshVersion(dshCompat.max);
  if (dshCompat.min && !min) return 'unknown';
  if (dshCompat.max && !max) return 'unknown';
  if (min && compareDshVersions(current, min) < 0) return 'too-old';
  if (max) {
    // 比较到核心版本号即可：current 更大 ⇒ 太新
    if (current.major !== max.major || current.minor !== max.minor || current.patch !== max.patch) {
      if (compareDshVersions(current, max) > 0) return 'too-new';
    }
  }
  return 'ok';
}

// ── latest.json 清单 ────────────────────────────────────────────────────────

const isSha256 = (value) => typeof value === 'string' && /^[0-9a-f]{64}$/i.test(value);

function normalizeEntry(entry, label) {
  if (!entry || typeof entry !== 'object' || Array.isArray(entry)) throw new Error(`${label} 不是对象`);
  const version = String(entry.version ?? '').trim();
  const parsed = parseVersion(version);
  if (!parsed) throw new Error(`${label}.version 非法：${JSON.stringify(entry.version)}`);
  const tag = String(entry.tag ?? `v${version}`).trim();
  const asset = String(entry.asset ?? `qq-bridge-${version}.zip`).trim();
  if (!/^[A-Za-z0-9._-]+\.zip$/.test(asset)) throw new Error(`${label}.asset 必须是 zip 文件名（不含路径）：${asset}`);
  const assetUrl = String(entry.assetUrl ?? '').trim();
  if (!isSafeUpdateUrl(assetUrl)) throw new Error(`${label}.assetUrl 必须是 https 地址（本地回环 http 仅演练）`);
  const sha256 = String(entry.sha256 ?? '').trim().toLowerCase();
  if (!isSha256(sha256)) throw new Error(`${label}.sha256 不是 64 位十六进制`);
  const size = Number(entry.size);
  if (!Number.isSafeInteger(size) || size <= 0) throw new Error(`${label}.size 非法：${entry.size}`);
  const dshCompat = entry.dshCompat && typeof entry.dshCompat === 'object'
    ? { min: String(entry.dshCompat.min ?? ''), max: String(entry.dshCompat.max ?? '') }
    : { min: '', max: '' };
  const dataSchema = Number(entry.dataSchema);
  const minDataSchema = Number(entry.minDataSchema ?? 1);
  return {
    line: String(entry.line ?? parsed.line),
    version,
    parsedVersion: parsed,
    tag,
    asset,
    assetUrl,
    sha256,
    size,
    dshCompat,
    requiresDshRestart: entry.requiresDshRestart === true,
    notes: String(entry.notes ?? ''),
    releasedAt: String(entry.releasedAt ?? ''),
    dataSchema: Number.isSafeInteger(dataSchema) ? dataSchema : null,
    minDataSchema: Number.isSafeInteger(minDataSchema) ? minDataSchema : 1,
  };
}

/**
 * 校验 latest.json。返回 { ok, manifest } 或 { ok:false, error }。
 * 清单来自网络，必须当作不可信输入：字段缺失/类型错误一律拒绝，宁可不更新。
 */
export function normalizeManifest(raw) {
  try {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('清单不是对象');
    if (Number(raw.schema) !== 1) throw new Error(`不支持的清单 schema：${raw.schema}`);
    const recommended = normalizeEntry(raw.recommended, 'recommended');
    const lines = {};
    if (raw.lines && typeof raw.lines === 'object') {
      for (const [line, entry] of Object.entries(raw.lines)) {
        lines[line] = normalizeEntry(entry, `lines.${line}`);
      }
    }
    return { ok: true, manifest: { schema: 1, updatedAt: String(raw.updatedAt ?? ''), recommended, lines } };
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  }
}

// ── 决定要不要更新 ──────────────────────────────────────────────────────────

/**
 * @param {object} opts
 * @param {object} opts.manifest normalizeManifest 的结果
 * @param {string} opts.currentVersion 当前桥接版本
 * @param {string} [opts.currentDshVersion] 当前 DSH 版本（读不到就省略）
 * @param {number} [opts.currentDataSchema] 当前数据 schema
 * @param {boolean} [opts.allowCrossLine=false] 是否允许跨版本线（默认不允许）
 * @returns {{status:'up-to-date'|'available'|'refused'|'invalid', target?:object, code?:string, message:string, warnings:string[]}}
 */
export function checkForUpdate({
  manifest,
  currentVersion,
  currentDshVersion = '',
  currentDataSchema = 1,
  allowCrossLine = false,
} = {}) {
  const normalized = manifest?.ok === true ? manifest.manifest : null;
  if (!normalized) return { status: 'invalid', code: 'bad-manifest', message: '更新清单格式不正确', warnings: [] };
  const current = parseVersion(currentVersion);
  if (!current) return { status: 'invalid', code: 'bad-current-version', message: `当前版本无法解析：${currentVersion}`, warnings: [] };
  const warnings = [];

  const target = normalized.lines[current.line] || normalized.recommended;
  if (!target) return { status: 'invalid', code: 'no-target', message: '清单里没有可用版本', warnings };
  if (!isNewerVersion(target.parsedVersion, current)) {
    return { status: 'up-to-date', target, message: `已是最新版本（${currentVersion}）`, warnings };
  }
  if (target.line !== current.line && !allowCrossLine) {
    return {
      status: 'refused',
      code: 'cross-line',
      target,
      message: `发现新版本 ${target.version}，但它属于另一条版本线（当前 ${current.line}）。跨线更新通常还需要更换 DSH 版本，请按发布说明手动升级。`,
      warnings,
    };
  }
  if (target.minDataSchema > currentDataSchema) {
    return {
      status: 'refused',
      code: 'data-too-old',
      target,
      message: `新版本要求数据 schema ≥ v${target.minDataSchema}（当前 v${currentDataSchema}），请先升级到中间版本再更新。`,
      warnings,
    };
  }
  if (currentDshVersion) {
    const compat = checkDshCompat(currentDshVersion, target.dshCompat);
    if (compat === 'too-old') {
      return {
        status: 'refused',
        code: 'dsh-too-old',
        target,
        message: `新版本要求 DSH ≥ ${target.dshCompat.min || '?'}（当前 ${currentDshVersion}），请先升级 DSH。`,
        warnings,
      };
    }
    if (compat === 'too-new') {
      return {
        status: 'refused',
        code: 'dsh-too-new',
        target,
        message: `新版本只兼容到 DSH ${target.dshCompat.max}（当前 ${currentDshVersion}），请等待适配版本。`,
        warnings,
      };
    }
    if (compat === 'unknown') warnings.push('无法确认当前 DSH 版本，更新前请手动确认兼容性');
  } else {
    warnings.push('读不到当前 DSH 版本，更新前请手动确认兼容性');
  }
  return {
    status: 'available',
    target,
    message: `发现新版本 ${target.version}（当前 ${currentVersion}）`,
    warnings,
    requiresDshRestart: target.requiresDshRestart === true,
  };
}

// ── 代码白名单（只换代码，绝不碰数据）──────────────────────────────────────

export const CODE_DIRS = Object.freeze(['src', 'public', 'scripts', 'dsh', 'plugins', 'ops', 'docs', 'assets', 'migrations']);
export const CODE_ROOT_FILES = Object.freeze([
  'README.md', 'README.en.md', 'CHANGELOG.md', 'LICENSE', 'RULES.md',
  'config.example.json', 'package.json', 'package-lock.json', 'pnpm-lock.yaml',
  'node.cmd', 'pnpm.cmd', 'start.bat', 'restart.bat',
  '安装.cmd', '启动.cmd',
]);
export const PROTECTED_PATHS = Object.freeze([
  'state', 'config.json', 'roles', 'life-profiles', 'osts', 'audio',
  'node_modules', '_backups', 'dist', '_local', '_cloudcheck', '.git', 'logs',
]);

const normalizeRel = (rel) => String(rel ?? '').replace(/\\/g, '/').replace(/^\/+/, '');

export function isCodePath(rel) {
  const p = normalizeRel(rel);
  if (!p) return false;
  if (p.split('/').some((seg) => seg === '..')) return false;
  if (p.includes('\u0000')) return false;
  const top = p.split('/')[0];
  if (CODE_ROOT_FILES.includes(p)) return true;
  return CODE_DIRS.includes(top) && p.includes('/');
}

export function isProtectedPath(rel) {
  const p = normalizeRel(rel);
  if (!p) return false;
  return PROTECTED_PATHS.some((item) => p === item || p.startsWith(`${item}/`));
}

// ── zip 安全检查 ────────────────────────────────────────────────────────────

/** 更新源 URL 安全判定：https，或本地回环 http（仅开发/演练）。 */
export function isSafeUpdateUrl(urlText, { allowLoopbackHttp = true } = {}) {
  let url;
  try { url = new URL(String(urlText)); } catch { return false; }
  if (url.protocol === 'https:') return true;
  if (url.protocol === 'http:' && allowLoopbackHttp
      && ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname)) return true;
  return false;
}

/**
 * 校验 zip 条目路径：拒绝绝对路径、盘符、穿越、反斜杠、空名、符号链接/目录逃逸。
 * 返回 { ok, entries, error }；entries 是规范化后的相对路径列表（过滤目录条目）。
 */
export function assertSafeZipEntries(entryNames) {
  if (!Array.isArray(entryNames)) return { ok: false, error: 'zip 条目不是数组' };
  const entries = [];
  for (const raw of entryNames) {
    const name = String(raw ?? '');
    if (!name) continue;
    if (name.endsWith('/')) continue; // 目录条目
    if (name.includes('\u0000')) return { ok: false, error: 'zip 条目含 NUL' };
    if (name.includes('\\')) return { ok: false, error: `zip 条目使用反斜杠：${name}` };
    if (/^[A-Za-z]:/.test(name)) return { ok: false, error: `zip 条目是绝对路径：${name}` };
    if (name.startsWith('/')) return { ok: false, error: `zip 条目是绝对路径：${name}` };
    const parts = name.split('/');
    if (parts.some((part) => part === '..' || part === '')) return { ok: false, error: `zip 条目含非法路径段：${name}` };
    entries.push(name);
  }
  if (!entries.length) return { ok: false, error: 'zip 里没有文件' };
  return { ok: true, entries };
}

/** 规划替换：只保留白名单代码文件；返回 { files, skippedProtected, skippedOther }。 */
export function planCodeReplacement(entries) {
  const files = [];
  const skippedProtected = [];
  const skippedOther = [];
  for (const rel of entries) {
    if (isProtectedPath(rel)) { skippedProtected.push(rel); continue; }
    if (!isCodePath(rel)) { skippedOther.push(rel); continue; }
    files.push(rel);
  }
  return { files, skippedProtected, skippedOther };
}

// ── 校验与格式化 ────────────────────────────────────────────────────────────

export function sha256Hex(buffer) {
  return createHash('sha256').update(buffer).digest('hex');
}

/** 校验下载内容：sha256 + 大小（两者都必查，缺一不可）。 */
export function verifyDownload({ buffer, sha256, size } = {}) {
  if (!buffer || !Buffer.isBuffer(buffer)) return { ok: false, error: '下载内容为空' };
  if (typeof size !== 'number' || buffer.length !== size) {
    return { ok: false, error: `文件大小不匹配：期望 ${size}，实际 ${buffer.length}` };
  }
  const actual = sha256Hex(buffer);
  if (String(sha256).toLowerCase() !== actual) {
    return { ok: false, error: `sha256 不匹配（下载可能损坏/被篡改）：期望 ${sha256}，实际 ${actual}` };
  }
  return { ok: true, sha256: actual };
}

export function formatBytes(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

/** 把任意来源的更新配置规范化（config.json 的 updates 段）。 */
export function normalizeUpdateSettings(raw) {
  const src = raw && typeof raw === 'object' ? raw : {};
  const settings = { ...DEFAULT_UPDATE_SETTINGS };
  if (typeof src.enabled === 'boolean') settings.enabled = src.enabled;
  if (typeof src.repo === 'string' && /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(src.repo)) settings.repo = src.repo;
  if (typeof src.autoCheck === 'boolean') settings.autoCheck = src.autoCheck;
  if (Number.isSafeInteger(Number(src.checkIntervalHours)) && Number(src.checkIntervalHours) >= 1) settings.checkIntervalHours = Number(src.checkIntervalHours);
  if (typeof src.channel === 'string') settings.channel = src.channel;
  if (typeof src.allowPrerelease === 'boolean') settings.allowPrerelease = src.allowPrerelease;
  if (typeof src.customManifestUrl === 'string') settings.customManifestUrl = src.customManifestUrl;
  if (Number.isSafeInteger(Number(src.keepCodeBackups)) && Number(src.keepCodeBackups) >= 1) settings.keepCodeBackups = Number(src.keepCodeBackups);
  if (typeof src.backupBeforeUpdate === 'boolean') settings.backupBeforeUpdate = src.backupBeforeUpdate;
  if (Array.isArray(src.mirrors)) {
    settings.mirrors = src.mirrors
      .map((m) => String(m ?? '').trim())
      .filter((m) => /^https?:\/\//i.test(m))
      .map((m) => (m.endsWith('/') ? m : m + '/'))
      .slice(0, 5);
  }
  return settings;
}
