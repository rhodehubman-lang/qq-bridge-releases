// 群组策略：把“这个群该多主动、什么时候安静、哪些话题别碰”从全局配置里拆出来。
//
// 设计边界：
// - 纯函数模块，不读写文件、不依赖桥接状态；桥接只负责落盘与调用。
// - 策略只影响**唤醒/主动发言**，不改变消息入库；关闭的群仍然保留最近消息，
//   供主人私聊的跨群简报使用。
// - 默认值保守：normal + 允许主动机会；真正的“安静”由控制台显式设置。

export const GROUP_POLICY_MODES = Object.freeze(['active', 'normal', 'quiet', 'mention-only', 'off']);
export const GROUP_REPORT_MODES = Object.freeze(['off', 'digest', 'all']);

export const DEFAULT_GROUP_POLICY = Object.freeze({
  mode: 'normal',
  proactive: true,
  proactiveEveryMinutes: 0,
  proactiveProbability: 1,
  replyProbability: 1,
  allowOwnerAlways: true,
  requireMentionAtNight: true,
  reportMode: 'all',
  reportKeywords: [],
  topicHints: '',
  avoidTopics: []
});

export const DEFAULT_GROUP_POLICY_STATE = Object.freeze({
  version: 1,
  defaults: DEFAULT_GROUP_POLICY,
  groups: {}
});

const MODE_SET = new Set(GROUP_POLICY_MODES);
const REPORT_SET = new Set(GROUP_REPORT_MODES);

function cleanText(value, max = 500) {
  return String(value ?? '')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
    .trim()
    .slice(0, max);
}

function cleanStringArray(value, { maxItems = 20, maxChars = 40 } = {}) {
  const raw = Array.isArray(value) ? value : String(value ?? '').split(/[,，\s]+/);
  const out = [];
  for (const item of raw) {
    const text = cleanText(item, maxChars);
    if (text && !out.includes(text)) out.push(text);
    if (out.length >= maxItems) break;
  }
  return out;
}

export function normalizeGroupId(value) {
  const id = String(value ?? '').trim();
  return /^\d{3,20}$/.test(id) ? id : '';
}

export function normalizeGroupPolicy(raw, defaults = DEFAULT_GROUP_POLICY) {
  const base = defaults && typeof defaults === 'object' ? defaults : DEFAULT_GROUP_POLICY;
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const mode = String(src.mode ?? base.mode ?? 'normal').toLowerCase();
  const reportMode = String(src.reportMode ?? base.reportMode ?? 'all').toLowerCase();
  const everyRaw = Number(src.proactiveEveryMinutes ?? base.proactiveEveryMinutes ?? 0);
  const clamp01 = (value, fallback) => {
    const n = Number(value);
    return Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : fallback;
  };
  return {
    mode: MODE_SET.has(mode) ? mode : 'normal',
    proactive: src.proactive === undefined ? base.proactive !== false : src.proactive === true,
    proactiveEveryMinutes: Number.isFinite(everyRaw)
      ? Math.min(1440, Math.max(0, Math.round(everyRaw)))
      : 0,
    proactiveProbability: clamp01(src.proactiveProbability, base.proactiveProbability ?? 1),
    replyProbability: clamp01(src.replyProbability, base.replyProbability ?? 1),
    allowOwnerAlways: src.allowOwnerAlways === undefined
      ? base.allowOwnerAlways !== false
      : src.allowOwnerAlways === true,
    requireMentionAtNight: src.requireMentionAtNight === undefined
      ? base.requireMentionAtNight !== false
      : src.requireMentionAtNight === true,
    reportMode: REPORT_SET.has(reportMode) ? reportMode : 'all',
    reportKeywords: cleanStringArray(src.reportKeywords ?? base.reportKeywords, { maxItems: 20, maxChars: 30 }),
    topicHints: cleanText(src.topicHints ?? base.topicHints, 500),
    avoidTopics: cleanStringArray(src.avoidTopics ?? base.avoidTopics, { maxItems: 20, maxChars: 30 })
  };
}

export function normalizeGroupPolicyState(raw) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const defaults = normalizeGroupPolicy(src.defaults, DEFAULT_GROUP_POLICY);
  const groups = {};
  if (src.groups && typeof src.groups === 'object' && !Array.isArray(src.groups)) {
    for (const [rawId, item] of Object.entries(src.groups)) {
      const groupId = normalizeGroupId(rawId);
      if (!groupId) continue;
      const name = cleanText(item?.name, 80);
      groups[groupId] = { ...normalizeGroupPolicy(item, defaults), ...(name ? { name } : {}) };
    }
  }
  return { version: 1, defaults, groups };
}

export function policyForGroup(state, groupId) {
  const id = normalizeGroupId(groupId);
  if (!id) return null;
  const normalized = state && state.groups ? state : normalizeGroupPolicyState(state);
  const item = normalized.groups[id];
  return item ? normalizeGroupPolicy(item, normalized.defaults) : normalizeGroupPolicy(normalized.defaults);
}

export function setGroupPolicy(state, groupId, patch, { name = '' } = {}) {
  const id = normalizeGroupId(groupId);
  if (!id) throw new Error('群号必须是 3~20 位数字');
  const normalized = state && state.groups ? state : normalizeGroupPolicyState(state);
  const current = normalized.groups[id] ?? normalizeGroupPolicy(normalized.defaults);
  const next = normalizeGroupPolicy({ ...current, ...(patch ?? {}) }, normalized.defaults);
  if (name) next.name = cleanText(name, 80);
  else if (current.name) next.name = current.name;
  normalized.groups[id] = next;
  return normalized;
}

export function isWakeAllowedByPolicy(policy, reason, { isOwner = false, atNight = false } = {}) {
  const p = policy && typeof policy === 'object' ? policy : DEFAULT_GROUP_POLICY;
  const base = String(reason ?? '').split(':')[0];
  if (!base) return false;
  if (p.mode === 'off') return false;
  // 管理员 @/提问等仍然可以触发；但“完全关闭”优先，不能被 owner 绕过。
  if (isOwner && p.allowOwnerAlways !== false) return true;
  // 夜间默认只对直接点名/直接提问作出反应，避免把普通闲聊当成对话。
  if (atNight && p.requireMentionAtNight !== false && !['atMention', 'nameMention', 'question'].includes(base)) {
    return false;
  }
  if (p.mode === 'active' || p.mode === 'normal') return true;
  if (p.mode === 'mention-only') return base === 'atMention' || base === 'nameMention';
  if (p.mode === 'quiet') {
    return ['atMention', 'nameMention', 'question', 'keyword', 'speaker'].includes(base);
  }
  return false;
}

export function isProactiveAllowedByPolicy(policy) {
  const p = policy && typeof policy === 'object' ? policy : DEFAULT_GROUP_POLICY;
  return p.mode !== 'off' && (p.mode === 'active' || p.mode === 'normal') && p.proactive !== false;
}

/** 注入群会话的提示词；只传达“这个群怎么对待我”，不暴露其它群。 */
export function formatGroupPolicyPrompt(policy, { groupName = '', groupId = '' } = {}) {
  const p = policy && typeof policy === 'object' ? policy : DEFAULT_GROUP_POLICY;
  const label = groupName ? `「${groupName}」` : (groupId ? `群 ${groupId}` : '当前群');
  const modeText = {
    active: '活跃：可以主动接话、主动开话题',
    normal: '正常：有自然机会可以参与',
    quiet: '安静：只在被 @/叫到名字/明确提问/急事关键词时回应，不主动开话题',
    'mention-only': '仅被叫：只有被 @ 或叫到名字时才回应',
    off: '关闭：不因群消息唤醒；仅保留最近消息供主人私聊简报'
  }[p.mode] ?? '正常';
  const lines = [`【本群规则】${label}：${modeText}。`];
  if (p.proactive === false || p.mode === 'quiet' || p.mode === 'mention-only' || p.mode === 'off') {
    lines.push('不要主动冒泡、不要用主动机会开话题。');
  }
  if (p.topicHints) lines.push(`【本群可聊方向】${p.topicHints}`);
  if (p.avoidTopics.length) lines.push(`【本群别碰的话题】${p.avoidTopics.join('、')}。不要主动提起，被追问也简短带过。`);
  if (p.requireMentionAtNight !== false) lines.push('【夜间规则】23:00–08:00 只有被直接 @、叫名字或明确提问时才回应，不主动接普通闲聊。');
  if (p.replyProbability < 1) lines.push(`【参与尺度】自然参与即可，不需要每条都回复；大约 ${Math.round(p.replyProbability * 100)}% 的消息适合接话。`);
  return lines.join('\n');
}

export function groupPolicySummary(policy) {
  const p = policy && typeof policy === 'object' ? policy : DEFAULT_GROUP_POLICY;
  return {
    mode: p.mode,
    proactive: p.proactive,
    proactiveEveryMinutes: p.proactiveEveryMinutes,
    proactiveProbability: p.proactiveProbability,
    replyProbability: p.replyProbability,
    allowOwnerAlways: p.allowOwnerAlways,
    requireMentionAtNight: p.requireMentionAtNight,
    reportMode: p.reportMode,
    topicHints: p.topicHints,
    avoidTopics: p.avoidTopics
  };
}
