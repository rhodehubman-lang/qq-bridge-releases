// 跨群感知 / 主动汇报：纯函数模块。
//
// 隐私边界（必须遵守）：
// - 群简报只来自**群聊**会话的最近消息，不读其它私聊；
// - 跨群上下文只注入**管理员私聊**，注入别的群属于串群泄露；
// - 汇报内容只含群名、发送者昵称和消息摘要，不含 agent token、群成员 QQ 号等管理字段。

export const DEFAULT_CROSS_GROUP_CONFIG = Object.freeze({
  enabled: true,
  ownerContext: true,
  ownerContextMaxChars: 3000,
  recentMessages: 6,
  maxReportsPerDay: 3,
  minIntervalMinutes: 60,
  reportMaxChars: 1800,
  ownerAliases: ['主人'],
  quietHours: { start: '23:00', end: '08:00' },
  dailyDigest: { enabled: true, time: '22:30' },
  impressions: {
    enabled: true,
    intervalMinutes: 120,
    minMessages: 6,
    maxChars: 240
  },
  urgent: {
    enabled: true,
    cooldownMinutes: 20,
    keywords: ['急', '出事了', '救命', '报警', '医院', '吵架', '生气', '难过', '找你', '不舒服']
  }
});

const OWNER_ALIAS_FALLBACK = ['主人'];

function cleanText(value, max = 200) {
  return String(value ?? '')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);
}

function cleanStringArray(value, { maxItems = 20, maxChars = 30 } = {}) {
  const raw = Array.isArray(value) ? value : String(value ?? '').split(/[,，\s]+/);
  const out = [];
  for (const item of raw) {
    const text = cleanText(item, maxChars);
    if (text && !out.includes(text)) out.push(text);
    if (out.length >= maxItems) break;
  }
  return out;
}

function normalizeClock(value, fallback) {
  const match = /^(\d{1,2}):(\d{2})$/.exec(String(value ?? '').trim());
  if (!match) return fallback;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  if (!Number.isFinite(hour) || !Number.isFinite(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) return fallback;
  return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
}

export function normalizeCrossGroupConfig(raw) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const daily = src.dailyDigest && typeof src.dailyDigest === 'object' ? src.dailyDigest : {};
  const urgent = src.urgent && typeof src.urgent === 'object' ? src.urgent : {};
  const quiet = src.quietHours && typeof src.quietHours === 'object' ? src.quietHours : {};
  const impressions = src.impressions && typeof src.impressions === 'object' ? src.impressions : {};
  const maxReports = Number(src.maxReportsPerDay);
  const minInterval = Number(src.minIntervalMinutes);
  const recent = Number(src.recentMessages);
  const contextChars = Number(src.ownerContextMaxChars);
  const reportChars = Number(src.reportMaxChars);
  const cooldown = Number(urgent.cooldownMinutes);
  const impressionInterval = Number(impressions.intervalMinutes);
  const impressionMinMessages = Number(impressions.minMessages);
  const impressionChars = Number(impressions.maxChars);
  return {
    enabled: src.enabled !== false,
    ownerContext: src.ownerContext !== false,
    ownerContextMaxChars: Number.isFinite(contextChars) ? Math.min(8000, Math.max(500, Math.round(contextChars))) : 3000,
    recentMessages: Number.isFinite(recent) ? Math.min(20, Math.max(1, Math.round(recent))) : 6,
    maxReportsPerDay: Number.isFinite(maxReports) ? Math.min(20, Math.max(1, Math.round(maxReports))) : 3,
    minIntervalMinutes: Number.isFinite(minInterval) ? Math.min(1440, Math.max(0, Math.round(minInterval))) : 60,
    reportMaxChars: Number.isFinite(reportChars) ? Math.min(5000, Math.max(500, Math.round(reportChars))) : 1800,
    ownerAliases: cleanStringArray(src.ownerAliases ?? OWNER_ALIAS_FALLBACK, { maxItems: 10, maxChars: 20 }),
    quietHours: {
      start: normalizeClock(quiet.start, '23:00'),
      end: normalizeClock(quiet.end, '08:00')
    },
    dailyDigest: {
      enabled: daily.enabled !== false,
      time: normalizeClock(daily.time, '22:30')
    },
    impressions: {
      enabled: impressions.enabled !== false,
      intervalMinutes: Number.isFinite(impressionInterval) ? Math.min(1440, Math.max(10, Math.round(impressionInterval))) : 120,
      minMessages: Number.isFinite(impressionMinMessages) ? Math.min(40, Math.max(2, Math.round(impressionMinMessages))) : 6,
      maxChars: Number.isFinite(impressionChars) ? Math.min(800, Math.max(80, Math.round(impressionChars))) : 240
    },
    urgent: {
      enabled: urgent.enabled !== false,
      cooldownMinutes: Number.isFinite(cooldown) ? Math.min(1440, Math.max(0, Math.round(cooldown))) : 20,
      keywords: cleanStringArray(urgent.keywords ?? DEFAULT_CROSS_GROUP_CONFIG.urgent.keywords, { maxItems: 20, maxChars: 20 })
    }
  };
}

export function normalizeCrossGroupState(raw) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const normalizeReport = (item) => ({
    at: Number(item?.at) || 0,
    kind: String(item?.kind ?? ''),
    characterId: cleanText(item?.characterId, 80),
    day: String(item?.day ?? ''),
    groups: Array.isArray(item?.groups) ? item.groups.map((x) => cleanText(x, 80)).filter(Boolean).slice(0, 20) : [],
    preview: cleanText(item?.preview, 500)
  });
  const reports = (Array.isArray(src.reports) ? src.reports : [])
    .map(normalizeReport)
    .filter((item) => item.at > 0)
    .sort((a, b) => a.at - b.at)
    .slice(-100);
  const normalizePending = (item) => ({
    at: Number(item?.at) || 0,
    groupId: cleanText(item?.groupId, 20),
    groupName: cleanText(item?.groupName, 80),
    sender: cleanText(item?.sender, 60),
    text: cleanText(item?.text, 240),
    reason: cleanText(item?.reason, 40),
    keyword: cleanText(item?.keyword, 30)
  });
  const pending = (Array.isArray(src.pending) ? src.pending : [])
    .map(normalizePending)
    .filter((item) => item.at > 0 && item.groupId)
    .sort((a, b) => a.at - b.at)
    .slice(-50);
  const normalizeImpression = (item) => ({
    id: cleanText(item?.id, 80),
    at: Number(item?.at) || 0,
    characterId: cleanText(item?.characterId, 80),
    groupId: cleanText(item?.groupId, 20),
    groupName: cleanText(item?.groupName, 80),
    text: cleanText(item?.text, 800),
    fromAt: Number(item?.fromAt) || 0,
    toAt: Number(item?.toAt) || 0,
    sourceCount: Math.max(0, Math.round(Number(item?.sourceCount) || 0))
  });
  const impressions = (Array.isArray(src.impressions) ? src.impressions : [])
    .map(normalizeImpression)
    .filter((item) => item.at > 0 && item.groupId && item.text)
    .sort((a, b) => a.at - b.at)
    .slice(-300);
  return {
    version: 1,
    lastDigestDay: String(src.lastDigestDay ?? ''),
    lastDigestAt: Number(src.lastDigestAt) || 0,
    lastReportAt: Number(src.lastReportAt) || 0,
    // 简报文本只在“写它的那个角色”下生效，角色切换后不能把 Jill 的摘要念给别的角色。
    digestCharacterId: cleanText(src.digestCharacterId, 80),
    digestText: String(src.digestText ?? '').slice(0, 8000),
    reports,
    pending,
    impressions
  };
}

export function localDayKey(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function minutesOfDay(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  return d.getHours() * 60 + d.getMinutes();
}

export function isQuietHours(date, quietHours) {
  const start = normalizeClock(quietHours?.start, '23:00');
  const end = normalizeClock(quietHours?.end, '08:00');
  const toMinutes = (clock) => {
    const [h, m] = clock.split(':').map(Number);
    return h * 60 + m;
  };
  const now = minutesOfDay(date);
  const a = toMinutes(start);
  const b = toMinutes(end);
  if (a === b) return false;
  return a < b ? (now >= a && now < b) : (now >= a || now < b);
}

export function canSendOwnerReport(state, config, now = new Date(), { kind = 'digest' } = {}) {
  const cfg = normalizeCrossGroupConfig(config);
  if (!cfg.enabled) return { ok: false, reason: 'cross-group disabled' };
  if (isQuietHours(now, cfg.quietHours)) return { ok: false, reason: 'quiet hours' };
  const day = localDayKey(now);
  const used = (state?.reports ?? []).filter((r) => r && r.day === day).length;
  if (used >= cfg.maxReportsPerDay) return { ok: false, reason: 'daily report limit' };
  return { ok: true, day, used, kind };
}

export function recordOwnerReport(state, config, { kind, now = new Date(), groups = [], preview = '', characterId = '' } = {}) {
  const target = state && Array.isArray(state.reports) ? state : normalizeCrossGroupState(state);
  const cfg = normalizeCrossGroupConfig(config);
  const at = now instanceof Date ? now.getTime() : Number(now) || Date.now();
  const char = cleanText(characterId, 80);
  target.reports.push({
    at,
    kind: cleanText(kind, 20),
    characterId: char,
    day: localDayKey(now),
    groups: Array.isArray(groups) ? groups.map((x) => cleanText(x, 80)).filter(Boolean).slice(0, 20) : [],
    preview: cleanText(preview, 500)
  });
  target.reports = target.reports.sort((a, b) => a.at - b.at).slice(-100);
  target.lastReportAt = at;
  if (kind === 'digest') {
    target.lastDigestAt = at;
    target.lastDigestDay = localDayKey(now);
    target.digestCharacterId = char;
  }
  return target;
}

/**
 * 跨群印象的写入提示词：把群消息碎片交给当前角色，写成 1~2 句第一人称记忆。
 * 角色提示词只作为“口吻参考”，避免后台写手把群消息写成客观简报。
 */
export function buildImpressionPrompt({ roleName = '当前角色', roleExcerpt = '', groupName = '群聊', messages = [], maxChars = 240 } = {}) {
  const lines = [];
  const who = cleanText(roleName, 80) || '当前角色';
  lines.push(`你是「${who}」。下面是你所在的 QQ 群「${cleanText(groupName, 80) || '群聊'}」最近的消息碎片。`);
  lines.push('请用第一人称，写 1~2 句你私下会记得的群印象。');
  lines.push('要求：像在吧台后面随口想起的，不像汇报；不要列点、不要写“A 说 / B 说”、不要复述所有消息；只挑一个具体细节、一句原话或一个态度；不要提到“摘要 / 简报 / 消息记录”；不要加引号或前缀。');
  lines.push(`总长不超过 ${Math.max(80, Math.min(800, Number(maxChars) || 240))} 字。`);
  const excerpt = String(roleExcerpt ?? '').trim();
  if (excerpt) lines.push(`\n【角色口吻参考】\n${excerpt.slice(0, 5000)}`);
  lines.push('\n【群消息碎片】');
  for (const m of (Array.isArray(messages) ? messages : []).slice(-12)) {
    const sender = cleanText(m?.sender || m?.userId || '某人', 40);
    const text = cleanText(m?.text || m?.plain, 180);
    if (text) lines.push(`- ${sender}：${text}`);
  }
  return lines.join('\n');
}

/** 解析写手输出：允许模型包了引号/项目符号，但不要让它把整段汇报塞进记忆。 */
export function parseImpression(raw, maxChars = 240) {
  let text = String(raw ?? '').trim();
  text = text.replace(/^```[a-z]*\s*/i, '').replace(/```$/i, '').trim();
  text = text.replace(/^[-*•]\s*/, '').replace(/^["“”'‘’]+|["“”'‘’]+$/g, '').trim();
  text = text.replace(/^(群印象|印象|记忆)[:：]\s*/i, '').trim();
  text = cleanText(text, Math.max(80, Math.min(800, Number(maxChars) || 240)));
  if (text.length < 4) return '';
  // 明显是“A 说、B 说”的汇报时丢弃，宁可没有印象也不要污染角色口吻。
  if ((text.match(/[：:]/g) || []).length >= 2 && /说|补充|表示|解释/.test(text)) return '';
  return text;
}

/** 只取当前角色、最近有效时间内的印象，按时间倒序。 */
export function latestImpressions(impressions, { characterId = '', maxAgeMs = 24 * 60 * 60 * 1000, now = Date.now() } = {}) {
  const char = cleanText(characterId, 80);
  return (Array.isArray(impressions) ? impressions : [])
    .filter((item) => item && item.text && Number(item.at) > 0)
    .filter((item) => !char || item.characterId === char)
    .filter((item) => now - Number(item.at) <= maxAgeMs)
    .sort((a, b) => Number(b.at) - Number(a.at));
}

function timeAgo(now, at) {
  const diff = Math.max(0, Number(now) - Number(at || 0));
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return '刚刚';
  if (minutes < 60) return `${minutes} 分钟前`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} 小时前`;
  return `${Math.floor(hours / 24)} 天前`;
}

/** 注入主人私聊的“跨群印象”：每个群只取最新一条，避免又变成简报。 */
export function formatImpressionContext(impressions, { maxChars = 2000, now = Date.now() } = {}) {
  const latestByGroup = new Map();
  for (const item of (Array.isArray(impressions) ? impressions : [])) {
    const groupId = String(item?.groupId ?? '');
    if (!groupId || !item?.text) continue;
    const previous = latestByGroup.get(groupId);
    if (!previous || Number(item.at) > Number(previous.at)) latestByGroup.set(groupId, item);
  }
  const rows = [...latestByGroup.values()]
    .sort((a, b) => Number(b.at) - Number(a.at))
    .slice(0, 8);
  if (!rows.length) return '';
  const lines = ['【你私下记得的群印象（只给你自己看，不是本轮任务）】这些是你自己在别的群听到后记下来的碎片，不是系统简报。主人不问就不要主动汇报；被问到某个群时，只挑你记得的一件说，像随口想起来，不要逐条复述。'];
  for (const item of rows) {
    lines.push(`- ${item.groupName || item.groupId}：${item.text}（${timeAgo(now, item.at)}）`);
  }
  const text = lines.join('\n');
  return text.length > maxChars ? `${text.slice(0, Math.max(0, maxChars - 1))}…` : text;
}

/** 从 socialV2.conversations 里提取群聊简报；只接受 group: 前缀。 */
export function buildGroupBriefs(conversations, groupNames, { now = Date.now(), limit = 6 } = {}) {
  const nameOf = (groupId) => {
    try {
      if (groupNames instanceof Map) return String(groupNames.get(String(groupId)) ?? '');
      if (groupNames && typeof groupNames.get === 'function') return String(groupNames.get(String(groupId)) ?? '');
      if (groupNames && typeof groupNames === 'object') return String(groupNames[String(groupId)] ?? '');
    } catch {}
    return '';
  };
  const entries = conversations instanceof Map ? [...conversations.entries()] : Object.entries(conversations ?? {});
  const briefs = [];
  for (const [key, st] of entries) {
    if (!String(key).startsWith('group:') || !st) continue;
    const groupId = String(key).slice('group:'.length);
    const recent = (Array.isArray(st.recentMessages) ? st.recentMessages : [])
      .filter((m) => m && (m.text || m.plain) && !m.deleted)
      .slice(-Math.max(1, Math.min(12, Number(limit) || 6)))
      .map((m) => ({
        sender: cleanText(m.sender || m.userId || '未知', 40),
        text: cleanText(m.text || m.plain, 160),
        time: Number(m.time) || 0,
        isSelf: !!m.isSelf
      }))
      .filter((m) => m.text);
    if (!recent.length && !Number(st.lastIncomingAt)) continue;
    const lastAt = Math.max(Number(st.lastIncomingAt) || 0, ...recent.map((m) => m.time), 0);
    briefs.push({
      groupId,
      groupName: nameOf(groupId) || groupId,
      lastAt,
      unreadCount: Array.isArray(st.unread) ? st.unread.length : 0,
      recent
    });
  }
  return briefs.sort((a, b) => b.lastAt - a.lastAt);
}

/** 注入主人私聊的跨群近况。没有群记录时返回空串，避免每轮都塞一句废话。 */
export function buildOwnerCrossGroupContext(briefs, { now = Date.now(), maxChars = 3000 } = {}) {
  if (!Array.isArray(briefs) || !briefs.length) return '';
  const lines = ['【跨群背景（只给你自己看，不是本轮任务）】下面是你所在的其它 QQ 群最近在聊什么。它们是别的群，不是当前私聊；除非主人明确提到某个群、某个群友，或直接问“群里/他们那边在聊什么”，否则不要把这里的内容当成回答主动汇报。主人发图片、表情或动图时，先看眼前这张图；不要拿群聊内容去猜图。不要假装自己参与了那些群的对话，也不要把 A 群的原话搬到 B 群。'];
  for (const brief of briefs.slice(0, 12)) {
    const recent = (brief.recent ?? []).slice(-4);
    if (!recent.length) continue;
    lines.push(`\n• ${brief.groupName}（群 ${brief.groupId}）｜最近活跃：${timeAgo(now, brief.lastAt)}`);
    for (const m of recent) {
      const who = m.isSelf ? `你（${m.sender}）` : m.sender;
      lines.push(`  - ${who}：${m.text}`);
    }
  }
  const text = lines.join('\n');
  return text.length > maxChars ? `${text.slice(0, Math.max(0, maxChars - 1))}…` : text;
}

/** 构造每日简报素材；since 之后没有新消息时返回空串。 */
export function formatCrossGroupDigest(briefs, { since = 0, now = Date.now(), maxChars = 1800 } = {}) {
  if (!Array.isArray(briefs) || !briefs.length) return '';
  const lines = [];
  for (const brief of briefs) {
    const fresh = (brief.recent ?? []).filter((m) => Number(m.time) > Number(since || 0));
    if (!fresh.length) continue;
    lines.push(`• ${brief.groupName}（群 ${brief.groupId}，${fresh.length} 条新动态）`);
    for (const m of fresh.slice(-5)) {
      const who = m.isSelf ? `你（${m.sender}）` : m.sender;
      lines.push(`  - ${who}：${m.text}`);
    }
  }
  if (!lines.length) return '';
  const date = new Date(now);
  const header = `【跨群动态 · ${date.getMonth() + 1}月${date.getDate()}日】`;
  const text = [header, ...lines].join('\n');
  return text.length > maxChars ? `${text.slice(0, Math.max(0, maxChars - 1))}…` : text;
}

/**
 * 判断这条群消息是否值得“立刻叫醒主人”。
 * 触发：有人 @ 主人、正文提到主人昵称，或命中了急事关键词。主人自己发的不算。
 */
export function detectUrgentGroupEvent({
  event,
  plainContent = '',
  ownerQQ = '',
  ownerAliases = [],
  policy = null,
  keywords = [],
  now = Date.now()
} = {}) {
  const ownerId = String(ownerQQ ?? '').trim();
  if (!ownerId) return null;
  const text = cleanText(plainContent, 2000).toLowerCase();
  const atOwner = Array.isArray(event?.message) && event.message.some((seg) => {
    if (!seg || seg.type !== 'at') return false;
    return String(seg.data?.qq ?? seg.data?.user_id ?? '') === ownerId;
  });
  const aliases = [...new Set([...(ownerAliases ?? []), ...OWNER_ALIAS_FALLBACK])]
    .map((a) => cleanText(a, 20).toLowerCase())
    .filter((a) => a.length >= 2);
  const mentionedByText = aliases.some((alias) => text.includes(alias));
  if (atOwner || mentionedByText) {
    return { reason: 'owner-mentioned', keyword: '' };
  }
  const words = [...new Set([
    ...(keywords ?? []),
    ...(policy?.reportKeywords ?? [])
  ].map((w) => cleanText(w, 20)).filter(Boolean))];
  for (const word of words) {
    if (text.includes(word.toLowerCase())) return { reason: 'urgent-keyword', keyword: word };
  }
  return null;
}
