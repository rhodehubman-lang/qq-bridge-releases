// 动态图（GIF/WebP 动图）抽帧故事板。
//
// 目的：模型通常只能稳定看到动图的第一帧，容易把“会动的表情/示意图”理解错。
// 这里在桥接层把动图均匀抽 2~6 帧，拼成一张从左到右、从上到下的故事板，
// 再交给 DSH 的视觉模型；不改变原图，也不依赖 QQ 客户端。
//
// 故意不在这里 require('sharp')：sharp 由调用方（bridge）按现有容错逻辑查找，
// 找不到时直接回退原图，不让动图处理影响消息主链路。

export const DEFAULT_GIF_STORYBOARD = Object.freeze({
  maxFrames: 4,
  maxCell: 480,
  minSide: 80,
  gap: 8,
  quality: 82
});

function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.round(n)));
}

function isGifBuffer(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 10) return false;
  const head = buf.toString('ascii', 0, 6);
  return head === 'GIF87a' || head === 'GIF89a';
}

function evenlySpacedIndices(pages, count) {
  if (count <= 1) return [0];
  const out = [];
  for (let i = 0; i < count; i += 1) {
    out.push(Math.round((i * (pages - 1)) / (count - 1)));
  }
  return [...new Set(out)];
}

/**
 * @param {Buffer} buf 原始动图
 * @param {Function} sharp sharp 模块（由 bridge 注入）
 * @param {object} options maxFrames/maxCell/minSide/gap/quality
 * @returns {Promise<null|{buffer:Buffer,mimeType:string,frames:number,pages:number,width:number,height:number}>}
 */
export async function createGifStoryboard(buf, sharp, options = {}) {
  if (!isGifBuffer(buf) || typeof sharp !== 'function') return null;
  const cfg = { ...DEFAULT_GIF_STORYBOARD, ...(options || {}) };
  const maxFrames = clampInt(cfg.maxFrames, 2, 6, DEFAULT_GIF_STORYBOARD.maxFrames);
  const maxCell = clampInt(cfg.maxCell, 160, 960, DEFAULT_GIF_STORYBOARD.maxCell);
  const minSide = clampInt(cfg.minSide, 16, 512, DEFAULT_GIF_STORYBOARD.minSide);
  const gap = clampInt(cfg.gap, 0, 32, DEFAULT_GIF_STORYBOARD.gap);

  const meta = await sharp(buf, { animated: true, limitInputPixels: false }).metadata();
  const pages = Number(meta?.pages) || 1;
  if (pages <= 1) return null;
  const width = Number(meta?.width) || 0;
  // sharp 对动图可能把 height 报成整张长图；pageHeight 是单帧高度。
  const pageHeight = Number(meta?.pageHeight) || Number(meta?.height) || 0;
  if (width < minSide || pageHeight < minSide) return null;

  const indices = evenlySpacedIndices(pages, Math.min(maxFrames, pages));
  if (!indices.length) return null;

  const cellW = Math.min(maxCell, width);
  const cellH = Math.min(maxCell, Math.round((cellW * pageHeight) / Math.max(1, width))) || cellW;
  const cols = indices.length === 1 ? 1 : 2;
  const rows = Math.ceil(indices.length / cols);
  const sheetW = cols * cellW + (cols + 1) * gap;
  const sheetH = rows * cellH + (rows + 1) * gap;

  const composites = [];
  for (let i = 0; i < indices.length; i += 1) {
    const frame = await sharp(buf, { page: indices[i], pages: 1, limitInputPixels: false })
      .rotate()
      .flatten({ background: '#000000' })
      .resize({ width: cellW, height: cellH, fit: 'contain', background: '#111111' })
      .png()
      .toBuffer();
    composites.push({
      input: frame,
      left: gap + (i % cols) * (cellW + gap),
      top: gap + Math.floor(i / cols) * (cellH + gap)
    });
  }

  const out = await sharp({
    create: { width: sheetW, height: sheetH, channels: 3, background: '#111111' }
  })
    .composite(composites)
    .jpeg({ quality: clampInt(cfg.quality, 60, 95, DEFAULT_GIF_STORYBOARD.quality), mozjpeg: true })
    .toBuffer();

  return {
    buffer: out,
    mimeType: 'image/jpeg',
    frames: indices.length,
    pages,
    width: sheetW,
    height: sheetH
  };
}
