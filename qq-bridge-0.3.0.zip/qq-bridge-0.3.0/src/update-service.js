// 自动更新服务层（IO 部分）：拉取 latest.json、下载校验、state/update.json 状态机。
//
// 与 src/update-engine.js 的分工：
//   · update-engine.js：纯函数（版本比较 / 清单校验 / 兼容判定 / 白名单 / zip 安全检查 / sha256）
//   · 本文件：真正的网络与文件操作（fetch / 下载落盘 / 状态持久化），可注入 fetchImpl 离线测试
//   · helper（PowerShell）：解压、换代码、恢复用户数据、迁移、重启；本文件只负责把 zip
//     下载并校验到 state/update-staging/，然后把状态写成 ready。
//
// 原则：任何一步失败都不动现有代码/数据；状态机只记录事实，helper 才执行替换。
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import {
  checkForUpdate,
  DEFAULT_UPDATE_MIRRORS,
  isSafeUpdateUrl,
  normalizeManifest,
  normalizeUpdateSettings,
  sha256Hex,
  verifyDownload
} from './update-engine.js';

export const UPDATE_STATE_VERSION = 1;
export const UPDATE_PHASES = Object.freeze([
  'idle', 'checking', 'up-to-date', 'available', 'downloading',
  'ready', 'applying', 'done', 'failed', 'rolled-back'
]);

const DEFAULT_TIMEOUT_MS = 20_000;
const DEFAULT_MAX_BYTES = 50 * 1024 * 1024;

// ── 更新源 URL ───────────────────────────────────────────────────────────────

/** 清单地址：自定义 URL 优先，否则走 GitHub 最新 Release 附件 latest.json。 */
export function resolveManifestUrl(settings = {}) {
  const custom = String(settings.customManifestUrl || '').trim();
  if (custom) return custom;
  const repo = String(settings.repo || 'Derpyu520/qq-bridge-releases').trim();
  return `https://github.com/${repo}/releases/latest/download/latest.json`;
}

/** 生成「直连 + 镜像」候选：镜像前缀只用于 GitHub URL（其它自定义源不套镜像）。 */
export function buildUpdateMirrorCandidates(urlText, mirrors = DEFAULT_UPDATE_MIRRORS) {
  const direct = String(urlText || '');
  const out = [direct];
  const isGithub = /^https:\/\/github\.com\//i.test(direct);
  if (isGithub) {
    for (const mirror of Array.from(mirrors || [])) {
      const prefix = String(mirror || '').trim();
      if (!/^https?:\/\//i.test(prefix)) continue;
      const url = prefix.endsWith('/') ? prefix + direct : prefix + '/' + direct;
      if (!out.includes(url)) out.push(url);
    }
  }
  return out;
}

/** 只允许 https；本地回环 http 仅供开发/测试（自定义源时也用）。 */
export function assertSafeUpdateUrl(urlText, { allowLoopbackHttp = true } = {}) {
  let url;
  try { url = new URL(String(urlText)); } catch { return { ok: false, error: `非法 URL：${urlText}` }; }
  if (!isSafeUpdateUrl(url.toString(), { allowLoopbackHttp })) {
    return { ok: false, error: `更新源必须是 https（本地回环 http 仅限演练）：${urlText}` };
  }
  return { ok: true, url: url.toString() };
}

// ── 状态机 ──────────────────────────────────────────────────────────────────

export function updateStateFile(projectRoot) {
  return path.join(projectRoot, 'state', 'update.json');
}

export function emptyUpdateState() {
  return {
    version: UPDATE_STATE_VERSION,
    phase: 'idle',
    currentVersion: '',
    targetVersion: '',
    targetTag: '',
    manifestUrl: '',
    zipPath: '',
    sha256: '',
    size: 0,
    backupBeforeUpdate: true,
    backupDir: '',
    restoredFiles: [],
    migratedFiles: [],
    error: '',
    at: 0,
    lastCheckAt: 0,
    skipVersion: '',
    attempts: 0
  };
}

export function normalizeUpdateState(raw) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const out = { ...emptyUpdateState() };
  for (const key of ['currentVersion', 'targetVersion', 'targetTag', 'manifestUrl', 'zipPath', 'sha256', 'backupDir', 'error', 'skipVersion']) {
    if (typeof src[key] === 'string') out[key] = src[key];
  }
  for (const key of ['size', 'at', 'lastCheckAt', 'attempts']) {
    const n = Number(src[key]);
    if (Number.isFinite(n) && n >= 0) out[key] = n;
  }
  for (const key of ['restoredFiles', 'migratedFiles']) {
    out[key] = Array.isArray(src[key]) ? src[key].map(String).slice(0, 500) : [];
  }
  if (typeof src.backupBeforeUpdate === 'boolean') out.backupBeforeUpdate = src.backupBeforeUpdate;
  out.phase = UPDATE_PHASES.includes(src.phase) ? src.phase : 'idle';
  return out;
}

export function readUpdateState(projectRoot) {
  try {
    return normalizeUpdateState(JSON.parse(fs.readFileSync(updateStateFile(projectRoot), 'utf8')));
  } catch {
    return emptyUpdateState();
  }
}

export function writeUpdateState(projectRoot, patch = {}) {
  const next = normalizeUpdateState({ ...readUpdateState(projectRoot), ...patch, at: patch.at ?? Date.now() });
  const file = updateStateFile(projectRoot);
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, `${JSON.stringify(next, null, 2)}\n`, 'utf8');
    fs.renameSync(tmp, file);
    return next;
  } catch {
    return next;
  }
}

// ── 检查更新（带缓存）────────────────────────────────────────────────────────

function updateCacheFile(projectRoot) {
  return path.join(projectRoot, 'state', 'update-cache.json');
}

function readCache(projectRoot) {
  try {
    const raw = JSON.parse(fs.readFileSync(updateCacheFile(projectRoot), 'utf8'));
    if (!raw || raw.version !== 1 || !raw.fetchedAt || !raw.manifest) return null;
    return raw;
  } catch {
    return null;
  }
}

function writeCache(projectRoot, payload) {
  try {
    fs.mkdirSync(path.dirname(updateCacheFile(projectRoot)), { recursive: true });
    fs.writeFileSync(updateCacheFile(projectRoot), `${JSON.stringify({ version: 1, ...payload }, null, 2)}\n`, 'utf8');
  } catch {}
}

function shouldUseCache(projectRoot, settings, force) {
  if (force) return false;
  const cached = readCache(projectRoot);
  if (!cached) return false;
  const interval = Math.max(1, Number(settings.checkIntervalHours) || 6) * 60 * 60 * 1000;
  return Date.now() - Number(cached.fetchedAt || 0) < interval;
}

/** 拉 latest.json 并校验。返回 {ok, manifest, raw, url, cached, error}。 */
export async function fetchManifest({ settings = {}, projectRoot = '', force = false, fetchImpl = globalThis.fetch, timeoutMs = DEFAULT_TIMEOUT_MS, maxBytes = 2 * 1024 * 1024 } = {}) {
  const normalized = normalizeUpdateSettings(settings);
  if (normalized.enabled === false) return { ok: false, error: '更新功能已关闭', disabled: true };
  const url = resolveManifestUrl(normalized);
  const safe = assertSafeUpdateUrl(url);
  if (!safe.ok) return { ok: false, error: safe.error, url };
  if (projectRoot && shouldUseCache(projectRoot, normalized, force)) {
    const cached = readCache(projectRoot);
    if (cached) {
      const result = normalizeManifest(cached.manifest);
      return { ...result, raw: cached.manifest, url: cached.url, cached: true };
    }
  }
  if (typeof fetchImpl !== 'function') return { ok: false, error: 'fetch 不可用', url };
  const candidates = buildUpdateMirrorCandidates(safe.url, normalized.mirrors);
  let lastError = '';
  for (const candidate of candidates) {
    try {
      const response = await fetchImpl(candidate, {
        method: 'GET',
        redirect: 'follow',
        headers: { 'user-agent': 'qq-bridge/update-check', accept: 'application/json' },
        signal: AbortSignal.timeout(Math.max(1000, Number(timeoutMs) || DEFAULT_TIMEOUT_MS))
      });
      if (!response.ok) { lastError = `获取更新清单失败：HTTP ${response.status}`; continue; }
      const text = await response.text();
      if (text.length > maxBytes) { lastError = `更新清单过大（${text.length} 字节）`; continue; }
      let raw;
      try { raw = JSON.parse(text); } catch (error) { lastError = `更新清单不是合法 JSON：${error.message}`; continue; }
      const result = normalizeManifest(raw);
      if (!result.ok) { lastError = `更新清单校验失败：${result.error}`; continue; }
      if (projectRoot) writeCache(projectRoot, { url: candidate, fetchedAt: Date.now(), manifest: raw });
      return { ...result, raw, url: candidate, cached: false };
    } catch (error) {
      lastError = `获取更新清单失败：${error?.message || error}`;
    }
  }
  return { ok: false, error: lastError || '获取更新清单失败', url: candidates[candidates.length - 1] || safe.url };
}

/**
 * 检查更新：拉清单 → 决策 → 写 state/update.json。
 * @returns {Promise<{ok:boolean, status:string, decision?:object, state:object, error?:string}>}
 */
export async function checkForUpdatesNow({
  projectRoot,
  currentVersion,
  currentDshVersion = '',
  currentDataSchema = 1,
  settings = {},
  force = false,
  fetchImpl = globalThis.fetch,
  timeoutMs = DEFAULT_TIMEOUT_MS
} = {}) {
  if (!projectRoot) throw new Error('projectRoot 必填');
  const settingsNorm = normalizeUpdateSettings(settings);
  if (settingsNorm.enabled === false) {
    writeUpdateState(projectRoot, { phase: 'idle', currentVersion, error: '' });
    return { ok: true, status: 'disabled', state: readUpdateState(projectRoot) };
  }
  writeUpdateState(projectRoot, { phase: 'checking', currentVersion, lastCheckAt: Date.now() });
  const fetched = await fetchManifest({ settings: settingsNorm, projectRoot, force, fetchImpl, timeoutMs });
  if (!fetched.ok) {
    const state = writeUpdateState(projectRoot, { phase: 'failed', currentVersion, lastCheckAt: Date.now(), error: fetched.error });
    return { ok: false, status: 'error', error: fetched.error, state };
  }
  const decision = checkForUpdate({
    manifest: fetched,
    currentVersion,
    currentDshVersion,
    currentDataSchema
  });
  let phase = 'idle';
  if (decision.status === 'available') phase = 'available';
  else if (decision.status === 'up-to-date') phase = 'up-to-date';
  else if (decision.status === 'refused') phase = 'failed';
  else phase = 'failed';
  const target = decision.target || null;
  const state = writeUpdateState(projectRoot, {
    phase,
    currentVersion,
    manifestUrl: fetched.url || '',
    lastCheckAt: Date.now(),
    error: decision.status === 'refused' ? decision.message : (decision.status === 'invalid' ? decision.message : ''),
    skipVersion: target && readUpdateState(projectRoot).skipVersion === target.version ? '' : readUpdateState(projectRoot).skipVersion,
    ...(target ? { targetVersion: target.version, targetTag: target.tag, sha256: target.sha256, size: target.size } : {})
  });
  return { ok: decision.status !== 'invalid', status: decision.status, decision, state, cached: fetched.cached === true };
}

// ── 下载并校验 ──────────────────────────────────────────────────────────────

export function stagingDir(projectRoot) {
  return path.join(projectRoot, 'state', 'update-staging');
}

export function stagingZipPath(projectRoot, version) {
  return path.join(stagingDir(projectRoot), `qq-bridge-${String(version || 'unknown').replace(/[^0-9A-Za-z._-]/g, '_')}.zip`);
}

/**
 * 下载更新包到 state/update-staging/，校验 sha256 + 大小；失败不留半成品。
 * @returns {Promise<{ok:boolean, zipPath?:string, sha256?:string, size?:number, error?:string}>}
 */
export async function downloadUpdateZip({
  projectRoot,
  target,
  fetchImpl = globalThis.fetch,
  timeoutMs = 120_000,
  maxBytes = DEFAULT_MAX_BYTES,
  onProgress = null,
  log = () => {}
} = {}) {
  if (!projectRoot) throw new Error('projectRoot 必填');
  if (!target?.assetUrl) return { ok: false, error: '更新目标缺少 assetUrl' };
  const safe = assertSafeUpdateUrl(target.assetUrl, { allowLoopbackHttp: true });
  if (!safe.ok) return { ok: false, error: safe.error };
  if (!Number.isSafeInteger(Number(target.size)) || Number(target.size) <= 0) return { ok: false, error: '更新目标 size 非法' };
  const dest = stagingZipPath(projectRoot, target.version);
  const tmp = `${dest}.part`;
  const candidates = buildUpdateMirrorCandidates(safe.url, (target.mirrors && target.mirrors.length ? target.mirrors : DEFAULT_UPDATE_MIRRORS));
  let lastError = '';
  try {
    fs.mkdirSync(stagingDir(projectRoot), { recursive: true });
    fs.rmSync(tmp, { force: true });
    for (const candidate of candidates) {
      try {
        const response = await fetchImpl(candidate, {
          method: 'GET',
          redirect: 'follow',
          headers: { 'user-agent': 'qq-bridge/update-download' },
          signal: AbortSignal.timeout(Math.max(5000, Number(timeoutMs) || 120_000))
        });
        if (!response.ok) { lastError = `下载失败：HTTP ${response.status}`; continue; }
        const buffer = Buffer.from(await response.arrayBuffer());
        if (buffer.length > maxBytes) { lastError = `更新包过大（${buffer.length} 字节，超过上限 ${maxBytes}）`; continue; }
        if (onProgress) onProgress(buffer.length, Number(target.size));
        const verified = verifyDownload({ buffer, sha256: target.sha256, size: Number(target.size) });
        if (!verified.ok) { lastError = verified.error; continue; }
        fs.writeFileSync(tmp, buffer);
        fs.renameSync(tmp, dest);
        log(`更新包已下载并校验：${dest}（${buffer.length} 字节）`);
        return { ok: true, zipPath: dest, sha256: verified.sha256, size: buffer.length };
      } catch (error) {
        lastError = `下载更新包失败：${error?.message || error}`;
      }
    }
    return { ok: false, error: lastError || '下载更新包失败' };
  } catch (error) {
    try { fs.rmSync(tmp, { force: true }); } catch {}
    return { ok: false, error: `下载更新包失败：${error?.message || error}` };
  }
}

/**
 * 准备更新：下载 → 校验 → 写 state/update.json（phase=ready），等 helper 执行。
 * @param {object} opts
 * @param {object} opts.target checkForUpdate 返回的 target
 * @param {string} opts.currentVersion
 * @param {boolean} opts.backupBeforeUpdate
 */
export async function prepareUpdate({
  projectRoot,
  target,
  currentVersion = '',
  backupBeforeUpdate = true,
  fetchImpl = globalThis.fetch,
  log = () => {}
} = {}) {
  if (!projectRoot || !target) return { ok: false, error: '缺少更新目标' };
  const existing = readUpdateState(projectRoot);
  writeUpdateState(projectRoot, { phase: 'downloading', currentVersion, targetVersion: target.version, targetTag: target.tag, sha256: target.sha256, size: target.size, error: '' });
  const downloaded = await downloadUpdateZip({ projectRoot, target, fetchImpl, log });
  if (!downloaded.ok) {
    const state = writeUpdateState(projectRoot, { phase: 'failed', error: downloaded.error });
    return { ok: false, error: downloaded.error, state };
  }
  const state = writeUpdateState(projectRoot, {
    phase: 'ready',
    currentVersion,
    targetVersion: target.version,
    targetTag: target.tag,
    zipPath: downloaded.zipPath,
    sha256: downloaded.sha256,
    size: downloaded.size,
    backupBeforeUpdate: backupBeforeUpdate !== false,
    skipVersion: existing.skipVersion || '',
    error: ''
  });
  return { ok: true, state, zipPath: downloaded.zipPath };
}

/** 记录「稍后」/「跳过此版本」/「开始执行」。 */
export function markUpdate(patch = {}, projectRoot) {
  if (!projectRoot) throw new Error('projectRoot 必填');
  return writeUpdateState(projectRoot, patch);
}

// ── 拉起 helper（桥接退出前最后一步）────────────────────────────────────────

export function helperScriptPath(projectRoot, platform = process.platform) {
  return path.join(projectRoot, 'scripts', platform === 'win32' ? 'update-helper.ps1' : 'update-helper.sh');
}

/**
 * 拉起独立 helper 进程（detached；桥接随后退出）。
 * 中文启动器名/路径全部走环境变量，helper 脚本本体保持 ASCII。
 * @returns {{ok:boolean, pid?:number, helper?:string, error?:string}}
 */
export function launchUpdateHelper({
  projectRoot,
  zipPath,
  fromVersion = '',
  toVersion = '',
  launcherName = '启动.cmd',
  backupBeforeUpdate = true,
  rollback = false,
  healthMs = 120000,
  platform = process.platform,
  spawnImpl = spawn,
  env = process.env
} = {}) {
  if (!projectRoot) return { ok: false, error: 'helper 参数不完整（projectRoot）' };
  if (!rollback && (!zipPath || !toVersion)) return { ok: false, error: 'helper 参数不完整（zipPath/toVersion）' };
  const helper = helperScriptPath(projectRoot, platform);
  if (!fs.existsSync(helper)) return { ok: false, error: `缺少 helper 脚本：${helper}` };
  const childEnv = {
    ...env,
    QQB_ROOT: projectRoot,
    QQB_ZIP: zipPath,
    QQB_FROM_VERSION: fromVersion,
    QQB_TO_VERSION: toVersion,
    QQB_LAUNCHER: launcherName,
    QQB_BACKUP: backupBeforeUpdate ? '1' : '0',
    QQB_ROLLBACK: rollback ? '1' : '0',
    QQB_HEALTH_MS: String(Math.max(2000, Number(healthMs) || 120000))
  };
  // 绝对路径：PATH 被精简/被改时也能启动（VM 实测成功手动运行、隐藏拉起却秒退）。
  const systemRoot = env.SystemRoot || env.windir || 'C:\Windows';
  const command = platform === 'win32'
    ? path.join(systemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
    : 'bash';
  const args = platform === 'win32'
    ? ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', helper]
    : [helper];
  let child = null;
  let error = '';
  try {
    child = spawnImpl(command, args, {
      detached: true,
      stdio: 'ignore',
      env: childEnv,
      cwd: projectRoot,
      // 可见窗口：更新过程透明，也避免某些安全软件拦截“隐藏 PowerShell”。
      windowsHide: false
    });
    child.unref?.();
  } catch (e) {
    error = String(e?.message || e);
  }
  // 启动日志：helper 秒退时至少能查到桥接这边尝试过什么。
  try {
    fs.appendFileSync(path.join(projectRoot, 'state', 'update-launch.log'),
      `${new Date().toISOString()} launch rollback=${rollback} command=${command} pid=${child?.pid ?? '-'} error=${error || '-'}\n`, 'utf8');
  } catch {}
  if (!child) return { ok: false, error: `拉起 helper 失败：${error || 'unknown'}` };
  return { ok: true, pid: child.pid, helper, child };
}

/**
 * 等待 helper 进程「活过启动窗口」。秒退/启动报错 → 返回失败（桥接不退出，控制台显示错误）。
 * 若进程正常存活到超时，则视为拉起成功。
 */
export function waitForHelperStart(child, { timeoutMs = 2000 } = {}) {
  if (!child || typeof child.once !== 'function') return Promise.resolve({ ok: true, stable: false });
  return new Promise((resolve) => {
    let settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      resolve(result);
    };
    child.once('error', (error) => finish({ ok: false, error: `helper 启动失败：${error?.message || error}` }));
    child.once('exit', (code, signal) => finish({ ok: false, error: `helper 启动后立即退出（code=${code ?? '?'}, signal=${signal || '-'}）` }));
    const timer = setTimeout(() => finish({ ok: true, stable: true }), Math.max(300, Number(timeoutMs) || 2000));
    timer.unref?.();
  });
}
/** 给 HTTP 响应留出返回时间后退出桥接（helper 会接管后续）。 */
export function scheduleBridgeExit(delayMs = 1500, exitCode = 3) {
  // exit code 3 = 正在更新；start.bat/启动.cmd 看到它就不再自动重启，交给 helper。
  setTimeout(() => process.exit(exitCode), Math.max(100, Number(delayMs) || 1500)).unref?.();
}
