// 控制台更新接口的逻辑层（与 HTTP 服务器解耦，便于离线单测）。
//
// 端点语义（全部要求控制台令牌；agent token 在 bridge 里被统一拒绝）：
//   GET  /api/update/status   → 当前版本 + state/update.json + 更新设置
//   GET  /api/update/check    → 拉清单/决策（?force=1 跳过缓存）
//   POST /api/update/apply    → 下载校验 → 拉起 helper → 桥接退出（start.bat 不重启）
//   POST /api/update/rollback → 拉起 helper 的回滚模式（恢复最近一次更新备份）
//   GET  /api/update/config   → 读更新设置
//   POST /api/update/config   → 保存更新设置到 config.json
import fs from 'node:fs';
import path from 'node:path';
import { normalizeUpdateSettings } from './update-engine.js';
import {
  checkForUpdatesNow,
  launchUpdateHelper,
  prepareUpdate,
  readUpdateState,
  waitForHelperStart,
  scheduleBridgeExit,
  writeUpdateState
} from './update-service.js';

const CONFIG_FILE = 'config.json';

function configPath(projectRoot) {
  return path.join(projectRoot, CONFIG_FILE);
}

function readConfig(projectRoot) {
  try {
    return JSON.parse(fs.readFileSync(configPath(projectRoot), 'utf8').replace(/^\uFEFF/, ''));
  } catch {
    return null;
  }
}

function writeConfig(projectRoot, cfg) {
  const file = configPath(projectRoot);
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, `${JSON.stringify(cfg, null, 2)}\n`, 'utf8');
  fs.renameSync(tmp, file);
}

export function readUpdateSettings(projectRoot) {
  const cfg = readConfig(projectRoot);
  return normalizeUpdateSettings(cfg?.updates ?? {});
}

export function saveUpdateSettings(projectRoot, patch = {}) {
  const cfg = readConfig(projectRoot);
  if (!cfg) throw new Error('config.json 不存在或无法解析');
  const next = normalizeUpdateSettings({ ...(cfg.updates ?? {}), ...(patch && typeof patch === 'object' ? patch : {}) });
  cfg.updates = next;
  writeConfig(projectRoot, cfg);
  return next;
}

/** 选启动器：优先 启动.cmd，其次 start.bat / start.sh。 */
export function detectLauncher(projectRoot) {
  for (const name of ['启动.cmd', 'start.bat', 'start.sh']) {
    try {
      if (fs.statSync(path.join(projectRoot, name)).isFile()) return name;
    } catch {}
  }
  return '启动.cmd';
}

export async function handleUpdateStatus({ projectRoot, currentVersion = '' } = {}) {
  if (!projectRoot) throw new Error('projectRoot 必填');
  let settings;
  try { settings = readUpdateSettings(projectRoot); } catch { settings = normalizeUpdateSettings({}); }
  return {
    ok: true,
    currentVersion,
    phase: readUpdateState(projectRoot).phase,
    state: readUpdateState(projectRoot),
    settings
  };
}

export async function handleUpdateCheck({
  projectRoot,
  currentVersion = '',
  currentDshVersion = '',
  currentDataSchema = 1,
  force = false,
  fetchImpl = globalThis.fetch
} = {}) {
  const settings = readUpdateSettings(projectRoot);
  const result = await checkForUpdatesNow({
    projectRoot,
    currentVersion,
    currentDshVersion,
    currentDataSchema,
    settings,
    force,
    fetchImpl
  });
  const target = result.decision?.target || null;
  return {
    ok: result.ok,
    status: result.status,
    error: result.error || (result.decision?.status === 'refused' ? result.decision.message : ''),
    message: result.decision?.message || '',
    warnings: result.decision?.warnings || [],
    cached: result.cached === true,
    currentVersion,
    target: target ? {
      version: target.version,
      tag: target.tag,
      notes: target.notes,
      size: target.size,
      dshCompat: target.dshCompat,
      requiresDshRestart: target.requiresDshRestart === true,
      releasedAt: target.releasedAt,
      dataSchema: target.dataSchema,
      minDataSchema: target.minDataSchema
    } : null,
    state: result.state
  };
}

/**
 * 执行更新：先重新确认有可用目标（拿完整 target），再下载校验，最后拉起 helper。
 * 成功后由 bridge 调用 scheduleBridgeExit 退出（helper 会在桥接退出后接管）。
 */
export async function handleUpdateApply({
  projectRoot,
  currentVersion = '',
  currentDshVersion = '',
  currentDataSchema = 1,
  backup = true,
  fetchImpl = globalThis.fetch,
  launchImpl = launchUpdateHelper,
  scheduleExitImpl = scheduleBridgeExit,
  log = () => {}
} = {}) {
  if (!projectRoot) throw new Error('projectRoot 必填');
  const existing = readUpdateState(projectRoot);
  if (existing.phase === 'applying') return { ok: false, error: '已有更新正在进行中', state: existing };

  const settings = readUpdateSettings(projectRoot);
  if (settings.enabled === false) return { ok: false, error: '更新功能已关闭' };

  const check = await handleUpdateCheck({
    projectRoot, currentVersion, currentDshVersion, currentDataSchema, force: false, fetchImpl
  });
  if (check.status === 'up-to-date') return { ok: true, status: 'up-to-date', message: '已是最新版本', state: readUpdateState(projectRoot) };
  if (check.status !== 'available' || !check.target) {
    return { ok: false, error: check.error || check.message || '当前没有可安装的更新', status: check.status, state: readUpdateState(projectRoot) };
  }

  // 重新拉一次清单缓存拿完整 target（含 assetUrl/sha256/size）
  const manifestFetched = await (async () => {
    const cached = await checkForUpdatesNow({ projectRoot, currentVersion, currentDshVersion, currentDataSchema, settings, force: true, fetchImpl });
    return cached;
  })();
  const target = manifestFetched.decision?.target;
  if (!target || !target.assetUrl) {
    return { ok: false, error: '更新清单缺少下载地址，无法安装' };
  }

  const prepared = await prepareUpdate({
    projectRoot,
    target,
    currentVersion,
    backupBeforeUpdate: backup !== false,
    fetchImpl,
    log
  });
  if (!prepared.ok) return { ok: false, error: prepared.error, state: prepared.state };

  const launcherName = detectLauncher(projectRoot);
  const launched = launchImpl({
    projectRoot,
    zipPath: prepared.zipPath,
    fromVersion: currentVersion,
    toVersion: target.version,
    launcherName,
    backupBeforeUpdate: backup !== false
  });
  if (!launched.ok) {
    writeUpdateState(projectRoot, { phase: 'failed', error: launched.error });
    return { ok: false, error: launched.error, state: readUpdateState(projectRoot) };
  }
  // 防「PowerShell 秒退」：等 helper 活过启动窗口再退出桥接；否则保留桥接并把错误显示给控制台。
  const startup = await waitForHelperStart(launched.child);
  if (!startup.ok) {
    writeUpdateState(projectRoot, { phase: 'failed', error: startup.error });
    return { ok: false, error: startup.error, state: readUpdateState(projectRoot) };
  }
  log(`[更新] 已拉起 helper（pid ${launched.pid ?? '?'}），桥接即将退出由 helper 接管`);
  scheduleExitImpl(1500);
  return {
    ok: true,
    status: 'applying',
    version: target.version,
    message: `正在更新到 ${target.version}，桥接将在几秒后重启`,
    state: readUpdateState(projectRoot)
  };
}

/** 手动回滚：拉起 helper 的回滚模式（恢复最近的更新备份）。 */
export function handleUpdateRollback({
  projectRoot,
  launchImpl = launchUpdateHelper,
  scheduleExitImpl = scheduleBridgeExit,
  log = () => {}
} = {}) {
  if (!projectRoot) throw new Error('projectRoot 必填');
  const state = readUpdateState(projectRoot);
  if (state.phase === 'applying') return { ok: false, error: '更新正在进行中，不能回滚' };
  const backupRoot = path.join(projectRoot, '_backups', 'update');
  let backups = [];
  try {
    backups = fs.readdirSync(backupRoot).filter((name) => {
      try { return fs.statSync(path.join(backupRoot, name)).isDirectory(); } catch { return false; }
    }).sort();
  } catch {}
  if (!backups.length) return { ok: false, error: '没有可用的更新备份' };
  const launched = launchImpl({
    projectRoot,
    zipPath: '',
    fromVersion: state.currentVersion || '',
    toVersion: '',
    launcherName: detectLauncher(projectRoot),
    rollback: true
  });
  if (!launched.ok) return { ok: false, error: launched.error };
  writeUpdateState(projectRoot, { phase: 'applying', error: '' });
  log(`[更新] 已拉起回滚 helper（pid ${launched.pid ?? '?'}），使用备份 ${backups[backups.length - 1]}`);
  scheduleExitImpl(1500);
  return { ok: true, status: 'applying', message: '正在回滚到上一个版本，桥接将在几秒后重启', backup: backups[backups.length - 1] };
}
