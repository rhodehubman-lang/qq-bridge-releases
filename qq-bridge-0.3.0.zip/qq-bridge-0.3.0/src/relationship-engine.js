// 关系记忆（第一阶段）：按角色 × 人保存长期关系，情绪由 mood-engine 单独负责。
// 原则：
// - 数值只内部使用，注入给模型的永远是人话标签；
// - 关系记忆必须带 scope（private:<qq> 或 group:<群号>），避免 A 群的内容漏到 B 群；
// - AI 只能追加观察，删除/固定重要记忆由控制台管理员操作。

export const RELATIONSHIP_VERSION = 1;
export const RELATIONSHIP_MAX_PEOPLE = 100;
export const RELATIONSHIP_MAX_RECENT = 30;

export const RELATIONSHIP_DEFAULT_SUMMARY_CHARS = 320;
export const RELATIONSHIP_MIN_SUMMARY_CHARS = 120;
export const RELATIONSHIP_MAX_SUMMARY_CHARS = 800;

export function normalizeSummaryChars(value, fallback = RELATIONSHIP_DEFAULT_SUMMARY_CHARS) {
  const n = Math.round(Number(value));
  const base = Number.isFinite(n) && n > 0 ? n : fallback;
  return Math.max(RELATIONSHIP_MIN_SUMMARY_CHARS, Math.min(RELATIONSHIP_MAX_SUMMARY_CHARS, base));
}

/** 看法是给人看的，保留换行，不把整段压成一行。 */
export function normalizeSummaryText(value, max = RELATIONSHIP_MAX_SUMMARY_CHARS) {
  return String(value ?? '')
    .replace(/\r\n?/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .trim()
    .slice(0, Math.max(0, Number(max) || RELATIONSHIP_MAX_SUMMARY_CHARS));
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, Number(value) || 0));
}

function asText(value, max = 200) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function nowMs(value) {
  return Number(value) || 0;
}

export function emptyRelationshipState(characterId = '') {
  return {
    version: RELATIONSHIP_VERSION,
    characterId,
    settings: {
      summaryMaxChars: RELATIONSHIP_DEFAULT_SUMMARY_CHARS
    },
    lastConsolidationDay: '',
    people: {}
  };
}

export function normalizePersonId(value) {
  const s = String(value ?? '').trim();
  return /^\d{5,20}$/.test(s) ? s : '';
}

function normalizeEntry(raw, scope, at) {
  const text = asText(raw?.text ?? raw, 240);
  if (!text) return null;
  return {
    text,
    scope: asText(raw?.scope ?? scope, 40),
    source: asText(raw?.source ?? 'observed', 20),
    at: nowMs(raw?.at) || at
  };
}

function normalizeEntries(list, scope, max, at) {
  const out = [];
  const seen = new Set();
  for (const raw of Array.isArray(list) ? list : []) {
    const entry = normalizeEntry(raw, scope, at);
    if (!entry || seen.has(entry.text)) continue;
    seen.add(entry.text);
    out.push(entry);
    if (out.length >= max) break;
  }
  return out;
}

export function normalizePerson(raw, { personId = '', characterId = '' } = {}) {
  const src = raw && typeof raw === 'object' ? raw : {};
  const id = normalizePersonId(src.personId ?? personId);
  const now = Date.now();
  const contexts = {};
  for (const [scope, value] of Object.entries(src.contexts && typeof src.contexts === 'object' ? src.contexts : {})) {
    if (!/^(private|group):\d{3,20}$/.test(String(scope))) continue;
    contexts[scope] = {
      lastSeenAt: nowMs(value?.lastSeenAt),
      interactionCount: Math.max(0, Number(value?.interactionCount) || 0)
    };
  }
  return {
    personId: id,
    displayName: asText(src.displayName, 60),
    relation: ['owner', 'member', 'stranger'].includes(src.relation) ? src.relation : 'member',
    familiarity: clamp(src.familiarity ?? 5, 0, 100),
    trust: clamp(src.trust ?? 20, 0, 100),
    warmth: clamp(src.warmth ?? 30, 0, 100),
    tension: clamp(src.tension ?? 0, 0, 100),
    interactionCount: Math.max(0, Number(src.interactionCount) || 0),
    firstSeenAt: nowMs(src.firstSeenAt) || now,
    lastSeenAt: nowMs(src.lastSeenAt),
    pinned: src.pinned === true,
    summary: normalizeSummaryText(src.summary ?? src.impression ?? '', RELATIONSHIP_MAX_SUMMARY_CHARS),
    summaryUpdatedAt: nowMs(src.summaryUpdatedAt),
    summarySource: ['manual', 'consolidated'].includes(src.summarySource) ? src.summarySource : '',
    notes: normalizeEntries(src.notes, 'global', 30, now),
    preferences: normalizeEntries(src.preferences, 'global', 12, now),
    boundaries: normalizeEntries(src.boundaries, 'global', 12, now),
    sharedMoments: normalizeEntries(src.sharedMoments, 'global', 12, now),
    contexts,
    recentInteractions: (Array.isArray(src.recentInteractions) ? src.recentInteractions : [])
      .map((item) => ({
        at: nowMs(item?.at),
        scope: asText(item?.scope, 40),
        text: asText(item?.text, 180)
      }))
      .filter((item) => item.text && /^(private|group):\d{3,20}$/.test(item.scope) && item.at > 0)
      .slice(-RELATIONSHIP_MAX_RECENT),
    lastConsolidatedAt: nowMs(src.lastConsolidatedAt)
  };
}

export function normalizeRelationshipState(raw, characterId = '') {
  const src = raw && typeof raw === 'object' ? raw : {};
  const state = emptyRelationshipState(characterId || src.characterId || '');
  state.settings.summaryMaxChars = normalizeSummaryChars(src.settings?.summaryMaxChars ?? src.summaryMaxChars, RELATIONSHIP_DEFAULT_SUMMARY_CHARS);
  state.lastConsolidationDay = asText(src.lastConsolidationDay, 20);
  for (const [id, person] of Object.entries(src.people && typeof src.people === 'object' ? src.people : {})) {
    const safeId = normalizePersonId(person?.personId ?? id);
    if (!safeId) continue;
    state.people[safeId] = normalizePerson(person, { personId: safeId, characterId: state.characterId });
  }
  pruneRelationships(state);
  return state;
}

export function ensurePerson(state, personId, { displayName = '', relation = 'member' } = {}) {
  if (!state || !state.people) return null;
  const id = normalizePersonId(personId);
  if (!id) return null;
  const existing = state.people[id];
  if (existing) {
    if (displayName) existing.displayName = asText(displayName, 60);
    if (relation === 'owner') existing.relation = 'owner';
    return existing;
  }
  const person = normalizePerson({ personId: id, displayName, relation }, { personId: id, characterId: state.characterId });
  state.people[id] = person;
  pruneRelationships(state);
  return person;
}

const POSITIVE_RE = /谢谢|辛苦|晚安|好梦|想你|陪你|好看|喜欢|开心|顺利|抱抱|别累着|注意休息|麻烦你|拜托|可爱|厉害|靠谱/;
const NEGATIVE_RE = /滚|闭嘴|烦死|讨厌|傻逼|蠢|废物|别来烦|生气|恶心|垃圾|去死/;
const VULNERABLE_RE = /只跟(你|你说)|其实我|有点难过|不太舒服|帮帮我|陪我说|有点累|压力好大|睡不着|害怕/;
const APOLOGY_RE = /对不起|抱歉|是我不好|我错了|别生气/;

export function applyRelationshipSignal(person, { text = '', scope = '', groupId = '', at = Date.now(), displayName = '', isOwner = false } = {}) {
  if (!person) return person;
  const safeScope = /^(private|group):\d{3,20}$/.test(String(scope)) ? String(scope) : '';
  if (!safeScope) return person;
  const content = asText(text, 500);
  if (!content) return person;
  person.displayName = asText(displayName, 60) || person.displayName;
  if (isOwner) person.relation = 'owner';
  person.interactionCount = (Number(person.interactionCount) || 0) + 1;
  person.lastSeenAt = at;
  if (!person.firstSeenAt) person.firstSeenAt = at;
  const ctx = person.contexts?.[safeScope] || { lastSeenAt: 0, interactionCount: 0 };
  person.contexts = person.contexts && typeof person.contexts === 'object' ? person.contexts : {};
  person.contexts[safeScope] = {
    lastSeenAt: at,
    interactionCount: (Number(ctx.interactionCount) || 0) + 1
  };
  const familiarityGain = person.familiarity < 20 ? 1 : person.familiarity < 60 ? 0.45 : 0.18;
  person.familiarity = clamp(person.familiarity + familiarityGain, 0, 100);
  if (POSITIVE_RE.test(content)) {
    person.warmth = clamp(person.warmth + 1.4, 0, 100);
    person.tension = clamp(person.tension - 0.6, 0, 100);
  }
  if (NEGATIVE_RE.test(content)) {
    person.warmth = clamp(person.warmth - 2.2, 0, 100);
    person.tension = clamp(person.tension + 4.5, 0, 100);
    person.trust = clamp(person.trust - 1.4, 0, 100);
  }
  if (APOLOGY_RE.test(content)) {
    person.tension = clamp(person.tension - 3.2, 0, 100);
    person.trust = clamp(person.trust + 0.6, 0, 100);
  }
  if (VULNERABLE_RE.test(content)) {
    person.trust = clamp(person.trust + 1.2, 0, 100);
    person.warmth = clamp(person.warmth + 0.8, 0, 100);
  }
  if (!person.recentInteractions) person.recentInteractions = [];
  person.recentInteractions.push({ at, scope: safeScope, text: content.slice(0, 180) });
  if (person.recentInteractions.length > RELATIONSHIP_MAX_RECENT) {
    person.recentInteractions.splice(0, person.recentInteractions.length - RELATIONSHIP_MAX_RECENT);
  }
  return person;
}

/** 关系衰减：紧张会慢慢退，熟悉度和信任不因时间自动归零。 */
export function decayRelationships(state, now = Date.now()) {
  if (!state?.people) return state;
  for (const person of Object.values(state.people)) {
    const days = Math.max(0, (now - (Number(person.lastSeenAt) || now)) / 86400000);
    if (days <= 0) continue;
    person.tension = clamp(person.tension - Math.min(8, days * 1.2), 0, 100);
    if (days > 30) person.warmth = clamp(person.warmth - Math.min(4, (days - 30) * 0.04), 0, 100);
  }
  return state;
}

export function pruneRelationships(state, maxPeople = RELATIONSHIP_MAX_PEOPLE) {
  if (!state?.people) return state;
  const entries = Object.entries(state.people);
  if (entries.length <= maxPeople) return state;
  entries.sort((a, b) => {
    const pa = a[1]?.pinned ? 1 : 0;
    const pb = b[1]?.pinned ? 1 : 0;
    if (pa !== pb) return pa - pb;
    return (Number(a[1]?.lastSeenAt) || 0) - (Number(b[1]?.lastSeenAt) || 0);
  });
  for (let i = 0; i < entries.length - maxPeople; i += 1) delete state.people[entries[i][0]];
  return state;
}

export function relationshipLabels(person) {
  const p = person || {};
  const familiarity = Number(p.familiarity) || 0;
  const trust = Number(p.trust) || 0;
  const warmth = Number(p.warmth) || 0;
  const tension = Number(p.tension) || 0;
  return {
    familiarity: familiarity < 15 ? '几乎陌生' : familiarity < 35 ? '见过几次' : familiarity < 60 ? '有点熟' : familiarity < 80 ? '熟人' : '很熟',
    trust: trust < 20 ? '还带着戒备' : trust < 45 ? '还没完全信' : trust < 70 ? '基本信任' : '信任',
    warmth: warmth < 20 ? '疏离' : warmth < 45 ? '平常' : warmth < 70 ? '有好感' : '亲近',
    tension: tension > 70 ? '明显紧张' : tension > 45 ? '有点别扭' : tension > 25 ? '一点芥蒂' : '没什么紧张'
  };
}

export function relationshipScopeForGroup(groupId) {
  const id = String(groupId ?? '').trim();
  return /^\d{3,20}$/.test(id) ? `group:${id}` : '';
}

export function relationshipScopeForPrivate(personId) {
  const id = normalizePersonId(personId);
  return id ? `private:${id}` : '';
}

function visibleEntries(list, scope) {
  const currentGroup = String(scope || '').startsWith('group:') ? String(scope) : '';
  const isPrivate = String(scope || '').startsWith('private:');
  return (Array.isArray(list) ? list : []).filter((entry) => {
    const entryScope = String(entry?.scope || 'global');
    if (entryScope === 'global') return true;
    if (isPrivate) return true; // 主人私聊可以看这个人的完整关系；不会注入到群里
    return !!currentGroup && entryScope === currentGroup;
  });
}

export function formatRelationshipPrompt(person, { scope = '', isOwner = false, includeSummary = false, maxChars = 1400, summaryMaxChars = RELATIONSHIP_DEFAULT_SUMMARY_CHARS } = {}) {
  if (!person) return '';
  const labels = relationshipLabels(person);
  const who = isOwner ? '主人' : '当前说话的人';
  const lines = [`【你对${who}的感觉】`];
  lines.push(`关系：${isOwner ? '主人' : person.relation === 'owner' ? '主人' : '认识的人'}；熟悉度：${labels.familiarity}；信任：${labels.trust}；亲近：${labels.warmth}；最近：${labels.tension}。`);
  // 完整看法只进主人私聊；群聊只使用本群范围内的观察，避免 A 群内容漏到 B 群。
  if (includeSummary && person.summary) {
    const summary = normalizeSummaryText(person.summary, normalizeSummaryChars(summaryMaxChars));
    if (summary) lines.push(`【你对${who}的整体看法】\n${summary}`);
  }
  const notes = visibleEntries(person.notes, scope).slice(-6).map((x) => x.text);
  const prefs = visibleEntries(person.preferences, scope).slice(-5).map((x) => x.text);
  const bounds = visibleEntries(person.boundaries, scope).slice(-4).map((x) => x.text);
  const moments = visibleEntries(person.sharedMoments, scope).slice(-3).map((x) => x.text);
  if (notes.length) lines.push(`你记得：${notes.join('；')}。`);
  if (prefs.length) lines.push(`他的偏好：${prefs.join('；')}。`);
  if (bounds.length) lines.push(`边界：${bounds.join('；')}。`);
  if (moments.length) lines.push(`共同经历：${moments.join('；')}。`);
  lines.push('这些是长期印象，不是本轮任务；不要报数值，不要一次全说出来，也不要假装记得没写在这里的事。');
  let text = lines.join('\n');
  if (text.length > maxChars) text = `${text.slice(0, maxChars)}\n（关系记忆过长，已截断。）`;
  return text;
}

export function buildRelationshipConsolidationPrompt({ roleName = '', roleExcerpt = '', person = null, scope = '', interactions = [], maxNotes = 3, summaryMaxChars = RELATIONSHIP_DEFAULT_SUMMARY_CHARS, currentSummary = '' } = {}) {
  const labels = relationshipLabels(person);
  const summaryLimit = normalizeSummaryChars(summaryMaxChars);
  const transcript = (Array.isArray(interactions) ? interactions : [])
    .slice(-20)
    .map((item, index) => `${index + 1}. ${asText(item.text, 180)}`)
    .join('\n');
  const existing = normalizeSummaryText(currentSummary, RELATIONSHIP_MAX_SUMMARY_CHARS);
  return `你正在整理「${roleName || '角色'}」对一个人的长期关系记忆。\n`
    + `当前关系标签：熟悉=${labels.familiarity}；信任=${labels.trust}；亲近=${labels.warmth}；紧张=${labels.tension}。\n`
    + (roleExcerpt ? `角色设定摘录：\n${String(roleExcerpt).slice(0, 1200)}\n` : '')
    + (existing ? `你之前对他的看法：\n${existing}\n` : '')
    + `最近互动（同一关系范围）：\n${transcript || '（无）'}\n\n`
    + `只输出一个 JSON 对象，不要 Markdown：\n`
    + `{"summary":"一段完整的第一人称看法","notes":["稳定观察，最多${maxNotes}条"],"preferences":["对方稳定的偏好，最多3条"],"boundaries":["对方明确/反复表现出的边界，最多2条"],"shared_moments":["值得记住的共同经历，最多2条"]}\n`
    + `要求：\n- summary 写你对他/她的整体看法：总体印象、相处方式、形成这个印象的依据、还不确定或保留的地方；不要只列标签。\n`
    + `- summary 用第一人称“我”，像私下回忆，不要写成档案，不要报关系数值，不要一次把最近互动全复述一遍。\n`
    + `- summary 控制在 120–${summaryLimit} 个中文字符之间；宁可具体一点，也不要空泛。\n`
    + `- 如果已有看法，保留仍然准确的部分，只补充或修正有新证据的部分，不要每次推倒重写。没有新证据时可以基本沿用。\n`
    + `- 其他数组只写有证据的稳定内容，不写一次性情绪、不写猜测。\n`
    + `- 用第一人称“我”写；没有内容就给空数组。不要输出 JSON 以外的任何文字。`;
}

export function parseRelationshipConsolidation(text, maxNotes = 3, summaryMaxChars = RELATIONSHIP_DEFAULT_SUMMARY_CHARS) {
  const raw = String(text ?? '').replace(/```(?:json)?/gi, '').trim();
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start < 0 || end <= start) return null;
  let parsed;
  try { parsed = JSON.parse(raw.slice(start, end + 1)); } catch { return null; }
  const list = (value, max) => (Array.isArray(value) ? value : [])
    .map((item) => asText(item, 240))
    .filter(Boolean)
    .slice(0, max);
  return {
    summary: normalizeSummaryText(parsed.summary ?? parsed.impression ?? '', normalizeSummaryChars(summaryMaxChars)),
    notes: list(parsed.notes, maxNotes),
    preferences: list(parsed.preferences, 3),
    boundaries: list(parsed.boundaries, 2),
    sharedMoments: list(parsed.shared_moments ?? parsed.sharedMoments, 2)
  };
}

function mergeEntries(target, incoming, scope, source, max) {
  if (!Array.isArray(target)) return [];
  const existing = new Set(target.map((item) => String(item?.text || '')));
  for (const text of Array.isArray(incoming) ? incoming : []) {
    if (!text || existing.has(text)) continue;
    existing.add(text);
    target.push({ text, scope, source, at: Date.now() });
  }
  target.sort((a, b) => (Number(a.at) || 0) - (Number(b.at) || 0));
  if (target.length > max) target.splice(0, target.length - max);
  return target;
}

export function mergeRelationshipConsolidation(person, scope, parsed, { summaryMaxChars = RELATIONSHIP_DEFAULT_SUMMARY_CHARS } = {}) {
  if (!person || !parsed) return person;
  const safeScope = /^(private|group):\d{3,20}$/.test(String(scope)) ? String(scope) : 'global';
  const summary = normalizeSummaryText(parsed.summary, normalizeSummaryChars(summaryMaxChars));
  if (summary) {
    person.summary = summary;
    person.summaryUpdatedAt = Date.now();
    person.summarySource = 'consolidated';
  }
  person.notes = mergeEntries(person.notes, parsed.notes, safeScope, 'consolidated', 30);
  person.preferences = mergeEntries(person.preferences, parsed.preferences, safeScope, 'consolidated', 12);
  person.boundaries = mergeEntries(person.boundaries, parsed.boundaries, safeScope, 'consolidated', 12);
  person.sharedMoments = mergeEntries(person.sharedMoments, parsed.sharedMoments, safeScope, 'consolidated', 12);
  person.lastConsolidatedAt = Date.now();
  return person;
}

export function formatRelationshipSummary(person, { now = Date.now() } = {}) {
  const labels = relationshipLabels(person);
  return {
    personId: person.personId,
    displayName: person.displayName,
    relation: person.relation,
    pinned: person.pinned === true,
    labels,
    values: {
      familiarity: Math.round(Number(person.familiarity) || 0),
      trust: Math.round(Number(person.trust) || 0),
      warmth: Math.round(Number(person.warmth) || 0),
      tension: Math.round(Number(person.tension) || 0)
    },
    interactionCount: Number(person.interactionCount) || 0,
    lastSeenAt: Number(person.lastSeenAt) || 0,
    summary: person.summary || '',
    summaryUpdatedAt: Number(person.summaryUpdatedAt) || 0,
    summarySource: person.summarySource || '',
    notes: (person.notes || []).slice(-8),
    preferences: (person.preferences || []).slice(-6),
    boundaries: (person.boundaries || []).slice(-6),
    sharedMoments: (person.sharedMoments || []).slice(-6),
    contexts: person.contexts || {},
    lastConsolidatedAt: Number(person.lastConsolidatedAt) || 0
  };
}
