// 数据迁移框架：大型更新（如城市革新）后，把朋友旧版数据逐级升级到新版 schema。
//
// 为什么需要（2026-10-31 用户提出）：
//   更新器能保证「只换代码、数据文件原样恢复」，但如果新版本改了数据模型
//   （字段语义变化 / 文件结构重排 / 默认模板换代），**新代码认不出旧数据**。
//   这种坏法通常不报错，朋友只会看到「我的城市没了/乱了」。
//   所以更新流程必须多一步：恢复用户文件 → 数据迁移 → 健康检查，失败可回滚。
//
// 设计要点：
//   · 数据文件本来就有 version 字段（truth.json / world-registry.json / life-profiles），
//     迁移链按 version 逐级升级，幂等（已到当前版本的文件跳过）。
//   · 迁移模块声明 { dataset, from, to, apply }，由 migrations/index.mjs 汇总；
//   · 写文件前先把原文件备份到 _backups/data/<时间戳>/，失败/回滚都能救；
//   · 迁移只增不改、未知字段保留（迁移编写原则见 docs/DATA_MIGRATIONS.md）；
//   · 本模块不读 DSH/QQ，纯文件操作，可离线单测。
import fs from 'node:fs';
import path from 'node:path';
import { WORLD_VERSION } from './world-engine.js';
import { REGISTRY_VERSION } from './world-registry.js';

/** 数据文件家族：id、匹配模式、当前版本、版本读取方式。 */
export const DATASETS = Object.freeze([
  {
    id: 'world-truth',
    label: '世界/城市真值',
    pattern: 'state/worlds/*/truth.json',
    current: WORLD_VERSION,
    readVersion: (data) => Number(data?.version) || 1,
  },
  {
    id: 'world-knowledge',
    label: '角色对世界的认知',
    pattern: 'state/worlds/*/characters/*.json',
    current: 1,
    readVersion: (data) => Number(data?.version) || 1,
  },
  {
    id: 'world-registry',
    label: '世界/角色注册表',
    pattern: 'state/world-registry.json',
    current: REGISTRY_VERSION,
    readVersion: (data) => Number(data?.version) || 1,
  },
  {
    id: 'life-profile',
    label: '角色生活配置',
    pattern: 'life-profiles/*.json',
    current: 1,
    readVersion: (data) => Number(data?.version) || 1,
  },
]);

/** 把一段通配（如 `truth.json`、`*.json`、`prefix*`）编译成正则，用于匹配文件名。 */
function segmentMatches(name, segment) {
  if (!segment.includes('*')) return name === segment;
  const parts = segment.split('*');
  let index = 0;
  for (let i = 0; i < parts.length; i += 1) {
    const part = parts[i];
    if (!part) continue;
    if (i === 0) {
      if (!name.startsWith(part)) return false;
      index = part.length;
    } else if (i === parts.length - 1) {
      return name.endsWith(part) && name.length - part.length >= index;
    } else {
      const found = name.indexOf(part, index);
      if (found < 0) return false;
      index = found + part.length;
    }
  }
  return true;
}

/** 当前代码支持的最新数据 schema（更新器做数据闸门用）。 */
export const CURRENT_DATA_SCHEMA = Math.max(...DATASETS.map((d) => d.current));

/** 把类似 state/worlds/<worldId>/truth.json 的单层通配模式展开成实际文件列表（相对 root 的 posix 路径）。 */
export function expandPattern(root, pattern) {
  const segments = String(pattern).split('/').filter(Boolean);
  const results = [];
  const walk = (dir, index) => {
    if (index >= segments.length) return;
    const segment = segments[index];
    const isLast = index === segments.length - 1;
    if (segment.includes('*')) {
      let entries;
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const entry of entries) {
        if (!segmentMatches(entry.name, segment)) continue;
        const next = path.join(dir, entry.name);
        if (entry.isDirectory() && !isLast) walk(next, index + 1);
        else if (entry.isFile() && isLast) results.push(next);
      }
      return;
    }
    const next = path.join(dir, segment);
    let stat;
    try { stat = fs.statSync(next); } catch { return; }
    if (isLast && stat.isFile()) results.push(next);
    else if (!isLast && stat.isDirectory()) walk(next, index + 1);
  };
  walk(root, 0);
  return results;
}

const toRel = (root, abs) => path.relative(root, abs).split(path.sep).join('/');
const datasetById = (id, datasets = DATASETS) => datasets.find((d) => d.id === id) || null;

/**
 * 扫描 root 下所有已知数据文件及其版本。
 * @returns {Array<{dataset:string, datasetLabel:string, relPath:string, absPath:string, version:number, current:number, json:object|null, error?:string}>}
 */
export function scanDataFiles(root, datasets = DATASETS) {
  const files = [];
  for (const dataset of datasets) {
    for (const abs of expandPattern(root, dataset.pattern)) {
      const relPath = toRel(root, abs);
      let json = null;
      let error = '';
      try {
        json = JSON.parse(fs.readFileSync(abs, 'utf8').replace(/^\uFEFF/, ''));
      } catch (e) {
        error = `JSON 解析失败：${e?.message ?? e}`;
      }
      const version = json ? dataset.readVersion(json) : 0;
      files.push({ dataset: dataset.id, datasetLabel: dataset.label, relPath, absPath: abs, version, current: dataset.current, json, error });
    }
  }
  return files.sort((a, b) => a.relPath.localeCompare(b.relPath));
}

/**
 * 为一个文件规划迁移链：从 version 逐级走到 dataset.current。
 * @returns {{ ok:boolean, steps?:Array, error?:string }}
 */
export function planChain(file, migrations = [], datasets = DATASETS) {
  const dataset = datasetById(file.dataset, datasets);
  if (!dataset) return { ok: false, error: `未知数据家族：${file.dataset}` };
  if (file.error) return { ok: false, error: file.error };
  if (file.version >= dataset.current) return { ok: true, steps: [] };
  if (file.version <= 0) return { ok: false, error: `版本号非法：${file.version}` };
  const steps = [];
  let at = file.version;
  let guard = 0;
  while (at < dataset.current) {
    if (guard++ > 50) return { ok: false, error: '迁移链过长，疑似循环' };
    const next = migrations.find((m) => m.dataset === file.dataset && m.from === at);
    if (!next) return { ok: false, error: `缺少迁移 ${file.dataset} v${at} -> v${at + 1}` };
    if (next.to !== at + 1) return { ok: false, error: `迁移 ${next.id} 的 to 不是 ${at + 1}` };
    steps.push(next);
    at = next.to;
  }
  return { ok: true, steps };
}

/** 生成全量迁移计划（dry-run 用）。 */
export function planAll(root, migrations = [], datasets = DATASETS) {
  const files = scanDataFiles(root, datasets);
  const pending = [];
  const errors = [];
  for (const file of files) {
    if (file.version >= file.current) continue;
    const plan = planChain(file, migrations, datasets);
    if (!plan.ok) {
      errors.push({ file: file.relPath, dataset: file.dataset, from: file.version, to: file.current, error: plan.error });
      continue;
    }
    pending.push({ file: file.relPath, dataset: file.dataset, from: file.version, to: file.current, steps: plan.steps.map((s) => s.id) });
  }
  return { files, pending, errors, targetVersions: Object.fromEntries(datasets.map((d) => [d.id, d.current])) };
}

function atomicWriteJson(absPath, data) {
  const dir = path.dirname(absPath);
  fs.mkdirSync(dir, { recursive: true });
  const tmp = `${absPath}.${process.pid}.migrate.tmp`;
  fs.writeFileSync(tmp, `${JSON.stringify(data, null, 2)}\n`, 'utf8');
  fs.renameSync(tmp, absPath);
}

function timestampKey(date = new Date()) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
}

/**
 * 执行迁移。
 *
 * @param {object} opts
 * @param {string} opts.root 项目根目录
 * @param {Array} opts.migrations 迁移模块列表
 * @param {boolean} opts.apply false = 只报告（dry-run）
 * @param {string} opts.backupRoot 备份根（默认 <root>/_backups/data）
 * @param {string} opts.logPath 迁移日志（默认 <root>/state/migration-log.json）
 * @returns {{ dryRun:boolean, scanned:number, pending:Array, migrated:Array, skipped:number, errors:Array, backupDir:string }}
 */
export function runMigrations({
  root,
  migrations = [],
  apply = false,
  backupRoot = null,
  logPath = null,
  datasets = DATASETS,
  log = () => {},
} = {}) {
  const plan = planAll(root, migrations, datasets);
  const report = {
    dryRun: !apply,
    scanned: plan.files.length,
    pending: plan.pending,
    migrated: [],
    skipped: plan.files.length - plan.pending.length - plan.errors.length,
    errors: [...plan.errors],
    backupDir: '',
  };
  if (!apply || !plan.pending.length) return report;

  const stamp = timestampKey();
  const backupDir = backupRoot || path.join(root, '_backups', 'data', stamp);
  const logFile = logPath || path.join(root, 'state', 'migration-log.json');
  const entries = [];

  for (const item of plan.pending) {
    const file = plan.files.find((f) => f.relPath === item.file);
    if (!file || !file.json) {
      report.errors.push({ file: item.file, error: '文件在规划后消失或无法解析' });
      continue;
    }
    // 备份原文件（保留相对路径）
    try {
      const backupPath = path.join(backupDir, item.file);
      fs.mkdirSync(path.dirname(backupPath), { recursive: true });
      fs.copyFileSync(file.absPath, backupPath);
    } catch (error) {
      report.errors.push({ file: item.file, error: `备份失败：${error?.message ?? error}` });
      continue;
    }
    const planChainResult = planChain(file, migrations, datasets);
    if (!planChainResult.ok) {
      report.errors.push({ file: item.file, error: planChainResult.error });
      continue;
    }
    let data = file.json;
    let ok = true;
    for (const step of planChainResult.steps) {
      try {
        const next = step.apply(data, { file: item.file, root });
        if (!next || typeof next !== 'object' || Array.isArray(next)) throw new Error('迁移返回值不是对象');
        data = next;
        data.version = step.to;
      } catch (error) {
        report.errors.push({ file: item.file, step: step.id, error: `迁移失败：${error?.message ?? error}` });
        ok = false;
        break;
      }
    }
    if (!ok) continue;
    try {
      atomicWriteJson(file.absPath, data);
      report.migrated.push({ file: item.file, dataset: item.dataset, from: item.from, to: item.to, steps: item.steps });
      entries.push({ at: Date.now(), file: item.file, dataset: item.dataset, from: item.from, to: item.to, steps: item.steps });
      log(`已迁移 ${item.file}：v${item.from} → v${item.to}`);
    } catch (error) {
      report.errors.push({ file: item.file, error: `写入失败：${error?.message ?? error}` });
    }
  }
  report.backupDir = report.migrated.length ? backupDir : '';

  if (entries.length) {
    try {
      let logData = { version: 1, entries: [] };
      try { logData = JSON.parse(fs.readFileSync(logFile, 'utf8')); } catch {}
      if (!Array.isArray(logData.entries)) logData.entries = [];
      logData.entries.push(...entries);
      fs.mkdirSync(path.dirname(logFile), { recursive: true });
      fs.writeFileSync(logFile, `${JSON.stringify(logData, null, 2)}\n`, 'utf8');
    } catch {}
  }
  return report;
}

/** 供控制台/更新器展示：每个数据家族的文件数、最低/最高版本、是否待迁移。 */
export function describeDataState(root, datasets = DATASETS) {
  const files = scanDataFiles(root, datasets);
  const byDataset = {};
  for (const dataset of datasets) byDataset[dataset.id] = { label: dataset.label, current: dataset.current, files: 0, minVersion: null, maxVersion: null, pending: 0, broken: 0 };
  for (const file of files) {
    const entry = byDataset[file.dataset];
    if (!entry) continue;
    entry.files += 1;
    if (file.error) { entry.broken += 1; continue; }
    entry.minVersion = entry.minVersion === null ? file.version : Math.min(entry.minVersion, file.version);
    entry.maxVersion = entry.maxVersion === null ? file.version : Math.max(entry.maxVersion, file.version);
    if (file.version < file.current) entry.pending += 1;
  }
  return { datasets: byDataset, files: files.length };
}
