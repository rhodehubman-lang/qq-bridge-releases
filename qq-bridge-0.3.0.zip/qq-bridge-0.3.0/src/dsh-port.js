// 桌面版 DSH 端口自动发现：解决「桌面版每次启动随机换端口，配置写死就失效」的问题。
//
// 背景（实测确认，2026-10-30 VM 与宿主两处样本）：
//   DSH 桌面版的 Web/API 服务和 `dsh web` 是同一套协议，但**监听端口每次启动随机**
//   （宿主两次实测 60186 / 59626；VM 实测 52984 / 12984）。桥接 config.json 里写死的
//   `dsh.baseUrl` 在 DSH 重启后必然失效，而朋友不可能自己去 netstat 查端口。
//
// 判定指纹（实测，比进程名可靠）：
//   未鉴权 GET /  →  HTTP 401 + 正文
//   "dsh web authentication required; reopen the URL printed by dsh web."
//   API 路径同样返回 401（正文 "unauthorized"）。因此探测只看「401 + 固定文案」，
//   进程名只用来给候选端口排序（桌面版进程名可能是 "DeepSeek Harness.exe"，
//   也可能是 electron 壳，不能当唯一依据）。
//
// 解析顺序（与 docs/DESKTOP_DSH_SUPPORT.md §3.1 一致）：
//   1) config.json 里显式配置的 dsh.baseUrl（探测通过才用）
//   2) state/dsh-port.json 缓存（探测通过才用）
//   3) 扫本机监听端口 → 按进程名排序 → 逐个探测 → 命中后写缓存
//   4) 全部失败 → 返回 null + reason，调用方给明确提示（不静默）
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';

export const DSH_PORT_CACHE_VERSION = 1;

/** 未鉴权访问 DSH 根路径时的固定正文（判定指纹）。 */
export const DSH_AUTH_MARKER = 'dsh web authentication required';

const DEFAULT_PROBE_TIMEOUT_MS = 800;
const DEFAULT_TOTAL_TIMEOUT_MS = 15000;
const DEFAULT_CONCURRENCY = 6;

// ── 地址归一化 ────────────────────────────────────────────────────────────────

/**
 * 把各种输入归一成 `http://host:port` 形式。
 * 接受：数字端口、`127.0.0.1:59626`、`http://127.0.0.1:59626/`、带路径的 URL（保留路径）。
 * 非法输入返回 ''（调用方视为不可用）。
 */
export function normalizeDshBaseUrl(input) {
  if (input === null || input === undefined) return '';
  const raw = String(input).trim();
  if (!raw) return '';
  if (/^\d{2,5}$/.test(raw)) {
    const port = Number(raw);
    if (port < 1 || port > 65535) return '';
    return `http://127.0.0.1:${port}`;
  }
  const withScheme = /^https?:\/\//i.test(raw) ? raw : `http://${raw}`;
  try {
    const url = new URL(withScheme);
    if (!url.port && (url.protocol === 'http:' || url.protocol === 'https:')) {
      // 无端口时按 DSH 老默认值补齐，保持行为可预期。
      url.port = url.protocol === 'https:' ? '443' : '3080';
    }
    const base = `${url.protocol}//${url.host}`;
    return url.pathname && url.pathname !== '/' ? `${base}${url.pathname.replace(/\/$/, '')}` : base;
  } catch {
    return '';
  }
}

export function portOfBaseUrl(baseUrl) {
  try {
    const url = new URL(String(baseUrl));
    return Number(url.port) || 0;
  } catch {
    return 0;
  }
}

// ── 命令执行（可注入，便于测试）──────────────────────────────────────────────

/** 默认的 exec 实现：返回 stdout 字符串；失败抛错。 */
export async function defaultExec(command, args = [], { timeoutMs = 5000 } = {}) {
  return await new Promise((resolve, reject) => {
    execFile(command, args, { timeout: timeoutMs, windowsHide: true, maxBuffer: 4 * 1024 * 1024 }, (error, stdout, stderr) => {
      if (error) {
        error.stderr = String(stderr || '');
        reject(error);
        return;
      }
      resolve(String(stdout || ''));
    });
  });
}

// ── 输出解析（纯函数，全部可单测）────────────────────────────────────────────

/**
 * 解析 Windows `netstat -ano` 的 LISTENING 行。
 * 形如：`  TCP    127.0.0.1:60186        0.0.0.0:0              LISTENING       6864`
 * 兼容 [::1]:port 与本地化系统（状态词在 Windows netstat 里仍是英文）。
 * 返回 [{port, pid, address}]。
 */
export function parseNetstatListeners(text) {
  const out = [];
  for (const line of String(text || '').split(/\r?\n/)) {
    const fields = line.trim().split(/\s+/);
    if (fields.length < 5) continue;
    if (!/^tcp/i.test(fields[0])) continue; // UDP 行没有状态列，跳过
    if (!/^LISTENING$/i.test(fields[3])) continue;
    const local = fields[1] || '';
    const idx = local.lastIndexOf(':');
    const port = Number(local.slice(idx + 1));
    const pid = Number(fields[fields.length - 1]);
    if (!Number.isInteger(port) || port <= 0 || port > 65535) continue;
    if (!Number.isInteger(pid) || pid <= 0) continue;
    const address = local.slice(0, idx);
    out.push({ port, pid, address });
  }
  return out;
}

/** 解析 `tasklist /FO CSV /NH`：`"DeepSeek Harness.exe","6864",...` → Map<pid, name>。 */
export function parseTasklistCsv(text) {
  const map = new Map();
  for (const line of String(text || '').split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const fields = parseCsvLine(trimmed);
    if (fields.length < 2) continue;
    const name = fields[0];
    const pid = Number(fields[1]);
    if (name && Number.isInteger(pid) && pid > 0) map.set(pid, name);
  }
  return map;
}

/** 极简 CSV 解析（支持双引号包裹与 "" 转义；tasklist 的字段里可能有逗号）。 */
function parseCsvLine(line) {
  const out = [];
  let cur = '';
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (quoted) {
      if (ch === '"') {
        if (line[i + 1] === '"') { cur += '"'; i += 1; }
        else quoted = false;
      } else cur += ch;
    } else if (ch === '"') {
      quoted = true;
    } else if (ch === ',') {
      out.push(cur);
      cur = '';
    } else cur += ch;
  }
  out.push(cur);
  return out;
}

/**
 * 解析 Linux `ss -lntp`：
 * `LISTEN 0 4096 127.0.0.1:60186 0.0.0.0:* users:(("node",pid=1234,fd=21))`
 * 也兼容不带 pid 的 `ss -lnt`（pid 为 0）。
 */
export function parseSsListeners(text) {
  const out = [];
  for (const line of String(text || '').split(/\r?\n/)) {
    if (!/^LISTEN/i.test(line.trim())) continue;
    const fields = line.trim().split(/\s+/);
    const local = fields[3] || '';
    const m = /:(\d+)$/.exec(local);
    const pid = /pid=(\d+)/.exec(line);
    if (!m) continue;
    const port = Number(m[1]);
    if (!Number.isInteger(port) || port <= 0 || port > 65535) continue;
    out.push({ port, pid: pid ? Number(pid[1]) : 0, address: local.slice(0, m.index) });
  }
  return out;
}

/** 解析 `ps -e -o pid=,comm=`（也接受 pid,args）。 */
export function parsePsNames(text) {
  const map = new Map();
  for (const line of String(text || '').split(/\r?\n/)) {
    const m = /^\s*(\d+)\s+(.+?)\s*$/.exec(line);
    if (!m) continue;
    const pid = Number(m[1]);
    const name = m[2].trim();
    if (Number.isInteger(pid) && pid > 0 && name) map.set(pid, name);
  }
  return map;
}

/**
 * 进程名是否“像 DSH”。只作候选排序提示，不当作判定依据 ——
 * 判定永远靠 HTTP 指纹（进程名可能是 electron 壳，或用户重命名过）。
 */
export function isLikelyDshProcessName(name) {
  const text = String(name || '').trim().toLowerCase();
  if (!text) return false;
  if (/deepseek[\s_-]*harness/.test(text)) return true;
  if (/deepseek[\s_-]*harness\.exe$/.test(text)) return true;
  if (/dsh[\s_-]?desktop/.test(text)) return true;
  if (/^dsh(\.exe)?$/.test(text)) return true;
  return false;
}

/**
 * 候选端口排序：DSH 进程占用的排前面，其余按端口升序垫后；去重。
 * 低端口（<1024）不排除（可能被自定义），但排在最后，减少无谓探测。
 */
export function pickCandidatePorts(listeners, pidNames = new Map()) {
  const strong = [];
  const weak = [];
  const seen = new Set();
  for (const item of Array.isArray(listeners) ? listeners : []) {
    const port = Number(item?.port);
    if (!Number.isInteger(port) || port <= 0 || port > 65535) continue;
    if (seen.has(port)) continue;
    seen.add(port);
    const name = pidNames.get(Number(item.pid)) || '';
    (isLikelyDshProcessName(name) ? strong : weak).push(port);
  }
  strong.sort((a, b) => a - b);
  weak.sort((a, b) => (a < 1024) - (b < 1024) || a - b);
  return [...strong, ...weak];
}

// ── HTTP 探测 ────────────────────────────────────────────────────────────────

/**
 * 探测一个 baseUrl 是否是 DSH。
 * 成功条件：HTTP 响应（任意状态码）正文包含 DSH 的固定鉴权文案。
 * 说明：未鉴权得到 401 是常态；但如果该 DSH 允许匿名（未来可能），200 也认。
 * @returns {Promise<{ok:boolean, status?:number, error?:string, elapsedMs:number}>}
 */
export async function probeDshBaseUrl(baseUrl, { timeoutMs = DEFAULT_PROBE_TIMEOUT_MS, fetchImpl = globalThis.fetch } = {}) {
  const startedAt = Date.now();
  const base = normalizeDshBaseUrl(baseUrl);
  if (!base) return { ok: false, error: 'invalid baseUrl', elapsedMs: 0 };
  if (typeof fetchImpl !== 'function') return { ok: false, error: 'fetch unavailable', elapsedMs: 0 };
  try {
    const response = await fetchImpl(`${base}/`, {
      method: 'GET',
      redirect: 'manual',
      signal: AbortSignal.timeout(Math.max(100, Number(timeoutMs) || DEFAULT_PROBE_TIMEOUT_MS)),
      headers: { 'user-agent': 'qq-bridge/dsh-port-probe' }
    });
    let body = '';
    try {
      body = await response.text();
    } catch {
      body = '';
    }
    const ok = String(body || '').includes(DSH_AUTH_MARKER);
    return { ok, status: response.status, elapsedMs: Date.now() - startedAt };
  } catch (error) {
    return { ok: false, error: String(error?.message || error), elapsedMs: Date.now() - startedAt };
  }
}

// ── 缓存（state/dsh-port.json）───────────────────────────────────────────────

export function dshPortCacheFile(stateDir) {
  return path.join(stateDir, 'dsh-port.json');
}

/** 读取缓存；损坏/版本不符返回 null（缓存只加速，不可信）。 */
export function readDshPortCache(stateDir) {
  try {
    const raw = JSON.parse(fs.readFileSync(dshPortCacheFile(stateDir), 'utf8'));
    if (!raw || raw.version !== DSH_PORT_CACHE_VERSION) return null;
    const baseUrl = normalizeDshBaseUrl(raw.baseUrl);
    if (!baseUrl) return null;
    return { baseUrl, port: portOfBaseUrl(baseUrl), updatedAt: Number(raw.updatedAt) || 0, source: String(raw.source || '') };
  } catch {
    return null;
  }
}

/** 写缓存（原子替换；失败只影响下次探测速度，不影响功能）。 */
export function writeDshPortCache(stateDir, { baseUrl, source = 'discover' } = {}) {
  try {
    fs.mkdirSync(stateDir, { recursive: true });
    const file = dshPortCacheFile(stateDir);
    const payload = { version: DSH_PORT_CACHE_VERSION, baseUrl, port: portOfBaseUrl(baseUrl), source, updatedAt: Date.now() };
    const tmp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
    fs.renameSync(tmp, file);
    return payload;
  } catch {
    return null;
  }
}

// ── 扫描与总解析 ──────────────────────────────────────────────────────────────

/**
 * 列出本机监听端口与进程名。
 * @param {object} opts.platform process.platform
 * @param {Function} opts.exec 注入的命令执行器（默认 defaultExec）
 * @returns {Promise<{listeners:Array, pidNames:Map, commands:string[]}>}
 */
export async function listLocalListeners({ platform = process.platform, exec = defaultExec, timeoutMs = 5000 } = {}) {
  const commands = [];
  if (platform === 'win32') {
    commands.push('netstat -ano', 'tasklist /FO CSV /NH');
    const netstatText = await exec('netstat', ['-ano'], { timeoutMs }).catch(() => '');
    const tasklistText = await exec('tasklist', ['/FO', 'CSV', '/NH'], { timeoutMs }).catch(() => '');
    return {
      listeners: parseNetstatListeners(netstatText),
      pidNames: parseTasklistCsv(tasklistText),
      commands
    };
  }
  // Linux / macOS：优先 ss，退 netstat；进程名用 ps。
  commands.push('ss -lntp', 'ps -e -o pid=,comm=');
  let listeners = [];
  const ssText = await exec('ss', ['-lntp'], { timeoutMs }).catch(() => '');
  if (ssText) listeners = parseSsListeners(ssText);
  if (!listeners.length) {
    commands.push('netstat -lntp');
    const netstatText = await exec('netstat', ['-lntp'], { timeoutMs }).catch(() => '');
    listeners = parseSsListeners(netstatText.replace(/^Proto.*$/gm, ''));
  }
  const psText = await exec('ps', ['-e', '-o', 'pid=,comm='], { timeoutMs }).catch(() => '');
  return { listeners, pidNames: parsePsNames(psText), commands };
}

/**
 * 扫描并探测，返回第一个命中的 DSH baseUrl。
 * 候选按「DSH 进程 > 普通端口 > 低端口」排序，小并发探测，命中即停。
 * @returns {Promise<{baseUrl?:string, port?:number, probed:number, elapsedMs:number, reason?:string}>}
 */
export async function discoverDshBaseUrl({
  platform = process.platform,
  exec = defaultExec,
  fetchImpl = globalThis.fetch,
  stateDir = '',
  timeoutMs = DEFAULT_PROBE_TIMEOUT_MS,
  totalTimeoutMs = DEFAULT_TOTAL_TIMEOUT_MS,
  concurrency = DEFAULT_CONCURRENCY,
  log = () => {}
} = {}) {
  const startedAt = Date.now();
  const deadline = startedAt + Math.max(1000, Number(totalTimeoutMs) || DEFAULT_TOTAL_TIMEOUT_MS);
  let listed;
  try {
    listed = await listLocalListeners({ platform, exec });
  } catch (error) {
    return { probed: 0, elapsedMs: Date.now() - startedAt, reason: `枚举监听端口失败：${error?.message || error}` };
  }
  const candidates = pickCandidatePorts(listed.listeners, listed.pidNames);
  log(`监听端口候选 ${candidates.length} 个：${candidates.slice(0, 12).join(', ')}${candidates.length > 12 ? '…' : ''}`);
  if (!candidates.length) {
    return { probed: 0, elapsedMs: Date.now() - startedAt, reason: '没有可探测的本地监听端口（DSH 桌面版可能没启动）' };
  }

  let probed = 0;
  const batchSize = Math.max(1, Math.min(Number(concurrency) || DEFAULT_CONCURRENCY, candidates.length));
  for (let i = 0; i < candidates.length; i += batchSize) {
    if (Date.now() > deadline) {
      return { probed, elapsedMs: Date.now() - startedAt, reason: `探测超时（${totalTimeoutMs}ms）` };
    }
    const batch = candidates.slice(i, i + batchSize);
    const results = await Promise.all(batch.map(async (port) => {
      const baseUrl = `http://127.0.0.1:${port}`;
      const result = await probeDshBaseUrl(baseUrl, { timeoutMs, fetchImpl });
      probed += 1;
      return { port, baseUrl, ...result };
    }));
    // 同一批内按候选顺序取第一个命中，避免随机性。
    const hit = results.find((item) => item.ok);
    if (hit) {
      if (stateDir) writeDshPortCache(stateDir, { baseUrl: hit.baseUrl, source: 'discover' });
      log(`命中 DSH：${hit.baseUrl}（探测 ${probed} 个端口，用时 ${Date.now() - startedAt}ms）`);
      return { baseUrl: hit.baseUrl, port: hit.port, probed, elapsedMs: Date.now() - startedAt };
    }
  }
  return { probed, elapsedMs: Date.now() - startedAt, reason: '所有本地监听端口都不是 DSH（请先启动 DSH 桌面版）' };
}

/**
 * 总解析：显式配置 → 缓存 → 扫描。
 * @param {object} opts
 * @param {string} opts.configured config.json 里现有的 dsh.baseUrl
 * @param {string} opts.stateDir 桥接 state 目录（缓存位置）
 * @returns {Promise<{baseUrl:string, source:'config'|'cache'|'discover', port:number, probed:number, elapsedMs:number, reason?:string}>}
 */
export async function resolveDshBaseUrl({
  configured = '',
  stateDir = '',
  platform = process.platform,
  exec = defaultExec,
  fetchImpl = globalThis.fetch,
  timeoutMs = DEFAULT_PROBE_TIMEOUT_MS,
  totalTimeoutMs = DEFAULT_TOTAL_TIMEOUT_MS,
  log = () => {}
} = {}) {
  const startedAt = Date.now();
  const configuredBase = normalizeDshBaseUrl(configured);
  if (configuredBase) {
    const probe = await probeDshBaseUrl(configuredBase, { timeoutMs, fetchImpl });
    if (probe.ok) {
      return { baseUrl: configuredBase, source: 'config', port: portOfBaseUrl(configuredBase), probed: 1, elapsedMs: Date.now() - startedAt };
    }
    log(`配置的 DSH 地址不可用：${configuredBase}（${probe.error || `HTTP ${probe.status}`}）`);
  }
  const cached = stateDir ? readDshPortCache(stateDir) : null;
  if (cached) {
    const probe = await probeDshBaseUrl(cached.baseUrl, { timeoutMs, fetchImpl });
    if (probe.ok) {
      return { baseUrl: cached.baseUrl, source: 'cache', port: cached.port, probed: 1, elapsedMs: Date.now() - startedAt };
    }
    log(`缓存的 DSH 端口已失效：${cached.baseUrl}`);
  }
  const found = await discoverDshBaseUrl({ platform, exec, fetchImpl, stateDir, timeoutMs, totalTimeoutMs, log });
  if (found.baseUrl) {
    return { baseUrl: found.baseUrl, source: 'discover', port: found.port || portOfBaseUrl(found.baseUrl), probed: found.probed, elapsedMs: Date.now() - startedAt };
  }
  return { baseUrl: '', source: 'none', port: 0, probed: found.probed || 0, elapsedMs: Date.now() - startedAt, reason: found.reason || '未找到 DSH' };
}

// ── 写回 config.json（只改 dsh.baseUrl，保留 BOM 与其它字段）───────────────────

/**
 * 把已确认可用的 DSH 地址写回 config.json。
 * 与 snowluma-conn.js 的 persistSnowLumaEndpoint 同一范式：只改该改的字段、
 * 保留原 BOM、内容一致时不写盘（幂等）。
 * @returns {{updated:boolean, from:string, to:string}}
 */
export function persistDshBaseUrl(cfgPath, baseUrl) {
  const nextBase = normalizeDshBaseUrl(baseUrl);
  if (!nextBase) throw new Error(`invalid dsh baseUrl: ${baseUrl}`);
  let text = fs.readFileSync(cfgPath, 'utf8');
  const hadBom = text.charCodeAt(0) === 0xFEFF;
  if (hadBom) text = text.slice(1);
  const cfg = JSON.parse(text);
  const cur = String(cfg?.dsh?.baseUrl ?? '');
  if (cur === nextBase) return { updated: false, from: cur, to: nextBase };
  cfg.dsh = cfg.dsh && typeof cfg.dsh === 'object' ? cfg.dsh : {};
  cfg.dsh.baseUrl = nextBase;
  const serialized = `${JSON.stringify(cfg, null, 2)}\n`;
  fs.writeFileSync(cfgPath, hadBom ? `\uFEFF${serialized}` : serialized, 'utf8');
  return { updated: true, from: cur, to: nextBase };
}
