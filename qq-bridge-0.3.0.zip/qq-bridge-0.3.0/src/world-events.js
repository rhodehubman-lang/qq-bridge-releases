// 大模型世界事件：每天一批（1 大 + 1~2 小），小事件自动应用，大事件待审核。
// 本模块只做提示词、解析、校验与事件对象转换；文件读写和 DSH 会话在 bridge 里。

export const WORLD_EVENTS_VERSION = 1;

export const WORLD_EVENT_CHANNELS = ['news', 'social', 'local', 'ambient', 'rumor'];
export const WORLD_EVENT_TYPES = ['transit', 'security', 'corp', 'weather', 'social', 'crime', 'city', 'rumor', 'life'];

export const DEFAULT_WORLD_EVENTS_CONFIG = Object.freeze({
  // 默认关闭：自动生成事件必须由用户在控制台显式开启（2026-10-31 发行要求）。
  enabled: false,
  auto: false,
  time: '08:00',
  preset: '',
  autoApplyMinor: false,
  reviewMajor: true,
  maxOutputTokens: 2000
});

export function normalizeWorldEventsConfig(raw = {}) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const timeText = String(src.time ?? DEFAULT_WORLD_EVENTS_CONFIG.time).trim();
  const time = /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(timeText) ? timeText : DEFAULT_WORLD_EVENTS_CONFIG.time;
  return {
    enabled: src.enabled === true,
    auto: src.auto === true,
    time,
    preset: String(src.preset || '').slice(0, 80),
    autoApplyMinor: src.autoApplyMinor === true,
    reviewMajor: src.reviewMajor !== false,
    maxOutputTokens: Math.min(4000, Math.max(400, Number(src.maxOutputTokens) || 2000))
  };
}

export function emptyWorldEventsState(worldId = '') {
  return {
    version: WORLD_EVENTS_VERSION,
    worldId: String(worldId || ''),
    config: { ...DEFAULT_WORLD_EVENTS_CONFIG },
    lastGeneratedDay: '',
    lastGeneratedAt: 0,
    lastAttemptAt: 0,
    lastError: '',
    pending: []
  };
}

export function normalizeWorldEventsState(raw = {}, worldId = '') {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const pending = Array.isArray(src.pending)
    ? src.pending.map((item) => normalizeWorldEventItem(item, { now: Number(item?.generatedAt) || Date.now(), allowId: true })).filter(Boolean).slice(-20)
    : [];
  return {
    ...emptyWorldEventsState(worldId),
    ...src,
    version: WORLD_EVENTS_VERSION,
    worldId: String(worldId || src.worldId || ''),
    config: normalizeWorldEventsConfig(src.config),
    lastGeneratedDay: String(src.lastGeneratedDay || ''),
    lastGeneratedAt: Number(src.lastGeneratedAt) || 0,
    lastAttemptAt: Number(src.lastAttemptAt) || 0,
    lastError: String(src.lastError || '').slice(0, 300),
    pending
  };
}

function clampNumber(value, min, max, fallback = 0) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, number));
}

function normalizeEffects(raw) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const effects = {};
  if (src.commuteExtraMinutes !== undefined) effects.commuteExtraMinutes = Math.round(clampNumber(src.commuteExtraMinutes, 0, 180, 0));
  if (src.shiftDelayMinutes !== undefined) effects.shiftDelayMinutes = Math.round(clampNumber(src.shiftDelayMinutes, 0, 180, 0));
  if (src.moodDelta !== undefined) effects.moodDelta = Math.round(clampNumber(src.moodDelta, -10, 10, 0));
  if (src.districtDanger !== undefined) effects.districtDanger = Math.round(clampNumber(src.districtDanger, 0, 5, 0));
  return effects;
}

function cleanText(value, maxLength) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, maxLength);
}

function cleanLocations(raw) {
  if (!Array.isArray(raw)) return [];
  return [...new Set(raw.map((item) => cleanText(item, 48)).filter(Boolean))].slice(0, 6);
}

function eventLooksMajor(item) {
  if (typeof item.major === 'boolean') return item.major;
  return Number(item.severity) >= 3 || item.type === 'crime' || item.type === 'security';
}

export function normalizeWorldEventItem(raw, { now = Date.now(), allowId = false } = {}) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const headline = cleanText(src.headline, 80);
  const detail = cleanText(src.detail, 500);
  if (headline.length < 4 || detail.length < 8) return null;
  const type = WORLD_EVENT_TYPES.includes(src.type) ? src.type : 'city';
  const channel = WORLD_EVENT_CHANNELS.includes(src.channel) ? src.channel : 'news';
  const severity = Math.round(clampNumber(src.severity, 1, 5, 2));
  const major = eventLooksMajor({ ...src, type, severity });
  const id = allowId && src.id ? cleanText(src.id, 80) : `wevt_${now.toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
  return {
    id,
    at: allowId && Number(src.at) > 0 ? Number(src.at) : now,
    type,
    channel,
    headline,
    detail,
    severity,
    major,
    locations: cleanLocations(src.locations),
    effects: normalizeEffects(src.effects),
    known: false,
    knownAt: 0,
    discoveredVia: '',
    source: 'llm',
    status: allowId && ['pending', 'applied', 'rejected'].includes(src.status) ? src.status : 'pending'
  };
}

export function classifyWorldEvents(items = []) {
  const normalized = items.map((item) => normalizeWorldEventItem(item, { now: item?.at || Date.now() })).filter(Boolean);
  if (!normalized.length) return [];
  // 提示词要求至少一条大事件；模型偶尔全给小事时，把最重的一条升为大事，保证审核入口存在。
  if (!normalized.some((item) => item.major)) {
    const strongest = normalized.reduce((best, item) => (item.severity > best.severity ? item : best), normalized[0]);
    strongest.major = true;
  }
  return normalized.slice(0, 3);
}

export function parseWorldEventsOutput(text) {
  const source = String(text ?? '').replace(/```(?:json)?/gi, '').trim();
  const start = source.indexOf('{');
  const end = source.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('世界事件输出里没有 JSON 对象');
  let parsed;
  try { parsed = JSON.parse(source.slice(start, end + 1)); }
  catch (error) { throw new Error(`世界事件 JSON 解析失败：${error?.message || error}`); }
  const items = Array.isArray(parsed) ? parsed : parsed?.events;
  if (!Array.isArray(items) || !items.length) throw new Error('世界事件 JSON 缺少 events 数组');
  const events = classifyWorldEvents(items);
  if (!events.length) throw new Error('世界事件没有有效条目');
  return events;
}

export function buildWorldEventsPrompt({ world = {}, profile = {}, now = Date.now(), recentEvents = [] } = {}) {
  const worldName = cleanText(world.name || profile?.world?.name || '当前城市', 80);
  const roleName = cleanText(profile?.roleName || profile?.displayName || '当前角色', 40);
  const locations = Array.isArray(profile?.locations)
    ? profile.locations.map((item) => `${item.name || item.id || ''}(${item.id || ''})`).filter(Boolean).slice(0, 20)
    : [];
  const recent = (Array.isArray(recentEvents) ? recentEvents : [])
    .map((item) => cleanText(item?.headline || item, 100))
    .filter(Boolean)
    .slice(0, 12);
  return [
    `你是《${worldName}》的世界事件编辑，不是角色本人。现在是 ${new Date(now).toLocaleString('zh-CN', { hour12: false })}。`,
    `为这座城市生成今天的一批动态：1 条大事件 + 1~2 条小事件，总共 2~3 条。`,
    '只输出一个 JSON 对象，不要 Markdown、不要解释、不要代码围栏。',
    '',
    '城市基调：赛博朋克、低烈度、日常黑色幽默、霓虹和雨；大事件是会影响城市或角色日程的新闻/事故，小事件是酒吧、天气、广告、传闻、熟人生活。',
    `当前视角角色：${roleName}。事件是世界真实发生的事，不需要写成这个角色已经知道。`,
    locations.length ? `城市地点：${locations.join('、')}` : '城市地点以当前角色生活档案里的地点为准。',
    `最近已有事件（不要重复这些标题，也不要直接推翻它们）：${recent.length ? recent.join('；') : '暂无'}`,
    '',
    '硬规则：',
    '- 不改变角色的硬日程（上班日、09:00–18:00 班次、23:00–07:00 睡眠、住址、工作）；只能通过 effects 表示“今天会晚到/通勤多花时间/附近危险”。',
    '- 不让主要角色死亡、不写战争/末日、不把角色写成动作英雄；不解决长期悬念，只增加城市质感和小麻烦。',
    '- 不写真实品牌、真实政治人物和现实地名；不输出露骨色情内容。',
    '- headline 4~40 个汉字；detail 20~160 个汉字；具体、有画面，不要新闻通稿腔。',
    '- 两条小事件不要互相矛盾；大事件最多 1 条。',
    '',
    'JSON 结构：',
    '{"events":[{"headline":"标题","detail":"具体描述","type":"transit|security|corp|weather|social|crime|city|rumor|life","channel":"news|social|local|ambient|rumor","severity":1,"major":false,"locations":["old_town"],"effects":{"commuteExtraMinutes":0,"shiftDelayMinutes":0,"moodDelta":0,"districtDanger":0}}]}',
    'severity 取 1~5；大事件 major=true 且 severity>=3。effects 只允许上面四个字段，没有影响就写空对象。'
  ].join('\n');
}
