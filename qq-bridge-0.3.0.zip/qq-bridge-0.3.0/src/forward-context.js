// 合并转发/聊天记录的上下文格式化。
// 只负责把 OneBot 的 get_forward_msg 结果变成模型可读的短文本；不发起网络请求。
import { formatForwardResponse } from './forward.js';

export const FORWARD_CONTEXT_MAX_CHARS = 3600;

export function formatForwardContent(id, data, options = {}) {
  const maxMessages = Math.max(1, Math.min(20, Number(options.maxMessages) || 20));
  const maxCharsPerMessage = Math.max(1, Math.min(1000, Number(options.maxCharsPerMessage) || 240));
  const maxTotal = Math.max(500, Math.min(8000, Number(options.maxTotal) || FORWARD_CONTEXT_MAX_CHARS));
  const formatted = formatForwardResponse(data, { maxMessages, maxCharsPerMessage });
  if (!Array.isArray(formatted.messages) || formatted.messages.length === 0) {
    return formatForwardFailure(id);
  }
  const lines = [];
  for (const msg of formatted.messages || []) {
    const sender = String(msg.sender || msg.userId || '未知').replace(/\s+/g, ' ').slice(0, 30);
    const text = String(msg.text || '').replace(/\s+/g, ' ').slice(0, maxCharsPerMessage);
    const hasInlineMedia = /\[(图片|表情|视频|语音|文件|转发)\]/.test(text);
    const media = Array.isArray(msg.media) && msg.media.length && !hasInlineMedia
      ? ` [${msg.media.map((m) => (m?.kind === 'image' ? '图片' : '表情')).join('/')}]`
      : '';
    const nested = Array.isArray(msg.nestedForwardIds) && msg.nestedForwardIds.length
      ? ' [内含嵌套聊天记录]'
      : '';
    lines.push(`${msg.index}. ${sender}：${text || '[空消息]'}${media}${nested}`);
  }
  const head = `【聊天记录 ${id}｜共 ${formatted.total || lines.length} 条${formatted.total > lines.length ? `，只展开前 ${lines.length} 条` : ''}】`;
  const tail = formatted.truncated ? '\n（内容过长，已截断；看不到的部分不要猜。）' : '';
  let text = `${head}\n${lines.join('\n')}${tail}`;
  if (text.length > maxTotal) {
    text = `${text.slice(0, maxTotal)}\n（聊天记录过长，已截断。）`;
  }
  return text;
}

export function formatForwardFailure(id) {
  return `【聊天记录 ${id}】读取失败，看不到具体内容；不要编造里面的话，可以告诉主人这条记录打不开。`;
}

export function buildForwardContextBlock(blocks) {
  const list = (Array.isArray(blocks) ? blocks : []).filter(Boolean);
  if (!list.length) return '';
  return `【用户发来的聊天记录（已自动展开）】\n${list.join('\n\n')}\n\n`;
}
