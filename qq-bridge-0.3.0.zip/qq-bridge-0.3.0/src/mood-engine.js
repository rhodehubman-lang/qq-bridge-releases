// 心情系统（第一阶段）：维度 + 生活基线 + 世界感知 + 对话微调 + 定性提示。
// 数值只在内部使用；注入给模型的永远是“人话状态”，不是分数。

export const MOOD_VERSION = 1;

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, Number(value) || 0));
}

export function emptyMood(characterId = '') {
  return {
    version: MOOD_VERSION,
    characterId,
    valence: 0.05,
    energy: 0.6,
    tension: 0.2,
    irritability: 0.2,
    socialOpenness: 0.6,
    factors: [],
    appliedEventIds: [],
    lastMessageAt: 0,
    updatedAt: Date.now()
  };
}

export function normalizeMood(raw, characterId = '') {
  const src = raw && typeof raw === 'object' ? raw : {};
  return {
    version: MOOD_VERSION,
    characterId,
    valence: clamp(src.valence ?? 0.05, -1, 1),
    energy: clamp(src.energy ?? 0.6, 0, 1),
    tension: clamp(src.tension ?? 0.2, 0, 1),
    irritability: clamp(src.irritability ?? 0.2, 0, 1),
    socialOpenness: clamp(src.socialOpenness ?? 0.6, 0, 1),
    factors: Array.isArray(src.factors) ? src.factors.slice(-12) : [],
    appliedEventIds: Array.isArray(src.appliedEventIds) ? src.appliedEventIds.slice(-300) : [],
    lastMessageAt: Number(src.lastMessageAt) || 0,
    updatedAt: Number(src.updatedAt) || Date.now()
  };
}

export function lifeMoodBaseline(lifeState = null, now = Date.now()) {
  const state = lifeState?.state || 'free';
  const hour = new Date(now).getHours();
  const base = {
    sleeping: { valence: -0.08, energy: 0.12, tension: 0.1, irritability: 0.15, socialOpenness: 0.12 },
    waking: { valence: -0.02, energy: 0.35, tension: 0.15, irritability: 0.2, socialOpenness: 0.4 },
    commute: { valence: -0.04, energy: 0.48, tension: 0.25, irritability: 0.22, socialOpenness: 0.4 },
    working: { valence: 0.02, energy: 0.52, tension: 0.2, irritability: 0.2, socialOpenness: 0.5 },
    free: { valence: 0.12, energy: 0.7, tension: 0.1, irritability: 0.15, socialOpenness: 0.68 }
  }[state] || { valence: 0.05, energy: 0.6, tension: 0.2, irritability: 0.2, socialOpenness: 0.6 };
  if (hour >= 1 && hour < 5) base.energy -= 0.08;
  if (hour >= 22) base.energy -= 0.05;
  return base;
}

function decayToward(value, target, rate) {
  return value + (target - value) * rate;
}

/** 时间衰减：向生活状态基线回归，避免情绪永久停留。 */
export function decayMood(mood, lifeState, now = Date.now()) {
  const last = Number(mood.updatedAt) || now;
  const hours = Math.max(0, Math.min(24, (now - last) / 3600000));
  if (hours <= 0.01) return mood;
  const target = lifeMoodBaseline(lifeState, now);
  const rate = Math.min(0.65, 1 - Math.exp(-hours / 3));
  mood.valence = decayToward(mood.valence, target.valence, rate);
  mood.energy = decayToward(mood.energy, target.energy, Math.min(0.8, rate * 1.2));
  mood.tension = decayToward(mood.tension, target.tension, Math.min(0.7, rate));
  mood.irritability = decayToward(mood.irritability, target.irritability, Math.min(0.7, rate));
  mood.socialOpenness = decayToward(mood.socialOpenness, target.socialOpenness, Math.min(0.65, rate));
  mood.updatedAt = now;
  return mood;
}

export function moodLabel(mood) {
  if (mood.tension > 0.62 || mood.irritability > 0.68) return '有点烦躁';
  if (mood.valence < -0.3) return '低落';
  if (mood.energy < 0.3) return '很累';
  if (mood.socialOpenness < 0.3) return '想一个人待着';
  if (mood.valence > 0.3 && mood.energy > 0.6) return '轻松';
  if (mood.valence < -0.1) return '不太提得起劲';
  return '平静';
}

export function moodGuidance(mood) {
  if (mood.tension > 0.62 || mood.irritability > 0.68) return '你耐心不高，句子可以短一点；不要主动开很长的话题，但别迁怒无关的人。';
  if (mood.valence < -0.3) return '你有点低落，不太想解释自己；如果对方认真问，可以简短说两句。';
  if (mood.energy < 0.3) return '你很累，回复慢半拍、短一点；能少说就少说。';
  if (mood.socialOpenness < 0.3) return '你想独处，不想主动找人说话；对熟人可以留一点余地。';
  if (mood.valence > 0.3 && mood.energy > 0.6) return '你现在比较放松，可以多接一句、偶尔开个玩笑。';
  return '你状态一般，正常说话就好。';
}

function addFactor(mood, text, delta, now) {
  mood.factors.push({ at: now, text: String(text || '').slice(0, 120), delta: delta || {} });
  mood.factors = mood.factors.slice(-12);
}

export function applyWorldMood(mood, events = [], now = Date.now()) {
  const applied = new Set(mood.appliedEventIds || []);
  for (const event of events) {
    if (!event?.id || applied.has(event.id)) continue;
    const raw = Number(event.effects?.moodDelta) || 0;
    if (!raw) { applied.add(event.id); continue; }
    const delta = clamp(raw / 12, -0.35, 0.35);
    mood.valence = clamp(mood.valence + delta, -1, 1);
    if (raw < 0) mood.tension = clamp(mood.tension + Math.abs(delta) * 0.7, 0, 1);
    addFactor(mood, event.headline || '城市事件', { valence: delta }, now);
    applied.add(event.id);
  }
  mood.appliedEventIds = [...applied].slice(-300);
  mood.updatedAt = now;
  return mood;
}

const POSITIVE_RE = /谢谢|辛苦了|晚安|好梦|想你|陪你|好看|喜欢|开心|顺利|抱抱|别累着|注意休息/;
const NEGATIVE_RE = /滚|闭嘴|烦死|讨厌|傻逼|蠢|废物|别来烦|生气|恶心/;

/** 对话后的轻量心情微调：只做很小的偏移，不做关系判断。 */
export function applyConversationMood(mood, messageText, now = Date.now()) {
  const text = String(messageText || '').trim();
  if (!text) return mood;
  if (now - Number(mood.lastMessageAt || 0) < 2 * 60 * 1000) return mood;
  let delta = 0;
  let factor = '';
  if (NEGATIVE_RE.test(text)) {
    delta = -0.06;
    mood.tension = clamp(mood.tension + 0.06, 0, 1);
    mood.irritability = clamp(mood.irritability + 0.04, 0, 1);
    factor = '有人说了不太好听的话';
  } else if (POSITIVE_RE.test(text)) {
    delta = 0.04;
    mood.socialOpenness = clamp(mood.socialOpenness + 0.03, 0, 1);
    factor = '有人说了让你舒服一点的话';
  }
  if (delta) {
    mood.valence = clamp(mood.valence + delta, -1, 1);
    addFactor(mood, factor, { valence: delta }, now);
    mood.updatedAt = now;
  }
  mood.lastMessageAt = now;
  return mood;
}

export function formatMoodPrompt(mood) {
  if (!mood) return '';
  const label = moodLabel(mood);
  const factors = (mood.factors || []).slice(-3).reverse().map((f) => f.text).filter(Boolean);
  const lines = [
    `【你现在的状态】${label}。`,
    factors.length ? `影响你的事：${[...new Set(factors)].join('；')}。` : '',
    `倾向：${moodGuidance(mood)}`,
    '这只是你此刻的情绪，不要主动解释“心情值”，也不要让它覆盖你的判断和边界。'
  ];
  return lines.filter(Boolean).join('\n');
}
