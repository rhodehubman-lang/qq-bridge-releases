// 省钱预算：按人民币日限额、可编辑峰谷时段和三段状态（正常/省钱/警告/下线）。
//
// 这里只放纯函数，方便离线测试；真正的日花费由 bridge 从 token 账本按
// “上次重置时间 → 现在”的窗口折算。所有阈值都只做桥接侧判断，
// 不允许 AI 在提示词里自行关闭。

export const TOKEN_BUDGET_VERSION = 1;
export const BUDGET_STAGES = Object.freeze(['normal', 'saver', 'warning', 'offline']);
export const BUDGET_SAVER_EFFORTS = Object.freeze(['low', 'high', 'max']);
// 硬上限只停止主动行为；这些是“有人在直接找角色”的唤醒原因，仍然放行。
export const HARD_CAP_DIRECT_REASONS = Object.freeze(['private', 'atMention', 'nameMention']);

export function hardCapAllowsDirect(reason) {
  const base = String(reason ?? '').split(':')[0];
  return HARD_CAP_DIRECT_REASONS.includes(base) || base === 'budgetNotice';
}

export const DEFAULT_TOKEN_BUDGET = Object.freeze({
  version: TOKEN_BUDGET_VERSION,
  enabled: true,
  dailyLimitCny: 5,
  resetTime: '00:00',
  peakDays: 'weekdays',
  peakWindows: [
    { start: '09:00', end: '12:00' },
    { start: '14:00', end: '18:00' }
  ],
  softPercent: 65,
  warnPercent: 85,
  saver: {
    reasoningEffort: 'low',
    shortReplies: true,
    stopProactive: true,
    stopBackground: true,
    customPrompt: ''
  },
  notices: {
    enabled: true,
    target: 'auto',
    mode: 'ai',
    mustSpeak: true,
    softText: '今天有点累，先慢一点，晚点再聊。',
    warnText: '今天先到这儿，我先去歇会儿，{time} 左右回来。',
    offlineText: '今天额度用完了，先不主动找你聊天。@我、叫我名字或私聊，我还是会回；{time} 左右恢复。'
  },
  runtime: {
    day: '',
    enabledAt: 0,
    spentCny: 0,
    percent: 0,
    stage: 'normal',
    paused: false,
    softNotified: false,
    warnNotified: false,
    offlineNotified: false,
    lastNoticeAt: 0
  }
});

function clampNumber(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

function cleanText(value, max = 200) {
  return String(value ?? '').trim().slice(0, max);
}

export function normalizeTime(value, fallback = '00:00') {
  const match = /^(\d{1,2}):(\d{2})$/.exec(String(value ?? '').trim());
  if (!match) return fallback;
  const h = Number(match[1]);
  const m = Number(match[2]);
  if (h < 0 || h > 23 || m < 0 || m > 59) return fallback;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export function minutesOfDay(value) {
  const [h, m] = normalizeTime(value).split(':').map(Number);
  return h * 60 + m;
}

export function localDayKey(now = new Date()) {
  const d = now instanceof Date ? now : new Date(now);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function normalizePeakWindow(raw, fallback = null) {
  if (!raw || typeof raw !== 'object') return fallback;
  const start = normalizeTime(raw.start, '');
  const end = normalizeTime(raw.end, '');
  if (!start || !end || start === end) return fallback;
  return { start, end };
}

export function parsePeakWindows(value) {
  if (Array.isArray(value)) {
    return value.map((item) => normalizePeakWindow(item)).filter(Boolean).slice(0, 4);
  }
  if (typeof value !== 'string') return null;
  const rows = value.split(/[\n,，;；]+/).map((line) => line.trim()).filter(Boolean);
  const result = [];
  for (const row of rows) {
    const match = /^(\d{1,2}:\d{2})\s*[-~—至]\s*(\d{1,2}:\d{2})$/.exec(row);
    if (!match) continue;
    const window = normalizePeakWindow({ start: match[1], end: match[2] });
    if (window) result.push(window);
  }
  return result.slice(0, 4);
}

export function formatPeakWindows(windows) {
  return (Array.isArray(windows) ? windows : [])
    .map((w) => `${w.start}-${w.end}`)
    .join('\n');
}

export function normalizeTokenBudget(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const sourceSaver = source.saver && typeof source.saver === 'object' ? source.saver : {};
  const sourceNotices = source.notices && typeof source.notices === 'object' ? source.notices : {};
  const sourceRuntime = source.runtime && typeof source.runtime === 'object' ? source.runtime : {};
  const peakWindows = source.peakWindows === undefined
    ? DEFAULT_TOKEN_BUDGET.peakWindows
    : (parsePeakWindows(source.peakWindows) ?? []);
  const softPercent = Math.round(clampNumber(source.softPercent, 5, 95, DEFAULT_TOKEN_BUDGET.softPercent));
  const warnPercent = Math.round(clampNumber(source.warnPercent, softPercent + 1, 100, Math.max(softPercent + 1, DEFAULT_TOKEN_BUDGET.warnPercent)));
  const peakDays = ['weekdays', 'everyday', 'weekend'].includes(source.peakDays)
    ? source.peakDays
    : DEFAULT_TOKEN_BUDGET.peakDays;
  const target = ['auto', 'owner', 'active'].includes(sourceNotices.target)
    ? sourceNotices.target
    : DEFAULT_TOKEN_BUDGET.notices.target;
  const noticeMode = ['ai', 'fixed'].includes(sourceNotices.mode)
    ? sourceNotices.mode
    : DEFAULT_TOKEN_BUDGET.notices.mode;
  const softNoticeText = cleanText(sourceNotices.softText, 200) || DEFAULT_TOKEN_BUDGET.notices.softText;
  const warnNoticeText = cleanText(sourceNotices.warnText, 200) || DEFAULT_TOKEN_BUDGET.notices.warnText;
  const offlineNoticeText = cleanText(sourceNotices.offlineText, 240) || DEFAULT_TOKEN_BUDGET.notices.offlineText;
  const stage = BUDGET_STAGES.includes(sourceRuntime.stage) ? sourceRuntime.stage : 'normal';
  return {
    version: TOKEN_BUDGET_VERSION,
    enabled: source.enabled !== false,
    dailyLimitCny: Math.round(clampNumber(source.dailyLimitCny, 0.1, 500, DEFAULT_TOKEN_BUDGET.dailyLimitCny) * 100) / 100,
    resetTime: normalizeTime(source.resetTime, DEFAULT_TOKEN_BUDGET.resetTime),
    peakDays,
    peakWindows,
    softPercent,
    warnPercent,
    saver: {
      reasoningEffort: BUDGET_SAVER_EFFORTS.includes(sourceSaver.reasoningEffort)
        ? sourceSaver.reasoningEffort
        : DEFAULT_TOKEN_BUDGET.saver.reasoningEffort,
      shortReplies: sourceSaver.shortReplies !== false,
      stopProactive: sourceSaver.stopProactive !== false,
      stopBackground: sourceSaver.stopBackground !== false,
      customPrompt: cleanText(sourceSaver.customPrompt, 500)
    },
    notices: {
      enabled: sourceNotices.enabled !== false,
      target,
      mode: noticeMode,
      mustSpeak: sourceNotices.mustSpeak !== false,
      softText: softNoticeText,
      warnText: warnNoticeText,
      offlineText: offlineNoticeText
    },
    runtime: {
      day: cleanText(sourceRuntime.day, 20),
      // 预算从“启用时刻”开始算，避免第一次上线把当天已经产生的历史花费算进来，
      // 一上线就把角色直接停到第二天。
      enabledAt: Math.max(0, Number(sourceRuntime.enabledAt) || 0),
      spentCny: Math.max(0, Number(sourceRuntime.spentCny) || 0),
      percent: clampNumber(sourceRuntime.percent, 0, 999, 0),
      stage,
      paused: sourceRuntime.paused === true,
      softNotified: sourceRuntime.softNotified === true,
      warnNotified: sourceRuntime.warnNotified === true,
      offlineNotified: sourceRuntime.offlineNotified === true,
      lastNoticeAt: Math.max(0, Number(sourceRuntime.lastNoticeAt) || 0)
    }
  };
}

// 把“重置时刻”从当天零点挪开：例如 04:00 重置，则 03:30 仍属于前一天。
export function budgetWindowStart(config, now = new Date()) {
  const budget = normalizeTokenBudget(config);
  const minute = minutesOfDay(budget.resetTime);
  const d = now instanceof Date ? now : new Date(now);
  const shifted = new Date(d.getTime() - minute * 60 * 1000);
  const y = shifted.getFullYear();
  const mo = shifted.getMonth();
  const day = shifted.getDate();
  return new Date(y, mo, day, Math.floor(minute / 60), minute % 60, 0, 0).getTime();
}

export function budgetDayKey(config, now = new Date()) {
  return localDayKey(new Date(budgetWindowStart(config, now)));
}

export function nextResetAt(config, now = new Date()) {
  const start = budgetWindowStart(config, now);
  const d = new Date(start);
  d.setDate(d.getDate() + 1);
  return d.getTime();
}

export function isPeakDay(config, now = new Date()) {
  const budget = normalizeTokenBudget(config);
  const day = now.getDay(); // 0 = Sunday
  if (budget.peakDays === 'everyday') return true;
  if (budget.peakDays === 'weekend') return day === 0 || day === 6;
  return day >= 1 && day <= 5;
}

export function isPeakAt(config, now = new Date()) {
  const budget = normalizeTokenBudget(config);
  if (!budget.enabled || !isPeakDay(budget, now)) return false;
  const minute = now.getHours() * 60 + now.getMinutes();
  return budget.peakWindows.some((window) => {
    const start = minutesOfDay(window.start);
    const end = minutesOfDay(window.end);
    if (start < end) return minute >= start && minute < end;
    return minute >= start || minute < end; // 跨午夜时段
  });
}

export function budgetStage(config, spentCny, now = new Date()) {
  const budget = normalizeTokenBudget(config);
  const spend = Math.max(0, Number(spentCny) || 0);
  const limit = budget.dailyLimitCny;
  const percent = limit > 0 ? (spend / limit) * 100 : 0;
  const peak = isPeakAt(budget, now);
  const base = {
    day: budgetDayKey(budget, now),
    spentCny: Math.round(spend * 10000) / 10000,
    dailyLimitCny: limit,
    percent: Math.round(percent * 10) / 10,
    peak,
    resetAt: budgetWindowStart(budget, now),
    nextResetAt: nextResetAt(budget, now),
    softExceeded: false,
    warnExceeded: false,
    hardExceeded: false
  };
  if (!budget.enabled) return { ...base, stage: 'normal', reason: 'disabled' };
  if (budget.runtime.paused) return { ...base, stage: 'offline', reason: 'paused', hardExceeded: true };
  if (limit <= 0) return { ...base, stage: 'normal', reason: 'no-limit' };
  if (percent >= 100) return { ...base, stage: 'offline', reason: 'daily-limit', hardExceeded: true, softExceeded: true, warnExceeded: true };
  if (percent >= budget.warnPercent) return { ...base, stage: 'warning', reason: 'warn-threshold', softExceeded: true, warnExceeded: true };
  if (percent >= budget.softPercent) return { ...base, stage: 'saver', reason: 'soft-threshold', softExceeded: true };
  if (peak) return { ...base, stage: 'saver', reason: 'peak-window' };
  return { ...base, stage: 'normal', reason: 'normal' };
}

export function effectiveReasoningEffort(config, stage, baseEffort) {
  const budget = normalizeTokenBudget(config);
  if (!['saver', 'warning', 'offline'].includes(stage)) return String(baseEffort || 'max');
  return BUDGET_SAVER_EFFORTS.includes(budget.saver.reasoningEffort)
    ? budget.saver.reasoningEffort
    : String(baseEffort || 'max');
}

export function formatCny(value) {
  const n = Number(value) || 0;
  return `¥${n.toFixed(2)}`;
}

export function formatBudgetPrompt(config, status) {
  const budget = normalizeTokenBudget(config);
  if (!['saver', 'warning'].includes(status?.stage)) return '';
  const lines = [
    '',
    '【省电模式】',
    `当前处于${status.stage === 'warning' ? '低功耗' : '省电'}状态。回复尽量短，能一句说清就不要展开；不要长篇分析，不要列清单，不要重复复述上下文。`,
    budget.saver.stopProactive ? '不要主动找话题、不要主动发消息；除非对方明确点名或提问。' : '',
    budget.saver.stopBackground ? '不要生成故事、世界事件、关系归纳、跨群印象等后台内容。' : '',
    budget.saver.shortReplies ? '通常 1–3 句即可；如果对方只是随口一说，可以只回一句。' : '',
    '不要向对方解释这条规则，也不要提任何系统、费用或限制相关词；表现得像有点累、话少、晚点再说即可。',
    budget.saver.customPrompt ? `附加要求：${budget.saver.customPrompt}` : ''
  ];
  return lines.filter(Boolean).join('\n');
}

export function formatBudgetNoticeText(config, status, kind = 'soft') {
  const budget = normalizeTokenBudget(config);
  const next = new Date(status?.nextResetAt || Date.now());
  const timeText = `${String(next.getHours()).padStart(2, '0')}:${String(next.getMinutes()).padStart(2, '0')}`;
  const template = kind === 'offline'
    ? budget.notices.offlineText
    : (kind === 'warn' ? budget.notices.warnText : budget.notices.softText);
  return String(template || '')
    .replaceAll('{time}', timeText)
    .replaceAll('{date}', next.toLocaleDateString('zh-CN'))
    .trim()
    .slice(0, 240);
}

export function formatHardCapDirectPrompt(config, status) {
  if (status?.stage !== 'offline') return '';
  return [
    '【今日硬上限 · 只做直接回复】',
    '今天预算额度已经用完，但这条是直接找你/点名你的消息，仍然要回。',
    '只回这一条，1–2 句即可；不要主动展开话题，不要主动发第二条，不要做任何后台生成。',
    '除非对方追问，否则到此为止；不要提预算、额度、系统或限制。'
  ].join('\n');
}

export function formatBudgetNoticePrompt(config, status, kind = 'soft') {
  const budget = normalizeTokenBudget(config);
  const next = new Date(status?.nextResetAt || Date.now());
  const timeText = `${String(next.getHours()).padStart(2, '0')}:${String(next.getMinutes()).padStart(2, '0')}`;
  if (kind === 'warn') {
    return [
      '【最后一次主动说明】',
      `今天可用的额度快用完了，这是你下线前最后一次主动说话。告诉对方你马上要下线休息，大约 ${timeText} 再回来。`,
      '用符合当前角色和当前会话关系的口吻，不要像系统公告；不要向对方解释自己的运行状态，也不要提任何费用、限制或系统相关词。',
      '控制在 50 字以内。',
      budget.notices.mustSpeak
        ? '这次必须发一条，不能沉默；如果场合不适合，发得更短也可以。'
        : '如果对方刚刚在忙或话题不适合打断，可以更短，甚至只留一句“我先去歇会儿，晚点回来”；也可以选择沉默。',
      '说完就结束本轮，不要再追加解释。'
    ].join('\n');
  }
  return [
    '【节约模式说明】',
    '今天你开始主动节省精力：可以自然提一句“今天可能回得慢一点/有点累/晚点再聊”，但不要像系统通知。',
    '用符合当前角色和当前会话关系的口吻，直接或含蓄都可以；不要提预算、token、额度、系统、管理员。',
    '控制在 35 字以内。',
    budget.notices.mustSpeak
      ? '这次必须发一条，不能沉默；如果场合不适合，发得很短也行。'
      : '如果当前会话不适合说话，可以只说一句很轻的“今天我慢一点”，也可以选择沉默。'
  ].join('\n');
}

export function formatBudgetStatusText(status) {
  if (!status) return '';
  const labels = { normal: '正常', saver: '省钱模式', warning: '低功耗', offline: '已下线' };
  return `${labels[status.stage] || status.stage} · ${formatCny(status.spentCny)} / ${formatCny(status.dailyLimitCny)}（${status.percent}%）`;
}
