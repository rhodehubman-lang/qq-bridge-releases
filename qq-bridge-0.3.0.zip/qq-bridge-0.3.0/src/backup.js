// 备份与恢复：只复制用户数据，不碰 node_modules / 日志 / 备份目录本身。
// 设计目标：
// - 备份目录默认放在项目外，避免更新器把它当代码覆盖；
// - 每次备份带 manifest，恢复前先给当前数据再做一份 pre-restore 备份；
// - 只处理固定的用户数据路径，不递归复制整个项目；
// - 不依赖 zip / 7z / tar，Node 自带 fs.cp 即可跨 Windows/Linux。

import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

export const BACKUP_VERSION = 1;
export const BACKUP_SETTINGS_VERSION = 1;

export const DEFAULT_BACKUP_SETTINGS = Object.freeze({
  version: BACKUP_SETTINGS_VERSION,
  enabled: true,
  autoDaily: true,
  keep: 7,
  backupRoot: '',
  lastBackupAt: 0,
  lastBackupPath: ''
});

export const BACKUP_ITEMS = Object.freeze([
  { path: 'config.json', type: 'file', required: false },
  { path: 'state', type: 'dir', required: false },
  { path: 'roles', type: 'dir', required: false },
  { path: 'life-profiles', type: 'dir', required: false },
  { path: 'osts', type: 'dir', required: false },
  { path: 'audio', type: 'dir', required: false }
]);

function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, Math.trunc(n)));
}

function asText(value, max = 200) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function pathInside(child, parent) {
  const c = path.resolve(child);
  const p = path.resolve(parent);
  return c === p || c.startsWith(p.endsWith(path.sep) ? p : `${p}${path.sep}`);
}

export function normalizeBackupSettings(raw) {
  const src = raw && typeof raw === 'object' ? raw : {};
  return {
    version: BACKUP_SETTINGS_VERSION,
    enabled: src.enabled !== false,
    autoDaily: src.autoDaily !== false,
    keep: clampInt(src.keep, 1, 60, DEFAULT_BACKUP_SETTINGS.keep),
    backupRoot: asText(src.backupRoot, 500),
    lastBackupAt: Math.max(0, Number(src.lastBackupAt) || 0),
    lastBackupPath: asText(src.lastBackupPath, 1000)
  };
}

export function backupSettingsFile(projectRoot) {
  return path.join(projectRoot, 'state', 'backup.json');
}

export function readBackupSettings(projectRoot) {
  const file = backupSettingsFile(projectRoot);
  try {
    return normalizeBackupSettings(JSON.parse(fs.readFileSync(file, 'utf8')));
  } catch {
    return normalizeBackupSettings({});
  }
}

export function writeBackupSettings(projectRoot, settings) {
  const file = backupSettingsFile(projectRoot);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const normalized = normalizeBackupSettings(settings);
  fs.writeFileSync(file, `${JSON.stringify(normalized, null, 2)}\n`, 'utf8');
  return normalized;
}

export function resolveBackupRoot(projectRoot, settings = {}) {
  const cfg = normalizeBackupSettings(settings);
  const root = cfg.backupRoot
    ? path.resolve(projectRoot, cfg.backupRoot)
    : path.join(path.dirname(path.resolve(projectRoot)), '_backups', 'qq-bridge');
  if (pathInside(root, projectRoot)) {
    throw new Error('备份目录不能放在项目目录内，否则会被更新/打包一起处理');
  }
  return root;
}

export function timestampKey(date = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}${p(date.getMonth() + 1)}${p(date.getDate())}-${p(date.getHours())}${p(date.getMinutes())}${p(date.getSeconds())}`;
}

function backupName(date = new Date(), label = 'manual') {
  return `qq-bridge-${timestampKey(date)}-${asText(label, 40).replace(/[^a-zA-Z0-9\u4e00-\u9fa5_-]+/g, '-') || 'manual'}`;
}

async function walkStats(target) {
  let bytes = 0;
  let files = 0;
  async function walk(p) {
    const stat = await fsp.lstat(p);
    if (stat.isDirectory()) {
      const entries = await fsp.readdir(p);
      for (const entry of entries) await walk(path.join(p, entry));
      return;
    }
    if (stat.isFile()) {
      bytes += stat.size;
      files += 1;
    }
  }
  await walk(target);
  return { bytes, files };
}

export async function listBackups(projectRoot, settings = {}) {
  const cfg = normalizeBackupSettings(settings);
  const root = resolveBackupRoot(projectRoot, cfg);
  let entries = [];
  try {
    entries = await fsp.readdir(root, { withFileTypes: true });
  } catch {
    return [];
  }
  const out = [];
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const dir = path.join(root, entry.name);
    try {
      const manifest = JSON.parse(await fsp.readFile(path.join(dir, 'manifest.json'), 'utf8'));
      if (manifest?.version !== BACKUP_VERSION) continue;
      out.push({
        name: entry.name,
        path: dir,
        createdAt: manifest.createdAt,
        createdAtMs: Number(manifest.createdAtMs) || 0,
        label: asText(manifest.label, 40),
        bytes: Number(manifest.stats?.bytes) || 0,
        files: Number(manifest.stats?.files) || 0
      });
    } catch {
      // 没有 manifest 的目录不认，避免误删用户自己放的东西。
    }
  }
  out.sort((a, b) => b.createdAtMs - a.createdAtMs);
  return out;
}

export async function pruneBackups(projectRoot, settings = {}) {
  const cfg = normalizeBackupSettings(settings);
  const list = await listBackups(projectRoot, cfg);
  const stale = list.slice(Math.max(0, cfg.keep));
  for (const item of stale) {
    await fsp.rm(item.path, { recursive: true, force: true });
  }
  return { removed: stale.map((x) => x.name), kept: Math.min(list.length, cfg.keep) };
}

export async function createBackup(projectRoot, { label = 'manual', settings = null, prune = true } = {}) {
  const root = path.resolve(projectRoot);
  const cfg = normalizeBackupSettings(settings ?? readBackupSettings(root));
  if (!cfg.enabled) throw new Error('自动备份已关闭');
  const backupRoot = resolveBackupRoot(root, cfg);
  await fsp.mkdir(backupRoot, { recursive: true });
  const name = backupName(new Date(), label);
  const dest = path.join(backupRoot, name);
  if (fs.existsSync(dest)) throw new Error(`备份目录已存在：${dest}`);
  await fsp.mkdir(dest, { recursive: true });

  const items = [];
  try {
    for (const item of BACKUP_ITEMS) {
      const src = path.join(root, item.path);
      if (!fs.existsSync(src)) {
        items.push({ path: item.path, type: item.type, exists: false, bytes: 0, files: 0 });
        continue;
      }
      const target = path.join(dest, item.path);
      await fsp.mkdir(path.dirname(target), { recursive: true });
      await fsp.cp(src, target, {
        recursive: item.type === 'dir',
        force: false,
        errorOnExist: true,
        preserveTimestamps: true,
        dereference: false
      });
      const stat = await walkStats(target);
      items.push({ path: item.path, type: item.type, exists: true, bytes: stat.bytes, files: stat.files });
    }

    const stats = items.reduce((acc, item) => ({
      bytes: acc.bytes + item.bytes,
      files: acc.files + item.files
    }), { bytes: 0, files: 0 });
    const manifest = {
      version: BACKUP_VERSION,
      createdAt: new Date().toISOString(),
      createdAtMs: Date.now(),
      label: asText(label, 40),
      hostname: os.hostname(),
      items,
      stats
    };
    await fsp.writeFile(path.join(dest, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
    const next = writeBackupSettings(root, {
      ...cfg,
      lastBackupAt: manifest.createdAtMs,
      lastBackupPath: dest
    });
    const pruned = prune ? await pruneBackups(root, next) : { removed: [], kept: 0 };
    return { ok: true, name, path: dest, manifest, pruned, settings: next };
  } catch (error) {
    // 半成品备份不留在列表里，避免恢复时选中不完整目录。
    await fsp.rm(dest, { recursive: true, force: true }).catch(() => {});
    throw error;
  }
}

export async function restoreBackup(projectRoot, backupDir, { confirm = '', settings = null } = {}) {
  if (String(confirm).trim() !== 'RESTORE') {
    throw new Error('恢复需要显式确认：--confirm RESTORE');
  }
  const root = path.resolve(projectRoot);
  const target = path.resolve(backupDir);
  const manifest = JSON.parse(await fsp.readFile(path.join(target, 'manifest.json'), 'utf8'));
  if (manifest?.version !== BACKUP_VERSION) throw new Error('备份 manifest 版本不匹配');

  // 恢复前先备份当前数据；失败会直接抛错，避免“恢复一半”。
  const emergency = await createBackup(root, {
    label: 'pre-restore',
    settings: settings ?? readBackupSettings(root),
    // 恢复前备份不能触发保留清理：否则可能把即将用于恢复的源备份删掉。
    prune: false
  });

  const restored = [];
  for (const item of Array.isArray(manifest.items) ? manifest.items : []) {
    if (!item?.path || !BACKUP_ITEMS.some((x) => x.path === item.path)) continue;
    const src = path.join(target, item.path);
    if (!item.exists || !fs.existsSync(src)) continue;
    const dst = path.join(root, item.path);
    await fsp.rm(dst, { recursive: true, force: true });
    await fsp.mkdir(path.dirname(dst), { recursive: true });
    await fsp.cp(src, dst, {
      recursive: item.type === 'dir',
      force: true,
      errorOnExist: false,
      preserveTimestamps: true,
      dereference: false
    });
    restored.push(item.path);
  }
  return { ok: true, restored, emergencyBackup: emergency.path, manifest };
}

export function formatBytes(bytes) {
  const n = Math.max(0, Number(bytes) || 0);
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
}
