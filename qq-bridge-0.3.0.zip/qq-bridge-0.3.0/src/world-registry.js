// 世界注册表：世界与角色分离。
// registry.worlds: { worldId: { id, name, mode: 'solo'|'shared', members: [profileId], createdAt } }
// registry.characters: { profileId: worldId }

export const REGISTRY_VERSION = 1;

export function emptyRegistry() {
  return { version: REGISTRY_VERSION, worlds: {}, characters: {} };
}

function safeId(text) {
  return String(text ?? '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 64);
}

export function normalizeRegistry(raw) {
  const src = raw && typeof raw === 'object' ? raw : {};
  const out = emptyRegistry();
  if (src.worlds && typeof src.worlds === 'object') {
    for (const [id, value] of Object.entries(src.worlds)) {
      if (!value || typeof value !== 'object') continue;
      const worldId = safeId(value.id || id);
      if (!worldId) continue;
      out.worlds[worldId] = {
        id: worldId,
        name: String(value.name || worldId).slice(0, 80),
        mode: value.mode === 'shared' ? 'shared' : 'solo',
        members: Array.isArray(value.members) ? [...new Set(value.members.map((x) => String(x || '').trim()).filter(Boolean))] : [],
        createdAt: Number(value.createdAt) || Date.now()
      };
    }
  }
  if (src.characters && typeof src.characters === 'object') {
    for (const [charId, worldId] of Object.entries(src.characters)) {
      const cid = String(charId || '').trim();
      const wid = safeId(worldId);
      if (cid && wid) out.characters[cid] = wid;
    }
  }
  return out;
}

export function ensureProfileWorld(registry, profileId, { name = '', worldName = '' } = {}) {
  const cid = String(profileId || '').trim();
  if (!cid) return null;
  registry.characters = registry.characters || {};
  registry.worlds = registry.worlds || {};
  let worldId = registry.characters[cid];
  if (worldId && registry.worlds[worldId]) {
    const world = registry.worlds[worldId];
    if (!world.members.includes(cid)) world.members.push(cid);
    return world;
  }
  worldId = safeId(cid) || 'world';
  let world = registry.worlds[worldId];
  if (!world) {
    world = {
      id: worldId,
      name: String(worldName || name || cid).slice(0, 80),
      mode: 'solo',
      members: [cid],
      createdAt: Date.now()
    };
    registry.worlds[worldId] = world;
  } else if (!world.members.includes(cid)) {
    world.members.push(cid);
  }
  registry.characters[cid] = worldId;
  return world;
}

export function createWorld(registry, name) {
  const base = safeId(name) || 'world';
  let id = base;
  let n = 2;
  while (registry.worlds[id]) { id = `${base}-${n++}`; }
  const world = { id, name: String(name || id).slice(0, 80), mode: 'solo', members: [], createdAt: Date.now() };
  registry.worlds[id] = world;
  return world;
}

export function assignCharacter(registry, profileId, worldId) {
  const cid = String(profileId || '').trim();
  const wid = safeId(worldId);
  if (!cid || !wid || !registry.worlds[wid]) return false;
  const old = registry.characters[cid];
  if (old && registry.worlds[old]) {
    registry.worlds[old].members = registry.worlds[old].members.filter((x) => x !== cid);
  }
  registry.characters[cid] = wid;
  if (!registry.worlds[wid].members.includes(cid)) registry.worlds[wid].members.push(cid);
  return true;
}

export function worldByProfile(registry, profileId) {
  const wid = registry.characters?.[String(profileId || '').trim()];
  return wid ? registry.worlds?.[wid] || null : null;
}
