// 「抓睡觉」：主人在私聊说过晚安后，又在群里出现时，角色可以自然点一句。
// 这是个轻量的小惊喜，不是提醒系统；只看“说过晚安”这个事实，不读取/转述私聊正文。

export const SLEEP_CATCHER_VERSION = 1;

export const DEFAULT_SLEEP_CATCHER_SETTINGS = Object.freeze({
  enabled: true,
  goodnightMaxAgeMinutes: 360,
  reappearWindowMinutes: 15,
  cooldownMinutes: 120,
  intensity: 'light',
  ignoreCannotSleep: true,
  customHint: '',
  disabledGroups: []
});

const GOODNIGHT_RE = /晚安|睡了|去睡|先睡|睡觉|梦里见|好梦|困了|撑不住/;
const CANNOT_SLEEP_RE = /睡不着|失眠|睡不著|又醒了|刚醒|起夜|没睡|熬夜|加班|不困|睡不着觉/;

export function emptySleepCatcherState() {
  return {
    version: SLEEP_CATCHER_VERSION,
    settings: { ...DEFAULT_SLEEP_CATCHER_SETTINGS, disabledGroups: [] },
    updatedAt: 0
  };
}

function clampInt(value, min, max, fallback) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, Math.round(number)));
}

function cleanText(value, max = 200) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

export function normalizeSleepCatcherSettings(raw = {}) {
  const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const intensity = source.intensity === 'tease' ? 'tease' : 'light';
  const disabledGroups = Array.isArray(source.disabledGroups)
    ? [...new Set(source.disabledGroups.map((x) => String(x).trim()).filter((x) => /^\d{3,20}$/.test(x)))]
    : [];
  return {
    enabled: source.enabled !== false,
    goodnightMaxAgeMinutes: clampInt(source.goodnightMaxAgeMinutes, 10, 24 * 60, DEFAULT_SLEEP_CATCHER_SETTINGS.goodnightMaxAgeMinutes),
    reappearWindowMinutes: clampInt(source.reappearWindowMinutes, 1, 120, DEFAULT_SLEEP_CATCHER_SETTINGS.reappearWindowMinutes),
    cooldownMinutes: clampInt(source.cooldownMinutes, 0, 24 * 60, DEFAULT_SLEEP_CATCHER_SETTINGS.cooldownMinutes),
    intensity,
    ignoreCannotSleep: source.ignoreCannotSleep !== false,
    customHint: cleanText(source.customHint, 200),
    disabledGroups
  };
}

export function normalizeSleepCatcherState(raw = {}) {
  const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  return {
    version: SLEEP_CATCHER_VERSION,
    settings: normalizeSleepCatcherSettings(source.settings ?? source),
    updatedAt: Number(source.updatedAt) || 0
  };
}

export function detectGoodnight(text) {
  return GOODNIGHT_RE.test(String(text ?? ''));
}

export function detectCannotSleep(text) {
  return CANNOT_SLEEP_RE.test(String(text ?? ''));
}

function messageTime(message) {
  return Number(message?.time) || 0;
}

function messageOwnerId(message) {
  return String(message?.userId ?? message?.user_id ?? '');
}

export function findPrivateGoodnight(messages, { ownerQQ = '', now = Date.now(), maxAgeMs = 6 * 60 * 60 * 1000 } = {}) {
  const owner = String(ownerQQ ?? '').trim();
  if (!owner || !Array.isArray(messages)) return null;
  const cutoff = now - Math.max(0, Number(maxAgeMs) || 0);
  let found = null;
  for (const message of messages.slice(-80)) {
    if (!message || message.isSelf) continue;
    if (messageOwnerId(message) !== owner) continue;
    if (messageTime(message) < cutoff) continue;
    if (detectGoodnight(message.text || message.plain)) found = message;
  }
  return found;
}

export function findRecentOwnerMessage(messages, { ownerQQ = '', now = Date.now(), windowMs = 15 * 60 * 1000 } = {}) {
  const owner = String(ownerQQ ?? '').trim();
  if (!owner || !Array.isArray(messages)) return null;
  const cutoff = now - Math.max(0, Number(windowMs) || 0);
  return [...messages].reverse().find((message) => (
    message
    && !message.isSelf
    && messageOwnerId(message) === owner
    && messageTime(message) >= cutoff
  )) ?? null;
}

export function ownerRecentlyCannotSleep(messages, { ownerQQ = '', now = Date.now(), windowMs = 10 * 60 * 1000 } = {}) {
  const owner = String(ownerQQ ?? '').trim();
  if (!owner || !Array.isArray(messages)) return false;
  const cutoff = now - Math.max(0, Number(windowMs) || 0);
  return messages.slice(-12).some((message) => (
    message
    && !message.isSelf
    && messageOwnerId(message) === owner
    && messageTime(message) >= cutoff
    && detectCannotSleep(message.text || message.plain)
  ));
}

export function decideSleepCatch({
  settings,
  groupId = '',
  isOwner = false,
  ownerMessage = null,
  goodnight = null,
  cooldownAt = 0,
  now = Date.now(),
  ownerTexts = [],
  groupPolicyMode = 'normal'
} = {}) {
  const config = normalizeSleepCatcherSettings(settings);
  const id = String(groupId ?? '').trim();
  if (!config.enabled) return { wake: false, reason: 'disabled' };
  if (!isOwner) return { wake: false, reason: 'owner-only' };
  if (!/^\d{3,20}$/.test(id)) return { wake: false, reason: 'group-only' };
  if (config.disabledGroups.includes(id)) return { wake: false, reason: 'group-disabled' };
  if (groupPolicyMode === 'off') return { wake: false, reason: 'group-off' };
  if (!ownerMessage) return { wake: false, reason: 'owner-not-reappeared' };
  if (!goodnight) return { wake: false, reason: 'no-goodnight' };
  const cooldownMs = config.cooldownMinutes * 60 * 1000;
  if (cooldownAt && cooldownMs > 0 && now - Number(cooldownAt) < cooldownMs) {
    return { wake: false, reason: 'cooldown' };
  }
  if (config.ignoreCannotSleep) {
    const texts = [ownerMessage.text || ownerMessage.plain, ...(Array.isArray(ownerTexts) ? ownerTexts : [])];
    if (texts.some((text) => detectCannotSleep(text))) {
      return { wake: false, reason: 'cannot-sleep' };
    }
  }
  return {
    wake: true,
    reason: 'owner-after-goodnight',
    goodnightAt: messageTime(goodnight) || now,
    intensity: config.intensity
  };
}

export function formatSleepCatchPrompt(settings, { goodnightAt = 0, ownerLabel = '主人' } = {}) {
  const config = normalizeSleepCatcherSettings(settings);
  const time = goodnightAt
    ? new Date(goodnightAt).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
    : '';
  const when = time ? `（${time}）` : '';
  const base = config.intensity === 'tease'
    ? `你不久前在私聊里和${ownerLabel}道过晚安${when}。现在他又在这个群里出现；如果你觉得自然，可以明显调侃一句“不是说晚安了吗/怎么又出来了/抓到了”，但别刻薄，也不要公开或转述私聊内容。`
    : `你不久前在私聊里和${ownerLabel}道过晚安${when}。现在他又在这个群里出现；如果你觉得自然，可以像真人一样轻轻点一句“不是说晚安了吗/怎么又出来了”，不要提私聊内容，也不要每句都提。`;
  const hint = config.customHint ? `\n你额外希望的说法：${config.customHint}` : '';
  return `【跨会话近况】${base}${hint}\n`;
}

export function sleepCatcherSummary(settings) {
  const config = normalizeSleepCatcherSettings(settings);
  return {
    enabled: config.enabled,
    intensity: config.intensity,
    goodnightMaxAgeMinutes: config.goodnightMaxAgeMinutes,
    reappearWindowMinutes: config.reappearWindowMinutes,
    cooldownMinutes: config.cooldownMinutes,
    ignoreCannotSleep: config.ignoreCannotSleep,
    disabledGroups: config.disabledGroups
  };
}
