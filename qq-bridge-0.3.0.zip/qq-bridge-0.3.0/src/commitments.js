// 承诺记忆（第一层 + 第三层）
// 记录当前角色在群里/主人私聊里答应过的“稍后/下次/我帮你”类承诺，按角色 + 会话隔离。
// 既识别角色单方面说出的承诺，也识别“对方请求 + 角色明确答应”的对话级承诺。
// 不负责定时唤醒；到点主动跟进属于第二层，这里刻意不做。
//
// 设计原则：
// - 自动从发送内容和上一句对方消息里提取候选，宁可少记，不把客套话都记成欠条；
// - 同一角色、同一群、同一句话 10 分钟内去重；同一轮请求只记一条；
// - 默认 14 天过期，最多保留 200 条；
// - 提示词里只出现“你自己说过/答应过的话”，不出现系统/监控口吻。

import crypto from 'node:crypto';

export const COMMITMENTS_VERSION = 1;
export const COMMITMENT_MAX_ACTIVE = 200;
export const COMMITMENT_TTL_MS = 14 * 24 * 60 * 60 * 1000;
const DEDUPE_MS = 10 * 60 * 1000;
export const FOLLOW_UP_EXPIRE_MS = 48 * 60 * 60 * 1000;
export const FOLLOW_UP_STATUSES = ['none', 'waiting', 'pending_confirmation', 'queued', 'sent', 'skipped', 'expired'];
const FOLLOW_UP_STATUS_SET = new Set(FOLLOW_UP_STATUSES);
export const FOLLOW_UP_MODES = ['off', 'observe', 'auto'];
export const DEFAULT_FOLLOW_UP_SETTINGS = {
  quietHours: { start: '23:00', end: '08:00' },
  globalMaxPerDay: 3
};

export function emptyCommitmentState() {
  return {
    version: COMMITMENTS_VERSION,
    characters: {},
    followUpSettings: normalizeFollowUpSettings(),
    followUpRules: {}
  };
}

function text(value, max = 300) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function clampCount(value, max = 1000) {
  return Math.max(0, Math.min(max, Math.floor(Number(value) || 0)));
}

function dueHintOf(sentence) {
  if (/明天/.test(sentence)) return '明天';
  if (/后天/.test(sentence)) return '后天';
  if (/下次|改天/.test(sentence)) return '下次';
  if (/马上|这就|立刻|现在|稍等|等我/.test(sentence)) return '马上';
  if (/等会|等会儿|待会|待会儿|一会儿|晚点|回头/.test(sentence)) return '稍后';
  return '';
}

// 对话级承诺：对方提出请求（“明天提醒我”），角色明确答应（“会的”）。
// 这类承诺不是角色单方面说出来的，不能再用 detectPromiseCandidates 从角色文本里抓。
const OWNER_REQUEST_RE = /(提醒我|叫我|喊我|帮我|替我|给我|告诉我|发我|带我|记得.{0,16}(?:提醒|叫|帮|告诉|发|带|买|查|问|处理)|别忘了.{0,16}(?:提醒|叫|帮|告诉|发|带|买|查|问|处理))/;
const AGREEMENT_RE = /^(好的?|好嘞|行吧?|可以|会的?|会|记得|收到|没问题|当然|放心吧|交给我|嗯|成|ok)/i;
const REFUSAL_RE = /(不行|不要|没空|忘了|不记得|不可能|再说吧|拒绝|做不到|不想)/;

export function detectOwnerRequest(content) {
  const raw = text(content, 300);
  if (!raw || raw.length < 4) return null;
  // “我明天提醒你”是对方在承诺，不是请求；不要把方向反过来。
  if (/^我(?:会|来|去|给|帮|提醒|叫|带|买|查|问|记得|忘)/.test(raw)) return null;
  const specific = OWNER_REQUEST_RE.test(raw);
  const genericRemember = /(记得|别忘了)/.test(raw) && !/^我(?:已经|也|不|会|来|去)/.test(raw);
  if (!specific && !genericRemember) return null;
  return {
    text: text(raw, 160),
    dueHint: dueHintOf(raw),
    confidence: specific ? 0.85 : 0.7,
    specific
  };
}

export function detectAgreement(content) {
  const raw = text(content, 160);
  if (!raw) return false;
  if (REFUSAL_RE.test(raw)) return false;
  return AGREEMENT_RE.test(raw);
}

export function detectExchangeCommitmentCandidates({ ownerText = '', jillText = '' } = {}) {
  const own = detectPromiseCandidates(jillText).map((item) => ({ ...item, sourceType: 'self-promise' }));
  const request = detectOwnerRequest(ownerText);
  if (!request || request.specific === false || !detectAgreement(jillText)) return own;
  const requestText = text(request.text, 160);
  if (own.some((item) => item.text === requestText)) return own;
  // 一次“请求 + 答应”只记一条，避免同一轮对话又记成角色自己的另一条承诺。
  return [{
    text: requestText,
    dueHint: request.dueHint || dueHintOf(jillText),
    confidence: 0.9,
    sourceType: 'owner-request',
    requestText,
    agreementText: text(jillText, 160)
  }];
}

function normalizeClock(value, fallback) {
  const match = String(value ?? '').trim().match(/^(\d{1,2}):(\d{1,2})$/);
  if (!match) return fallback;
  const hour = Math.min(23, Math.max(0, Number(match[1]) || 0));
  const minute = Math.min(59, Math.max(0, Number(match[2]) || 0));
  return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
}

export function normalizeFollowUpSettings(raw) {
  const src = raw && typeof raw === 'object' ? raw : {};
  const quiet = src.quietHours && typeof src.quietHours === 'object' ? src.quietHours : {};
  return {
    quietHours: {
      start: normalizeClock(quiet.start, DEFAULT_FOLLOW_UP_SETTINGS.quietHours.start),
      end: normalizeClock(quiet.end, DEFAULT_FOLLOW_UP_SETTINGS.quietHours.end)
    },
    globalMaxPerDay: Math.max(1, Math.min(10, Math.floor(Number(src.globalMaxPerDay) || DEFAULT_FOLLOW_UP_SETTINGS.globalMaxPerDay)))
  };
}

function normalizeFollowUpMode(value) {
  return FOLLOW_UP_MODES.includes(value) ? value : 'off';
}

function validScopeKey(scopeKey) {
  return /^(group:\d{3,20}|private:\d{3,20})$/.test(String(scopeKey ?? '').trim());
}

export function normalizeFollowUpRules(raw) {
  const src = raw && typeof raw === 'object' ? raw : {};
  const out = {};
  for (const [characterId, rule] of Object.entries(src)) {
    if (!/^[A-Za-z0-9_\-\u4e00-\u9fa5]{1,40}$/.test(characterId)) continue;
    if (!rule || typeof rule !== 'object') continue;
    const scopes = {};
    for (const [scopeKey, entry] of Object.entries(rule.scopes || {})) {
      if (!validScopeKey(scopeKey) || !entry || typeof entry !== 'object') continue;
      scopes[scopeKey] = {
        mode: normalizeFollowUpMode(entry.mode),
        maxPerDay: Math.max(1, Math.min(10, Math.floor(Number(entry.maxPerDay) || 1)))
      };
    }
    out[characterId] = { defaultMode: 'off', scopes };
  }
  return out;
}

export function followUpRuleFor(state, { characterId, scopeKey = '' } = {}) {
  const key = String(scopeKey ?? '').trim();
  const characterRules = state?.followUpRules?.[characterId];
  const explicit = characterRules?.scopes?.[key];
  if (explicit) return { mode: explicit.mode, maxPerDay: Math.max(1, Number(explicit.maxPerDay) || 1) };
  return { mode: characterRules?.defaultMode || 'off', maxPerDay: 1 };
}

export function setFollowUpRule(state, { characterId, scopeKey = '', mode = 'off', maxPerDay = 1 } = {}) {
  if (!state || !characterId || !validScopeKey(scopeKey)) return false;
  const nextMode = normalizeFollowUpMode(mode);
  state.followUpRules = state.followUpRules && typeof state.followUpRules === 'object' ? state.followUpRules : {};
  state.followUpRules[characterId] = state.followUpRules[characterId] && typeof state.followUpRules[characterId] === 'object'
    ? state.followUpRules[characterId]
    : { defaultMode: 'off', scopes: {} };
  state.followUpRules[characterId].scopes = state.followUpRules[characterId].scopes || {};
  state.followUpRules[characterId].scopes[String(scopeKey).trim()] = {
    mode: nextMode,
    maxPerDay: Math.max(1, Math.min(10, Math.floor(Number(maxPerDay) || 1)))
  };
  return true;
}

export function isQuietHours(settings, now = Date.now()) {
  const normalized = normalizeFollowUpSettings(settings);
  const minutes = (clock) => {
    const [hour, minute] = String(clock).split(':').map(Number);
    return hour * 60 + minute;
  };
  const start = minutes(normalized.quietHours.start);
  const end = minutes(normalized.quietHours.end);
  if (start === end) return false;
  const current = new Date(now).getHours() * 60 + new Date(now).getMinutes();
  return start < end ? (current >= start && current < end) : (current >= start || current < end);
}

export function countFollowUpsToday(state, { characterId, scopeKey = '', now = Date.now() } = {}) {
  const start = new Date(now);
  start.setHours(0, 0, 0, 0);
  return commitmentsForCharacter(state, characterId).filter((item) => {
    if (!['queued', 'sent'].includes(item.followUpStatus)) return false;
    if (Number(item.followUpSentAt || item.followUpReadyAt || 0) < start.getTime()) return false;
    return !scopeKey || commitmentScopeKey(item) === String(scopeKey);
  }).length;
}

export function canAutoFollowUp(state, { characterId, item, now = Date.now() } = {}) {
  if (!state || !characterId || !item) return { ok: false, reason: 'missing' };
  if (item.status !== 'pending' || item.followUpStatus !== 'pending_confirmation') return { ok: false, reason: 'not-ready' };
  const rule = followUpRuleFor(state, { characterId, scopeKey: commitmentScopeKey(item) });
  if (rule.mode !== 'auto') return { ok: false, reason: rule.mode === 'observe' ? 'observe' : 'off', rule };
  if (isQuietHours(state.followUpSettings, now)) return { ok: false, reason: 'quiet', rule };
  const globalUsed = countFollowUpsToday(state, { characterId, now });
  if (globalUsed >= Number(state.followUpSettings?.globalMaxPerDay || 3)) return { ok: false, reason: 'global-limit', rule };
  const scopeUsed = countFollowUpsToday(state, { characterId, scopeKey: commitmentScopeKey(item), now });
  if (scopeUsed >= rule.maxPerDay) return { ok: false, reason: 'scope-limit', rule };
  return { ok: true, rule, globalUsed, scopeUsed };
}

// 把模糊的“等会儿/明天/后天”换算成一个可检测的到期时间。
// “下次/改天”太模糊，不做自动到点提醒，只保留承诺本身。
export function followUpDueAt(dueHint, now = Date.now()) {
  const hint = String(dueHint ?? '').trim();
  if (!hint) return 0;
  if (hint === '马上') return now + 15 * 60 * 1000;
  if (hint === '稍后') return now + 60 * 60 * 1000;
  const base = new Date(now);
  if (hint === '明天' || hint === '后天') {
    const days = hint === '明天' ? 1 : 2;
    const target = new Date(base.getFullYear(), base.getMonth(), base.getDate() + days, 10, 0, 0, 0);
    return target.getTime();
  }
  return 0;
}

export function commitmentScopeKey(item) {
  if (!item || typeof item !== 'object') return '';
  const explicit = text(item.scopeKey, 80);
  if (explicit) return explicit;
  const groupId = text(item.groupId, 30);
  return groupId ? `group:${groupId}` : '';
}

export function commitmentScopeLabel(item, { groupName = '' } = {}) {
  const key = commitmentScopeKey(item);
  if (key.startsWith('group:')) return groupName || `群 ${key.slice(6)}`;
  if (key.startsWith('private:')) return '主人私聊';
  return '当前会话';
}

// 只匹配“我承诺之后做某件事”的句子。故意排除纯情绪、反问和明显玩笑。
export function detectPromiseCandidates(content) {
  const raw = String(content ?? '');
  if (!raw || raw.length > 800) return [];
  const sentences = raw
    .split(/(?<=[。！？!?；;])|\n+/)
    .map((s) => text(s, 120))
    .filter(Boolean);
  const out = [];
  for (const sentence of sentences) {
    if (sentence.length < 4 || sentence.length > 80) continue;
    if (/[？?]$/.test(sentence)) continue;
    const future = /(等会|等会儿|待会|待会儿|一会儿|晚点|回头|下次|改天|明天|后天|马上|这就|立刻|现在|稍等|等我)/;
    const action = /(给你|帮你|替你|告诉你|留|拿|带|问|查|发|请你|找你|点(?:一)?杯|点酒|点单|下单|买|弄|调|安排|敬|送|做|准备|处理|接|取|订)/;
    const firstPersonPromise = /我(给|帮|替)你/;
    const deferred = /(等|回头|下次|改天|明天|后天|马上|这就|立刻|现在|稍等|等我).{0,24}(给你|帮你|替你|告诉你|留|拿|带|问|查|发|请你|找你|点(?:一)?杯|点酒|点单|下单|买|弄|调|安排|敬|送|做|准备|处理|接|取|订)/;
    // 没有明确时间词、但“给你点一杯/帮你拿…”已经是清楚的承诺。
    const directPromise = /(给你|帮你|替你).{0,12}(点(?:一)?杯|点酒|点单|下单|买|弄|调|安排|敬|送|做|准备|处理|接|取|订)/;
    if (!(deferred.test(sentence) || (future.test(sentence) && action.test(sentence)) || firstPersonPromise.test(sentence) || directPromise.test(sentence))) continue;
    const normalized = text(sentence.replace(/^[“"'‘’]+|[”"'‘’]+$/g, ''), 80);
    if (!normalized) continue;
    const hint = dueHintOf(normalized)
      || ((directPromise.test(normalized) || firstPersonPromise.test(normalized)) ? '稍后' : '');
    out.push({ text: normalized, dueHint: hint, confidence: deferred.test(normalized) ? 0.8 : 0.65 });
  }
  // 同一句只保留一次
  const seen = new Set();
  return out.filter((item) => {
    const key = item.text;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 3);
}

export function normalizeCommitmentState(raw) {
  const src = raw && typeof raw === 'object' ? raw : {};
  const characters = {};
  const source = src.characters && typeof src.characters === 'object' ? src.characters : {};
  for (const [characterId, list] of Object.entries(source)) {
    if (!/^[A-Za-z0-9_\-\u4e00-\u9fa5]{1,40}$/.test(characterId)) continue;
    if (!Array.isArray(list)) continue;
    characters[characterId] = list
      .filter((item) => item && typeof item === 'object')
      .map((item) => {
        const groupId = text(item.groupId, 30);
        const scopeKey = text(item.scopeKey, 80) || (groupId ? `group:${groupId}` : '');
        const dueAt = clampCount(item.dueAt, Number.MAX_SAFE_INTEGER);
        const status = ['pending', 'done', 'cancelled'].includes(item.status) ? item.status : 'pending';
        const followUpStatus = FOLLOW_UP_STATUS_SET.has(item.followUpStatus)
          ? item.followUpStatus
          : (status === 'pending' && dueAt ? 'waiting' : 'none');
        return {
          id: text(item.id, 80) || `commit-${crypto.randomUUID()}`,
          scopeKey,
          groupId,
          personId: text(item.personId, 30),
          personName: text(item.personName, 80),
          text: text(item.text, 160),
          sourceText: text(item.sourceText, 300),
          sourceType: item.sourceType === 'owner-request' ? 'owner-request' : 'self-promise',
          requestText: text(item.requestText, 300),
          agreementText: text(item.agreementText, 160),
          dueHint: text(item.dueHint, 20),
          confidence: Math.max(0, Math.min(1, Number(item.confidence) || 0)),
          createdAt: clampCount(item.createdAt, Number.MAX_SAFE_INTEGER),
          lastInjectedAt: clampCount(item.lastInjectedAt, Number.MAX_SAFE_INTEGER),
          injectCount: clampCount(item.injectCount, 20),
          status,
          dueAt,
          followUpStatus,
          followUpReadyAt: clampCount(item.followUpReadyAt, Number.MAX_SAFE_INTEGER),
          followUpSentAt: clampCount(item.followUpSentAt, Number.MAX_SAFE_INTEGER),
          followUpSkippedAt: clampCount(item.followUpSkippedAt, Number.MAX_SAFE_INTEGER),
          sourceMessageId: text(item.sourceMessageId, 80)
        };
      })
      .filter((item) => (item.scopeKey || item.groupId) && item.text)
      .slice(-COMMITMENT_MAX_ACTIVE);
  }
  return {
    version: COMMITMENTS_VERSION,
    characters,
    followUpSettings: normalizeFollowUpSettings(src.followUpSettings),
    followUpRules: normalizeFollowUpRules(src.followUpRules)
  };
}

export function commitmentsForCharacter(state, characterId) {
  if (!state?.characters || !characterId) return [];
  return Array.isArray(state.characters[characterId]) ? state.characters[characterId] : [];
}

export function recordCommitments(state, { characterId, scopeKey = '', groupId = '', personId = '', personName = '', content, ownerText = '', sourceMessageId = '', now = Date.now() }) {
  const scope = text(scopeKey, 80) || (groupId ? `group:${text(groupId, 30)}` : '');
  if (!state || !characterId || !scope) return { state, added: [] };
  const list = commitmentsForCharacter(state, characterId);
  const added = [];
  const candidates = ownerText
    ? detectExchangeCommitmentCandidates({ ownerText, jillText: content })
    : detectPromiseCandidates(content).map((item) => ({ ...item, sourceType: 'self-promise' }));
  const recentOwnerRequest = list.some((item) =>
    item.sourceType === 'owner-request'
    && commitmentScopeKey(item) === scope
    && Math.abs(now - Number(item.createdAt || 0)) < DEDUPE_MS
  );
  for (const candidate of candidates) {
    // 同一轮“对方请求 + 角色答应”已经记过时，后续补充句不再重复建一条提醒。
    if (candidate.sourceType === 'self-promise' && recentOwnerRequest) continue;
    const duplicate = list.some((item) =>
      commitmentScopeKey(item) === scope
      && item.text === candidate.text
      && Math.abs(now - Number(item.createdAt || 0)) < DEDUPE_MS
    );
    if (duplicate) continue;
    const dueAt = followUpDueAt(candidate.dueHint, now);
    list.push({
      id: `commit-${crypto.randomUUID()}`,
      scopeKey: scope,
      groupId: text(groupId, 30),
      personId: text(personId, 30),
      personName: text(personName, 80),
      text: candidate.text,
      sourceText: candidate.sourceType === 'owner-request' ? text(ownerText, 300) : text(content, 300),
      sourceType: candidate.sourceType || 'self-promise',
      requestText: text(candidate.requestText || '', 300),
      agreementText: text(candidate.agreementText || '', 160),
      dueHint: candidate.dueHint,
      confidence: candidate.confidence,
      createdAt: now,
      lastInjectedAt: 0,
      injectCount: 0,
      status: 'pending',
      dueAt,
      followUpStatus: dueAt ? 'waiting' : 'none',
      followUpReadyAt: 0,
      followUpSentAt: 0,
      followUpSkippedAt: 0,
      sourceMessageId: text(sourceMessageId, 80)
    });
    added.push(list[list.length - 1]);
  }
  // 只保留最近 200 条，先清过期，再清最旧的已完成项。
  const cutoff = now - COMMITMENT_TTL_MS;
  for (const item of list) {
    if (item.status === 'pending' && item.createdAt < cutoff) item.status = 'cancelled';
  }
  while (list.length > COMMITMENT_MAX_ACTIVE) {
    const idx = list.findIndex((item) => item.status !== 'pending');
    list.splice(idx >= 0 ? idx : 0, 1);
  }
  state.characters[characterId] = list;
  return { state, added };
}

export function pendingCommitments(state, { characterId, scopeKey = '', groupId = '', personId = '', now = Date.now() }) {
  const scope = text(scopeKey, 80) || (groupId ? `group:${text(groupId, 30)}` : '');
  return commitmentsForCharacter(state, characterId)
    .filter((item) => item.status === 'pending')
    .filter((item) => !scope || commitmentScopeKey(item) === scope)
    .filter((item) => !personId || !item.personId || item.personId === personId)
    .filter((item) => now - Number(item.createdAt || 0) < COMMITMENT_TTL_MS)
    .sort((a, b) => Number(b.createdAt) - Number(a.createdAt));
}

export function formatCommitmentsPrompt(state, { characterId, scopeKey = '', groupId = '', personId = '', now = Date.now(), max = 3, markInjected = false } = {}) {
  const items = pendingCommitments(state, { characterId, scopeKey, groupId, personId, now })
    .filter((item) => {
      // 已经注入过两次的，不再反复提；避免像系统催办。
      if (Number(item.injectCount) >= 2) return false;
      if (item.lastInjectedAt && now - Number(item.lastInjectedAt) < 24 * 60 * 60 * 1000) return false;
      return true;
    })
    .slice(0, max);
  if (!items.length) return '';
  if (markInjected) {
    for (const item of items) {
      item.lastInjectedAt = now;
      item.injectCount = Number(item.injectCount || 0) + 1;
    }
  }
  const lines = items.map((item) => {
    const who = item.personName || (item.personId ? `QQ ${item.personId}` : '群里的人');
    const when = item.dueHint && !String(item.text || '').includes(item.dueHint) ? `（${item.dueHint}）` : '';
    if (item.sourceType === 'owner-request') return `- 你答应过${who}：${item.text}${when}`;
    return `- 你对${who}说过：${item.text}${when}`;
  });
  return [
    '【你自己说过的话】',
    '这些不是系统提醒，是你之前在这个群答应过的事。合适就自然兑现；不合适就忽略，不要机械复述，也不要说“系统提醒我”。',
    ...lines
  ].join('\n');
}

export function setCommitmentStatus(state, { characterId, id, status, now = Date.now() }) {
  if (!state || !characterId || !['done', 'cancelled', 'pending'].includes(status)) return false;
  const item = commitmentsForCharacter(state, characterId).find((x) => x.id === id);
  if (!item) return false;
  item.status = status;
  if (status !== 'pending') {
    item.updatedAt = now;
    if (['waiting', 'pending_confirmation', 'queued'].includes(item.followUpStatus)) item.followUpStatus = 'skipped';
  }
  return true;
}

export function commitmentById(state, characterId, id) {
  return commitmentsForCharacter(state, characterId).find((item) => item.id === id) || null;
}

// 到点只生成“等待确认”，绝不主动发送；真正的发送由控制台确认或后续自动开关触发。
export function refreshCommitmentFollowUps(state, { characterId, now = Date.now() } = {}) {
  if (!state || !characterId) return { changed: 0, ready: [] };
  const ready = [];
  let changed = 0;
  for (const item of commitmentsForCharacter(state, characterId)) {
    if (item.status !== 'pending' || !item.dueAt) continue;
    if (!['waiting', 'pending_confirmation'].includes(item.followUpStatus)) continue;
    if (now - Number(item.createdAt || 0) >= COMMITMENT_TTL_MS) {
      item.followUpStatus = 'expired';
      changed += 1;
      continue;
    }
    if (Number(item.dueAt) > now) continue;
    if (now - Number(item.dueAt) > FOLLOW_UP_EXPIRE_MS) {
      item.followUpStatus = 'expired';
      changed += 1;
      continue;
    }
    if (item.followUpStatus !== 'pending_confirmation') {
      item.followUpStatus = 'pending_confirmation';
      item.followUpReadyAt = now;
      changed += 1;
    }
    ready.push(item);
  }
  return { changed, ready };
}

export function setCommitmentFollowUpStatus(state, { characterId, id, status, now = Date.now(), dueAt = null }) {
  const allowed = new Set(['waiting', 'pending_confirmation', 'queued', 'sent', 'skipped', 'expired']);
  if (!state || !characterId || !allowed.has(status)) return false;
  const item = commitmentById(state, characterId, id);
  if (!item) return false;
  item.followUpStatus = status;
  if (status === 'pending_confirmation') item.followUpReadyAt = now;
  if (status === 'sent') item.followUpSentAt = now;
  if (status === 'skipped') item.followUpSkippedAt = now;
  if (status === 'waiting') {
    item.followUpReadyAt = 0;
    item.followUpSentAt = 0;
    item.followUpSkippedAt = 0;
    if (dueAt != null) item.dueAt = Math.max(0, Number(dueAt) || 0);
  }
  return true;
}

export function followUpStatusLabel(item) {
  const status = String(item?.followUpStatus || '');
  return {
    waiting: '等待到期',
    pending_confirmation: '待确认',
    queued: '已排队',
    sent: '已触发',
    skipped: '已跳过',
    expired: '已过期',
    none: ''
  }[status] || '';
}
