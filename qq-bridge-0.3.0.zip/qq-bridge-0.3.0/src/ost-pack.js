// 角色专属的“音乐记忆”曲目包。
//
// 设计边界：
// - 曲目包按角色文件存放，只注入当前角色，避免把 Jill 的记忆塞给别的角色。
// - 它是“听歌记忆”，不是资料库；提示词要求角色不要背曲目表、不要假装现场播放。
// - 文件缺失或格式不对时静默降级，不影响聊天主链路。
import fs from 'node:fs';
import path from 'node:path';

export const DEFAULT_OST_CONFIG = Object.freeze({
  enabled: true,
  maxChars: 1600,
  maxTracks: 18
});

const TRACK_LIMIT = 60;

function cleanText(value, max) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

export function ostFileKey(characterId) {
  const key = cleanText(characterId, 80) || 'unknown';
  return key.replace(/[\\/:*?"<>|]/g, '_');
}

export function ostFilePath(dir, characterId) {
  return path.join(dir, `${ostFileKey(characterId)}.json`);
}

export function normalizeOstPack(raw, characterId = '') {
  const source = raw && typeof raw === 'object' ? raw : {};
  const tracks = Array.isArray(source.tracks) ? source.tracks : [];
  return {
    version: 1,
    characterId: cleanText(source.characterId || characterId, 80),
    title: cleanText(source.title || '音乐记忆', 120),
    source: cleanText(source.source, 240),
    tracks: tracks
      .map((track) => ({
        title: cleanText(track?.title, 120),
        mood: cleanText(track?.mood, 120),
        memory: cleanText(track?.memory, 400)
      }))
      .filter((track) => track.title)
      .slice(0, TRACK_LIMIT)
  };
}

export function loadOstPack(dir, characterId, { fsImpl = fs } = {}) {
  const file = ostFilePath(dir, characterId);
  let raw;
  try {
    raw = JSON.parse(fsImpl.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
  const pack = normalizeOstPack(raw, characterId);
  return pack.tracks.length ? pack : null;
}

export function formatOstPrompt(pack, { maxChars = DEFAULT_OST_CONFIG.maxChars, maxTracks = DEFAULT_OST_CONFIG.maxTracks } = {}) {
  if (!pack || !Array.isArray(pack.tracks) || !pack.tracks.length) return '';
  const limit = Math.max(1, Math.min(30, Number(maxTracks) || DEFAULT_OST_CONFIG.maxTracks));
  const charLimit = Math.max(400, Math.min(4000, Number(maxChars) || DEFAULT_OST_CONFIG.maxChars));
  const lines = [];
  lines.push(`【音乐记忆 · ${pack.title}】`);
  lines.push('这些不是资料库，是你自己听过的歌和当时的记忆。只在自然的时候想起或提到，不要一次背曲目表，不要说“正在播放”；别人问起时按情绪和记忆回答。');
  if (pack.source) lines.push(`来源：${pack.source}`);
  let text = lines.join('\n');
  for (const track of pack.tracks.slice(0, limit)) {
    const mood = track.mood ? `｜${track.mood}` : '';
    const memory = track.memory ? `｜${track.memory}` : '';
    const line = `- 《${track.title}》${mood}${memory}`;
    if (text.length + line.length + 1 > charLimit) break;
    text += `\n${line}`;
  }
  return text;
}
