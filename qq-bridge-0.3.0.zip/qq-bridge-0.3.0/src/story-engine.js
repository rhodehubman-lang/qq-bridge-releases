// 故事工坊：把世界动态写成连续章节，并输出可审核的 canon 变更。
// 生成由 bridge 里的独立 DSH 会话完成；这里只负责状态、提示词和 canon 规范化。

export const STORY_VERSION = 1;

export const DEFAULT_STORY_STYLE = {
  tone: '日常、克制、有生活质感',
  pov: '第三人称',
  length: 1000,
  // focus 为空 = 从当前角色的生活档案里取（城市/职业/日常圈），不在代码里写死任何设定。
  focus: '',
  avoid: '不要写宏大战争、不要突然角色死亡、不要把角色写成动作英雄',
  auto: false,
  cadenceHours: 24,
  autoApply: false
};

export function emptyStory(profileId = '') {
  return {
    version: STORY_VERSION,
    profileId,
    style: { ...DEFAULT_STORY_STYLE },
    chapters: [],
    pending: null,
    lastGeneratedAt: 0
  };
}

export function normalizeStory(raw, profileId = '') {
  const src = raw && typeof raw === 'object' ? raw : {};
  const style = { ...DEFAULT_STORY_STYLE, ...(src.style && typeof src.style === 'object' ? src.style : {}) };
  style.length = Math.min(3000, Math.max(300, Number(style.length) || 1000));
  style.cadenceHours = Math.min(168, Math.max(1, Number(style.cadenceHours) || 24));
  style.auto = style.auto === true;
  style.autoApply = style.autoApply === true;
  return {
    version: STORY_VERSION,
    profileId,
    style,
    chapters: Array.isArray(src.chapters) ? src.chapters.slice(-100) : [],
    pending: src.pending && typeof src.pending === 'object' ? src.pending : null,
    lastGeneratedAt: Number(src.lastGeneratedAt) || 0
  };
}

export function renumberStory(story) {
  const src = story && typeof story === 'object' ? story : {};
  const pending = src.pending && typeof src.pending === 'object' ? { ...src.pending } : null;
  let chapters = (Array.isArray(src.chapters) ? src.chapters : [])
    .filter((chapter) => chapter && typeof chapter === 'object')
    .map((chapter, index) => ({
      chapter,
      at: Number.isFinite(Number(chapter.at)) ? Number(chapter.at) : index,
      index
    }))
    .sort((a, b) => a.at - b.at || a.index - b.index)
    .map((item) => item.chapter);
  if (pending && pending.id) {
    chapters = chapters.filter((chapter) => String(chapter.id || '') !== String(pending.id));
  }
  chapters = chapters.map((chapter, index) => ({ ...chapter, chapter: index + 1 }));
  if (pending) pending.chapter = chapters.length + 1;
  return { ...src, chapters, pending };
}

export function buildStoryPrompt(story, { world = null, profile = null, now = Date.now() } = {}) {
  const ordered = renumberStory(story);
  const nextChapter = ordered.chapters.length + 1;
  const previous = ordered.chapters.slice(-3).map((c) => `第 ${c.chapter} 章《${c.title}》：${c.summary || ''}`).join('\n');
  const events = (world?.events || [])
    .filter((e) => Number(e.at) > now - 3 * 24 * 60 * 60 * 1000)
    .slice(-8)
    .map((e) => `- ${new Date(e.at).toLocaleString('zh-CN', { hour12: false })} ${e.headline}（${e.detail}）`)
    .join('\n');
  const worldName = String(profile?.world?.name || world?.name || '').trim();
  const who = String(profile?.displayName || profile?.id || '').trim();
  const place = worldName || '当前城市';
  return [
    `你是「${place}」的连续故事作者。你写的不是大纲，而是可以被人读的短篇章节。`,
    worldName
      ? `世界观：城市「${worldName}」${who ? `，主角是「${who}」` : ''}；细节以角色生活档案为准。`
      : '世界观：以当前角色的生活档案为准（城市、职业、日常圈）；档案里没有的不要编造宏大设定。',
    `写作风格：${story.style.tone}`,
    `视角：${story.style.pov}`,
    `长度：约 ${story.style.length} 个汉字。`,
    `关注：${story.style.focus}`,
    `避免：${story.style.avoid}`,
    '要求：故事要有生活质感；大事件只能是背景新闻，不能突然变成战争片。',
    `本章是第 ${nextChapter} 章。JSON 里的 "chapter" 必须填 ${nextChapter}，不要从 1 重新开始。`,
    '只输出一个 JSON 对象，不要 Markdown 代码块，不要额外解释。JSON 结构：',
    `{"title":"章节标题","chapter":${nextChapter},"story":"章节正文","summary":"一句话摘要","canon_updates":[{"type":"event","headline":"新事件标题","detail":"事件描述","severity":1,"locations":["old_town"],"effects":{"commuteExtraMinutes":0,"shiftDelayMinutes":0},"channel":"story"}]}`,
    `当前时间：${new Date(now).toLocaleString('zh-CN', { hour12: false })}`,
    profile ? `角色：${profile.displayName || profile.id}${worldName ? `；城市：${worldName}` : ''}。` : '',
    previous ? `前情：\n${previous}` : '前情：这是第一章。',
    events ? `最近城市动态（可作为背景，不必逐条复述）：\n${events}` : '',
    'canon_updates 是可选的；只写真正会改变世界的事件。普通情绪和对话不要写成 canon。'
  ].filter(Boolean).join('\n\n');
}

function safeText(value, max = 4000) {
  return String(value ?? '').trim().slice(0, max);
}

function normalizeLocation(value) {
  return safeText(value, 64).toLowerCase().replace(/[^a-z0-9_-]/g, '');
}

function normalizeEffects(raw) {
  const src = raw && typeof raw === 'object' ? raw : {};
  const out = {};
  for (const key of ['commuteExtraMinutes', 'shiftDelayMinutes', 'moodDelta', 'districtDanger']) {
    const n = Number(src[key]);
    if (Number.isFinite(n) && n !== 0) out[key] = Math.max(-30, Math.min(180, Math.trunc(n)));
  }
  return out;
}

export function normalizeCanonUpdates(raw) {
  if (!Array.isArray(raw)) return [];
  const out = [];
  for (const item of raw.slice(0, 10)) {
    if (!item || typeof item !== 'object') continue;
    const type = safeText(item.type, 20) || 'event';
    if (type !== 'event') continue;
    const headline = safeText(item.headline, 120);
    if (!headline) continue;
    out.push({
      type: 'event',
      headline,
      detail: safeText(item.detail, 600),
      severity: Math.max(1, Math.min(5, Number(item.severity) || 2)),
      locations: Array.isArray(item.locations) ? item.locations.map(normalizeLocation).filter(Boolean).slice(0, 8) : [],
      effects: normalizeEffects(item.effects),
      channel: 'story'
    });
  }
  return out;
}

export function parseStoryOutput(text, chapterNumber = 1) {
  const textValue = String(text ?? '').trim();
  const start = textValue.indexOf('{');
  const end = textValue.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('故事输出不是 JSON 对象');
  const data = JSON.parse(textValue.slice(start, end + 1));
  const title = safeText(data.title, 120) || `第 ${chapterNumber} 章`;
  const body = safeText(data.story ?? data.content, 20000);
  if (!body) throw new Error('故事正文为空');
  const summary = safeText(data.summary, 300) || body.slice(0, 80);
  const expectedChapter = Number(chapterNumber);
  return {
    title,
    chapter: Number.isFinite(expectedChapter) && expectedChapter > 0 ? expectedChapter : (Number(data.chapter) || 1),
    story: body,
    summary,
    canonUpdates: normalizeCanonUpdates(data.canon_updates)
  };
}

export function applyCanonToWorld(world, chapter) {
  if (!world || !chapter) return [];
  const updates = Array.isArray(chapter.canonUpdates) ? chapter.canonUpdates : [];
  if (!Array.isArray(world.events)) world.events = [];
  const now = Date.now();
  const added = [];
  for (const update of updates) {
    const event = {
      id: `story_${now.toString(36)}_${added.length}`,
      at: now,
      type: 'story',
      channel: 'story',
      headline: update.headline,
      detail: update.detail,
      severity: update.severity,
      locations: update.locations,
      effects: update.effects,
      known: true,
      knownAt: now,
      discoveredVia: '故事'
    };
    world.events.push(event);
    added.push(event);
  }
  world.events = world.events.slice(-300);
  return added;
}
