// 跨会话共享记忆（二代仿真）。
//
// 背景：qq-bridge 里每个 QQ 群/私聊都对应一个独立的 DSH 会话，DSH 的上下文
// 按会话隔离；本模块提供一套**桥接层**的分层共享记忆，让同一个机器人角色
// 在不同群/私聊之间拥有一致的长程记忆，同时默认不把私聊内容泄露到群里。
//
// 三层：
//   global      全局记忆：角色/世界观/所有场合都安全的事，所有会话可见
//   user:<QQ>   用户记忆：关于某个人的事实，默认只在私聊可见；标 public 才允许在群内提及
//   group:<群>  群记忆：某个群自己的事，只在该群可见
//
// 本文件只做纯数据操作（不碰 fs、不读配置），方便单元测试；
// 读写文件、鉴权、scope 权限由 bridge.js 负责。

export const SHARED_MEMORY_VERSION = 1;
export const SHARED_SCOPES = Object.freeze(['global', 'user', 'group']);

const MAX_TAGS = 8;
const MAX_TAG_CHARS = 24;
const MAX_SOURCE_NAME = 64;

function randomId() {
  return `sm_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(n)));
}

function normalizeText(value, maxChars) {
  return String(value ?? '')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxChars);
}

function normalizeVisibility(value) {
  return value === 'public' ? 'public' : value === 'shared' ? 'shared' : 'private';
}

function normalizeTags(tags) {  if (!Array.isArray(tags)) return [];
  const out = [];
  for (const tag of tags) {
    const text = normalizeText(tag, MAX_TAG_CHARS);
    if (text && !out.includes(text)) out.push(text);
    if (out.length >= MAX_TAGS) break;
  }
  return out;
}

export function emptySharedMemory() {
  return { version: SHARED_MEMORY_VERSION, entries: [] };
}

/** 把磁盘/旧版本数据整理成可安全使用的结构；坏条目直接丢弃，绝不抛出。 */
export function normalizeSharedMemory(raw) {
  const out = emptySharedMemory();
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return out;
  const entries = Array.isArray(raw.entries) ? raw.entries : [];
  const seen = new Set();
  for (const item of entries) {
    const entry = normalizeEntry(item);
    if (!entry) continue;
    if (seen.has(entry.id)) entry.id = randomId();
    seen.add(entry.id);
    out.entries.push(entry);
  }
  return out;
}

function normalizeEntry(item) {
  if (!item || typeof item !== 'object' || Array.isArray(item)) return null;
  const scope = String(item.scope ?? '').trim();
  if (!SHARED_SCOPES.includes(scope)) return null;
  const scopeId = scope === 'global' ? '' : String(item.scopeId ?? '').trim();
  if (scope !== 'global' && !/^\d+$/.test(scopeId)) return null;
  const content = normalizeText(item.content, 500);
  if (!content) return null;
  const createdAt = Number(item.createdAt) > 0 ? Number(item.createdAt) : Date.now();
  const updatedAt = Number(item.updatedAt) > 0 ? Number(item.updatedAt) : createdAt;
  const subjectName = normalizeText(item.subjectName, MAX_SOURCE_NAME);
  const archivedAt = Number(item.archivedAt) > 0 ? Number(item.archivedAt) : 0;
  const archiveReason = normalizeText(item.archiveReason, 40);
  const source = item.source && typeof item.source === 'object' && !Array.isArray(item.source)
    ? {
        key: normalizeText(item.source.key, 80),
        kind: item.source.kind === 'group' ? 'group' : item.source.kind === 'private' ? 'private' : '',
        id: normalizeText(item.source.id, 32),
        name: normalizeText(item.source.name, MAX_SOURCE_NAME)
      }
    : undefined;
  return {
    id: typeof item.id === 'string' && item.id.trim() ? item.id.trim().slice(0, 64) : randomId(),
    scope,
    scopeId,
    characterId: normalizeText(item.characterId, 64),
    content,
    tags: normalizeTags(item.tags),
    visibility: normalizeVisibility(item.visibility),
    importance: clampInt(item.importance, 1, 5, 3),
    subjectName: subjectName || '',
    ...(archivedAt ? { archivedAt, archiveReason: archiveReason || 'archive' } : {}),
    source,
    createdAt,
    updatedAt,
    lastUsedAt: Number(item.lastUsedAt) > 0 ? Number(item.lastUsedAt) : 0
  };
}

export function parseSessionKey(key) {
  const m = /^(group|private):(\d+)$/.exec(String(key ?? '').trim());
  if (!m) return null;
  const id = m[2].replace(/^0+(?=\d)/, '');
  if (!id || id.length > 20) return null;
  const num = Number(id);
  if (!Number.isSafeInteger(num) || num <= 0) return null;
  return num <= 9007199254740991
    ? {
        key: `${m[1]}:${id}`,
        kind: m[1],
        id: String(id),
        groupId: m[1] === 'group' ? String(id) : '',
        uin: m[1] === 'private' ? String(id) : ''
      }
    : null;
}

function normalizeSource(input, fallback = {}) {
  const src = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
  const kind = src.kind === 'group' || src.kind === 'private' ? src.kind : (fallback.kind || '');
  const id = normalizeText(src.id ?? fallback.id, 32);
  const key = normalizeText(src.key ?? (kind && id ? `${kind}:${id}` : ''), 80);
  const name = normalizeText(src.name, MAX_SOURCE_NAME);
  return { key, kind, id, ...(name ? { name } : {}) };
}

/**
 * 追加一条共享记忆。
 * @param {{version:number,entries:object[]}} state
 * @param {{scope:string,scopeId?:string,content:string,tags?:string[],visibility?:string,importance?:number,subjectName?:string,source?:object}} input
 * @param {{now?:number,maxEntries?:number,entryMaxChars?:number,ttlDays?:number}} options
 * @returns {{ok:true,entry:object,deduped:boolean}|{ok:false,error:string}}
 */
export function appendSharedMemory(state, input, options = {}) {
  try {
    if (!state || typeof state !== 'object') return { ok: false, error: '内部状态无效' };
    if (!Array.isArray(state.entries)) state.entries = [];
    const scope = String(input?.scope ?? '').trim();
    if (!SHARED_SCOPES.includes(scope)) return { ok: false, error: 'scope 必须是 global / user / group' };
    const scopeId = scope === 'global' ? '' : String(input?.scopeId ?? '').trim();
    if (scope !== 'global' && !/^\d+$/.test(scopeId)) {
      return { ok: false, error: scope === 'user' ? 'user 记忆需要 scopeId（QQ 号）' : 'group 记忆需要 scopeId（群号）' };
    }
    if (scope !== 'global' && scopeId.length > 20) return { ok: false, error: 'scopeId 不合法' };
    const maxChars = clampInt(options.entryMaxChars, 40, 2000, 300);
    const content = normalizeText(input?.content, maxChars);
    if (content.length < 2) return { ok: false, error: '记忆内容太短' };
    const now = Number(options.now) > 0 ? Number(options.now) : Date.now();
    const ttlDays = Number(options.ttlDays) > 0 ? Number(options.ttlDays) : 0;
    pruneSharedMemory(state, { now, ttlDays, maxEntries: options.maxEntries });
    const visibility = normalizeVisibility(input?.visibility);
    const importance = clampInt(input?.importance, 1, 5, 3);
    const tags = normalizeTags(input?.tags);
    const subjectName = normalizeText(input?.subjectName, MAX_SOURCE_NAME);
    const source = normalizeSource(input?.source);
    const characterId = normalizeText(input?.characterId, 64);
    const existing = state.entries.find((e) => e
      && e.scope === scope
      && e.scopeId === scopeId
      && (e.characterId || '') === characterId
      && e.content === content);
    if (existing) {
      existing.tags = tags.length ? tags : existing.tags;
      existing.visibility = visibility;
      existing.importance = Math.max(existing.importance || 3, importance);
      existing.updatedAt = now;
      if (subjectName) existing.subjectName = subjectName;
      if (characterId) existing.characterId = characterId;
      if (source.key) existing.source = source;
      return { ok: true, entry: existing, deduped: true };
    }
    const entry = {
      id: randomId(),
      scope,
      scopeId,
      characterId,
      content,
      tags,
      visibility,
      importance,
      subjectName,
      source,
      createdAt: now,
      updatedAt: now,
      lastUsedAt: 0
    };
    state.entries.push(entry);
    enforceMaxEntries(state, options.maxEntries);
    return { ok: true, entry, deduped: false };
  } catch (error) {
    return { ok: false, error: `写入共享记忆失败：${error?.message ?? error}` };
  }
}

/** 删除过期/超量条目。importance=5 的条目不按 TTL 清理。 */
export function pruneSharedMemory(state, options = {}) {
  if (!state || !Array.isArray(state.entries)) return 0;
  const now = Number(options.now) > 0 ? Number(options.now) : Date.now();
  const ttlDays = Number(options.ttlDays) > 0 ? Number(options.ttlDays) : 0;
  let removed = 0;
  if (ttlDays > 0) {
    const cutoff = now - ttlDays * 24 * 60 * 60 * 1000;
    const kept = [];
    for (const entry of state.entries) {
      if (!entry || typeof entry !== 'object') { removed += 1; continue; }
      if ((entry.importance || 3) < 5 && Number(entry.updatedAt || entry.createdAt || 0) < cutoff) {
        removed += 1;
        continue;
      }
      kept.push(entry);
    }
    state.entries = kept;
  }
  removed += enforceMaxEntries(state, options.maxEntries);
  return removed;
}

function enforceMaxEntries(state, maxEntries) {
  if (!state || !Array.isArray(state.entries)) return 0;
  const limit = clampInt(maxEntries, 20, 5000, 400);
  if (state.entries.length <= limit) return 0;
  // 保留：重要度高、更新时间新的。先排序再截断。
  const sorted = [...state.entries].sort((a, b) => {
    const imp = (Number(b?.importance) || 3) - (Number(a?.importance) || 3);
    if (imp !== 0) return imp;
    return (Number(b?.updatedAt) || 0) - (Number(a?.updatedAt) || 0);
  });
  const keep = new Set(sorted.slice(0, limit).map((e) => e));
  const before = state.entries.length;
  state.entries = state.entries.filter((e) => keep.has(e));
  return before - state.entries.length;
}

/**
 * 查询共享记忆（只做数据过滤，权限由 bridge 决定传哪些 scope/scopeId）。
 * @param {{version:number,entries:object[]}} state
 * @param {{scope?:string,scopeId?:string,scopes?:Array<{scope:string,scopeId?:string}>,characterId?:string,query?:string,visibility?:string,limit?:number,includePublicCrossGroup?:boolean,includePublicUserMemories?:boolean,excludeGroupId?:string}} filters
 */
export function querySharedMemory(state, filters = {}) {
  const list = state && Array.isArray(state.entries) ? state.entries : [];
  const characterId = String(filters.characterId ?? '').trim();
  const wanted = new Set();
  if (Array.isArray(filters.scopes)) {
    for (const s of filters.scopes) {
      if (s && SHARED_SCOPES.includes(s.scope)) wanted.add(`${s.scope}:${s.scopeId ?? ''}`);
    }
  } else if (filters.scope && SHARED_SCOPES.includes(filters.scope)) {
    wanted.add(`${filters.scope}:${filters.scopeId ?? ''}`);
  }
  const q = String(filters.query ?? '').trim().toLowerCase();
  const visibility = ['public', 'shared', 'private'].includes(filters.visibility) ? filters.visibility : '';
  const limit = clampInt(filters.limit, 1, 100, 20);
  const includePublicCrossGroup = filters.includePublicCrossGroup === true;
  const includePublicUserMemories = filters.includePublicUserMemories === true;
  const excludeGroupId = String(filters.excludeGroupId ?? '').trim();
  const hit = [];
  for (const entry of list) {
    if (!entry) continue;
    if (characterId && entry.characterId && entry.characterId !== '*'
      && entry.characterId !== characterId) continue;
    if (wanted.size && !wanted.has(`${entry.scope}:${entry.scopeId ?? ''}`)) {
      // 跨群 public 记忆：别的群明确标成 public 的条目，允许在查询里带出来。
      const crossPublic = includePublicCrossGroup
        && entry.scope === 'group'
        && entry.visibility === 'public'
        && entry.scopeId !== excludeGroupId;
      // public 用户记忆：public=所有会话可见，私聊里也可以查询到别人的公开记忆。
      const publicUser = includePublicUserMemories
        && entry.scope === 'user'
        && entry.visibility === 'public';
      if (!crossPublic && !publicUser) continue;
    }
    if (visibility && entry.visibility !== visibility) continue;
    hit.push(entry);
  }
  if (q && hit.length) {
    // 精确包含整句查询的条目优先；没有精确命中时才用 BM25 召回（含同义词扩展）。
    const exactHits = hit.filter((entry) => String(entry.content || '').toLowerCase().includes(q));
    return rankMemoryEntries(exactHits.length ? exactHits : hit, q, { now: Date.now(), onlyMatched: true }).slice(0, limit);
  }
  hit.sort((a, b2) => (Number(b2.importance) || 3) - (Number(a.importance) || 3)
    || (Number(b2.updatedAt) || 0) - (Number(a.updatedAt) || 0));
  return hit.slice(0, limit);
}

/**
 * 删除共享记忆条目。
 * 支持按 id 精确删除，或按 scope/scopeId + 内容片段（query）删除。
 * @returns {number} 删除条数
 */
export function forgetSharedMemory(state, filters = {}) {
  if (!state || !Array.isArray(state.entries)) return 0;
  const id = String(filters.id ?? '').trim();
  const scope = String(filters.scope ?? '').trim();
  const scopeId = String(filters.scopeId ?? '').trim();
  const q = String(filters.query ?? '').trim().toLowerCase();
  const sourceKey = String(filters.sourceKey ?? '').trim();
  const max = clampInt(filters.max, 1, 20, 5);
  const matches = (entry) => {
    if (!entry) return false;
    if (id) return entry.id === id;
    if (sourceKey && entry.source?.key === sourceKey) {
      if (scope && entry.scope !== scope) return false;
      if (scopeId && entry.scopeId !== scopeId) return false;
      return true;
    }
    if (scope && entry.scope !== scope) return false;
    if (scopeId && entry.scopeId !== scopeId) return false;
    if (q && !`${entry.content} ${(entry.tags || []).join(' ')}`.toLowerCase().includes(q)) return false;
    return !!(scope || scopeId || q);
  };
  let removed = 0;
  state.entries = state.entries.filter((entry) => {
    if (removed >= max) return true;
    if (!matches(entry)) return true;
    removed += 1;
    return false;
  });
  return removed;
}

// ── 轻量“语义”检索（不引入向量库）──────────────────────────────────────────
// 中文没有空格，直接用 substring 命中率很低。这里用：
//   1. 中文单字 + 二元组、英文/数字词作为检索 token；
//   2. BM25 打分（词频 + 逆文档频率 + 长度归一化）；
//   3. 少量同义词/近义扩展（开黑↔打游戏、喜欢↔爱、难过↔伤心……）；
//   4. 重要度 + 新近度加权。
// 这不是神经网络语义，但对“短记忆条目”的召回明显好于 includes()，且 2G 内存无压力。
const SEARCH_SYNONYMS = Object.freeze({
  '开黑': '打游戏 联机 组队 游戏',
  '打游戏': '开黑 联机 游戏',
  '联机': '开黑 打游戏 一起玩',
  '游戏': '开黑 联机 打游戏',
  '甜': '甜味 甜酒 甜食',
  '甜酒': '甜 甜味 酒',
  '喝酒': '酒 酒量 醉了',
  '难过': '伤心 不开心 低落 郁闷',
  '开心': '高兴 快乐 愉快',
  '喜欢': '爱 中意 偏好',
  '讨厌': '不喜欢 反感',
  '工作': '上班 公司 打工',
  '猫': 'fore 小猫 猫咪',
  '表情': '表情包 贴纸 表情包',
  '比赛': '赛事 对局 竞技',
  '生日': '出生 纪念日',
  '钱': '工资 房租 账 费用'
});

function isCjk(ch) {
  return ch >= '\u3400' && ch <= '\u9fff';
}

/** 把一段中英混排文本切成检索 token：中文单字 + 二元组，英文/数字词。 */
export function tokenizeForSearch(text) {
  const cleaned = normalizeText(text, 4000).toLowerCase();
  if (!cleaned) return [];
  const out = [];
  const seen = new Set();
  const add = (token) => {
    if (!token || seen.has(token)) return;
    seen.add(token);
    out.push(token);
  };
  const latin = cleaned.match(/[a-z0-9_]+/g) || [];
  for (const word of latin) if (word.length >= 2) add(word);
  const cjkRuns = cleaned.match(/[\u3400-\u9fff]+/g) || [];
  for (const run of cjkRuns) {
    const chars = Array.from(run);
    for (const char of chars) add(char);
    for (let i = 0; i + 1 < chars.length; i += 1) add(chars[i] + chars[i + 1]);
  }
  return out;
}

function expandQueryTokens(tokens) {
  const out = [...tokens];
  const seen = new Set(out);
  const add = (token) => {
    if (!token || seen.has(token)) return;
    seen.add(token);
    out.push(token);
  };
  for (const token of tokens) {
    const synonyms = SEARCH_SYNONYMS[token];
    if (synonyms) {
      for (const synonym of synonyms.split(/\s+/)) {
        for (const t of tokenizeForSearch(synonym)) add(t);
      }
    }
  }
  return out;
}

function entryTokens(entry) {
  return tokenizeForSearch(`${entry?.content ?? ''} ${(entry?.tags ?? []).join(' ')} ${entry?.subjectName ?? ''}`);
}

/**
 * 用 BM25 + 重要度 + 新近度给记忆排序。
 * @returns {object[]} 按相关度从高到低排序后的条目
 */
export function rankMemoryEntries(entries, query = '', options = {}) {
  const list = Array.isArray(entries) ? entries.filter((e) => e && typeof e === 'object') : [];
  if (!list.length) return [];
  const now = Number(options.now) > 0 ? Number(options.now) : Date.now();
  const importanceWeight = Number.isFinite(Number(options.importanceWeight)) ? Number(options.importanceWeight) : 0.8;
  const recencyWeight = Number.isFinite(Number(options.recencyWeight)) ? Number(options.recencyWeight) : 0.5;
  const q = String(query ?? '').trim().toLowerCase();
  const qTokens = q ? expandQueryTokens(tokenizeForSearch(q)) : [];
  const docs = list.map((entry) => {
    const tokens = entryTokens(entry);
    return { entry, tokens, tf: countTokens(tokens), len: tokens.length };
  });
  const docFreq = new Map();
  for (const doc of docs) {
    for (const token of new Set(doc.tokens)) docFreq.set(token, (docFreq.get(token) || 0) + 1);
  }
  const N = docs.length;
  const avgdl = docs.reduce((sum, doc) => sum + doc.len, 0) / N || 1;
  const k1 = 1.2;
  const b = 0.75;
  const scored = docs.map((doc) => {
    let bm25 = 0;
    for (const token of qTokens) {
      const tf = doc.tf.get(token) || 0;
      if (!tf) continue;
      const df = docFreq.get(token) || 0;
      const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5));
      bm25 += idf * ((tf * (k1 + 1)) / (tf + k1 * (1 - b + b * (doc.len / avgdl))));
    }
    const exact = q && String(doc.entry.content || '').toLowerCase().includes(q) ? 3 : 0;
    const importance = (Number(doc.entry.importance) || 3) / 5;
    const updatedAt = Number(doc.entry.updatedAt || doc.entry.createdAt || 0);
    const ageDays = updatedAt > 0 ? Math.max(0, (now - updatedAt) / 86400000) : 999;
    const recency = Math.exp(-ageDays / 45);
    const score = bm25 + exact + importanceWeight * importance + recencyWeight * recency;
    return { entry: doc.entry, score, bm25, exact };
  });
  // 没有 query 时按重要度/新近度；有 query 但全无命中时也保留“重要度+新近度”排序，
  // 避免查询过度把记忆全部过滤掉。onlyMatched=true 时优先只返回真正命中的条目。
  let finalScored = scored;
  if (q && options.onlyMatched === true) {
    const matched = scored.filter((item) => item.bm25 > 0 || item.exact > 0);
    finalScored = matched;
  }
  finalScored.sort((a, b2) => b2.score - a.score
    || (Number(b2.entry.importance) || 3) - (Number(a.entry.importance) || 3)
    || (Number(b2.entry.updatedAt) || 0) - (Number(a.entry.updatedAt) || 0));
  return finalScored.map((item) => item.entry);
}

function countTokens(tokens) {
  const map = new Map();
  for (const token of tokens) map.set(token, (map.get(token) || 0) + 1);
  return map;
}

function stringSimilarity(a, b2) {
  const setA = new Set(tokenizeForSearch(a));
  const setB = new Set(tokenizeForSearch(b2));
  if (!setA.size || !setB.size) return 0;
  let inter = 0;
  for (const token of setA) if (setB.has(token)) inter += 1;
  return inter / (setA.size + setB.size - inter);
}

/**
 * 自动压缩/摘要：
 * - 合并同 scope 下高度相似（或完全重复）的条目，标签/重要度取并集；
 * - 每个 scope 超过 maxPerScope 时，把较旧/较低重要度的条目抽取成一条“自动摘要”；
 * - 最后按总上限淘汰。
 * @returns {{merged:number,dropped:number,digests:number,before:number,after:number}}
 */
export function compressSharedMemory(state, options = {}) {
  const stats = { merged: 0, dropped: 0, digests: 0, before: 0, after: 0 };
  if (!state || !Array.isArray(state.entries)) return stats;
  stats.before = state.entries.length;
  const now = Number(options.now) > 0 ? Number(options.now) : Date.now();
  const maxPerScope = clampInt(options.maxPerScope, 5, 500, 40);
  const keepPerScope = clampInt(options.keepPerScope, 3, maxPerScope, Math.max(3, maxPerScope - 10));
  const similarityThreshold = Math.min(0.99, Math.max(0.5, Number(options.similarityThreshold) || 0.9));
  const maxEntries = clampInt(options.maxEntries, 20, 5000, 400);

  const groups = new Map();
  for (const entry of state.entries) {
    if (!entry) continue;
    const groupKey = `${entry.characterId || ''}\u0000${entry.scope}:${entry.scopeId ?? ''}`;
    if (!groups.has(groupKey)) groups.set(groupKey, []);
    groups.get(groupKey).push(entry);
  }

  const result = [];
  for (const group of groups.values()) {
    group.sort((a, b2) => (Number(b2.importance) || 3) - (Number(a.importance) || 3)
      || (Number(b2.updatedAt) || 0) - (Number(a.updatedAt) || 0));
    const kept = [];
    for (const entry of group) {
      let mergedInto = null;
      for (const target of kept) {
        if (target.tags?.includes('自动摘要') || entry.tags?.includes('自动摘要')) continue;
        const similar = String(target.content) === String(entry.content)
          || stringSimilarity(target.content, entry.content) >= similarityThreshold;
        if (similar) { mergedInto = target; break; }
      }
      if (mergedInto) {
        mergeEntryInto(mergedInto, entry, now);
        stats.merged += 1;
      } else {
        kept.push({ ...entry });
      }
    }
    if (kept.length > maxPerScope) {
      const overflow = kept.slice(keepPerScope);
      const base = kept.slice(0, keepPerScope);
      const existingDigest = base.find((e) => e.tags?.includes('自动摘要'));
      const digestEntries = [...overflow, ...(existingDigest ? [existingDigest] : [])];
      const digestContent = `（自动摘要）${digestEntries.slice(0, 10).map((e) => e.content).join('；')}`.slice(0, 300);
      const digest = {
        id: existingDigest?.id || randomId(),
        scope: overflow[0].scope,
        scopeId: overflow[0].scopeId ?? '',
        characterId: overflow[0].characterId || '',
        content: digestContent,
        tags: ['自动摘要'],
        visibility: digestEntries.every((e) => e.visibility === 'public')
          ? 'public'
          : digestEntries.every((e) => e.visibility !== 'private') ? 'shared' : 'private',
        importance: Math.max(...digestEntries.map((e) => Number(e.importance) || 3)),
        subjectName: '',
        source: { key: '@auto-digest', kind: '', id: '' },
        createdAt: existingDigest?.createdAt || now,
        updatedAt: now,
        lastUsedAt: 0
      };
      result.push(...base.filter((e) => e !== existingDigest), digest);
      stats.digests += 1;
      stats.dropped += overflow.length;
    } else {
      result.push(...kept);
    }
  }

  state.entries = result;
  pruneSharedMemory(state, { now, maxEntries });
  stats.after = state.entries.length;
  return stats;
}

function mergeEntryInto(target, incoming, now) {
  const targetImp = Number(target.importance) || 3;
  const incomingImp = Number(incoming.importance) || 3;
  if (incomingImp > targetImp
    || (incomingImp === targetImp && String(incoming.content).length > String(target.content).length)) {
    target.content = incoming.content;
  }
  target.tags = [...new Set([...(target.tags || []), ...(incoming.tags || [])])].slice(0, 8);
  target.importance = Math.max(targetImp, incomingImp);
  target.updatedAt = Math.max(Number(target.updatedAt) || 0, Number(incoming.updatedAt) || 0, now);
  target.visibility = target.visibility === 'public' && incoming.visibility === 'public'
    ? 'public'
    : target.visibility === 'shared' && incoming.visibility === 'shared' ? 'shared' : 'private';
  if (!target.characterId && incoming.characterId) target.characterId = incoming.characterId;
  if (incoming.subjectName) target.subjectName = target.subjectName || incoming.subjectName;
}

/**
 * 把与当前会话相关的共享记忆格式化成唤醒提示词里的一段。
 * @param {{version:number,entries:object[]}} state
 * @param {{kind?:'group'|'private',groupId?:string,uin?:string,participants?:Array<{uin?:string,name?:string}>}} ctx
 * @param {{promptMaxChars?:number,globalLimit?:number,userLimit?:number,groupLimit?:number,crossGroupLimit?:number,queryText?:string,allowPublicUserMemoryInGroups?:boolean,now?:number}} options
 */
export function formatSharedMemoryForPrompt(state, ctx = {}, options = {}) {
  if (!state || !Array.isArray(state.entries) || state.entries.length === 0) return '';
  const characterFilter = String(options.characterId ?? '').trim();
  const entries = characterFilter
    ? state.entries.filter((e) => !e.characterId || e.characterId === '*' || e.characterId === characterFilter)
    : state.entries;
  if (!entries.length) return '';
  const kind = ctx.kind === 'group' ? 'group' : ctx.kind === 'private' ? 'private' : '';
  const groupId = String(ctx.groupId ?? '').trim();
  const uin = String(ctx.uin ?? '').trim();
  const participants = Array.isArray(ctx.participants) ? ctx.participants : [];
  const participantUins = [];
  const participantNames = new Map();
  for (const p of participants.slice(0, 8)) {
    const id = String(p?.uin ?? '').trim();
    if (!id || !/^\d+$/.test(id)) continue;
    if (!participantUins.includes(id)) participantUins.push(id);
    const name = normalizeText(p?.name, MAX_SOURCE_NAME);
    if (name) participantNames.set(id, name);
  }
  const globalLimit = clampInt(options.globalLimit, 1, 50, 10);
  const userLimit = clampInt(options.userLimit, 0, 50, 8);
  const groupLimit = clampInt(options.groupLimit, 0, 50, 8);
  const crossGroupLimit = clampInt(options.crossGroupLimit, 0, 50, 5);
  const maxChars = clampInt(options.promptMaxChars, 200, 6000, 1800);
  const allowPublicInGroups = options.allowPublicUserMemoryInGroups !== false;
  const allowAllCrossGroups = options.allowedCrossGroupIds === '*' || options.allowedCrossGroupIds === true
    || options.allowedCrossSources === '*';
  const rawCrossSources = Array.isArray(options.allowedCrossSources)
    ? options.allowedCrossSources
    : (Array.isArray(options.allowedCrossGroupIds)
      ? options.allowedCrossGroupIds.map((id) => `group:${String(id ?? '').trim()}`)
      : []);
  const allowedGroupSourceSet = new Set();
  const allowedPrivateSourceSet = new Set();
  for (const source of rawCrossSources) {
    const text = String(source ?? '').trim();
    const groupMatch = /^group:(\d+)$/.exec(text);
    if (groupMatch) { allowedGroupSourceSet.add(groupMatch[1]); continue; }
    const privateMatch = /^private:(\d+)$/.exec(text);
    if (privateMatch) allowedPrivateSourceSet.add(privateMatch[1]);
  }
  const sourceNames = options.sourceNames && typeof options.sourceNames === 'object'
    ? options.sourceNames
    : (options.crossGroupNames && typeof options.crossGroupNames === 'object' ? options.crossGroupNames : {});
  const now = Number(options.now) > 0 ? Number(options.now) : Date.now();
  const queryText = String(options.queryText ?? '').trim();

  const sortEntries = (list) => [...list].sort((a, b) => (Number(b.importance) || 3) - (Number(a.importance) || 3)
    || (Number(b.updatedAt) || 0) - (Number(a.updatedAt) || 0));
  const rankEntries = (list) => queryText
    ? rankMemoryEntries(list, queryText, { now })
    : sortEntries(list);

  const globals = rankEntries(entries.filter((e) => e.scope === 'global')).slice(0, globalLimit);
  const groups = kind === 'group' && groupId && groupLimit > 0
    ? rankEntries(entries.filter((e) => e.scope === 'group' && e.scopeId === groupId)).slice(0, groupLimit)
    : [];
  // 跨群记忆：public 永远可见；private 群记忆只有在访问矩阵授权了该来源群时才可见。
  const crossGroups = crossGroupLimit > 0
    ? rankEntries(entries.filter((e) => e.scope === 'group'
      && e.scopeId !== groupId
      && (e.visibility === 'public' || allowAllCrossGroups || allowedGroupSourceSet.has(e.scopeId)))).slice(0, crossGroupLimit)
    : [];
  const usersById = new Map();
  const addUser = (entry) => { if (entry && !usersById.has(entry.id)) usersById.set(entry.id, entry); };
  if (kind === 'private' && uin) {
    // 自己的用户记忆全可见。
    for (const entry of entries) {
      if (entry.scope === 'user' && entry.scopeId === uin) addUser(entry);
    }
  }
  // public = 所有会话可见；group 模式受 allowPublicInGroups 开关约束。
  if (kind === 'private' || allowPublicInGroups) {
    for (const entry of entries) {
      if (entry.scope === 'user' && entry.visibility === 'public') addUser(entry);
    }
  }
  // 被授权的私聊来源：只暴露 shared/public，private 永远不出私聊。
  for (const entry of entries) {
    if (entry.scope !== 'user') continue;
    if (entry.scopeId === uin) continue;
    if (entry.visibility !== 'shared' && entry.visibility !== 'public') continue;
    if (allowAllCrossGroups || allowedPrivateSourceSet.has(entry.scopeId)) addUser(entry);
  }
  const users = userLimit > 0 ? rankEntries([...usersById.values()]).slice(0, userLimit) : [];

  const header = '【跨会话记忆】你记得这些（不同群/私聊共享；只在自然相关时提，别硬聊；私聊里听到的事不要在群里说，不同群之间不要互相引用——标成“跨群公开”或“你被授权读取”的除外）：';
  const lines = [];
  const pushSection = (label, entries, labelFor) => {
    for (const entry of entries) {
      lines.push(`- ${labelFor(entry, label)}：${entry.content}`);
    }
  };
  pushSection('全局', globals, () => '全局');
  pushSection('本群', groups, () => '本群');
  pushSection('跨群', crossGroups, (entry) => {
    const name = sourceNames[`group:${entry.scopeId}`] || sourceNames[entry.scopeId];
    return name ? `跨群·${name}` : `跨群·${entry.scopeId}`;
  });
  pushSection('用户', users, (entry) => {
    const name = entry.subjectName
      || sourceNames[`private:${entry.scopeId}`]
      || participantNames.get(entry.scopeId)
      || `QQ ${entry.scopeId}`;
    if (entry.scopeId === uin) return `关于 ${name}`;
    if (entry.visibility === 'public') return `关于 ${name}（公开）`;
    return `关于 ${name}（私聊授权）`;
  });
  if (lines.length === 0) return '';

  const out = [header];
  let used = header.length;
  for (const line of lines) {
    if (used + line.length + 1 > maxChars) break;
    out.push(line);
    used += line.length + 1;
  }
  return out.join('\n');
}

/** 给调试/控制台用：返回一份可序列化的摘要，不包含内部缓存字段。 */
export function summarizeSharedMemory(state) {
  const entries = state && Array.isArray(state.entries) ? state.entries : [];
  const counts = { global: 0, user: 0, group: 0 };
  for (const entry of entries) if (entry && counts[entry.scope] != null) counts[entry.scope] += 1;
  return { total: entries.length, counts };
}
