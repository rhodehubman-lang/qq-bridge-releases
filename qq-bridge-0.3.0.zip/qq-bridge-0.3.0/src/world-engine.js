// 世界动态引擎：每小时检查、每天随机事件预算、角色感知延迟。
// 真实事件存在 world.events 里；角色是否知道存在 known/knownAt 里。

export const WORLD_VERSION = 1;

const EVENT_TEMPLATES = [
  {
    type: 'transit', channel: 'news', weight: 12, severity: 2,
    headlines: ['公交线路临时改道', '地铁信号故障停运半小时', '晚高峰堵成一条红线'],
    details: ['站台上全是等车的人，广播循环播放同一句道歉。', '打车软件显示前方排队 47 人，价格翻了三倍。'],
    locations: ['transit', 'old_town', 'downtown'],
    effects: { commuteExtraMinutes: 15 }
  },
  {
    type: 'security', channel: 'social', weight: 10, severity: 3,
    headlines: ['街口临时设卡检查', '巡逻车明显变多了', '两所学校门口加派了保安'],
    details: ['路过的人被要求出示证件，队伍排到了马路对面。', '社区群里说只是例行检查，但没人说得清例行到什么时候。'],
    locations: ['old_town', 'downtown', 'transit'],
    effects: { districtDanger: 1 }
  },
  {
    type: 'corp', channel: 'news', weight: 10, severity: 2,
    headlines: ['某公司宣布裁员', '新品牌广告占领大屏', '写字楼又空了两层'],
    details: ['被裁的人抱着纸箱站在楼下，HR 说会按流程办。', '广告里的笑脸比真人还真，底下小字写着分期利息。'],
    locations: ['downtown'],
    effects: {}
  },
  {
    type: 'weather', channel: 'ambient', weight: 14, severity: 1,
    headlines: ['雨下了一整天', '空气里有股潮味', '今晚降温，风很大'],
    details: ['窗外的霓虹被雨水泡开，整条街像一张没洗干净的底片。', '晾在阳台的衣服又白洗了，楼下传来收摊的卷帘门声。'],
    locations: ['home', 'old_town', 'downtown'],
    effects: { moodDelta: -1 }
  },
  {
    type: 'social', channel: 'local', weight: 10, severity: 1,
    headlines: ['楼下小店换了新老板', '社区广场在办旧物市集', '街角早餐铺排起了队'],
    details: ['新老板说先干一个月看看，价格没敢涨。', '市集上有人拿旧书换了盆花，聊得比买卖还认真。'],
    locations: ['local_market', 'cafe', 'old_town'],
    effects: { moodDelta: 1 }
  },
  {
    type: 'crime', channel: 'social', weight: 5, severity: 4,
    headlines: ['旧城区发生一起盗窃案', '有人在公交上被偷了手机', '群里提醒最近有诈骗电话'],
    details: ['消息在社交媒体上炸开，配图是模糊的街角和一辆停歪的车。', '派出所贴了告示，让大家晚上尽量结伴走。'],
    locations: ['old_town', 'transit'],
    effects: { commuteExtraMinutes: 30, districtDanger: 2, moodDelta: -3 }
  },
  {
    type: 'city', channel: 'news', weight: 8, severity: 2,
    headlines: ['市中心大屏换成了新广告', '房租又涨了', '城市宣布新的夜间管理草案'],
    details: ['大屏上是一张不认识的脸，底下有人举着牌子抗议。', '房东发来消息时只用了四个字：下月涨租。'],
    locations: ['downtown', 'home'],
    effects: { moodDelta: -2 }
  },
  {
    type: 'rumor', channel: 'rumor', weight: 7, severity: 2,
    headlines: ['有人在传一个都市传说', '常客说附近诊所出事了', '群里在传一段模糊视频'],
    details: ['没人能确认真假，但所有人都在讲；到最后连讲的人都信了。', '视频里只有雨声和一段听不清的尖叫。'],
    locations: ['cafe', 'old_town'],
    effects: {}
  }
];

function hashSeed(text) {
  let h = 2166136261;
  for (const ch of String(text)) {
    h ^= ch.codePointAt(0);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function emptyWorld(profileId = '') {
  // auto=false：新安装/新角色默认不自动生成世界事件，必须由用户在控制台显式开启。
  return { version: WORLD_VERSION, profileId, day: '', budget: 0, generatedToday: 0, lastTickAt: 0, auto: false, events: [] };
}

// 每个角色在每个世界里有一份独立认知；世界真相共享，认知不共享。
export function emptyKnowledge(characterId = '') {
  return { version: 1, characterId, knownEvents: {} };
}

export function normalizeKnowledge(raw, characterId = '') {
  const src = raw && typeof raw === 'object' ? raw : {};
  const known = src.knownEvents && typeof src.knownEvents === 'object' ? src.knownEvents : {};
  const out = {};
  for (const [id, value] of Object.entries(known)) {
    if (!id || !value || typeof value !== 'object') continue;
    out[id] = {
      knownAt: Number(value.knownAt) || 0,
      via: String(value.via || '').slice(0, 40),
      status: ['unknown', 'rumor', 'confirmed'].includes(value.status) ? value.status : 'rumor',
      version: String(value.version || '').slice(0, 600)
    };
  }
  return { version: 1, characterId, knownEvents: out };
}

export function dayKey(now = Date.now()) {
  return new Date(now).toLocaleDateString('en-CA');
}

function rollDailyBudget(world, now) {
  const rng = mulberry32(hashSeed(`${world.profileId}:${dayKey(now)}`));
  const r = rng();
  // 0~4 件；大事稀有。
  if (r < 0.28) return 0;
  if (r < 0.58) return 1;
  if (r < 0.82) return 2;
  if (r < 0.95) return 3;
  return 4;
}

function pruneEvents(world, now) {
  const cutoff = now - 7 * 24 * 60 * 60 * 1000;
  world.events = (world.events || []).filter((e) => Number(e.at) >= cutoff).slice(-300);
}

function pickTemplate(rng) {
  const total = EVENT_TEMPLATES.reduce((s, t) => s + t.weight, 0);
  let n = rng() * total;
  for (const t of EVENT_TEMPLATES) {
    n -= t.weight;
    if (n <= 0) return t;
  }
  return EVENT_TEMPLATES[0];
}

export function generateEvent(world, now = Date.now()) {
  const rng = mulberry32(hashSeed(`${world.profileId}:${dayKey(now)}:${world.events.length}:${now}`));
  const t = pickTemplate(rng);
  const headline = t.headlines[Math.floor(rng() * t.headlines.length)];
  const detail = t.details[Math.floor(rng() * t.details.length)];
  const severity = t.severity + (rng() < 0.08 ? 1 : 0);
  const event = {
    id: `evt_${now.toString(36)}_${world.events.length}`,
    at: now,
    type: t.type,
    channel: t.channel,
    headline,
    detail,
    severity,
    locations: t.locations || [],
    effects: t.effects || {},
    known: false,
    knownAt: 0,
    discoveredVia: ''
  };
  world.events.push(event);
  world.events = world.events.slice(-300);
  return event;
}

export function advanceWorld(world, { now = Date.now(), force = false, generate = true } = {}) {
  const today = dayKey(now);
  if (world.day !== today) {
    world.day = today;
    world.budget = rollDailyBudget(world, now);
    world.generatedToday = 0;
  }
  pruneEvents(world, now);
  const generated = [];
  // 大模型事件接管时，模板只负责日期翻页和清理，不再偷偷生成模板事件。
  if (!generate) return { generated, budget: world.budget, generatedToday: world.generatedToday };
  if (world.generatedToday < world.budget && (force || now - Number(world.lastTickAt) >= 55 * 60 * 1000)) {
    const event = generateEvent(world, now);
    world.generatedToday += 1;
    world.lastTickAt = now;
    generated.push(event);
  } else if (force && world.generatedToday === 0) {
    const event = generateEvent(world, now);
    world.generatedToday += 1;
    world.lastTickAt = now;
    generated.push(event);
  }
  return { generated, budget: world.budget, generatedToday: world.generatedToday };
}

function distanceAware(event, lifeState, now) {
  const at = Number(event.at) || 0;
  const age = now - at;
  const delay = event.channel === 'news' ? 20 * 60 * 1000
    : event.channel === 'social' ? 12 * 60 * 1000
    : event.channel === 'local' ? 2 * 60 * 1000
    : 30 * 60 * 1000;
  if (age < delay) return false;
  const atLocation = lifeState && event.locations?.includes(lifeState.locationId);
  if (event.channel === 'ambient') return true;
  if (event.channel === 'local') return !!atLocation;
  if (atLocation) return true;
  const r = mulberry32(hashSeed(`${event.id}:${dayKey(now)}`))();
  if (event.channel === 'news') return r < 0.45;
  if (event.channel === 'social') return r < 0.35;
  if (event.channel === 'rumor') return (lifeState?.state === 'working' || lifeState?.state === 'free') && r < 0.35;
  return false;
}

export function discoverEvents(world, { now = Date.now(), lifeState = null, knowledge = null } = {}) {
  const discovered = [];
  for (const event of world.events || []) {
    if (!event) continue;
    if (knowledge) {
      if (knowledge.knownEvents?.[event.id]) continue;
    } else if (event.known) {
      continue;
    }
    if (!distanceAware(event, lifeState, now)) continue;
    const via = event.channel === 'news' ? '新闻'
      : event.channel === 'social' ? '社交媒体'
      : event.channel === 'local' ? '亲眼看到'
      : event.channel === 'rumor' ? '听人说的'
      : '天气';
    if (knowledge) {
      if (!knowledge.knownEvents) knowledge.knownEvents = {};
      knowledge.knownEvents[event.id] = {
        knownAt: now,
        via,
        status: event.channel === 'local' || event.channel === 'rumor' ? 'rumor' : 'confirmed',
        version: event.detail || ''
      };
    } else {
      event.known = true;
      event.knownAt = now;
      event.discoveredVia = via;
    }
    discovered.push(event);
  }
  return discovered;
}

export function formatWorldPrompt(world, { now = Date.now(), lifeState = null, knowledge = null } = {}) {
  const discovered = discoverEvents(world, { now, lifeState, knowledge });
  const isKnown = (event) => knowledge
    ? !!knowledge.knownEvents?.[event.id]
    : !!event.known;
  const known = (world.events || [])
    .filter((e) => isKnown(e) && now - Number(e.at) < 24 * 60 * 60 * 1000)
    .slice(-3);
  if (!known.length) return { text: '', discovered };
  const lines = ['【城市近况】以下是你知道的最近城市动态；不知道的事不要编：'];
  for (const event of known) {
    const tag = discovered.includes(event) ? '刚听说' : '';
    const memory = knowledge?.knownEvents?.[event.id];
    const heard = memory && memory.version && memory.version !== event.detail ? `（你听到的版本：${memory.version}）` : '';
    lines.push(`- ${event.headline}${tag ? `（${tag}）` : ''}：${event.detail}${heard}`);
  }
  const effects = known.flatMap((e) => {
    const out = [];
    if (e.effects?.commuteExtraMinutes) out.push(`通勤可能多花 ${e.effects.commuteExtraMinutes} 分钟`);
    if (e.effects?.shiftDelayMinutes) out.push(`上班可能晚到 ${e.effects.shiftDelayMinutes} 分钟`);
    if (e.effects?.districtDanger >= 2) out.push('附近不太安全');
    return out;
  });
  if (effects.length) lines.push(`【日程影响】${[...new Set(effects)].join('；')}。`);
  return { text: lines.join('\n'), discovered };
}
