// 通用「角色生活引擎」：时区、上X休Y/按星期、硬日程、状态、地点、短期状态、提示词。
// 这个模块不包含任何具体角色逻辑；所有角色差异都在 life-profiles/<id>.json 里。

export const LIFE_VERSION = 1;
export const WEEKDAY_KEYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
export const WEEKDAY_LABELS = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
const DEFAULT_TZ = 'Asia/Shanghai';

function pad2(n) { return String(n).padStart(2, '0'); }

export function hhmmToMinutes(value) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(value ?? '').trim());
  if (!m) return null;
  const hour = Number(m[1]);
  const minute = Number(m[2]);
  if (!Number.isInteger(hour) || !Number.isInteger(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
  return hour * 60 + minute;
}

export function minutesToHHMM(value) {
  const n = Math.max(0, Math.min(24 * 60 - 1, Math.round(Number(value) || 0)));
  return `${pad2(Math.floor(n / 60))}:${pad2(n % 60)}`;
}

function validTimeZone(timeZone) {
  try { new Intl.DateTimeFormat('en-US', { timeZone }).format(new Date()); return true; } catch { return false; }
}

export function getZonedParts(ms, timeZone = DEFAULT_TZ) {
  const tz = validTimeZone(timeZone) ? timeZone : DEFAULT_TZ;
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: tz,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    weekday: 'short', hourCycle: 'h23'
  }).formatToParts(new Date(Number(ms) || Date.now()));
  const map = {};
  for (const part of parts) if (part.type !== 'literal') map[part.type] = part.value;
  const dateKey = `${map.year}-${map.month}-${map.day}`;
  const minuteOfDay = (Number(map.hour) % 24) * 60 + Number(map.minute);
  const weekdayIndex = WEEKDAY_KEYS.indexOf(String(map.weekday || '').slice(0, 3).toLowerCase());
  return {
    timeZone: tz,
    dateKey,
    year: Number(map.year),
    month: Number(map.month),
    day: Number(map.day),
    hour: Number(map.hour) % 24,
    minute: Number(map.minute),
    second: Number(map.second),
    minuteOfDay,
    weekdayIndex: weekdayIndex >= 0 ? weekdayIndex : 0,
    weekdayKey: WEEKDAY_KEYS[weekdayIndex >= 0 ? weekdayIndex : 0],
    weekdayLabel: WEEKDAY_LABELS[weekdayIndex >= 0 ? weekdayIndex : 0],
    timeText: `${dateKey} ${pad2(Number(map.hour) % 24)}:${map.minute} ${WEEKDAY_LABELS[weekdayIndex >= 0 ? weekdayIndex : 0]}`
  };
}

export function addDaysToDateKey(dateKey, delta) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(dateKey));
  if (!m) return String(dateKey);
  const d = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
  d.setUTCDate(d.getUTCDate() + Number(delta || 0));
  return `${d.getUTCFullYear()}-${pad2(d.getUTCMonth() + 1)}-${pad2(d.getUTCDate())}`;
}

export function daysBetweenDateKeys(a, b) {
  const parse = (key) => {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(key));
    return m ? Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : null;
  };
  const aa = parse(a);
  const bb = parse(b);
  if (aa === null || bb === null) return 0;
  return Math.round((bb - aa) / 86400000);
}

export function normalizeLifeProfile(raw) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const schedule = src.schedule && typeof src.schedule === 'object' ? src.schedule : {};
  const sleep = schedule.sleep && typeof schedule.sleep === 'object' ? schedule.sleep : {};
  const shift = schedule.shift && typeof schedule.shift === 'object' ? schedule.shift : {};
  const freeTime = src.freeTime && typeof src.freeTime === 'object' ? src.freeTime : {};
  const world = src.world && typeof src.world === 'object' ? src.world : {};
  const locations = Array.isArray(src.locations) ? src.locations : [];
  const cleanLocations = [];
  const seen = new Set();
  for (const item of locations) {
    if (!item || typeof item !== 'object') continue;
    const id = String(item.id ?? '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '_').slice(0, 64);
    if (!id || seen.has(id)) continue;
    seen.add(id);
    cleanLocations.push({
      id,
      name: String(item.name ?? id).trim().slice(0, 64),
      description: String(item.description ?? '').trim().slice(0, 600),
      openHours: String(item.openHours ?? '').trim().slice(0, 64)
    });
  }
  const weekly = {};
  const rawWeekly = schedule.weekly && typeof schedule.weekly === 'object' ? schedule.weekly : {};
  for (const day of WEEKDAY_KEYS) weekly[day] = rawWeekly[day] === 'rest' ? 'rest' : 'work';
  const overrides = {};
  if (schedule.overrides && typeof schedule.overrides === 'object') {
    for (const [date, value] of Object.entries(schedule.overrides)) {
      if (/^\d{4}-\d{2}-\d{2}$/.test(date) && (value === 'work' || value === 'rest')) overrides[date] = value;
    }
  }
  return {
    version: LIFE_VERSION,
    id: String(src.id ?? 'character').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '_').slice(0, 64) || 'character',
    displayName: String(src.displayName ?? src.id ?? '角色').trim().slice(0, 64) || '角色',
    // 对应 roles/<名字>.md 里的角色名；用于切换角色时自动加载这份生活档案。
    roleName: String(src.roleName ?? src.displayName ?? src.id ?? '角色').trim().slice(0, 64) || '角色',
    timezone: validTimeZone(src.timezone) ? String(src.timezone) : DEFAULT_TZ,
    world: {
      name: String(world.name ?? '').trim().slice(0, 64),
      summary: String(world.summary ?? '').trim().slice(0, 1200),
      lore: Array.isArray(world.lore)
        ? world.lore.map((x) => String(x ?? '').trim().slice(0, 240)).filter(Boolean).slice(0, 12)
        : []
    },
    homeLocation: String(src.homeLocation ?? 'home').trim().toLowerCase() || 'home',
    workLocation: String(src.workLocation ?? 'work').trim().toLowerCase() || 'work',
    locations: cleanLocations,
    schedule: {
      mode: schedule.mode === 'weekly' ? 'weekly' : 'cycle',
      anchorDate: /^\d{4}-\d{2}-\d{2}$/.test(String(schedule.anchorDate ?? '')) ? String(schedule.anchorDate) : '2026-01-05',
      workDays: Math.max(1, Math.min(60, Math.round(Number(schedule.workDays) || 5))),
      restDays: Math.max(1, Math.min(60, Math.round(Number(schedule.restDays) || 2))),
      weekly,
      shift: { start: hhmmToMinutes(shift.start) !== null ? String(shift.start) : '09:00', end: hhmmToMinutes(shift.end) !== null ? String(shift.end) : '18:00' },
      sleep: { start: hhmmToMinutes(sleep.start) !== null ? String(sleep.start) : '23:00', end: hhmmToMinutes(sleep.end) !== null ? String(sleep.end) : '07:00' },
      wakeBeforeShiftMinutes: Math.max(0, Math.min(240, Math.round(Number(schedule.wakeBeforeShiftMinutes) || 90))),
      commuteMinutes: Math.max(0, Math.min(180, Math.round(Number(schedule.commuteMinutes) || 30))),
      restWakingMinutes: Math.max(0, Math.min(240, Math.round(Number(schedule.restWakingMinutes) || 60))),
      overrides
    },
    freeTime: {
      allowedLocations: Array.isArray(freeTime.allowedLocations)
        ? [...new Set(freeTime.allowedLocations.map((x) => String(x).trim().toLowerCase()).filter(Boolean))]
        : cleanLocations.map((x) => x.id),
      defaultLocation: String(freeTime.defaultLocation ?? src.homeLocation ?? 'home').trim().toLowerCase() || 'home',
      activities: Array.isArray(freeTime.activities)
        ? freeTime.activities.map((x) => String(x).trim()).filter(Boolean).slice(0, 20)
        : []
    },
    responsePolicy: {
      sleeping: String(src.responsePolicy?.sleeping ?? '').trim().slice(0, 600),
      waking: String(src.responsePolicy?.waking ?? '').trim().slice(0, 600),
      commute: String(src.responsePolicy?.commute ?? '').trim().slice(0, 600),
      working: String(src.responsePolicy?.working ?? '').trim().slice(0, 600),
      free: String(src.responsePolicy?.free ?? '').trim().slice(0, 600)
    }
  };
}

/** 校验档案；返回 {ok, errors, profile}。 */
export function validateLifeProfile(raw) {
  const profile = normalizeLifeProfile(raw);
  const errors = [];
  if (!/^[a-z0-9_-]{1,64}$/.test(profile.id)) errors.push('id 只能用小写字母/数字/下划线/短横线');
  if (!validTimeZone(profile.timezone)) errors.push('timezone 不是合法 IANA 时区');
  if (!profile.locations.length) errors.push('至少需要一个地点');
  const locationIds = new Set(profile.locations.map((x) => x.id));
  if (!locationIds.has(profile.homeLocation)) errors.push('homeLocation 不在 locations 里');
  if (!locationIds.has(profile.workLocation)) errors.push('workLocation 不在 locations 里');
  if (hhmmToMinutes(profile.schedule.shift.start) === null || hhmmToMinutes(profile.schedule.shift.end) === null) errors.push('班次时间格式应为 HH:MM');
  if (hhmmToMinutes(profile.schedule.sleep.start) === null || hhmmToMinutes(profile.schedule.sleep.end) === null) errors.push('睡眠时间格式应为 HH:MM');
  if (hhmmToMinutes(profile.schedule.shift.start) >= hhmmToMinutes(profile.schedule.shift.end)) errors.push('班次结束时间必须晚于开始时间');
  if (profile.schedule.mode === 'cycle') {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(profile.schedule.anchorDate)) errors.push('anchorDate 格式应为 YYYY-MM-DD');
    if (profile.schedule.workDays < 1 || profile.schedule.restDays < 1) errors.push('上X休Y的天数必须至少为 1');
  }
  if (!profile.freeTime.allowedLocations.length) errors.push('自由活动至少允许一个地点');
  for (const id of profile.freeTime.allowedLocations) if (!locationIds.has(id)) errors.push(`自由活动地点不存在：${id}`);
  if (!locationIds.has(profile.freeTime.defaultLocation)) errors.push('freeTime.defaultLocation 不在 locations 里');
  return { ok: errors.length === 0, errors, profile };
}

/** 计算某天是 work 还是 rest。 */
export function dayTypeFor(profile, dateKey) {
  const p = normalizeLifeProfile(profile);
  const override = p.schedule.overrides[dateKey];
  if (override === 'work' || override === 'rest') return override;
  if (p.schedule.mode === 'weekly') {
    // dateKey 的星期几需要算出来（用 UTC 避免系统时区影响）
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(dateKey));
    if (!m) return 'rest';
    const idx = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]))).getUTCDay();
    return p.schedule.weekly[WEEKDAY_KEYS[idx]] === 'rest' ? 'rest' : 'work';
  }
  const diff = daysBetweenDateKeys(p.schedule.anchorDate, dateKey);
  const period = p.schedule.workDays + p.schedule.restDays;
  const index = ((diff % period) + period) % period;
  return index < p.schedule.workDays ? 'work' : 'rest';
}

function locationById(profile, id) {
  return profile.locations.find((x) => x.id === id) || { id, name: id, description: '', openHours: '' };
}

function blockCommon(profile, state, blockId, blockLabel, locationId, activity, sinceMinute, untilMinute, policyKey) {
  const location = locationId === '__commute__'
    ? { id: '__commute__', name: '通勤路上', description: '正在城市里赶路，周围是潮湿的街道和霓虹灯。' }
    : locationById(profile, locationId);
  return {
    profileId: profile.id,
    displayName: profile.displayName,
    timeZone: profile.timezone,
    blockId,
    state,
    statusLabel: blockLabel,
    locationId: location.id,
    locationName: location.name,
    locationDescription: location.description,
    activity,
    sinceMinute,
    untilMinute,
    sinceText: sinceMinute == null ? '' : minutesToHHMM(sinceMinute),
    untilText: untilMinute == null ? '' : minutesToHHMM(untilMinute),
    tone: policyKey || state,
    policyKey: policyKey || state
  };
}

/**
 * 计算当前生活状态。
 * @param {object} profileRaw
 * @param {object} persisted 上一轮保存的状态
 * @param {number} nowMs
 */
export function resolveLifeState(profileRaw, persisted = {}, nowMs = Date.now()) {
  const profile = normalizeLifeProfile(profileRaw);
  const parts = getZonedParts(nowMs, profile.timezone);
  const minute = parts.minuteOfDay;
  const sleepStart = hhmmToMinutes(profile.schedule.sleep.start);
  const sleepEnd = hhmmToMinutes(profile.schedule.sleep.end);
  const shiftStart = hhmmToMinutes(profile.schedule.shift.start);
  const shiftEnd = hhmmToMinutes(profile.schedule.shift.end);
  const workday = dayTypeFor(profile, parts.dateKey) === 'work';
  const last = persisted && typeof persisted === 'object' ? persisted : {};
  const prevActivity = String(last.activity || '');
  const home = profile.homeLocation;
  const commuteStart = shiftStart - profile.schedule.commuteMinutes;
  const wakeStart = shiftStart - profile.schedule.wakeBeforeShiftMinutes;
  let state;
  if (sleepStart > sleepEnd) {
    if (minute >= sleepStart || minute < sleepEnd) {
      const since = minute >= sleepStart ? sleepStart : sleepStart;
      state = blockCommon(profile, 'sleeping', `${parts.dateKey}:sleep`, '睡觉', home, '睡觉', since, sleepEnd, 'sleeping');
    }
  } else if (minute >= sleepStart && minute < sleepEnd) {
    state = blockCommon(profile, 'sleeping', `${parts.dateKey}:sleep`, '睡觉', home, '睡觉', sleepStart, sleepEnd, 'sleeping');
  }
  if (!state && workday) {
    if (minute >= wakeStart && minute < commuteStart) {
      state = blockCommon(profile, 'waking', `${parts.dateKey}:wake`, '刚起床', home, '刚醒，洗漱、吃点东西', wakeStart, commuteStart, 'waking');
    } else if (minute >= commuteStart && minute < shiftStart) {
      state = blockCommon(profile, 'commute', `${parts.dateKey}:commute`, '通勤', '__commute__', '走在去上班的路上', commuteStart, shiftStart, 'commute');
    } else if (minute >= shiftStart && minute < shiftEnd) {
      state = blockCommon(profile, 'working', `${parts.dateKey}:work`, '上班中', profile.workLocation, '在上班，手头有工作', shiftStart, shiftEnd, 'working');
    } else if (minute >= shiftEnd && minute < sleepStart) {
      const blockId = `${parts.dateKey}:free-evening`;
      const plan = last.blockId === blockId && last.plannedBy === 'ai' ? last : null;
      const allowed = profile.freeTime.allowedLocations.includes(plan?.locationId)
        ? plan.locationId : profile.freeTime.defaultLocation;
      const activity = plan?.activity || profile.freeTime.activities[0] || '自由时间';
      state = blockCommon(profile, 'free', blockId, '自由时间', allowed, activity, shiftEnd, sleepStart, 'free');
      if (plan) { state.plannedBy = 'ai'; state.planLocationId = plan.locationId; }
    }
  } else if (!state) {
    // 休息日：睡眠结束后先有一段“刚醒”，之后自由活动。
    const restWakeEnd = Math.min(sleepStart, sleepEnd + profile.schedule.restWakingMinutes);
    if (minute >= sleepEnd && minute < restWakeEnd) {
      state = blockCommon(profile, 'waking', `${parts.dateKey}:wake`, '刚起床', home, '刚醒，慢慢收拾', sleepEnd, restWakeEnd, 'waking');
    } else if (minute >= restWakeEnd && minute < sleepStart) {
      const blockId = `${parts.dateKey}:free-rest`;
      const plan = last.blockId === blockId && last.plannedBy === 'ai' ? last : null;
      const allowed = profile.freeTime.allowedLocations.includes(plan?.locationId)
        ? plan.locationId : profile.freeTime.defaultLocation;
      const activity = plan?.activity || profile.freeTime.activities[0] || '自由时间';
      state = blockCommon(profile, 'free', blockId, '自由时间', allowed, activity, restWakeEnd, sleepStart, 'free');
      if (plan) { state.plannedBy = 'ai'; state.planLocationId = plan.locationId; }
    }
  }
  if (!state) {
    // 兜底：处在日程缝隙里（例如睡眠不跨天时的凌晨）按自由/在家处理。
    const blockId = `${parts.dateKey}:free-fallback`;
    const plan = last.blockId === blockId && last.plannedBy === 'ai' ? last : null;
    const allowed = profile.freeTime.allowedLocations.includes(plan?.locationId)
      ? plan.locationId : profile.freeTime.defaultLocation;
    state = blockCommon(profile, 'free', blockId, '自由时间', allowed, plan?.activity || profile.freeTime.activities[0] || '自由时间', null, sleepStart, 'free');
  }
  state.dateKey = parts.dateKey;
  state.weekdayIndex = parts.weekdayIndex;
  state.weekdayLabel = parts.weekdayLabel;
  state.timeText = parts.timeText;
  state.nowMs = Number(nowMs) || Date.now();
  state.dayType = workday ? 'work' : 'rest';
  const sameBlock = last.blockId === state.blockId;
  state.lastActivity = sameBlock ? (last.lastActivity || '') : prevActivity;
  state.since = sameBlock && Number(last.since) > 0 ? Number(last.since) : Number(nowMs) || Date.now();
  if (sameBlock && last.plannedBy === 'ai') { state.plannedBy = 'ai'; state.planLocationId = last.planLocationId || last.locationId; }
  return state;
}

/** 生成给模型看的生活上下文。 */
export function formatLifePrompt(profileRaw, state, options = {}) {
  const profile = normalizeLifeProfile(profileRaw);
  const policy = profile.responsePolicy[state.policyKey] || profile.responsePolicy[state.state] || '';
  const lines = [];
  lines.push(`【当前时间】${state.timeText}（${profile.timezone}）`);
  lines.push(`【生活状态】${state.statusLabel}｜地点：${state.locationName}｜${state.activity}`);
  if (state.sinceText) lines.push(`【从什么时候开始】${state.sinceText} 开始，${state.untilText ? `预计到 ${state.untilText}` : '暂时没有明确结束时间'}`);
  if (state.dayType === 'work') lines.push(`【今天】工作日；班次 ${profile.schedule.shift.start}–${profile.schedule.shift.end}`);
  else lines.push('【今天】休息日；没有固定工作安排');
  const worldSummary = String(profile.world.summary || '').slice(0, 500);
  if (worldSummary) lines.push(`【城市】${profile.world.name}：${worldSummary}`);
  if (Array.isArray(profile.world.lore) && profile.world.lore.length) {
    lines.push('【城市设定】');
    for (const item of profile.world.lore.slice(0, 4)) lines.push(`- ${item}`);
  }
  if (state.locationDescription) lines.push(`【环境】${state.locationDescription}`);
  if (state.lastActivity) lines.push(`【刚才】${state.lastActivity}`);
  if (policy) lines.push(`【行为规则】${policy}`);
  if (state.state === 'sleeping') {
    lines.push('【夜间】现在是睡眠时段：群聊里没有被明确点名、提问或急事就不要回复；管理员私聊可以叫醒你，但回复要短，带起床气。');
  }
  lines.push('【一致性】被问“在干嘛/在哪”时按上面的状态回答；不要主动解释“日程/状态机”，也不要假装自己随时都在营业。');
  if (state.state === 'free') {
    const locs = profile.freeTime.allowedLocations
      .map((id) => profile.locations.find((x) => x.id === id))
      .filter(Boolean)
      .map((x) => `${x.name}(${x.id})`)
      .join('、');
    if (locs) lines.push(`【自由活动】可选地点：${locs}`);
    if (profile.freeTime.activities.length) lines.push(`【自由活动】可选活动：${profile.freeTime.activities.join('；')}`);
    lines.push('现在是自由时间。你可以保持当前安排，也可以调用 qq_life_plan 从允许的地点里选一个、写一句正在做的事；选完会一直持续到本时段结束，不要每句话都换地点。');
  }
  if (options.reason === 'proactiveCheck') {
    lines.push('【主动机会】这是自由冒泡的机会，不是任务；想分享生活就发，不想说就安静收尾。');
  }
  return lines.join('\n');
}

/** 自由时段设置计划：只允许在 free 状态、允许地点内。 */
export function applyLifePlan(profileRaw, persisted, plan, nowMs = Date.now()) {
  const profile = normalizeLifeProfile(profileRaw);
  const state = resolveLifeState(profile, persisted, nowMs);
  if (state.state !== 'free') return { ok: false, error: `现在是${state.statusLabel}，不能改自由活动计划` };
  const locationId = String(plan?.locationId ?? '').trim().toLowerCase();
  if (!profile.freeTime.allowedLocations.includes(locationId)) return { ok: false, error: '这个地点不在自由活动允许列表里' };
  const activity = String(plan?.activity ?? '').trim().slice(0, 200);
  if (!activity) return { ok: false, error: 'activity 不能为空' };
  const next = {
    ...(persisted && typeof persisted === 'object' ? persisted : {}),
    blockId: state.blockId,
    state: state.state,
    locationId,
    activity,
    since: Date.now(),
    plannedBy: 'ai',
    lastActivity: state.activity,
    planLocationId: locationId,
    updatedAt: Date.now()
  };
  return { ok: true, state: resolveLifeState(profile, next, nowMs), persisted: next };
}

export function calendarForProfile(profileRaw, startDateKey, days = 30) {
  const profile = normalizeLifeProfile(profileRaw);
  const start = /^\d{4}-\d{2}-\d{2}$/.test(String(startDateKey)) ? String(startDateKey) : getZonedParts(Date.now(), profile.timezone).dateKey;
  const count = Math.max(1, Math.min(90, Number(days) || 30));
  const out = [];
  for (let i = 0; i < count; i += 1) {
    const dateKey = addDaysToDateKey(start, i);
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateKey);
    const idx = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]))).getUTCDay();
    out.push({
      dateKey,
      weekday: WEEKDAY_LABELS[idx],
      dayType: dayTypeFor(profile, dateKey),
      override: profile.schedule.overrides[dateKey] || ''
    });
  }
  return out;
}
