// 管理员安排：让操作者在控制台给某个会话（主人私聊或指定群）排“到点/看到关键词就做”的任务。
//
// 任务只负责在正确的时间/条件唤醒目标会话，并把 instructions 注入唤醒 prompt；
// 真正怎么执行仍由 agent 决定（它可能发言、记笔记、发私聊）。这里不直接发 QQ 消息，
// 避免“定时任务”绕过角色语气和发送频率闸门。

import crypto from 'node:crypto';

export const DEFAULT_OWNER_TASK_STATE = Object.freeze({ version: 1, tasks: [] });

function cleanText(value, max = 1000) {
  return String(value ?? '')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
    .replace(/\r\n?/g, '\n')
    .trim()
    .slice(0, max);
}

function normalizeClock(value) {
  const match = /^(\d{1,2}):(\d{2})$/.exec(String(value ?? '').trim());
  if (!match) return '';
  const h = Number(match[1]);
  const m = Number(match[2]);
  if (h < 0 || h > 23 || m < 0 || m > 59) return '';
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function normalizeDate(value) {
  const text = String(value ?? '').trim();
  return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : '';
}

function cleanStringArray(value, { maxItems = 10, maxChars = 30 } = {}) {
  const raw = Array.isArray(value) ? value : String(value ?? '').split(/[,，\s]+/);
  const out = [];
  for (const item of raw) {
    const text = cleanText(item, maxChars);
    if (text && !out.includes(text)) out.push(text);
    if (out.length >= maxItems) break;
  }
  return out;
}

export function localDayKey(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function minutesOfDay(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  return d.getHours() * 60 + d.getMinutes();
}

export function normalizeOwnerTask(raw) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const type = src.type === 'keyword' ? 'keyword' : src.type === 'condition' ? 'condition' : 'time';
  let target = String(src.target ?? 'owner').trim();
  if (target.startsWith('private:')) target = 'owner';
  else if (target.startsWith('group:')) target = target.slice('group:'.length);
  target = target === 'owner' ? 'owner' : String(target);
  const repeat = src.repeat === 'once' ? 'once' : src.repeat === 'weekdays' ? 'weekdays' : 'daily';
  const weekdays = (Array.isArray(src.weekdays) ? src.weekdays : String(src.weekdays ?? '').split(/[,，\s]+/))
    .map((n) => Number(n))
    .filter((n) => Number.isInteger(n) && n >= 1 && n <= 7)
    .filter((n, i, all) => all.indexOf(n) === i);
  const task = {
    id: cleanText(src.id, 80) || `task-${crypto.randomUUID()}`,
    title: cleanText(src.title, 80) || '未命名安排',
    // 安排必须知道“这是给哪个角色排的”：切换角色后不能让另一个角色替她执行。
    characterId: cleanText(src.characterId, 80),
    enabled: src.enabled !== false,
    type,
    time: normalizeClock(src.time),
    date: normalizeDate(src.date),
    repeat,
    weekdays,
    keywords: cleanStringArray(src.keywords, { maxItems: 10, maxChars: 30 }),
    groupIds: cleanStringArray(src.groupIds, { maxItems: 20, maxChars: 20 }),
    target: /^\d{3,20}$/.test(target) ? target : 'owner',
    instruction: cleanText(src.instruction, 1500),
    createdAt: Number(src.createdAt) || Date.now(),
    updatedAt: Number(src.updatedAt) || Date.now(),
    lastTriggeredAt: Number(src.lastTriggeredAt) || 0,
    lastTriggeredDay: String(src.lastTriggeredDay ?? '')
  };
  return task;
}

export function normalizeOwnerTaskState(raw) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const tasks = (Array.isArray(src.tasks) ? src.tasks : [])
    .map(normalizeOwnerTask)
    .filter((task) => task.id)
    .slice(0, 200);
  return { version: 1, tasks };
}

export function ownerTaskById(state, id) {
  const target = String(id ?? '').trim();
  if (!target) return null;
  return (state?.tasks ?? []).find((task) => task.id === target) ?? null;
}

export function upsertOwnerTask(state, raw) {
  const normalized = state && Array.isArray(state.tasks) ? state : normalizeOwnerTaskState(state);
  const task = normalizeOwnerTask(raw);
  const index = normalized.tasks.findIndex((item) => item.id === task.id);
  if (index >= 0) normalized.tasks[index] = { ...task, createdAt: normalized.tasks[index].createdAt || task.createdAt, updatedAt: Date.now() };
  else normalized.tasks.push(task);
  normalized.tasks = normalized.tasks.slice(-200);
  return normalized;
}

export function removeOwnerTask(state, id) {
  const normalized = state && Array.isArray(state.tasks) ? state : normalizeOwnerTaskState(state);
  normalized.tasks = normalized.tasks.filter((task) => task.id !== String(id ?? ''));
  return normalized;
}

/** 时间型任务：到点且当天/一次性未触发。 */
export function ownerTaskTimeDue(task, now = new Date()) {
  if (!task || task.enabled === false || task.type !== 'time' || !task.time) return false;
  const day = localDayKey(now);
  if (task.date && task.date !== day) return false;
  if (task.repeat === 'weekdays') {
    const weekday = now.getDay() === 0 ? 7 : now.getDay();
    const allowed = Array.isArray(task.weekdays) && task.weekdays.length ? task.weekdays : [1, 2, 3, 4, 5];
    if (!allowed.includes(weekday)) return false;
  }
  if (task.repeat === 'once' && task.lastTriggeredAt) return false;
  if (task.lastTriggeredDay === day) return false;
  const [h, m] = task.time.split(':').map(Number);
  const target = h * 60 + m;
  const nowMinutes = minutesOfDay(now);
  // 允许 5 分钟补触发：桥接重启/事件循环卡顿时，不因为错过整点那一分钟就丢任务。
  if (nowMinutes < target || nowMinutes > target + 5) return false;
  return true;
}

/** 关键词型任务：群消息命中关键词，且 30 分钟内没重复触发。 */
export function ownerTaskMatchesMessage(task, { groupId = '', text = '', now = new Date() } = {}) {
  if (!task || task.enabled === false || task.type !== 'keyword') return false;
  const gid = String(groupId ?? '');
  if (Array.isArray(task.groupIds) && task.groupIds.length && !task.groupIds.includes(gid)) return false;
  const lower = String(text ?? '').toLowerCase();
  if (!lower) return false;
  const hit = (task.keywords ?? []).some((kw) => kw && lower.includes(String(kw).toLowerCase()));
  if (!hit) return false;
  const at = now instanceof Date ? now.getTime() : Number(now) || Date.now();
  if (task.lastTriggeredAt && at - task.lastTriggeredAt < 30 * 60 * 1000) return false;
  return true;
}

export function markOwnerTaskTriggered(task, now = new Date()) {
  if (!task) return;
  task.lastTriggeredAt = now instanceof Date ? now.getTime() : Number(now) || Date.now();
  task.lastTriggeredDay = localDayKey(now);
  task.updatedAt = Date.now();
}

export function formatOwnerTaskPrompt(task, { now = new Date(), groupName = '' } = {}) {
  if (!task) return '';
  const where = task.target === 'owner' ? '主人私聊' : `群「${groupName || task.target}」（${task.target}）`;
  const when = task.type === 'time'
    ? `${task.repeat === 'once' ? '一次性' : task.repeat === 'weekdays' ? '工作日' : '每天'} ${task.time}${task.date ? `（${task.date}）` : ''}`
    : task.type === 'condition'
      ? '满足条件时（由你结合上下文判断）'
      : `群里出现关键词：${task.keywords.join('、')}`;
  return [
    '【管理员安排的任务】',
    `标题：${task.title}`,
    `触发：${when}`,
    `目标：${where}`,
    task.instruction ? `要做什么：${task.instruction}` : '要做什么：按当前上下文自然处理这条安排。',
    `当前时间：${new Date(now).toLocaleString('zh-CN', { hour12: false })}`,
    '执行要求：先看目标会话最近的消息，按安排行动；如果是群任务，不要暴露这是“管理员定时安排”，用角色自己的方式完成。完成后按正常收尾设置唤醒或标读。'
  ].join('\n');
}

/** 注入当前会话的任务列表；只给与它相关的任务，避免把别的群的安排泄露过去。 */
export function formatOwnerTasksContext(state, { key = '', now = new Date(), characterId = '' } = {}) {
  const groupId = String(key).startsWith('group:') ? String(key).slice('group:'.length) : '';
  const isOwner = String(key).startsWith('private:');
  const char = String(characterId ?? '').trim();
  const tasks = (state?.tasks ?? []).filter((task) => {
    if (!task || task.enabled === false) return false;
    if (char && task.characterId && task.characterId !== char) return false;
    if (task.target === 'owner') return isOwner;
    return groupId && task.target === groupId;
  });
  if (!tasks.length) return '';
  return [
    '【管理员安排（仅列与本会话相关的）】',
    ...tasks.slice(0, 12).map((task) => `- ${task.title}：${task.type === 'time' ? `${task.repeat === 'once' ? '一次性' : task.repeat === 'weekdays' ? '工作日' : '每天'} ${task.time}` : task.type === 'condition' ? '满足条件时由你判断' : `关键词 ${task.keywords.join('/')}`}。${task.instruction ? `要求：${task.instruction.slice(0, 200)}` : ''}`)
  ].join('\n');
}
