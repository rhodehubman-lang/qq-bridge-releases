// 冷场保护：识别“对方不想继续聊”的轻量信号。
// 原则：
// - 只做减法和收尾，不主动追问、不连续补话；
// - 不把“短回复”直接等同于讨厌，只在刚说过话、对方确实接话时累计；
// - 明确拒绝/连续冷回应才进入 stop；普通短回先进入 cooling；
// - 状态按角色 + 会话隔离，不跨角色、不跨群共享。

export const ENGAGEMENT_VERSION = 1;

export const DEFAULT_ENGAGEMENT_SETTINGS = Object.freeze({
  enabled: true,
  groupStopScore: 3,
  privateStopScore: 2,
  decayMs: 2 * 60 * 60 * 1000,
  awaitingMs: 6 * 60 * 60 * 1000
});

export const ENGAGEMENT_LEVELS = Object.freeze(['normal', 'cooling', 'stop']);

const SHORT_REPLY_RE = /^(嗯+|哦+|喔+|噢+|好|好的|好嘞|行|可以|知道了|收到|明白|6+|…+|\.+|。。。|哈哈|笑死|？+|\?+)$/i;
const NEGATIVE_RE = /(不想聊|别说了|换个话题|没兴趣|不聊了|算了|无语|你忙吧|先这样|到此为止|闭嘴|烦不烦)/i;
const WARM_REPLY_RE = /(？|\?|哈哈|笑死|好耶|谢谢|继续|然后呢|真的假的|怎么说|细说|展开|可以啊|有意思|不错)/i;

function cleanText(value, max = 500) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function numberOr(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function normalizeEngagementSettings(raw = {}, base = DEFAULT_ENGAGEMENT_SETTINGS) {
  const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const fallback = base && typeof base === 'object' ? base : DEFAULT_ENGAGEMENT_SETTINGS;
  return {
    enabled: source.enabled === undefined ? fallback.enabled !== false : source.enabled !== false,
    groupStopScore: Math.max(2, Math.min(8, numberOr(source.groupStopScore, fallback.groupStopScore))),
    privateStopScore: Math.max(1, Math.min(8, numberOr(source.privateStopScore, fallback.privateStopScore))),
    decayMs: Math.max(60_000, Math.min(24 * 60 * 60 * 1000, numberOr(source.decayMs, fallback.decayMs))),
    awaitingMs: Math.max(60_000, Math.min(24 * 60 * 60 * 1000, numberOr(source.awaitingMs, fallback.awaitingMs)))
  };
}

const SETTINGS_KEYS = Object.freeze(['enabled', 'groupStopScore', 'privateStopScore', 'decayMs', 'awaitingMs']);

function pickSettings(raw = {}) {
  const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const picked = {};
  if (source.enabled !== undefined) picked.enabled = source.enabled !== false;
  if (source.groupStopScore !== undefined) picked.groupStopScore = Math.max(2, Math.min(8, numberOr(source.groupStopScore, DEFAULT_ENGAGEMENT_SETTINGS.groupStopScore)));
  if (source.privateStopScore !== undefined) picked.privateStopScore = Math.max(1, Math.min(8, numberOr(source.privateStopScore, DEFAULT_ENGAGEMENT_SETTINGS.privateStopScore)));
  if (source.decayMs !== undefined) picked.decayMs = Math.max(60_000, Math.min(24 * 60 * 60 * 1000, numberOr(source.decayMs, DEFAULT_ENGAGEMENT_SETTINGS.decayMs)));
  if (source.awaitingMs !== undefined) picked.awaitingMs = Math.max(60_000, Math.min(24 * 60 * 60 * 1000, numberOr(source.awaitingMs, DEFAULT_ENGAGEMENT_SETTINGS.awaitingMs)));
  return picked;
}

export function emptyEngagementState() {
  return {
    version: ENGAGEMENT_VERSION,
    settings: { ...DEFAULT_ENGAGEMENT_SETTINGS },
    roles: {},
    characters: {}
  };
}

/** 当前角色的实际阈值：全局默认 + 角色覆盖。 */
export function engagementSettingsFor(state, characterId) {
  const cid = cleanText(characterId, 80) || 'default';
  const defaults = normalizeEngagementSettings(state?.settings ?? {});
  const override = state?.roles?.[cid]?.settings;
  return normalizeEngagementSettings(override ?? {}, defaults);
}

/** 保存角色覆盖；reset=true 时删除该角色覆盖，恢复继承全局默认。 */
export function setEngagementSettings(state, { characterId, patch = {}, reset = false } = {}) {
  const cid = cleanText(characterId, 80) || 'default';
  if (!state.roles || typeof state.roles !== 'object') state.roles = {};
  if (reset) {
    delete state.roles[cid];
  } else {
    const current = state.roles[cid]?.settings ?? {};
    state.roles[cid] = {
      ...(state.roles[cid] ?? {}),
      settings: { ...current, ...pickSettings(patch) }
    };
  }
  refreshEngagementLevels(state, cid);
  return engagementSettingsFor(state, cid);
}

/** 删除当前角色的全部会话状态，不影响全局默认或别的角色。 */
export function resetCharacterEngagement(state, { characterId } = {}) {
  const cid = cleanText(characterId, 80) || 'default';
  const conversations = state?.characters?.[cid];
  const count = conversations && typeof conversations === 'object' ? Object.keys(conversations).length : 0;
  if (conversations) delete state.characters[cid];
  return count;
}

/** 阈值改变后重算已有会话级别，避免旧 stop 把新阈值卡住。 */
function refreshEngagementLevels(state, characterId) {
  const cid = cleanText(characterId, 80) || 'default';
  const settings = engagementSettingsFor(state, cid);
  const conversations = state?.characters?.[cid];
  if (!conversations || typeof conversations !== 'object') return;
  for (const [key, entry] of Object.entries(conversations)) {
    const normalized = normalizeEntry(entry);
    normalized.key = key;
    normalized.level = levelFor(normalized.score, key.startsWith('group:') ? 'group' : 'private', settings);
    conversations[key] = normalized;
  }
}

function normalizeEntry(raw = {}) {
  const level = ENGAGEMENT_LEVELS.includes(raw.level) ? raw.level : 'normal';
  return {
    key: cleanText(raw.key, 120),
    score: Math.max(0, Math.min(20, numberOr(raw.score, 0))),
    level,
    coldCount: Math.max(0, Math.min(20, numberOr(raw.coldCount, 0))),
    explicitCount: Math.max(0, Math.min(20, numberOr(raw.explicitCount, 0))),
    lastAiAt: Math.max(0, numberOr(raw.lastAiAt, 0)),
    lastIncomingAt: Math.max(0, numberOr(raw.lastIncomingAt, 0)),
    updatedAt: Math.max(0, numberOr(raw.updatedAt, 0)),
    awaitingSince: Math.max(0, numberOr(raw.awaitingSince, 0))
  };
}

export function normalizeEngagementState(raw = {}) {
  const state = emptyEngagementState();
  state.settings = normalizeEngagementSettings(raw?.settings ?? {});
  if (raw?.roles && typeof raw.roles === 'object' && !Array.isArray(raw.roles)) {
    for (const [characterId, role] of Object.entries(raw.roles)) {
      const cid = cleanText(characterId, 80);
      if (!cid) continue;
      const override = pickSettings(role?.settings ?? {});
      if (Object.keys(override).length) state.roles[cid] = { settings: override };
    }
  }
  if (!raw?.characters || typeof raw.characters !== 'object' || Array.isArray(raw.characters)) return state;
  for (const [characterId, conversations] of Object.entries(raw.characters)) {
    const cid = cleanText(characterId, 80);
    if (!cid || !conversations || typeof conversations !== 'object' || Array.isArray(conversations)) continue;
    state.characters[cid] = {};
    for (const [key, entry] of Object.entries(conversations)) {
      const k = cleanText(key, 120);
      if (!k) continue;
      const normalized = normalizeEntry(entry);
      normalized.key = k;
      state.characters[cid][k] = normalized;
    }
  }
  return state;
}

function ensureCharacter(state, characterId) {
  const cid = cleanText(characterId, 80) || 'default';
  if (!state.characters[cid] || typeof state.characters[cid] !== 'object') state.characters[cid] = {};
  return state.characters[cid];
}

export function getEngagementEntry(state, { characterId, key, now = 0 } = {}) {
  const cid = cleanText(characterId, 80) || 'default';
  const k = cleanText(key, 120);
  const entry = state?.characters?.[cid]?.[k];
  if (!entry) return normalizeEntry({ key: k });
  const normalized = normalizeEntry(entry);
  const settings = engagementSettingsFor(state, cid);
  const kind = k.startsWith('group:') ? 'group' : 'private';
  if (now && normalized.updatedAt && now - normalized.updatedAt > settings.decayMs) {
    const fresh = normalizeEntry({ key: k });
    state.characters[cid][k] = fresh;
    return fresh;
  }
  normalized.level = levelFor(normalized.score, kind, settings);
  return normalized;
}

export function resetEngagementEntry(state, { characterId, key } = {}) {
  const cid = cleanText(characterId, 80) || 'default';
  const k = cleanText(key, 120);
  if (!k) return false;
  const conversations = ensureCharacter(state, cid);
  delete conversations[k];
  return true;
}

function levelFor(score, kind, settings) {
  const threshold = kind === 'group' ? settings.groupStopScore : settings.privateStopScore;
  if (score >= threshold) return 'stop';
  if (score > 0) return 'cooling';
  return 'normal';
}

function applyLevel(entry, kind, settings) {
  entry.score = Math.max(0, Math.min(20, entry.score));
  entry.level = levelFor(entry.score, kind, settings);
  return entry;
}

export function noteJillMessage(state, { characterId, key, now = Date.now() } = {}) {
  const cid = cleanText(characterId, 80) || 'default';
  const k = cleanText(key, 120);
  if (!k) return null;
  const conversations = ensureCharacter(state, cid);
  const entry = conversations[k] ? normalizeEntry(conversations[k]) : normalizeEntry({ key: k });
  entry.key = k;
  entry.lastAiAt = now;
  entry.awaitingSince = now;
  entry.updatedAt = now;
  conversations[k] = entry;
  return entry;
}

function isShortReply(text) {
  const value = cleanText(text, 120);
  if (!value) return false;
  if (value.length <= 4 && SHORT_REPLY_RE.test(value)) return true;
  return value.length <= 2 && !WARM_REPLY_RE.test(value);
}

export function observeIncoming(state, {
  characterId,
  key,
  text,
  kind = 'group',
  addressedToSelf = false,
  isOwner = false,
  now = Date.now()
} = {}) {
  const cid = cleanText(characterId, 80) || 'default';
  const k = cleanText(key, 120);
  if (!k) return null;
  const settings = engagementSettingsFor(state, cid);
  if (!settings.enabled) return null;

  const conversations = ensureCharacter(state, cid);
  const entry = conversations[k] ? normalizeEntry(conversations[k]) : normalizeEntry({ key: k });
  entry.key = k;
  if (entry.updatedAt && now - entry.updatedAt > settings.decayMs) {
    entry.score = 0;
    entry.coldCount = 0;
    entry.explicitCount = 0;
    entry.awaitingSince = 0;
    entry.level = 'normal';
  }
  const value = cleanText(text, 500);

  // 群里没有点到 Jill、也不是主人接话时，不把别人的闲聊当成冷场。
  if (kind === 'group' && !addressedToSelf && !isOwner) return entry;

  if (!value) {
    entry.lastIncomingAt = now;
    entry.updatedAt = now;
    conversations[k] = entry;
    return entry;
  }

  const explicit = NEGATIVE_RE.test(value);
  const warm = WARM_REPLY_RE.test(value) || value.length >= 24;
  const wasAwaiting = entry.lastAiAt > 0 && now - entry.lastAiAt <= settings.awaitingMs;

  if (warm && !explicit) {
    entry.score = 0;
    entry.coldCount = 0;
    entry.explicitCount = 0;
    entry.awaitingSince = 0;
    entry.level = 'normal';
  } else if (explicit) {
    entry.explicitCount += 1;
    entry.score += 3;
    entry.awaitingSince = 0;
  } else if (wasAwaiting && isShortReply(value)) {
    entry.coldCount += 1;
    entry.score += 1;
    entry.awaitingSince = 0;
  } else if (wasAwaiting && now - entry.lastAiAt <= settings.awaitingMs) {
    // 对方接话了但不算热情：慢慢降温，不额外加分。
    entry.score = Math.max(0, entry.score);
  } else if (!wasAwaiting && now - entry.updatedAt > settings.decayMs) {
    entry.score = 0;
    entry.coldCount = 0;
  }

  entry.lastIncomingAt = now;
  entry.updatedAt = now;
  applyLevel(entry, kind, settings);
  conversations[k] = entry;
  return entry;
}

export function shouldSuppressEngagementWake(entry, reason, { isOwner = false, kind = 'group' } = {}) {
  if (!entry || entry.level !== 'stop') return false;
  if (isOwner) return false;
  const base = String(reason ?? '').split(':')[0];
  const direct = new Set(['private', 'atMention', 'nameMention', 'question']);
  return !direct.has(base);
}

export function formatEngagementPrompt(entry, { kind = 'group' } = {}) {
  if (!entry || entry.level === 'normal') return '';
  if (entry.level === 'stop') {
    return [
      '【聊天的分寸】',
      kind === 'group'
        ? '对方最近回应很短，或明确表示不想继续这个话题。不要再追问、不要连续补话，也不要在群里反复接同一个话头。'
        : '对方最近回应很短，或明确表示不想继续这个话题。不要再追问，也不要问“你是不是不想聊”。',
      '如果必须回，只回一句自然的收尾（例如“行，那你先忙”“好，我听着”），然后停下。',
      '不要解释自己为什么停下，也不要把这条规则说出来。'
    ].join('\n');
  }
  return [
    '【聊天的分寸】',
    '对方最近回得比较短。最多轻轻接一句，不要追问、不要连续发第二条；对方如果还是短回，就自然收住。'
  ].join('\n');
}

export function engagementSummary(entry) {
  if (!entry) return '正常';
  return entry.level === 'stop' ? '已收住' : entry.level === 'cooling' ? '降温中' : '正常';
}
