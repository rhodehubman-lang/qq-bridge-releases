// 冷存档：活跃共享记忆超过每角色上限/超过年龄后移到这里，不再进入每轮提示词。
// 检索仍按角色隔离：当前角色 + '*' 全局记忆可见。

import {
  normalizeSharedMemory,
  querySharedMemory
} from './core/shared-memory-store.js';

export const ARCHIVE_VERSION = 1;

export function emptyArchive() {
  return { version: ARCHIVE_VERSION, entries: [] };
}

export function normalizeArchive(raw) {
  const src = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const state = normalizeSharedMemory({ entries: Array.isArray(src.entries) ? src.entries : [] });
  return { version: ARCHIVE_VERSION, entries: state.entries };
}

function sortForArchive(a, b) {
  const ai = Number(a.importance) || 3;
  const bi = Number(b.importance) || 3;
  if (ai !== bi) return ai - bi;
  return (Number(a.updatedAt) || 0) - (Number(b.updatedAt) || 0);
}

/**
 * 把活跃库里超出每角色上限、或超过最大年龄的条目移入冷存档。
 * @returns {{moved:number,active:number,archived:number,reasons:object}}
 */
export function archiveExcess(activeState, archiveState, options = {}) {
  const stats = { moved: 0, active: 0, archived: 0, reasons: { capacity: 0, age: 0 } };
  if (!activeState || !Array.isArray(activeState.entries)) return stats;
  if (!archiveState || !Array.isArray(archiveState.entries)) archiveState = emptyArchive();
  if (options.enabled === false) {
    stats.active = activeState.entries.length;
    stats.archived = archiveState.entries.length;
    return stats;
  }
  const now = Number(options.now) > 0 ? Number(options.now) : Date.now();
  const maxPerCharacter = Math.max(10, Number(options.maxPerCharacter) || 2000);
  const maxAgeDays = Math.max(1, Number(options.maxAgeDays) || 180);
  const maxArchiveEntries = Math.max(100, Number(options.maxEntries) || 100000);
  const cutoff = now - maxAgeDays * 24 * 60 * 60 * 1000;

  const moveIds = new Set();
  const reasonById = new Map();

  // 每角色超量：优先归档低重要度、旧的条目；importance=5 尽量留在活跃库。
  const byCharacter = new Map();
  for (const entry of activeState.entries) {
    if (!entry) continue;
    const char = entry.characterId || '';
    if (!byCharacter.has(char)) byCharacter.set(char, []);
    byCharacter.get(char).push(entry);
  }
  for (const [char, list] of byCharacter) {
    if (char === '*') continue; // 全局层不计入单角色配额
    if (list.length <= maxPerCharacter) continue;
    const sorted = [...list].sort(sortForArchive);
    const overflow = sorted.slice(0, list.length - maxPerCharacter);
    for (const entry of overflow) {
      moveIds.add(entry.id);
      reasonById.set(entry.id, 'capacity');
    }
  }

  // 年龄过期：importance=5 不按年龄归档。
  for (const entry of activeState.entries) {
    if (!entry || moveIds.has(entry.id)) continue;
    if (Number(entry.importance) === 5) continue;
    if (Number(entry.updatedAt) > 0 && Number(entry.updatedAt) < cutoff) {
      moveIds.add(entry.id);
      reasonById.set(entry.id, 'age');
    }
  }

  if (!moveIds.size) {
    stats.active = activeState.entries.length;
    stats.archived = archiveState.entries.length;
    return stats;
  }

  const keep = [];
  const moving = [];
  for (const entry of activeState.entries) {
    if (entry && moveIds.has(entry.id)) moving.push(entry);
    else keep.push(entry);
  }
  activeState.entries = keep;
  const archivedIds = new Set(archiveState.entries.map((e) => e && e.id).filter(Boolean));
  for (const entry of moving) {
    if (!entry || archivedIds.has(entry.id)) continue;
    archivedIds.add(entry.id);
    archiveState.entries.push({
      ...entry,
      archivedAt: now,
      archiveReason: reasonById.get(entry.id) || 'archive'
    });
    stats.moved += 1;
    stats.reasons[reasonById.get(entry.id) || 'archive'] = (stats.reasons[reasonById.get(entry.id) || 'archive'] || 0) + 1;
  }
  // 冷存档总上限：最旧的先丢，避免无限膨胀。
  if (archiveState.entries.length > maxArchiveEntries) {
    archiveState.entries.sort((a, b) => (Number(a.archivedAt) || 0) - (Number(b.archivedAt) || 0));
    archiveState.entries = archiveState.entries.slice(-maxArchiveEntries);
  }
  stats.active = activeState.entries.length;
  stats.archived = archiveState.entries.length;
  return stats;
}

/** 冷存档检索（只做数据过滤；权限由 bridge 传 scopes）。 */
export function searchArchive(archiveState, filters = {}) {
  const entries = archiveState && Array.isArray(archiveState.entries) ? archiveState.entries : [];
  return querySharedMemory({ entries }, filters);
}

export function summarizeArchive(archiveState) {
  const entries = archiveState && Array.isArray(archiveState.entries) ? archiveState.entries : [];
  const counts = {};
  for (const entry of entries) {
    const char = entry.characterId || '(legacy)';
    counts[char] = (counts[char] || 0) + 1;
  }
  return { total: entries.length, counts };
}
