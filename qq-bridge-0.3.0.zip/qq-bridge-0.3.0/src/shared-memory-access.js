// 跨会话记忆访问矩阵（纯函数，可单测）。
//
// 语义：每个「目标会话」（群聊/私聊）可以有自己的一份策略：
//   none     不读取其他来源的记忆（默认）
//   all      读取全部来源的记忆
//   selected 只读取指定来源（单向；A 能读 B 不代表 B 能读 A）
//
// 来源 source 用会话 key 表示：
//   group:<群号>     一个群的记忆（group 层）
//   private:<QQ号>   一个私聊里的用户记忆（user 层；只有 shared/public 会被暴露）
//
// 管理员私聊默认 all；其他会话默认 none。

import { parseSessionKey } from './core/shared-memory-store.js';

export const ACCESS_STATE_VERSION = 1;
export const ACCESS_MODES = Object.freeze(['none', 'all', 'selected']);

function normalizeSourceKey(raw) {
  const text = String(raw ?? '').trim();
  const sess = parseSessionKey(text);
  return sess ? sess.key : '';
}

function normalizeSources(sources) {
  if (!Array.isArray(sources)) return [];
  const out = [];
  for (const item of sources) {
    const key = normalizeSourceKey(item);
    if (!key || out.includes(key)) continue;
    out.push(key);
    if (out.length >= 200) break;
  }
  return out;
}

function normalizeLegacyGroups(groups) {
  if (!Array.isArray(groups)) return [];
  return normalizeSources(groups.map((id) => `group:${String(id ?? '').trim()}`));
}

function normalizePolicy(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const mode = ACCESS_MODES.includes(raw.mode) ? raw.mode : null;
  if (!mode) return null;
  const sources = mode === 'selected'
    ? normalizeSources([...(raw.sources ?? []), ...normalizeLegacyGroups(raw.groups)])
    : [];
  return { mode, sources };
}

export function emptyAccessState() {
  return { version: ACCESS_STATE_VERSION, conversations: {} };
}

export function normalizeAccessState(raw) {
  const out = emptyAccessState();
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return out;
  const conversations = raw.conversations;
  if (!conversations || typeof conversations !== 'object' || Array.isArray(conversations)) return out;
  for (const [key, value] of Object.entries(conversations)) {
    const sess = parseSessionKey(key);
    if (!sess) continue;
    const policy = normalizePolicy(value);
    if (!policy) continue;
    out.conversations[sess.key] = policy;
  }
  return out;
}

export function isOwnerPrivate(key, ownerQQ) {
  const sess = parseSessionKey(key);
  return !!(sess && sess.kind === 'private' && ownerQQ && sess.uin === String(ownerQQ));
}

/** 该会话的默认策略（没有显式配置时使用）。 */
export function defaultAccessPolicy(key, { ownerQQ } = {}) {
  return isOwnerPrivate(key, ownerQQ)
    ? { mode: 'all', sources: [] }
    : { mode: 'none', sources: [] };
}

export function getAccessPolicy(state, key, { ownerQQ } = {}) {
  const sess = parseSessionKey(key);
  if (!sess) return { mode: 'none', sources: [] };
  const explicit = state?.conversations?.[sess.key];
  const policy = normalizePolicy(explicit);
  return policy || defaultAccessPolicy(sess.key, { ownerQQ });
}

/**
 * 设置/覆盖某个会话的访问策略。
 * 兼容旧调用：groups: ['123'] 会被迁移成 sources: ['group:123']。
 * @returns {{ok:true,key:string,policy:object}|{ok:false,error:string}}
 */
export function setAccessPolicy(state, key, { mode, sources, groups } = {}) {
  const sess = parseSessionKey(key);
  if (!sess) return { ok: false, error: '无效的会话 key' };
  if (!ACCESS_MODES.includes(mode)) return { ok: false, error: 'mode 必须是 none / all / selected' };
  if (!state.conversations || typeof state.conversations !== 'object') state.conversations = {};
  const normalizedSources = mode === 'selected'
    ? normalizeSources([...(Array.isArray(sources) ? sources : []), ...normalizeLegacyGroups(groups)])
    : [];
  const policy = { mode, sources: normalizedSources };
  state.conversations[sess.key] = policy;
  return { ok: true, key: sess.key, policy };
}

/** 目标会话能否读取 sourceKey 这个来源（不含“本会话自身”的特例）。 */
export function canReadSource(state, targetKey, sourceKey, { ownerQQ } = {}) {
  const sess = parseSessionKey(targetKey);
  const source = normalizeSourceKey(sourceKey);
  if (!sess || !source) return false;
  if (sess.key === source) return true;
  const policy = getAccessPolicy(state, sess.key, { ownerQQ });
  if (policy.mode === 'all') return true;
  if (policy.mode === 'selected') return policy.sources.includes(source);
  return false;
}

/**
 * 返回目标会话可以读取的“其他来源”key 列表。
 * @param {object} state
 * @param {string} targetKey
 * @param {string[]} knownSources 已知来源 key（group:... / private:...）
 * @param {{ownerQQ?:string}} options
 */
export function allowedCrossSources(state, targetKey, knownSources, { ownerQQ } = {}) {
  const sess = parseSessionKey(targetKey);
  if (!sess) return [];
  const known = normalizeSources(knownSources).filter((key) => key !== sess.key);
  const policy = getAccessPolicy(state, sess.key, { ownerQQ });
  if (policy.mode === 'all') return known;
  if (policy.mode === 'selected') return known.filter((key) => policy.sources.includes(key));
  return [];
}

/** 控制台列表用：把会话/策略整理成稳定结构。 */
export function listAccessPolicies(state, sessionKeys, { ownerQQ } = {}) {
  const keys = new Set();
  for (const key of Array.isArray(sessionKeys) ? sessionKeys : []) {
    const sess = parseSessionKey(key);
    if (sess) keys.add(sess.key);
  }
  for (const key of Object.keys(state?.conversations || {})) {
    const sess = parseSessionKey(key);
    if (sess) keys.add(sess.key);
  }
  return [...keys].sort().map((key) => {
    const sess = parseSessionKey(key);
    return {
      key,
      kind: sess.kind,
      id: sess.id,
      policy: getAccessPolicy(state, key, { ownerQQ })
    };
  });
}
