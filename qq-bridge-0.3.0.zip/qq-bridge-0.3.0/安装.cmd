@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo   QQ Bridge one-click installer
echo ============================================
set "NODE="
if exist "%~dp0node.cmd" set "NODE=%~dp0node.cmd"
where node.exe >nul 2>nul
if not errorlevel 1 set "NODE=node.exe"
if "%NODE%"=="" goto no_node
call "%NODE%" "%~dp0scripts\install.mjs" %*
set code=%errorlevel%
if "%code%"=="127" echo [install] Node runtime not found - open DSH desktop once, then rerun this script.
goto done
:no_node
echo [install] Node.js not found.
echo [install] Install Node.js 22.13+ (nodejs.org), or open DSH desktop once, then rerun.
pause
exit /b 1
:done
echo.
pause
exit /b %code%
