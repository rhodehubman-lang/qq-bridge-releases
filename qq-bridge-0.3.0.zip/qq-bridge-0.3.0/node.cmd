@echo off
rem node.cmd - run Node.js even when the machine has no system-wide install.
rem
rem Why this file exists: the DSH desktop app ships its own Node runtime, and a
rem clean Windows box has no node.exe on PATH. Batch scripts in this repo call
rem bare `node`; cmd.exe resolves from the current directory before PATH, so this
rem shim transparently supplies it.
rem
rem Candidates, in order:
rem   1) a real node.exe on PATH (never shadow it when it exists)
rem   2) DSH desktop runtime, user-level install (most common for friends)
rem   3) DSH desktop runtime, all-users install
rem   4) CLI-provisioned runtimes under %USERPROFILE%\.dsh\dsh-runtimes\*
rem 2026-10-31 VM rehearsal: only checking ~/.dsh/dsh-runtimes broke the very
rem first install on a desktop-app-only machine (the desktop app keeps its
rem runtime inside its install dir, not in ~/.dsh). That is why 2) and 3) exist.
setlocal
where node.exe >nul 2>nul
if not errorlevel 1 goto system

set "NODE_EXE="
set "DESKTOP_NODE=%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"
if exist "%DESKTOP_NODE%" set "NODE_EXE=%DESKTOP_NODE%"
if defined NODE_EXE goto bundled

set "DESKTOP_NODE_ALL=%ProgramFiles%\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"
if exist "%DESKTOP_NODE_ALL%" set "NODE_EXE=%DESKTOP_NODE_ALL%"
if defined NODE_EXE goto bundled

set "DSH_RUNTIME=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
if exist "%DSH_RUNTIME%" set "NODE_EXE=%DSH_RUNTIME%"
if defined NODE_EXE goto bundled

rem CLI-provisioned runtimes may use other directory names; scan them too.
for /d %%D in ("%USERPROFILE%\.dsh\dsh-runtimes\*") do (
  if not defined NODE_EXE if exist "%%~D\dependencies\node\bin\node.exe" set "NODE_EXE=%%~D\dependencies\node\bin\node.exe"
)
if defined NODE_EXE goto bundled

echo [node.cmd] Node.js not found. Tested: PATH, DSH desktop install dirs, and %USERPROFILE%\.dsh\dsh-runtimes. 1>&2
echo [node.cmd] Fix: open the DeepSeek Harness desktop app once (it provisions its runtime), or install Node.js 22.13+ from nodejs.org. 1>&2
exit /b 127

:system
node.exe %*
exit /b %errorlevel%

:bundled
"%NODE_EXE%" %*
exit /b %errorlevel%
