@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0config.json" goto no_config
if not exist "%~dp0node.cmd" goto no_node
echo [启动] 正在查找 DSH 桌面版的端口…
call "%~dp0node.cmd" "%~dp0scripts\find-dsh-port.mjs" --write
set code=%errorlevel%
if "%code%"=="2" goto no_dsh
if not "%code%"=="0" goto port_fail
echo.
echo [启动] 检查 SnowLuma 连接…
call "%~dp0node.cmd" "%~dp0scripts\check-onebot.mjs"
echo.
echo [启动] 启动桥接。这个窗口不要关（关掉 = 机器人下线）。
call "%~dp0start.bat"
goto end
:no_config
echo [启动] 还没有 config.json，请先双击「安装.cmd」。
goto fail
:no_node
echo [启动] 缺少 node.cmd，请确认解压完整，或先双击「安装.cmd」。
goto fail
:no_dsh
echo.
echo [启动] 没有检测到 DSH 桌面版。请先打开 DeepSeek Harness 并登录，然后重新双击本脚本。
goto fail
:port_fail
echo [启动] 端口发现失败，请把上面的提示发给管理员。
goto fail
:fail
echo.
pause
exit /b 1
:end
