# 自动备份与恢复

备份只保存“用户数据”，不保存 `node_modules`、源码、日志和旧备份本身。默认每天自动备份一次，保留 7 份；备份目录在项目外，代码更新不会覆盖。

## 备份什么

| 路径 | 内容 |
| --- | --- |
| `config.json` | QQ/DSH/控制台配置 |
| `state/` | 会话、记忆、关系、情绪、安排、跨群汇报、事件库等运行状态 |
| `roles/` | 角色人格文件 |
| `life-profiles/` | 生活/日程档案 |
| `osts/` | 角色专属 OST 记忆 |
| `audio/` | 本地音频（如果存在） |

`node_modules/`、`public/`、`src/`、`logs/`、备份目录自身不会进备份。

## 默认位置与保留

- Windows 默认：`<项目目录>\_backups\qq-bridge`
- Linux 默认：`/opt/_backups/qq-bridge`
- 每份备份是一个带 `manifest.json` 的目录，名字类似 `qq-bridge-20261028-132338-manual`
- 默认保留最近 7 份，旧的自动清理
- 可在控制台「调试与运维 → 自动备份」修改是否启用、是否每天自动、保留份数

## 控制台操作

1. 打开「调试与运维」。
2. 找到「自动备份」卡片。
3. 可以启用/关闭备份、启用/关闭每天自动、修改保留份数、点「立即备份」。
4. 列表里能看到每份备份的时间、大小、文件数和类型（自动/手动）。

## 命令行

在 `qq-bridge` 目录运行：

```bash
npm run backup
npm run backup -- --label before-update
npm run backup -- --list
npm run backup -- --restore qq-bridge-20261028-132338-manual --confirm RESTORE
```

恢复必须显式写 `--confirm RESTORE`。恢复前，程序会先给“当前数据”再做一份 `pre-restore` 备份；如果恢复中途失败，至少还有这份当前快照。

> 恢复前请先停止 qq-bridge（Windows 关闭桥接窗口；Linux `systemctl stop qq-bridge`），恢复完成后再启动。桥接运行中直接覆盖 `state/` 可能与内存里的旧状态打架。恢复同样可以在控制台停桥接后，用本机命令行执行；控制台只提供备份，不提供一键恢复。

## 从安装包或另一台电脑迁移

1. 在新机器装好 qq-bridge，先不要启动 QQ。
2. 把旧机器的备份目录（如 `<项目目录>\_backups\qq-bridge\qq-bridge-...`）复制到新机器。
3. 在新机器 `qq-bridge` 目录运行：

```bash
npm run backup -- --restore <备份目录的完整路径> --confirm RESTORE
```

4. 再启动桥接。QQ 账号、token、角色、记忆会一起恢复；如果换号，仍需要在 `config.json` / 控制台重新确认账号相关配置。

## 安全边界

- 备份目录默认不允许放在项目目录内，防止更新/打包把备份一起卷进去。
- 备份包含 `config.json` 和 `state/`，可能有账号 token、聊天记忆等敏感信息；不要上传到公开仓库或发给别人。
- 恢复只允许写入备份 manifest 里声明过的固定用户数据路径，不会执行备份里的脚本。
- 控制台接口不能由 QQ 群里的 AI 角色令牌调用；恢复操作只放在命令行，避免误触。
