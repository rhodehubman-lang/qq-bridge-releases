# 语音发送（Voice）

> 状态：语音发送是**可选的独立组件**；主仓库只提供共享内核与协议，工具本体（`voice-cli.mjs` / `voice-gui.mjs`）位于仓库上一级的 `voice-tool/`，不在发行包里。

## 默认是关的

- 控制台「二代仿真 → 语音」与 `config.json` 的 `socialV2.voice.enabled` / `tools.sendVoice` 默认都是 `false`。
- 只有管理员在控制台显式打开后，AI 才能调用 `qq_send_voice`。
- `qq_list_voices` / `qq_send_voice` 报「语音功能已关闭」「工具未启用」是**正常状态**，不代表故障。

## 两个入口

| 入口 | 说明 |
| --- | --- |
| `voice-cli.mjs` | 命令行发语音：`node voice-cli.mjs --file <音频> --target <QQ/群>` |
| `voice-gui.mjs` | 图形界面：Windows 下双击同目录的 `发语音-图形界面.cmd` 启动 |

两个工具共用 `qq-bridge/src/voice-core.js`（单一实现），并按固定顺序读取配置：

```text
环境变量（SNOWLUMA_HTTP_URL / SNOWLUMA_TOKEN / SNOWLUMA_HOME / VOICE_DIR / FFMPEG_PATH）
  → voice-tool/config.json
  → ../qq-bridge/config.json
  → 内置默认值
```

## 依赖

- **ffmpeg / ffprobe**：音频转码与音量/响度处理需要它们；可通过 `FFMPEG_PATH` / `FFPROBE_PATH` 指定。
- 音频文件放在 `audio/`（`voice.voiceDir` 默认 `audio`，相对仓库根目录，便于整体拷贝）。
- 语音库由 `qq_list_voices` 暴露给 AI；AI 发语音受 `socialV2.voice` 的音量、归一化、每日上限等设置约束。

## 相关文档

- 控制台与 AI 侧开关：见 [README](../../README.md) 的「已知限制」
- 多模态与 OST：见 [MULTIMODAL_AND_OST.md](MULTIMODAL_AND_OST.md)
- 安全边界：语音发送强制走 QQ 白名单，见 [SECURITY_BASELINE.md](SECURITY_BASELINE.md)
