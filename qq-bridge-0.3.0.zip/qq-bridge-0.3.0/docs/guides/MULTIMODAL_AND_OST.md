# 聊天记录、GIF 故事板与角色音乐记忆

本文档对应 2026-10-27 的“角色能力通用、内容按角色隔离”改造。三块能力都走桥接层，不改 QQ 客户端，也不要求 DSH 额外安装工具。

## 1. 点开聊天记录

QQ 的“聊天记录 / 合并转发”卡片本身是一层消息容器，桥接已有 `qq_get_forward_msg`：

- 群里有人发“聊天记录”卡片时，消息里会出现 `[转发消息 id=...]` 或 `forwardIds`；
- 模型调用 `qq_get_forward_msg` 展开，读取里面的文字、图片和嵌套转发；
- 普通 `qq_get_recent_messages` 负责最近消息，`qq_get_group_context` 只给管理员私聊读其他群的最近上下文。

这块没有新增“聊天记录开关”，因为能力原本就在；本次只在提示词里明确告诉角色：看到聊天记录卡片可以主动展开，而不是只凭预览猜。

## 2. GIF / 动态图故事板

模型通常只能稳定看到 GIF 的第一帧，容易把“会动的表情”理解错。桥接会在转发图片给 DSH 前，把动图均匀抽 2~6 帧，拼成一张故事板 JPEG。

配置在 `config.json` 的 `socialV2.media.gifStoryboard`：

```json
{
  "socialV2": {
    "media": {
      "gifStoryboard": {
        "enabled": true,
        "maxFrames": 4,
        "maxCell": 480,
        "minSide": 80
      }
    }
  }
}
```

行为：

- 只处理真正的 GIF（文件头 `GIF87a` / `GIF89a`），静态图片不受影响；
- 默认抽 4 帧，2 列排版，交给视觉模型；
- 帧数、单帧最大边长有硬上限，避免把上下文撑爆；
- 本地没有 `sharp` 时自动回退原图，不影响消息主链路；
- 云端使用 DSH 自带的 sharp。

代码：

- `src/gif-storyboard.js`：纯函数，调用方注入 sharp；
- `src/bridge.js` 的 `prepareImageVariants()`：接入现有图片准入流程；
- `scripts/test-gif-storyboard.mjs`：云端集成测试。

## 3. 角色专属音乐记忆

Jill 的曲目包在 `osts/Jill.json`。它不是“QQ 音乐播放器”，也不是公共资料库，而是角色自己的听歌记忆：

```json
{
  "version": 1,
  "characterId": "Jill",
  "title": "Glitch City 听歌记忆",
  "source": "VA-11 HALL-A - Second Round",
  "tracks": [
    {
      "title": "Every Day Is Night",
      "mood": "城市刚亮起来的时候",
      "memory": "下班路上穿过旧城区……"
    }
  ]
}
```

注入规则：

- 只加载当前角色同名文件：`osts/<角色>.json`；
- 只注入当前角色，切到别的角色就不会看到 Jill 的曲目；
- 文件缺失、JSON 损坏、没有曲目时静默关闭；
- 提示词要求“自然想起，不要背曲目表，不要说正在播放”；
- 最多注入 `maxTracks` 条、`maxChars` 字符，防止挤占对话上下文。

配置：

```json
{
  "socialV2": {
    "ost": {
      "enabled": true,
      "maxChars": 1600,
      "maxTracks": 18
    }
  }
}
```

新增角色时，复制 `osts/Jill.json`，改 `characterId`、`title` 和曲目即可；不需要改代码。

只读预览接口（仅控制台）：

```bash
GET /api/socialV2/ost
```

返回当前角色、文件路径、曲目数和实际注入的提示词，方便核对“到底加载了什么”。

代码：

- `src/ost-pack.js`：解析、加载、渲染；
- `src/bridge.js` 的 `ostPromptBlock()`：按当前角色加载，按 mtime 缓存；
- `scripts/test-ost-pack.mjs`：单元测试。

## 4. 测试与部署

本地没有 sharp 时，GIF 集成测试会明确输出 `SKIP`，不会假装通过。云端测试：

```bash
cd /opt/qq-bridge
SHARP_PATH=/usr/lib/node_modules/@deepseek-ai/dsh/node_modules/sharp \
  node scripts/test-gif-storyboard.mjs /tmp/test-animated.gif
node scripts/test-ost-pack.mjs
```

部署时只需上传：

- `src/bridge.js`
- `src/gif-storyboard.js`
- `src/ost-pack.js`
- `osts/<角色>.json`
- 对应测试脚本

然后重启 `qq-bridge`，不要重启 SnowLuma。
