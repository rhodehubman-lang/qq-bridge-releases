# SnowLuma 安全更新与回滚

这份说明适用于「QQ 机器人跑在 Docker 里的 SnowLuma」。目标不是追求最快更新，而是保证：

1. QQ 数据不丢
2. 第一次启动的 Hook 延迟不会被误判成“版本坏了”
3. 更新失败时能自动回到旧版
4. 发给朋友时有一个可重复的流程

## 当前已验证版本

- 已验证可用：**SnowLuma v2.2.1**（Linux x64）
- 回滚镜像：`motricseven7/snowluma:latest`（当时是 2.1.1）
- 镜像在 Compose 中要**固定版本号**，不要长期写 `latest`

## 先备份

更新脚本会自己备份 Compose，但数据目录仍建议单独备份一次：

```bash
sudo cp -a /opt/snowluma/docker-compose.yml /root/docker-compose.yml.bak
sudo tar -czf /root/snowluma-data-$(date +%Y%m%d-%H%M%S).tgz \
  /opt/snowluma/data /opt/snowluma/qq-config
```

不要为了更新删除卷，也不要执行 `docker compose down -v`。

## 推荐更新方式

仓库里的脚本是 `ops/update-snowluma.sh`。把脚本放到服务器上，例如 `/opt/snowluma/update-snowluma.sh`：

```bash
sudo cp ops/update-snowluma.sh /opt/snowluma/update-snowluma.sh
sudo chmod +x /opt/snowluma/update-snowluma.sh
sudo bash /opt/snowluma/update-snowluma.sh --version v2.2.1
```

脚本会做这些事：

1. 备份 Compose 文件
2. 检查/拉取目标镜像
3. 把 Compose 固定到目标版本
4. 启动并等待以下三个信号：
   - 容器保持 `running`
   - 日志出现 `[Hook] login detected`
   - OneBot 3000/3001 端口开始监听
5. 首次等待最多 5 分钟
6. 如果没起来，执行一次干净重建（保留数据卷），再等 4 分钟
7. 第二次仍失败，自动恢复更新前的 Compose，并等待旧版恢复

只有看到 `UPDATE_OK` 或 `UPDATE_OK_AFTER_RECREATE` 才算成功。

## 为什么第一次可能看起来“卡住”

SnowLuma 的 QQ Hook 在容器重建后需要重新注入并等待 QQ 登录。实测会出现：

- 容器已经 `Up`
- 但 Hook 还没输出 `login detected`
- OneBot 端口暂时没监听

这不等于版本坏了。**先等 3–5 分钟**，不要连续 `docker restart`；连续重启只会让 Hook 重新开始计时。

## 手动检查

```bash
docker ps --format '{{.Names}} | {{.Image}} | {{.Status}}'
docker exec snowluma cat /app/runtime/release.json | head
docker logs --since 10m snowluma 2>&1 | grep -E '\[Hook\]|OneBot'
ss -ltn | grep -E ':(3000|3001)'
```

再从 QQ 发一条消息，确认 qq-bridge 正常回复。

## 回滚

```bash
sudo bash /opt/snowluma/update-snowluma.sh --rollback
```

或者手动：

```bash
cd /opt/snowluma
cp -a docker-compose.yml.bak-<时间戳> docker-compose.yml
docker compose up -d
```

回滚不会删除消息数据、角色配置或记忆文件。

## 发给朋友时的建议

- 固定镜像版本：`motricseven7/snowluma:v2.2.1`
- 首次启动留 5–8 分钟观察窗口
- 健康检查以 `[Hook] login detected` 和 OneBot 端口为准，不以容器 `Up` 为准
- 不要在失败后反复 `restart`；先等，必要时 `down && up -d` 一次，再回滚
- 不要把 `state/`、`data/`、`qq-config/` 打进更新包覆盖
- 同时保留旧镜像，至少保留到新版稳定运行一天

## 常见问题

**Q：更新后 QQ 一直不上线，但容器是 Up？**
先看 `docker logs snowluma | grep Hook`。没有 `login detected` 就等；超过 5 分钟按脚本做一次干净重建；仍失败再回滚。

**Q：能直接点 SnowLuma 网页里的“更新”吗？**
Docker 部署不建议这样更新。网页更新可能只改容器内 `/app/runtime`，容器重建后会丢失；应使用镜像版本更新。

**Q：更新会丢聊天记录/记忆吗？**
不会。数据在 Compose 挂载的目录/卷里，更新只替换镜像；但仍要先备份。
