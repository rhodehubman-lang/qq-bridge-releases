# 发布检查清单（Release Checklist）

> 适用版本：`0.3.0`
> 目标：产出**不含本机状态、凭据、个人角色卡和语音素材**的可分发包，并让 0.3.0 之后的版本能自动更新。

## 1. 冻结与备份

- [ ] 停止改动代码，确认没有未完成的实验分支或临时补丁。
- [ ] 备份当前 `state/`、`config.json` 与本次要替换的云端文件。
- [ ] 确认 `package.json` / `package-lock.json` / `plugins/qq-mode-console/package.json` / 三个 MCP `serverInfo.version` 都是同一个版本号。
- [ ] 确认 `CHANGELOG.md` 顶部有对应版本的条目（`latest.json` 的更新说明从这里提取）。

## 2. 隐私扫描

```bash
npm run privacy-scan -- --json
```

- [ ] `findings` 为空。
- [ ] 发行包不含：`config.json`、`state/`、个人角色卡（`roles/` 只保留默认的傲娇助手/小鲸鱼）、`life-profiles/`、`osts/`、`audio/`、`_cloudcheck/`、`scripts/privacy-rules.json`。
- [ ] 代码里不得再出现私有角色/城市默认值（`npm run test:role-agnostic`）。

## 3. 回归测试

```bash
node scripts/check-console-syntax.mjs
npm run test:audit
```

`test:audit` 已包含自动更新、数据迁移、角色通用性、安装脚本、preset、安全守卫等全部离线回归。另建议单独跑：

```bash
npm run test:update-engine
npm run test:update-service
npm run test:update-helper
npm run test:update-api
npm run test:update-manifest
npm run test:data-migrations
npm run test:role-agnostic
npm run test:install-scripts
```

- [ ] 全部通过（环境缺少可选组件时允许 SKIP，但要记录）。

## 4. 构建分发包 + 更新清单

```bash
npm run release:zip        # dist/qq-bridge-<版本>.zip
npm run release:manifest   # dist/latest.json（sha256/size/兼容线/说明）
```

产物：

```text
dist/qq-bridge-0.3.0.zip
dist/latest.json
```

- [ ] `dist/qq-bridge-<版本>/` 里手工抽查：根目录有 `README.md`、`config.example.json`、`安装.cmd`、`启动.cmd`、`node.cmd`；`src/`、`public/`、`scripts/`、`dsh/`、`plugins/`、`migrations/` 完整。
- [ ] 默认人格存在：`roles/傲娇助手.md`、`roles/小鲸鱼.md`（且未被脱敏替换）。
- [ ] `latest.json` 里 `sha256` 与 zip 的 SHA256 一致、`size` 一致。

## 5. 校验压缩包

```powershell
Get-FileHash .\dist\qq-bridge-0.3.0.zip -Algorithm SHA256
```

- [ ] 与 `latest.json` 的 `sha256` 一致。
- [ ] 压缩包大小合理（约 1.7 MB，不含 `node_modules`）。
- [ ] 解压后无 `state/`、无 `config.json`、无个人数据。

## 5.5 许可证检查

- [ ] `LICENSE` 是专有授权许可（非开源），含「授权用户 / 禁止再分发 / 禁止商用 / 历史版本 MIT」条款。
- [ ] `README.md` 有「许可证与授权」段；`package.json` / 插件包的 `license` 字段为 `SEE LICENSE IN LICENSE`。
- [ ] 发行包内含 `LICENSE`。

## 6. 发布

在**公开的发布仓库** `Derpyu520/qq-bridge-releases` 创建 Release `v0.3.0`（源码仓库保持私有不影响更新），**同时上传两个附件**：

- [ ] `qq-bridge-0.3.0.zip`
- [ ] `latest.json`（**必须**；自动更新通过 `https://github.com/Derpyu520/qq-bridge-releases/releases/latest/download/latest.json` 读取）

Release 说明可直接用 `CHANGELOG.md` 的 0.3.0 段落，并写明：

- 版本、日期、适配的 DSH 版本范围（本版 `0.2.0-rc.2 ~ 0.2.1`）；
- 朋友安装方式（解压 → 安装.cmd → 启动.cmd）；
- 自动更新从 **0.3.0 之后的版本**开始生效（0.3.0 用户第一次升级到新版本仍可点控制台按钮完成）。

## 7. 发布后冒烟

- [ ] 全新解压 → `安装.cmd` → 启动 → 控制台可打开、QQ 私聊能回。
- [ ] 控制台版本显示 `0.3.0`；检查更新应返回「已是最新」。
- [ ] 下一次发版（如 `0.3.0-r2`）后，用已装的 0.3.0 实测一次：横幅出现 → 更新 → 重启 → 版本变化、`config/state/roles` 保留、`_backups/update/` 有备份。
- [ ] 如果需要回滚，用控制台「回滚到上一版本」验证一次。
- [ ] 发布失败时保留旧包和备份，按备份指南回滚。

## 已知限制

- 本仓库没有本地 git 历史，发布包由文件清单生成，不是 `git archive`。
- 版本线：`MAJOR.MINOR.PATCH` 跟随 DSH 版本线，同一线内的修订用 `-rN`（如 `0.3.0-r2`）。跨线不会自动更新，只提示手动升级。
- 个人角色/OST 数据默认不发布；需要分享角色时另行脱敏打包。
- 桌面版 DSH 的 `verify:adaptation` 活体段跑不了（依赖 app.asar），以「真实 QQ 收发 + 更新链路」作为验收。
- 自动更新的健康检查只以「桥接控制台成功启动」为准；更新后仍需用户自行确认 DSH 状态（弹窗会提示需要重启 DSH 的情况）。
