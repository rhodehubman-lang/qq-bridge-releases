# 桌面版 DSH 适配（DESKTOP_DSH_SUPPORT）

> 状态：**方案已定，发行阻塞项**；2026-10-31 起实施
> 决策（2026-10-30）：走**桌面版适配路线**，把朋友的安装工作量压到最低
> 背景：VM 实测记录见 [HANDOFF-2026-10-30.md](../HANDOFF-2026-10-30.md) 第 9 节
> 目标一句话：**朋友只点 3 次鼠标，其余全自动。**

---

## 一、背景：VM 实测发现的三件事

1. **DSH 桌面版的 Web/API 服务和 `dsh web` 是同一套**。桥接连上桌面版随机端口（52984）后，事件流正常、QQ 收发正常——协议完全兼容。
2. **但桌面版端口每次启动随机**（宿主 60186 / VM 52984、12984……）。桥接配置里写死的 `dsh.baseUrl` 重启后必然失效，朋友不可能自己去查端口。
3. **preset/MCP 必须装在 DSH 实际使用的 profile**。桌面版用 `desktop` profile，而 `setup-dsh.mjs` 默认装的是 `web`——装错的表现是“QQ 上完全不回”，且日志里只写 `preset "qq-chat-v2" 无法解析`。

结论：协议不用改，只需要补**端口自动发现**和**profile 自动安装**。

---

## 二、目标

朋友侧完整安装流程，鼠标操作不超过 3 步：

1. 解压发行包，双击 `安装.cmd`
2. 打开 DSH 桌面版并登录（必须由本人完成）
3. 双击 `启动.cmd`

其余全部自动：依赖安装、配置生成、preset/MCP 安装、端口发现、快捷方式、检查清单。

---

## 三、设计

### 3.1 端口自动发现（核心）

解析顺序：

1. `config.json` 的 `dsh.baseUrl` 显式配置且**探测通过** → 直接用
2. `state/dsh-port.json` 缓存端口且探测通过 → 用
3. 自动扫描：
   - **Windows**：`netstat -ano` 取 `127.0.0.1` 的 LISTENING 端口 → `tasklist` 匹配进程名（`DeepSeek Harness.exe` / `electron.exe` 等）→ 得到候选端口
   - **Linux**：`ss -lntp` + `ps` 同样思路
   - 对候选端口做 DSH 特征探测（GET `/` 或 `/api/`，检查响应头/标题/401 形态）
   - 命中 → 写入 `state/dsh-port.json`，并可选写回 `config.json`
4. 全部失败 → 日志明确提示「请先启动 DSH 桌面版」，桥接**照常启动**（QQ 侧可用，DSH 侧等重连）

参数：

```json
"dsh": {
  "baseUrl": "http://127.0.0.1:3080",
  "autoDiscover": true,
  "discoverTimeoutMs": 15000
}
```

频率约束：启动时一次 + 首次连接失败后重试一次，之后指数退避；**不做每秒扫进程**。

### 3.2 profile / preset 自动安装

- `setup-dsh.mjs` 改为：遍历 `~/.dsh/profiles/*` **全部安装**（web、desktop、其它），幂等
- profiles 目录为空（DSH 还没启动过）→ 同时准备 `web` 和 `desktop` 两个目录，并提示“先启动一次 DSH 让它识别”
- MCP 条目写进**每个** profile 的 `cordis.patch.yml`
- 安装完成后必须提示“重启 DSH 才生效”

### 3.3 一键脚本

**`安装.cmd`**（新增）：

1. 检查 `node.cmd` / `pnpm.cmd` 是否存在（缺 → 提示装 Node 或先开一次 DSH）
2. `pnpm.cmd install`
3. `config.json` 不存在则从 `config.example.json` 复制
4. 跑 `setup-dsh.mjs`（全 profile）
5. 创建桌面快捷方式（启动.cmd、控制台 `.url`、重启检查清单）
6. 打印「请重启 DSH，然后双击 启动.cmd」

**`启动.cmd`**（新增）：

1. 探测 DSH 是否在线（复用 3.1）
2. 不在线 → 提示「请先打开 DSH 桌面版并入」，`pause` 退出
3. 在线 → 把端口写进配置 → `call start.bat`

**`start.bat`**：保持修复版（`call "%~dp0node.cmd"` + 纯 ASCII + CRLF）。

---

## 四、验收标准

1. 全新 VM（快照回滚）→ 解压发行包 → 双击 `安装.cmd` → 打开 DSH 登录 → 双击 `启动.cmd` → 私聊收到回复
2. 全程不要求朋友：开命令行、改 JSON、查端口、手动装 preset
3. DSH 重启后，朋友只需双击 `启动.cmd`
4. 端口发现对 60186 / 52984 两种随机端口都有效
5. 失败场景（DSH 没开/没登录）有明确中文提示，不静默

---

## 五、风险与回退

| 风险 | 处理 |
| --- | --- |
| 扫端口 spawn PowerShell 被杀软拦 | 提供 `dsh.baseUrl` 手动填写的兜底，并打印当前探测日志 |
| DSH 桌面版未来改端口/鉴权策略 | `dshCompat` 版本线（更新器已有设计） |
| 多 profile 重复安装产生垃圾 | 幂等设计，重复运行只覆盖链接 |
| 更新器装完也要重启 DSH | 更新弹窗必须提示，且清单标 `requiresDshRestart` |
| 时间不够 | 降级：文档写「用 `dsh web` 固定 3080」，一键脚本进 0.3.0 |

---

## 六、任务拆分（2026-10-31）

| 阶段 | 内容 | 预估 |
| --- | --- | --- |
| P1 | 端口发现模块 + 单测（含主机 60186 / VM 52984 两个真实样本） | 2h |
| P2 | `setup-dsh.mjs` 全 profile + 幂等 | 1h |
| P3 | `安装.cmd` / `启动.cmd` | 2h |
| P4 | VM 全新流程验证（用快照回滚到干净状态） | 1h |
| P5 | 文档 + 发行检查清单更新 | 1h |

---

## 七、与发行的关系

**这是发行阻塞项。** 不解决，「朋友能自己装」这个前提就不成立。今天 VM 里踩到的 `start.bat`、profile、端口三个坑，朋友一个都绕不过去。

如果 10-31 当天做不完，最小可发布方案是：

1. `start.bat` 修复（必须）
2. `setup-dsh.mjs` 全 profile（必须）
3. 端口发现做成「启动时扫一次 + 失败提示手动填」（可接受）
4. 一键脚本和自动化留到 0.3.0

---

## 八、实施进度

### 2026-10-31：P1 完成

交付物（先进本地工作区，并同步到共享目录 `p1/`）：

| 文件 | 内容 |
| --- | --- |
| `src/dsh-port.js` | 地址归一化、Windows netstat / tasklist 解析、Linux ss / ps 解析、进程名候选排序、HTTP 指纹探测、`state/dsh-port.json` 缓存、config→cache→扫描 优先级解析、`persistDshBaseUrl` 写回 |
| `scripts/find-dsh-port.mjs` | CLI：`--write` / `--json` / `--base-url` / `--timeout`；退出码 0/2/3/4 |
| `scripts/test-dsh-port.mjs` | 46 条断言，已挂进 `test:audit`；`package.json` 增加 `find:dsh-port` / `test:dsh-port` |

验证证据：

- 单测 **46/46 通过**；
- 宿主真实环境：扫描 29 个监听端口，**1405ms 命中 DSH 59626**（配置里过期的 19387 被正确跳过）；
- 指纹取自实测：未鉴权 GET `/` → `401` + `dsh web authentication required`。

### 2026-10-31：P1.5 完成（0.2.1 适配回灌）

按 A 方案把 `v0.2.1-r1` 的适配增量回灌本地树（**不动**本地 10-27~10-30 的功能代码）：

| 回灌项 | 说明 |
| --- | --- |
| `dsh/agent-presets/qq-chat*` | 删除 `suffix: ... {{cwd}}`；带入 0.2.1 时代的人格文案（鲸鱼身份、表情包/斗图规则、别用问号开场等） |
| `plugins/qq-agent-presets/qq-tool-restrict.mjs` | 0.2.1 新工具守卫（`working_directory`、`terminal_*`、`session_*`、`plugin_market`、`create_worktree`、`wait_agent`）+ 可选包名单 + restrict 失败诊断落盘 |
| `plugins/qq-agent-presets/presets/*.patch.yml` | 生成器重新生成（`--check` 通过） |
| `scripts/verify-dsh-021-adaptation.mjs` | 新验证脚本，`verify:adaptation` 指向它；旧的 020 版归档 |
| `scripts/verify-persona-config.mjs` | 改为「只允许 provider/model 两个变量」的断言 |
| `scripts/scan-dsh-tool-names.mjs` / `test-preset-local-tools.mjs` / `test-tool-restrict-guard.mjs` / `test-qq-preset-contract.mjs` | 0.2.1 版；`test:audit` 登记新守卫回归 |
| `docs/guides/DSH_021_ADAPTATION.md` | 适配记录；README（中/英）目标版本改为 0.2.1-rc.2 |

验证证据（2026-10-31，本地 + DSH 0.2.1-rc.5 模块树）：

- `verify-persona-config`：**全部通过**（preset 只引用 provider/model，无 `{{cwd}}`）
- `test-preset-local-tools`：**7/7**（守卫名单覆盖真实 0.2.1 工具、无拼错假名）
- `test-tool-restrict-guard`：**4/4**
- `test-qq-preset-contract`：**7/7**
- `test-preset-prompt`：**12/12**（顺手修了一个「LF/CRLF 环境依赖」的假失败）
- `build-agent-preset-patches --check`：已最新
- 另有 P1 的 `test-dsh-port` 46/46

已知限制：桌面版把 DSH 依赖打在 `app.asar` 里，`verify:adaptation` 的**活体段**需要 3080 上的 `dsh web`（云端/npm 部署），桌面版环境跑不了；P4 用「真实 QQ 收发」作为验收。

下一步：P2（`setup-dsh` 全 profile + 幂等）。

### 2026-10-31：P2 完成（全 profile 安装）

- `setup-dsh.mjs` 默认安装到 **`web` + `desktop` + `~/.dsh/profiles` 下所有已存在的其它 profile**；显式传参仍只装那一个（云端部署脚本 / 旧用法兼容）。
- 新增 `scripts/test-setup-dsh-profiles.mjs`：4 个场景——默认全装（含额外 profile 与自定义 patch 保留）、重复运行幂等、显式只装一个、全新 `DSH_HOME` 自动创建 web+desktop；已挂进 `test:audit`。
- 校验顺序改为「先验证所有目标 profile 的 YAML，再统一动手」，避免改一半才报错。
- 自动 `dsh plugin install`：CLI 候选改为「`DSH_CLI` → PATH → 桌面版自带 CLI」；profile 与 CLI 路径都走**环境变量**传参（cmd 单遍展开，防 `%CD%`/`&`/`!` 注入），含空格路径用 `call` 包裹。
- `start.bat` 改为 **纯 ASCII + CRLF + `call "%~dp0node.cmd"`**：无系统 Node 时窗口不再闪退，同时满足 guards 回归。
- 证据：`test-setup-dsh-profiles` **ALL PASS**；`test-audit-setup` **6/6**；`test-setup-dsh-idempotent` 通过；`test-audit-setup-guards` 通过。
- 下一步：P3（`安装.cmd` / `启动.cmd`）。

### 2026-10-31：P3 完成（一键安装 / 一键启动）

朋友侧的按钮齐了：

| 文件 | 作用 |
| --- | --- |
| `安装.cmd` | 一键：依赖安装 → 生成 `config.json` → `setup-dsh`（全 profile）→ 桌面快捷方式 |
| `启动.cmd` | 一键：自动发现 DSH 端口并写回 → 预检 SnowLuma → 调 `start.bat`（守护重启） |
| `scripts/install.mjs` | 安装逻辑（`--dry-run` / `--no-deps` / `--no-shortcuts` / `--desktop-dir`） |
| `scripts/check-onebot.mjs` | 启动前 OneBot 可达性预检（连不上给明确提示，不阻塞启动） |
| `scripts/create-desktop-shortcuts.ps1` | 纯 ASCII PowerShell + 环境变量传中文名，创建 `.lnk` / `.url` |

- 编码契约：两个 `.cmd` = **UTF-8 无 BOM + CRLF + 首行 `chcp 65001`**；`安装.cmd` 纯 ASCII，`启动.cmd` 中文提示实测正常。
- `安装.cmd` 还会**自动发现 SnowLuma 连接**（复用 `src/snowluma-conn.js`，真发一次 `get_login_info` 探测），把 `accessToken` / `httpUrl` / `wsUrl` 写回 `config.json`——朋友不需要手改 JSON；找不到只提示不阻断（可能还没启动 SnowLuma）。
- 验证：`test-install-scripts` **43/43**（含 `安装.cmd --dry-run` 真运行、桌面 `.lnk`/`.url` 真创建、SnowLuma 自动发现写入/失败保护）；`build-release` 已把新文件打进发行包（stage 内确认有 `安装.cmd` / `启动.cmd` / `scripts/install.mjs` / `check-onebot.mjs` / `create-desktop-shortcuts.ps1`）。
- 朋友流程：装 DSH 并登录 → 双击 `安装.cmd` → 双击「启动QQ桥接」。

### 2026-10-31：P4 完成（VM 朋友视角全流程，手动演练）

演练：VM 全新解压 → `安装.cmd` → `启动.cmd` → 控制台填白名单 → 主人号私聊。
**结果：全流程通过**。DSH 重启后端口 `64381 → 57315`，`启动.cmd` 自动写回 config 并连上（P1 端口发现生效）；SnowLuma 1006 后自愈成功。

演练中发现并修复的真实坑（都已进回归）：

1. `node.cmd` 只认 `~/.dsh/dsh-runtimes`，桌面版运行时在安装目录 → **首装直接失败**；已加桌面版/全用户/CLI 运行时候选 + 回归。
2. `pnpm.cmd` 同源问题 → 同样修。
3. 发行 zip 中文文件名：PS `Compress-Archive` 写成 GBK 且无 UTF-8 标记 → 解压后 `安装.cmd` 乱码；改用 Windows 自带 bsdtar + `zip:hdrcharset=UTF-8`，并在打包后校验。
4. SnowLuma 自动发现只认 `config.homeDir` → 朋友把 SnowLuma 放桌面时全 401；加常见路径 + Desktop 浅扫（实测：用户桌面的 `Snow Luma` 目录）。
5. 安装日志经 PowerShell `Tee-Object` 乱码 → `install.mjs` 自带 `--log` UTF-8 日志。
6. ~~发行包脱敏把“示例主人”替换成“示例主人”，快捷方式显示「启动示例主人QQ」~~ → 已改为中性名「启动QQ桥接 / QQ桥接控制台」。

另外两条发行要求（2026-10-31 追加）：
- **默认人格**：发行白名单保留 `roles/傲娇助手.md`、`roles/小鲸鱼.md`，且不做脱敏。
- **0.3.0 范围扩大**：自动更新器 + 数据迁移框架（见 `docs/AUTO_UPDATE.md`、`docs/DATA_MIGRATIONS.md`）。


### 2026-10-31：P6 角色通用性修复（发行阻塞）

VM 实测发现：发行包装完就出现 Jill 的世界/生活，且**未经同意自动生成并写盘**。
根因：开发树默认值固化（`bridge.js` 16 处 `|| 'jill'`、`life.profile='jill'`、`Glitch City`、VA-11 模板、故事提示词写死 Jill 世界观），并且世界/事件/故事默认自动开启。

修复内容：

- 新增 `config.characterId`（默认空）；活动角色 = 配置 → 控制台当前角色 → 已有生活档案；**一个档案都没有就禁用世界/生活/情绪/关系/故事**，控制台给空状态引导。
- 世界模板事件全部通用化（交通/天气/治安/商业/社区/谣言），不再有 VA-11/Jill/Karmotrine/White Knight 内容；类型 `white_knight → security`；新世界 `auto=false`。
- 事件工坊默认全关（`enabled/auto/autoApplyMinor=false`）；故事默认不自动（原本已关）；空角色时所有生成函数直接返回、不写盘；全新安装**不创建** `world-registry.json`/世界/故事/心情/关系文件。
- 故事提示词改为从生活档案读取城市与称呼，不再内置 VA-11 世界观。
- 控制台占位符通用化（`my-character` / `临海市`），确认框去掉 Jill。
- 新增 `scripts/test-role-agnostic.mjs`（20 条：发行代码禁止串扫描、默认关闭、空角色降级、模板配置、全新目录不写盘），已挂 `test:audit`。
- 回归：world-engine / world-events / world-registry / life-engine / mood / relationship / story 全部通过；发行包已重打并校验代码目录无禁止串。

下一步：VM 清空重装复测（确认全新安装无任何自动写入），然后继续 0.3.0 更新器。

### 2026-10-31：0.3.0 发行候选完成

- 版本 bump 到 **0.3.0**；发行包 `dist/qq-bridge-0.3.0.zip`（含 安装.cmd/启动.cmd、默认人格、更新器、迁移框架）。
- `latest.json` 已生成并与 zip 校验一致；演练物料在 `release-0.3.0/` 与 `update-test/`。
- 全部新回归通过（更新器 159 条、迁移 32、角色通用 20、安装脚本 55、控制台静态）。
- 下一步：VM 真机演练 0.3.0 → 0.3.1（本地假更新源），通过后发布。

下一步：VM 演练 + 发布。

- 下一步：P4（VM 快照回滚 → 按朋友视角全流程重放）。


### P2 前的决策点（待拍板）

**发行基线**：本地树是 `0.2.0-r4`，preset 里含 `{{cwd}}`，在 DSH 0.2.1 上每回合 fail loud（QQ 表现为完全不回）；而朋友装桌面版会拿到 0.2.1+。

建议：把 `v0.2.1-r1` 的适配增量**回灌本地树**（去掉 `{{cwd}}`、补齐 0.2.1 新工具守卫、换用 0.2.1 验证脚本），再继续 P2；否则 P4（朋友视角全流程验证）在 VM 上必然失败。

P2 起要动 `setup-dsh.mjs` / `start.bat` / 新增 `安装.cmd`、`启动.cmd`，需要先确定基线在哪个树。
