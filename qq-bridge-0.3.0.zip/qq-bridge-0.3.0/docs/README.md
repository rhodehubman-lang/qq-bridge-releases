# 文档索引（docs/README.md）

> 最后核对：2026-10-29
> 这里只列**当前真实存在**的文档；旧索引、过期设计稿和一次性报告已经移到项目外归档，不再制造死链。
> 目录结构见 [FOLDER_MAP.md](FOLDER_MAP.md)。

---

## 先看这几篇

| 文档 | 用途 |
| --- | --- |
| [ROADMAP.md](ROADMAP.md) | 公开脱敏版路线图：已完成、未完成计划、风险、预算 |
| [BEGINNER_GUIDE.md](BEGINNER_GUIDE.md) | 公开脱敏版小白手册：从消息旅程到记忆、生活、群聊策略 |
| [FOLDER_MAP.md](FOLDER_MAP.md) | 当前仓库目录、`scripts/` 命名约定、哪些是用户数据 |
| [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md) | 发布前隐私、测试、打包、校验与冒烟检查清单 |
| [../RULES.md](../RULES.md) | 权限边界与安全承诺 |

## guides/ —— 使用与运维

| 文档 | 说明 |
| --- | --- |
| [guides/DSH_SETUP.md](guides/DSH_SETUP.md) | DSH 端安装：preset、MCP server、目标设备接入 |
| [guides/DSH_020_ADAPTATION.md](guides/DSH_020_ADAPTATION.md) | DSH 0.2.0 适配记录与升级检查清单 |
| [guides/DSH_021_ADAPTATION.md](guides/DSH_021_ADAPTATION.md) | DSH 0.2.1 适配记录：删除 `{{cwd}}` 的根因、0.2.1 新工具守卫、验证清单 |
| [guides/SNOWLUMA_UPDATE.md](guides/SNOWLUMA_UPDATE.md) | SnowLuma Docker 安全更新、Hook 就绪判断、自动重试与回滚 |
| [guides/SECURITY_BASELINE.md](guides/SECURITY_BASELINE.md) | 安全基线、威胁模型、发布前检查 |
| [guides/PRIVACY.md](guides/PRIVACY.md) | 隐私边界：群聊/私聊、跨群上下文、记忆可见性 |
| [guides/CROSS_GROUP_AND_TASKS.md](guides/CROSS_GROUP_AND_TASKS.md) | 每群策略、主人私聊跨群上下文、跨群汇报、跨群印象、安排 |
| [guides/RELATIONSHIPS_AND_MOOD.md](guides/RELATIONSHIPS_AND_MOOD.md) | 关系与情绪：短期情绪、长期关系、隔离范围、控制台与接口 |
| [guides/COMMITMENTS_AND_IMPLICIT_REQUESTS.md](guides/COMMITMENTS_AND_IMPLICIT_REQUESTS.md) | 听话外音与承诺记忆：当前实现的两层、边界、控制台与数据 |
| [guides/CONVERSATION_PACING.md](guides/CONVERSATION_PACING.md) | 聊天分寸：冷场识别、收住与恢复，数据与开关边界 |
| [guides/SLEEP_CATCHER.md](guides/SLEEP_CATCHER.md) | 抓睡觉：晚安后群里再出现、时间窗口、语气与隐私边界 |
| [guides/MULTIMODAL_AND_OST.md](guides/MULTIMODAL_AND_OST.md) | 聊天记录展开、GIF 抽帧故事板、角色专属 OST 记忆 |
| [guides/BACKUP_AND_RESTORE.md](guides/BACKUP_AND_RESTORE.md) | 自动备份、保留策略、恢复与迁移 |
| [guides/TOKEN_USAGE_CONSOLE.md](guides/TOKEN_USAGE_CONSOLE.md) | 控制台「令牌与花费」看板、计价口径、API |
| [guides/VOICE.md](guides/VOICE.md) | 语音发送：默认关闭、`voice-cli.mjs`/`voice-gui.mjs`、ffmpeg 依赖与配置顺序 |
| [guides/TOKEN_BUDGET.md](guides/TOKEN_BUDGET.md) | 人民币日限额、峰谷时段、省电/警告/下线三档与接口 |
| [guides/CONSOLE-UI-TESTING.md](guides/CONSOLE-UI-TESTING.md) | 控制台离线预览与浏览器回归 |

## plans/ —— 待检阅计划

| 文档 | 说明 |
| --- | --- |
| [plans/CITY_OVERHAUL_PHASE1.md](plans/CITY_OVERHAUL_PHASE1.md) | 城市大改第一阶段：最小闭环、明确不做清单、验收标准与回滚 |
| [plans/CITY_SIMULATION_FEASIBILITY.md](plans/CITY_SIMULATION_FEASIBILITY.md) | 城市模拟技术可行性备忘：L0–L3、交通分层、成本、红线与推迟条件（不排期） |
| [plans/EVENT_LIFECYCLE.md](plans/EVENT_LIFECYCLE.md) | 事件生命周期与城市状态联动：持续事件/悬案/余波、未决池结算频率、城市标签层、分阶段验收（方案已定，未开工） |
| [plans/AUTONOMOUS_TOPIC_ENGAGEMENT.md](plans/AUTONOMOUS_TOPIC_ENGAGEMENT.md) | 自主话题与追答：能力拆解、成本实测与推演、社交/工程风险、硬护栏、分档路线（研究备忘，高危，不排期） |
| [plans/AUTO_UPDATE.md](plans/AUTO_UPDATE.md) | 自动更新：版本线与 DSH 兼容、latest.json 清单、白名单替换、双平台 helper、回滚与测试计划（方案已定，0.3.0 实施） |
| [plans/DESKTOP_DSH_SUPPORT.md](plans/DESKTOP_DSH_SUPPORT.md) | 桌面版 DSH 适配：端口自动发现、preset 自动装到实际 profile、一键安装/启动脚本（发行阻塞项） |

## 文档维护约定

- 只把**真实存在、仍然有效**的文档放进本索引。
- 过期设计稿/一次性测试报告移到项目外归档，不留在 `docs/` 里当“待办”。
- 新功能至少更新：`CHANGELOG.md`、对应 guide、本索引。
- 根目录文档只保留 `README.md`、`README.en.md`、`RULES.md`。
