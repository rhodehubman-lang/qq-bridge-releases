# 自动更新（AUTO_UPDATE）：方案与实施计划

> 状态：**方案已定，0.3.0 实施**；本次发行版不带更新器
> 更新：2026-10-30
> 平台：Windows 本地 + Linux 云服务器（双 helper）
> 发布源：GitHub Release 附件 `qq-bridge-<版本>.zip` + `latest.json`
> 原则：**只提示、不静默；只换代码、不碰数据；失败必须能回滚。**

---

## 〇、已拍板（2026-10-30）

| # | 决定 | 结论 |
| --- | --- | --- |
| 1 | 朋友环境 | **Windows 本地 + Linux 云服务器都要** |
| 2 | 排期 | **0.3.0 实施**；本次发行版先发，更新器进下一个版本 |
| 3 | 发布方式 | **Release 附件 zip + latest.json**（不用 git pull / zipball） |
| 4 | 触发方式 | 控制台顶部横幅 + 弹窗，**用户点按钮才安装**，不静默 |
| 5 | 备份 | 弹窗里可勾选「更新前自动备份」，默认勾选 |
| 6 | 安全 | sha256 必校验；只从配置的仓库/清单取包；只替换代码白名单 |

---

## 一、现状与前置条件

| 项 | 现状 | 对更新的意义 |
| --- | --- | --- |
| 仓库 | `github.com/Derpyu520/qq-bridge`（公开） | 朋友端不需要 token |
| Release 附件 | **目前全部为空** | ⚠️ **必须先改发布流程**，否则没有可下载的包 |
| 版本线 | 存在 `0.2.0-r4`（DSH 0.2.0 线）与 `v0.2.1-r1`（DSH 0.2.1 线） | 不能简单“推最新”，必须按版本线匹配 |
| 发行包 | `npm run release:zip` → 213 文件 / 约 4MB，不含 `node_modules` / `state` / `config.json` | 更新包直接复用 |
| 备份 | 已有每日自动 + 手动 + 恢复前再备份（`src/backup.js`） | 「更新前备份」直接复用 |
| 重启 | `start.bat` 守护循环（退出 5 秒自动重启）；`restart.bat` 按 PID 杀干净再启动 | 更新后重启有现成机制 |
| 说明 | Release notes 写得很详细 | 直接作为弹窗里的「更新内容」 |

**前置动作（发布侧）**：每次发布必须上传 `qq-bridge-<版本>.zip` 与 `latest.json` 到 Release 附件；`latest.json` 的附件名固定。

---

## 二、版本与版本线

### 2.1 版本格式

`MAJOR.MINOR.PATCH[-rN]`，`N` 从 1 递增。

- 排序：先比 `MAJOR.MINOR.PATCH`，同级再比 `rN`；**无 `-rN` 视为 `r0`**（因此 `0.2.0` 比 `0.2.0-r4` 旧）。
- 版本线 `line = MAJOR.MINOR.PATCH`（如 `0.2.0` / `0.2.1`）。**版本线与 DSH 版本线同步**。
- 默认**只在同一版本线内更新**；跨线更新意味着 DSH 也要换版本，必须人工确认，更新器只提示不安装。

### 2.2 兼容性

`latest.json` 里每个版本带 `dshCompat`（如 `{ "min": "0.2.0-rc.2", "max": "0.2.1" }`）。
桥接尽力读取当前 DSH 版本；读不到时弹窗显示「无法确认 DSH 版本」，要求用户手动勾选确认后才能继续。

---

## 三、更新清单 `latest.json`

```json
{
  "schema": 1,
  "updatedAt": "2026-11-02T12:00:00+08:00",
  "recommended": {
    "line": "0.3.0",
    "version": "0.3.0",
    "tag": "v0.3.0",
    "releasedAt": "2026-11-02",
    "asset": "qq-bridge-0.3.0.zip",
    "assetUrl": "https://github.com/Derpyu520/qq-bridge/releases/download/v0.3.0/qq-bridge-0.3.0.zip",
    "sha256": "……64 位小写十六进制……",
    "size": 0,
    "dshCompat": { "min": "0.2.0-rc.2", "max": "0.2.1" },
    "requiresDshRestart": false,
    "notes": "## 更新内容\n……"
  },
  "lines": {
    "0.2.0": { "version": "0.2.0-r5", "tag": "v0.2.0-r5", "assetUrl": "…", "sha256": "…", "dshCompat": {} },
    "0.2.1": { "version": "0.2.1-r2", "tag": "v0.2.1-r2", "assetUrl": "…", "sha256": "…", "dshCompat": {} }
  }
}
```

- `recommended`：当前主推版本（给“不知道自己在哪条线”的用户兜底）。
- `lines`：按版本线的精确匹配，优先使用。
- `requiresDshRestart`：MCP 子进程代码有变化时为 `true`，弹窗要提示「更新后需要手动重启 DSH」。
- 发布时由 `npm run release` 自动生成，**不手写**。

---

## 四、数据流与时序

```text
控制台加载
  └─ GET /api/update/status      ← 上次更新结果（成功/失败/已回滚）
  └─ GET /api/update/check       ← 有缓存，按 interval 自动查

发现新版本
  └─ 顶部横幅「发现新版本 v0.3.0」+「查看」
      └─ 弹窗：版本 / 日期 / 大小 / 更新内容 / DSH 兼容 / ☑ 更新前自动备份
          ├─ 「稍后」→ 本次会话不再提示
          ├─ 「跳过此版本」→ 记录跳过，直到有更高版本
          └─ 「立即更新」
               ├─ POST /api/update/apply { backup: true }
               ├─ 桥接进程内：下载 zip → 校验 sha256 → （备份）→ 写 state/update.json
               ├─ 拉起独立 helper（Windows: PowerShell / Linux: bash），桥接退出
               ├─ 弹窗提示「桥接正在更新并重启，约 10~30 秒后页面自动刷新」
               └─ 页面轮询 /api/update/status（重启后恢复）
```

helper 做的事：

```text
停桥接（复用 restart.bat / systemctl 的杀进程逻辑）
  → 代码目录备份到 _backups/code/<当前版本>-<时间戳>/
  → 解压新包到临时目录，校验根目录与白名单
  → 逐文件覆盖代码目录（不删除本地额外文件）
  → package.json / lockfile 有变化 → pnpm.cmd install（Linux: pnpm install）
  → 启动桥接
  → 轮询 /api/status，60 秒内健康则写 update.json = done
  → 不健康：恢复代码备份 → 重启 → 写 update.json = rolled-back
```

---

## 五、安全边界

### 5.1 只替换白名单（代码），绝不碰数据

| 允许替换 | 永不触碰 |
| --- | --- |
| `src/` `public/` `scripts/` `dsh/` `plugins/` `ops/` `docs/` `assets/` | `state/` `config.json` `roles/` `life-profiles/` `osts/` `audio/` |
| 根文件：`README*.md` `CHANGELOG.md` `LICENSE` `RULES.md` `config.example.json` `package.json` `package-lock.json` `pnpm-lock.yaml` `node.cmd` `pnpm.cmd` `start.bat` `restart.bat` 三个 `.cmd` | `node_modules/` `_backups/` `.git/` `dist/` `_local/` `_cloudcheck/` 控制台生成的 `state/console-token` |

- **只覆盖不删除**：新包里没有的本地额外文件保留，避免误删用户脚本；旧版本废弃文件暂时留在原地（不影响运行，后续版本再清理）。
- **zip 路径穿越防护**：解压前拒绝 `..`、绝对路径、盘符、符号链接条目。

### 5.2 校验与来源

- 必须校验 `sha256`（清单里）与文件大小；不匹配直接中止，不动任何文件。
- 默认只从配置的 `repo` 的 Release 附件取包；自定义源需在设置页手动填写并二次确认。
- 手动兜底：设置页支持「从本地 zip 安装」，同样校验包内 `package.json` 的版本号与路径。
- **不做静默安装**，不做开机自动更新，不做跨版本线自动升级。

### 5.3 权限

- `/api/update/*` 只允许**控制台**调用，Agent/MCP 一律拒绝（避免模型自我升级）。
- 控制台仍走 token 鉴权；更新器不引入新端口。

---

## 六、接口与配置

### 6.1 接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/update/check?force=1` | 返回当前版本、目标版本、是否可更新、兼容性、说明 |
| GET | `/api/update/status` | 读取 `state/update.json`（阶段/结果/错误） |
| POST | `/api/update/apply` | `{ version, backup }`，下载+校验+备份+拉起 helper |
| POST | `/api/update/rollback` | 拉起 helper 回滚到上一个代码备份 |
| POST | `/api/update/local` | 上传本地 zip（multipart），校验后走同样的 apply 流程 |
| GET/POST | `/api/update/config` | 读取/保存更新设置 |

### 6.2 配置段

```json
"updates": {
  "enabled": true,
  "repo": "Derpyu520/qq-bridge",
  "autoCheck": true,
  "checkIntervalHours": 6,
  "channel": "auto",
  "allowPrerelease": false,
  "customManifestUrl": "",
  "keepCodeBackups": 3
}
```

---

## 七、文件改动清单

| 文件 | 类型 | 内容 |
| --- | --- | --- |
| `src/update-engine.js` | 新增 | 版本解析/比较、版本线匹配、清单解析、sha256、白名单、zip 安全检查（纯函数，可单测） |
| `src/bridge.js` | 修改 | 更新配置、API 路由、启动时读取 `state/update.json`、检查定时器 |
| `scripts/apply-update.ps1` | 新增 | Windows helper：杀进程 → 备份代码 → 解压覆盖 → 依赖重装 → 启动 → 健康检查 → 回滚 |
| `scripts/apply-update.sh` | 新增 | Linux helper：同上，用 systemd |
| `scripts/build-release.mjs` | 修改 | 输出 zip 的同时生成 `dist/latest.json`（含 sha256、size、version、dshCompat、notes 摘要） |
| `public/console.html` | 修改 | 顶部横幅、更新弹窗、更新设置页、进度与结果、回滚按钮 |
| `scripts/test-update.mjs` | 新增 | 版本比较表、清单解析、sha256、白名单、zip 穿越、接口鉴权 |
| `docs/guides/AUTO_UPDATE.md` | 新增 | 面向用户的使用说明（怎么更新、怎么回滚、怎么换源） |
| `docs/RELEASE_CHECKLIST.md` | 修改 | 新增「发布附件上传」检查项（0.3.0 起） |
| `.github/workflows/release.yml` | 可选 | 打 tag 自动构建并上传附件（P2） |

---

## 八、回滚

- **代码回滚**：每次更新前把代码白名单目录复制到 `_backups/code/<版本>-<时间戳>/`，保留 `keepCodeBackups` 份。
- **自动回滚**：helper 启动后健康检查失败（60 秒内 `/api/status` 不通或版本号未变）→ 恢复代码备份 → 重启 → 记 `rolled-back`。
- **手动回滚**：控制台「更新」页有「回滚到上一版」按钮（只在存在代码备份时可用）。
- **数据不参与回滚**：`state/` 与 `config.json` 永远不换；数据安全靠现有的每日备份。

---

## 九、发布流程改造

1. `npm run release`（在原 `release:zip` 基础上）：
   - 生成 `dist/qq-bridge-<版本>/` 与 `dist/qq-bridge-<版本>.zip`
   - 生成 `dist/latest.json`（含 sha256、size、版本、dshCompat、release notes 摘要）
2. 在 GitHub 建 Release 时上传两个附件：zip 与 `latest.json`（名称固定）。
3. `docs/RELEASE_CHECKLIST.md` 增加检查项：附件已上传、`latest.json` 内 sha256 与实际文件一致。
4. 可选 P2：`.github/workflows/release.yml` 在打 tag 时自动完成 1~2。

---

## 十、测试计划

| 用例 | 期望 |
| --- | --- |
| 版本比较 | `0.2.0 < 0.2.0-r4 < 0.2.1-r1`；跨线不自动推荐 |
| 清单解析 | 缺字段/坏 JSON/未知 schema → 报错且不改任何文件 |
| sha256 | 篡改 1 字节 → 中止 |
| zip 穿越 | `../`、绝对路径、盘符条目 → 拒绝 |
| 白名单 | 包里出现 `state/` 或 `config.json` → 拒绝更新 |
| 依赖变更 | lockfile 变化时执行 `pnpm install` |
| 更新成功 | 版本号变化、桥接自动重启、QQ 收发正常 |
| 更新失败 | 自动回滚、数据完整、控制台显示原因 |
| 断网 | 下载失败 → 不动文件、可重试 |
| 鉴权 | Agent/MCP 调 `/api/update/*` → 403 |
| 双平台 | Windows 与 Linux 各完成一次成功 + 一次失败回滚 |

测试技巧：用 `customManifestUrl` 指向本地文件服务器，模拟“上游发版”，避免污染真实 GitHub Release。

---

## 十一、验收标准

1. 控制台顶部能发现新版本，弹窗显示版本、日期、更新内容、大小与 DSH 兼容提示；
2. 勾选备份后，`_backups/` 出现后备份记录；
3. 点「立即更新」后全自动完成下载、校验、替换、重启，页面自动刷新并显示新版本；
4. 任何一步失败都不破坏现有数据，且能自动或手动回滚；
5. 非控制台调用一律拒绝；
6. 跨版本线只提示、不安装；
7. Windows 与 Linux 各通过一次完整更新和一次回滚。

---

## 十二、明确不做

1. 不做静默/自动安装（必须点按钮）；
2. 不做从任意 URL 安装（自定义源需手动开启并二次确认）；
3. 不做差分/增量更新；
4. 不做数据迁移（更新只换代码）；
5. 不自动重启 DSH（需要时只提示）；
6. 不做跨版本线自动升级；
7. 本次发行版不带更新器。

---

## 十三、排期

| 阶段 | 内容 | 预估 |
| --- | --- | --- |
| P1 | `update-engine.js` + API + 清单/校验 + 单测 | 1 天 |
| P2 | Windows/Linux helper + 代码备份 + 自动回滚 | 1 天 |
| P3 | 控制台横幅/弹窗/设置页/回滚按钮 | 0.5 天 |
| P4 | 发布流程（`latest.json` + 附件说明 + 检查清单） | 0.5 天 |
| P5 | 双平台端到端测试 + 文档 | 1 天 |

合计约 **4 个工作日**。0.3.0 发布后，用 0.3.0 → 0.3.1 验证一次真实更新链路，再交给朋友。
