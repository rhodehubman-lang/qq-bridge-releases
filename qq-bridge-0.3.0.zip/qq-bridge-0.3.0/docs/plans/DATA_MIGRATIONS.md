# 数据迁移（DATA_MIGRATIONS）：城市/世界等数据在大型更新后的保全方案

> 状态：**已拍板（2026-10-31）：随 0.3.0 一起落地**；框架核心已实现
> 关联：`AUTO_UPDATE.md`（更新器）、`docs/plans/DESKTOP_DSH_SUPPORT.md`（发行）
> 核心结论：**备份/恢复只保证文件还在，不保证新代码认得旧数据**；必须在更新流程里加「数据迁移」阶段

---

## 一、问题：大型更新会怎么坏

朋友的“城市数据”实际是 `state/` 下的一批 JSON 文件。更新器保证「只换代码、数据原样恢复」，但如果新版本改了数据模型：

| 变更类型 | 例子 | 不迁移的后果 |
| --- | --- | --- |
| 字段语义变化 | `truth.weather` 从字符串改成 `{type, temp}` | 新代码读到旧格式，城市显示为空/报错 |
| 结构重排 | `state/worlds/*/truth.json` → `state/cities/*.json` | 新代码找不到旧文件，世界“重建”，朋友的城市消失 |
| 默认资源替换 | 新版内置城市模板/事件库 | 朋友自定义城市内容被模板覆盖（若按文件覆盖） |
| 版本不匹配 | 旧 `version: 1`，新代码只认 `version: 2` | 启动日志刷警告、功能静默失效 |

**关键**：这类问题**没有异常**、没有红字，朋友只会看到“我的城市没了/乱码了”，这是最坏的失效形态。

---

## 二、现有数据盘点（2026-10-31）

| 路径 | 内容 | 版本字段 |
| --- | --- | --- |
| `state/worlds/<worldId>/truth.json` | 世界/城市真值（天、事件、预算…） | `version: WORLD_VERSION` |
| `state/worlds/<worldId>/characters/<characterId>.json` | 角色对世界的认知 | `version: 1` |
| `state/world-registry.json` | 世界与角色注册表 | `version: REGISTRY_VERSION` |
| `state/world-event-session.json`、`state/world-event-agent/` | 随机事件运行态 | 暂无版本 |
| `life-profiles/<id>.json` | 角色生活配置（含 `world.name` 等） | 暂无统一版本 |
| `state/social-v2.json`、`sessions.json`、`stickers.json` 等 | 其余用户数据 | 各自有 version 或未标注 |

现有 `src/backup.js` 的 `BACKUP_ITEMS` 已覆盖 `state/`、`roles/`、`life-profiles/` 等用户数据，**可直接复用**做更新前备份和迁移前备份。

---

## 三、更新流程：插入迁移阶段

```text
用户点「更新」
  → ① 完整备份（代码 + 用户数据）到 _backups/update/<旧版本>-<时间戳>/
  → ② 下载新包 → sha256 校验 → 解压 → 只覆盖代码白名单
  → ③ 从备份自动恢复用户文件（config / state / roles / life-profiles / osts / audio）
  → ④【新增】数据迁移：
        node scripts/migrate-data.mjs --apply --backup
        · 逐文件读 version → 按迁移链逐级升级到新版 schemaVersion
        · 迁移前再打一次 data-only 备份（_backups/data/<时间戳>-migrate-<from>-to-<to>/）
        · 原子写入，报告迁移了哪些文件、哪些字段被搬移
  → ⑤ 启动桥接，健康检查
        · 健康 → update.json = done（附 restoredFiles + migratedFiles 报告）
        · 不健康 → 整包回滚（代码 + 用户数据 + 迁移备份）→ update.json = rolled-back
  → ⑥ 控制台显示更新结果：「已恢复 N 个文件，迁移 M 个数据文件（城市数据已保留）」
```

失败分两种，都能回滚到**更新前**的状态：

- 代码不健康 → 恢复整包备份（含数据）
- 迁移脚本报错 → 先恢复迁移前 data-only 备份，再整包回滚

---

## 四、迁移机制设计

### 4.1 迁移模块

```js
// migrations/0001-world-truth-v2.mjs
export default {
  id: '0001',
  name: '城市真值 v1→v2：weather 结构化',
  from: 1,
  to: 2,
  files: ['state/worlds/*/truth.json'],   // 支持通配
  apply(data, ctx) {
    // ctx 提供 readJson/writeJson/backupFile/log
    // 规则：只增不改旧字段、未知字段原样保留、无法映射的旧字段挪到 legacy.*
    return { ...data, weather: data.weather ? { type: String(data.weather), temp: null } : data.weather };
  }
};
```

- **幂等**：已迁移过的文件（version ≥ to）跳过。
- **dry-run**：`migrate-data.mjs --check` 只报告将要迁移什么。
- **JSON 报告**：迁移结束输出 `{ migrated: [{file, from, to}], skipped, errors }`，供控制台与日志展示。
- **不删文件**：旧目录/旧文件结构变化时，迁移写入新位置后**保留旧文件**（或挪到 `state/legacy/`），避免误删朋友数据；清理留到后续大版本（且需控制台确认）。

### 4.2 迁移编写原则（保数据，不保代码漂亮）

1. **只增不改**：新增字段给默认值；不轻易改名字；不删字段。
2. **未知字段保留**：用户/未来版本写入的字段一律 `...data` 带回，不 schema 白名单过滤。
3. **旧字段映射**：必须改结构时，旧字段值搬到新字段，旧字段可留作 `legacy.<field>`。
4. **按 id/键合并**：城市/角色/事件列表迁移时按 id 合并，不整表替换，避免覆盖朋友自定义内容。
5. **默认资源只补缺**：新版内置城市模板/事件库只补不存在的条目，绝不覆盖同名自定义项。
6. **每步可回滚**：每个迁移模块自己声明 `backup: true`，失败时恢复该步之前的 data-only 备份。

### 4.3 版本闸门（latest.json）

`latest.json` 增加：

```json
{
  "version": "0.3.0",
  "dataSchema": 2,
  "minDataSchema": 1
}
```

- 朋友当前数据 schema < `minDataSchema`：**拒绝自动更新**，提示「请先升级到中间版本」并列出升级路径（多步更新）。
- 迁移脚本长期保留（从 1 升到 N 的链路一直可用），因此 `minDataSchema` 通常可以保持在 1，除非发生无法自动迁移的重构。

---

## 五、测试策略

- 每个迁移模块配 fixture：`scripts/fixtures/data-migration/<id>/before/` 与 `expected/`，断言迁移后逐字段一致、未知字段不丢。
- `test-data-migrations.mjs` 挂进 `test:audit`：迁移链完整性（版本连续）、幂等（跑两次结果一致）、失败回滚。
- 更新器集成测试：造一个「旧数据 + 假新包」临时目录，跑完整 备份→更新→恢复→迁移→健康检查 流程。
- 大型更新（城市革新）发布前，用真实旧数据快照跑一次迁移 dry-run。

---

## 六、排期建议

| 阶段 | 内容 | 时机 |
| --- | --- | --- |
| 0.3.0 | 迁移框架骨架：schema 注册、`migrate-data.mjs` runner、更新流程接入、`dataSchema` 进 `latest.json`、测试 | **本次发行**（成本比更新器小，但必须和更新器同时上线） |
| 城市革新版本 | 只新增一个 `migrations/xxxx-city-v2.mjs` + fixture | 未来大型更新时 |
| 长期 | 迁移链保留、旧备份保留最近 N 份、控制台「数据迁移报告」页 | 持续 |

**为什么框架必须这次上**：更新器一旦开始给朋友自动换代码，下一次大型更新就没有“让朋友手动处理”的余地；迁移入口必须先存在。

---

## 七、实施进度

### 2026-10-31：框架核心完成（P1）

| 文件 | 内容 |
| --- | --- |
| `src/data-migration.js` | 数据集定义（world-truth / world-knowledge / world-registry / life-profile）、通配展开、版本扫描、迁移链规划、dry-run、执行、迁移前备份、原子写、迁移日志、`describeDataState` |
| `migrations/index.mjs` | 迁移模块注册表（当前为空；城市革新时只加一个模块） |
| `scripts/migrate-data.mjs` | CLI：默认 dry-run，`--apply` 执行，`--json` 给更新器/控制台，`--root` 测试 |
| `scripts/test-data-migrations.mjs` | **32 条断言**：版本探测、链式迁移、幂等、dry-run、备份、未知字段保留、失败不写坏文件、CLI 冒烟；已挂 `test:audit` |

下一步（随更新器一起）：
- 更新 helper 在「恢复用户文件」之后调用 `migrate-data.mjs --apply --json`，失败则回滚；
- `latest.json` 增加 `dataSchema` / `minDataSchema`；
- 首个真实迁移模块等城市革新版本再写（框架不再改）。
