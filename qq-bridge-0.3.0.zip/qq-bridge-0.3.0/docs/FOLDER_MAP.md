# 仓库目录地图（FOLDER_MAP）

> 最后核对：2026-10-28
> 本文只描述当前实际结构；文档索引见 [README.md](README.md)。
> 旧版目录地图和已失效的设计/审计稿已归档到项目外，不再保留死链。

---

## 一、顶层目录

| 目录/文件 | 作用 | 注意 |
| --- | --- | --- |
| `src/` | 桥接源码：`bridge.js` 主程序、DSH 客户端、MCP server、各功能模块 | `bridge.js` 约 16,000 行，是主入口 |
| `scripts/` | 测试、探针、一次性运维脚本 | 当前约 97 个文件；测试脚本不要随便删 |
| `public/` | 控制台前端 `console.html` | 运行时会读取，不要放备份 |
| `dsh/` | 要安装到 DSH 的 preset / 配置源 | 改 preset 后要重新生成并安装 |
| `plugins/` | DSH 插件（QQ mode、agent presets 等） | 改完要重装/重启 DSH |
| `roles/` | 人格卡 | 用户内容，别乱动 |
| `osts/` | 角色专属 OST 记忆 JSON | 用户内容；按角色隔离 |
| `life-profiles/` | 生活档案 JSON | 用户内容 |
| `state/` | 运行时状态：会话、记忆、策略、安排、日志、令牌 | **用户数据，绝不删除/移动** |
| `assets/` | 仓库图片等资源 | 不要加大体积二进制 |
| `docs/` | 文档 | 索引见 `docs/README.md` |
| `config.json` | 本机运行配置 | 真实配置不入库；模板是 `config.example.json` |
| `node_modules/` | 依赖 | 忽略 |

根目录另有 `README.md`、`README.en.md`、`RULES.md`、`CHANGELOG.md`、`AGENTS.md`、`LICENSE`、启动脚本等。

## 二、`src/` 主要文件

| 文件 | 作用 |
| --- | --- |
| `bridge.js` | 主程序：QQ 接入、唤醒、记忆、生活、世界、故事、控制台 API |
| `group-policy.js` | 每群参与策略与唤醒门控 |
| `cross-group.js` | 跨群上下文、汇报、跨群印象 |
| `owner-tasks.js` | 定时/关键词/条件安排 |
| `gif-storyboard.js` | GIF 抽帧故事板 |
| `ost-pack.js` | 角色专属 OST 记忆 |
| `world-engine.js` / `world-registry.js` | 世界动态与多世界注册 |
| `story-engine.js` | 故事工坊提示词与正史变更 |
| `mood-engine.js` | 心情第一阶段 |
| `relationship-engine.js` | 关系记忆：按角色 × 人、按私聊/群聊范围保存长期印象 |
| `commitments.js` | 听话外音/承诺记忆：按角色 × 群提取“等会儿/下次”类承诺，不自动唤醒 |
| `backup.js` | 自动备份与恢复：固定用户数据、保留策略、恢复前再备份 |
| `life-engine.js` | 作息/生活状态 |
| `mcp-snowluma-safe.js` | QQ 安全 MCP 工具 |
| `token-ledger.js` / `model-prices.js` | 花费账本与价格 |

## 三、`docs/` 结构

```text
docs/
├── README.md                 # 文档索引
├── FOLDER_MAP.md             # 本文件
├── ROADMAP.md                # 公开脱敏路线图
├── BEGINNER_GUIDE.md         # 公开脱敏小白手册
└── guides/
    ├── CROSS_GROUP_AND_TASKS.md
    ├── MULTIMODAL_AND_OST.md
    ├── DSH_SETUP.md
    ├── DSH_020_ADAPTATION.md
    ├── SECURITY_BASELINE.md
    ├── PRIVACY.md
    ├── TOKEN_USAGE_CONSOLE.md
    ├── BACKUP_AND_RESTORE.md
    └── CONSOLE-UI-TESTING.md
```

## 四、`scripts/` 命名约定

| 前缀 | 用途 | 处理 |
| --- | --- | --- |
| `test-*.mjs` | 自动化回归/契约测试 | 保留；改代码后按需跑 |
| `verify-*.mjs` | 安装/配置一致性校验 | 保留 |
| `probe-*.mjs` | 只读探针，问 DSH/QQ 当前能力 | 按需跑，不当回归 |
| `send-*.mjs` | 真发送工具 | 会真的发 QQ 消息，慎用 |
| `setup-*.mjs` | 安装/初始化 | 保留 |
| `cleanup-*` / `fix-*` / `diag-*` / `debug-*` | 一次性运维脚本 | 不是回归套件；确认无用后可归档 |
| `patch-snowluma-sdk.mjs` | postinstall 补丁 | **必须保留** |

## 五、归档位置

一次性云端验证文件、旧 `bridge.cloud.js`、控制台截图和旧 smoke 脚本已经移到：

```text
<项目目录>\_archive\2026-10-28-pre-cleanup\
```

项目内不再保留 700 KB 级的运行代码快照；需要对照旧版本时从归档取。
