@echo off
rem 安装 / 修复 DSH 端：注册 qq-chat / qq-chat-v2 preset、挂载 3 个 MCP server、
rem 把 qq-mode-console 与 qq-agent-presets 两个 bundle 接进 DSH 桌面版使用的
rem `desktop` profile。
rem
rem 何时重跑：DSH 升级后 preset/MCP 消失、profile 被重置、或本目录被移动过。
rem 跑完 DSH 通常会自动热加载 patch；若没有，重启 DSH 桌面版即可。
setlocal
cd /d "%~dp0"
call "%~dp0node.cmd" "scripts\setup-dsh.mjs" desktop
echo.
echo === 完成。若 DSH 里看不到 QQ 预设/工具，请重启 DSH 桌面版。 ===
pause
exit /b %errorlevel%
