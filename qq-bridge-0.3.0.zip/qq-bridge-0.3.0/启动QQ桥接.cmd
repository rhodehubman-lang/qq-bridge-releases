@echo off
rem 启动 QQ 桥接（守护模式：崩溃 5 秒后自动拉起；关掉窗口即停止）。
rem 等价于 start.bat，只是中文名更直观。node 由同目录的 node.cmd 提供
rem （本机没有全局 Node.js，DSH 桌面版自带运行时）。
setlocal
cd /d "%~dp0"
call "%~dp0start.bat"
exit /b %errorlevel%
