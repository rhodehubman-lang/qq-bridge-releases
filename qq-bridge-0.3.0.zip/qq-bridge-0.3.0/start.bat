@echo off

chcp 65001 >nul

cd /d "%~dp0"

rem No system-wide Node: node.cmd falls back to DSH's bundled runtime.

rem MUST use `call` - invoking a .cmd from a .bat without call never returns,

rem so the guard loop below would never run and the window would close.

set "NODE=%~dp0node.cmd"

rem Harden state/ ACLs (Windows needs WRITE_DAC; the directory owner normally has it,

rem so no UAC prompt in the usual case). This NEVER blocks startup: if it cannot get

rem permission it prints a copy-pasteable command and exits 0.

rem See docs/guides/SECURITY_BASELINE.md ("secrets at rest").

call "%NODE%" scripts\harden-state-acl.mjs --quiet

:loop

call "%NODE%" src\bridge.js

set code=%errorlevel%

if "%code%"=="3" (

    echo [start.bat] bridge handed over to update helper. This window can close.

    exit /b 0

)

if "%code%"=="2" (

    echo [%date% %time%] bridge already running in another window. Exiting.

    pause

    exit /b 2

)

echo [%date% %time%] bridge exited (code %code%), restarting in 5 seconds...

timeout /t 5 /nobreak >nul

goto loop

