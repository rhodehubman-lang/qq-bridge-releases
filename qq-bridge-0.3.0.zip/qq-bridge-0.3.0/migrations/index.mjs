// 数据迁移模块注册表。
//
// 新增一次迁移：
//   1. 在 migrations/ 下新建文件（如 `0001-world-truth-v2.mjs`），默认导出：
//        { id, name, dataset, from, to, apply(data, ctx) }
//      · dataset 对应 src/data-migration.js 的 DATASETS id
//      · from/to 必须是连续整数（from=2, to=3）
//      · apply 返回新对象；**未知字段原样保留**，旧字段值搬到新字段或 legacy.*
//      · 不要在这里读写文件，runner 负责备份/原子写/日志
//   2. 在下面 import 并加入 MIGRATIONS。
//   3. 配 fixture（scripts/fixtures/data-migration/<id>/before|expected）并挂进
//      scripts/test-data-migrations.mjs 的迁移链测试。
//
// 编写原则见 docs/DATA_MIGRATIONS.md §4.2。
export const MIGRATIONS = [];
