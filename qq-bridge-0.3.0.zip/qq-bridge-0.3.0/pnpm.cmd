@echo off
rem pnpm.cmd - run the pnpm that ships with DSH desktop, through node.cmd.
rem Used only when you need to re-install / update dependencies:
rem   pnpm.cmd install
rem
rem 2026-10-31 VM rehearsal: the first version only looked under
rem %USERPROFILE%\.dsh\dsh-runtimes, but the desktop app keeps pnpm inside its
rem install dir - so the very first one-click installer run failed with "Bundled pnpm not
rem found". Search the same places as node.cmd.
rem (Deliberately no "system pnpm first" probe: `where pnpm.cmd` would find
rem  this very file in the current directory and recurse forever.)
setlocal
set "PNPM_MJS="

set "DESKTOP_PNPM=%LOCALAPPDATA%\Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\pnpm\bin\pnpm.mjs"
if exist "%DESKTOP_PNPM%" set "PNPM_MJS=%DESKTOP_PNPM%"
if defined PNPM_MJS goto found

set "DESKTOP_PNPM_ALL=%ProgramFiles%\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\pnpm\bin\pnpm.mjs"
if exist "%DESKTOP_PNPM_ALL%" set "PNPM_MJS=%DESKTOP_PNPM_ALL%"
if defined PNPM_MJS goto found

set "DSH_PNPM=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\pnpm\bin\pnpm.mjs"
if exist "%DSH_PNPM%" set "PNPM_MJS=%DSH_PNPM%"
if defined PNPM_MJS goto found

for /d %%D in ("%USERPROFILE%\.dsh\dsh-runtimes\*") do (
  if not defined PNPM_MJS if exist "%%~D\dependencies\pnpm\bin\pnpm.mjs" set "PNPM_MJS=%%~D\dependencies\pnpm\bin\pnpm.mjs"
)
if defined PNPM_MJS goto found

echo [pnpm.cmd] pnpm not found. Tested: DSH desktop install dirs and %USERPROFILE%\.dsh\dsh-runtimes. 1>&2
echo [pnpm.cmd] Fix: open the DeepSeek Harness desktop app once, or install pnpm from pnpm.io. 1>&2
exit /b 127

:found
call "%~dp0node.cmd" "%PNPM_MJS%" %*
exit /b %errorlevel%
