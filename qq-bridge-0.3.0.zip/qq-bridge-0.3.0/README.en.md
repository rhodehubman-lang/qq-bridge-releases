# QQ ↔ DeepSeek Harness Bridge (qq-bridge)

> Connect QQ messages to DeepSeek Harness (DSH) agents: QQ friends/groups become DSH conversations, and agent replies (including questions and tool approvals) are sent back to QQ.

> 📦 **Releases live in a separate public repo**: the source repo can stay private. Installers and the update manifest are published to [`Derpyu520/qq-bridge-releases`](https://github.com/Derpyu520/qq-bridge-releases); friends only need access to that repo.
>
> 🖱️ **Windows quick start (3 steps)**: (1) install and sign in to the DeepSeek Harness desktop app once; (2) unzip the release and double-click **`安装.cmd`** (installs deps, creates `config.json` and auto-detects the SnowLuma connection (token/ports), installs presets/MCP into **all** DSH profiles, creates desktop shortcuts); (3) double-click the desktop shortcut **启动QQ桥接** (it discovers DSH's random port, pre-checks SnowLuma, then starts the bridge).
> Before each use: open DSH → open SnowLuma → double-click the shortcut.

> ⚠️ **Current release `v0.3.0`, targets DSH 0.2.1-rc.2** (also compatible with 0.2.0-rc.2) (verified item by item on that version; run `npm run verify:adaptation`). It uses the persistent local signing key to **mint the session Cookie offline**, slash RPC endpoints and the `/api/remote.mux` event stream — a protocol generation introduced in DSH `0.1.2-alpha.1`, incompatible with the older dot-endpoint protocol. Reading the launch token out of the old guard logs has not worked since DSH 0.1.7 (the token is generated per process and never written to disk). Agent presets are `@deepseek-ai/dsh-agent-preset` Cordis rows since DSH 0.1.7 (the `~/.dsh/.agent-presets/` directory mechanism is gone). On **DSH `0.1.1-rc.2` or earlier**, historical versions `v0.1.0` (DSH 0.1.1-rc.2 or earlier), `v0.1.5` (DSH 0.1.5-rc.1) and `v0.1.7` (DSH 0.1.7-rc.2) are **no longer available for download** and are documented for reference only.
>
> **v0.3.0 highlights**: one-click auto-update from the console (full backup before, user files restored after, rollback on failure), automatic discovery of the DSH desktop random port, one-click `安装.cmd` / `启动.cmd` installers, two bundled sample personas, removal of hard-coded private role defaults (no autonomous world/story writes on fresh installs), and a data-migration framework for large updates.
>
> **r4 highlights**: sticker/animated-emoji pipeline (CDN first, `emoji_id` fallback, multi-address DNS failover), web search now reuses DSH's own DeepSeek search backend (Bing only as fallback), `qq_wait_for_messages` long-polling past the 300 s undici timeout, plus fixes for the mode-switch rollback, permanent "busy" turns, missing self-identity injection and a full-project audit. Details: see the 0.2.0 section in `CHANGELOG.md`.
>
> The default branch `main` **is** this version — a plain `git clone` gets it, no branch switching needed.

For the Chinese documentation entry point, see **[docs/README.md](docs/README.md)**.
The documentation index (one line per doc, with "still current?" notes) is **[docs/README.md](docs/README.md)**;
the repository/folder and script-naming conventions are in **[docs/FOLDER_MAP.md](docs/FOLDER_MAP.md)**.

## Architecture

```
QQ messages ──► SnowLuma (OneBot v11 WS) ──► qq-bridge ──► DSH Web API (127.0.0.1:3080/api)
                                                    ▲                      │
                                                    └── agent replies / questions / approvals ┘
```

- **QQ side**: `@snowluma/sdk` provides the OneBot v11 WebSocket client.
- **DSH side**: adapted for DSH 0.1.2+ and **re-verified on 0.2.1-rc.2** (0.2.0-rc.2 also compatible) — session Cookie minted from the persistent local signing key, `/api/<namespace>/<method>` slash RPC, and `/api/remote.mux` + `session/follow` event stream (the pending queue is read from `value.projections[<id>].values.inbox`, with the unary `session/projections` RPC as the primary path). The per-session model is pinned by the bridge via `session.selectModel` from `config.json`'s `dsh.model` (default `deepseek-flash` = DeepSeek-V41-Flash, multimodal).
- **Agent tools**: three bundled MCP servers expose a restricted QQ toolset (`qq_status`, `qq_list_groups`, `qq_get_group_history`, `qq_send_group_message`, `qq_reply`, etc.), a read-only host probe (`snowluma_status` only), and a read-only `web_search` / `web_fetch` pair with SSRF protection.
  ⚠️ **`start_snowluma` / `stop_snowluma` (and `snowluma.allowProcessControl`) were removed in v0.1.5**: SnowLuma EULA §5.4 requires prior written permission to deploy its proprietary native components through automated scripts. This program only probes, never deploys — installing, starting and scanning SnowLuma is always up to you. See [LICENSE](LICENSE) and [RULES.md](RULES.md).
- **Console**: a local web console at `http://127.0.0.1:3100`, organised into twenty task-based pages (Overview, Sessions & Approvals, Persona, Life, World, Social v2, Social v1, Slang, Shared Memory, Memory Access, Group Policies, Schedule, Cross-group Reports, Relationships & Mood, Chat Pacing, Sleep Catcher, Usage & Cost, Access & Security, Operations, Tool Reference) with cross-page feature search and a **light / dark theme** (one-click toggle in the header; follows the OS preference until you choose), for mode switching, role management, whitelist/admin settings, slang management, memory, stickers and more. The Persona page manages roles (view/edit/rename/duplicate/delete the prompt of each persona), shows and edits both prompt layers separately — the **simulation prompt** built into the preset (tool/behaviour protocol; synced to DSH, restart required) and the **persona prompt** (`roles/*.md`; applied immediately) — and sets the **DSH reasoning effort** (`max` by default, `high`/`low` selectable). The **Usage & Cost** page shows real-time token consumption and its price in CNY, broken down per group/friend and per conversation turn (see [docs/guides/TOKEN_USAGE_CONSOLE.md](docs/guides/TOKEN_USAGE_CONSOLE.md)). The same page now includes a **CNY daily budget** (default ¥5/day): editable peak windows, a soft threshold that switches to a power-saving mode (lower reasoning effort, short replies, no proactive/background work), a warning message, and a hard daily cap that stops automatic wakes until the next budget-day reset (see [docs/guides/TOKEN_BUDGET.md](docs/guides/TOKEN_BUDGET.md)).

## Features

- Bridges QQ group/private messages to DSH agent sessions.
- Social simulation mode ("simulated group friend") with idle/active/probing/exiting states.
- Space-based message splitting for more natural multi-message replies.
- Whitelist/blacklist access control, fail-closed by default.
- Sensitive text audit prevents paths/credentials from being sent to QQ.
- MCP tools for reading group history/members, sending messages, replying with quotes, and (in `reserved2`) full simulated-group-friend tooling.
- Slang/network-expression learning with human confirmation.
- Lightweight memory system for active topics, pending thoughts and member impressions.
- Sticker library integration with AI-friendly sticker usage.
- Cross-group awareness and per-group policies: configurable participation/proactivity per group, an owner-private cross-group digest (default 22:30, urgent alerts, 3/day, quiet 23:00–08:00), per-character cross-group **impressions** (1–2 first-person fragments per group, written by the current role, injected only into the owner's private chat), and scheduled/keyword/condition tasks that wake the right conversation. Group-chat data only; owner private context only. Details: [docs/guides/CROSS_GROUP_AND_TASKS.md](docs/guides/CROSS_GROUP_AND_TASKS.md).
- **Relationships & mood**: short-term mood affects the tone of the current reply; long-term relationships are stored per character × person (familiarity, trust, warmth, tension), scoped by private chat/group, and injected as natural-language labels rather than numeric stats. The AI can only append observations; pinning, renaming and deletion are console-only. Daily consolidation runs around 04:30 when DSH is online, with up to 100 people per role and pinned people exempt from pruning. Details: [docs/guides/RELATIONSHIPS_AND_MOOD.md](docs/guides/RELATIONSHIPS_AND_MOOD.md).
- **Sleep catcher**: after the owner says goodnight in private chat, if they reappear in a group the current character can naturally tease “didn’t you say goodnight?”. Console settings cover the goodnight validity window, reappearance window, per-group cooldown, tone (light/teasing), a custom hint and which groups are allowed. Owner-only, group-only, and never opens a private chat with group members; insomnia/just-woke-up messages are skipped. Details: [docs/guides/SLEEP_CATCHER.md](docs/guides/SLEEP_CATCHER.md).

## Requirements

- Node.js >= 22.13
- Running DeepSeek Harness Web (default `http://127.0.0.1:3080`)
- Running SnowLuma with OneBot v11 WebSocket and HTTP API enabled

## Quick Start

```bash
npm install        # postinstall automatically patches the @snowluma/sdk ESM packaging bug
```

Copy `config.example.json` to `config.json`, then edit:

```bash
cp config.example.json config.json
```

Key settings:

| Field | Description |
| --- | --- |
| `dsh.baseUrl` | DSH Web API URL, default `http://127.0.0.1:3080` |
| `dsh.authToken` | DSH launch token (a process-launch credential). **Normally leave this empty**: with no token the bridge mints the session cookie offline from the persistent signing key in `~/.dsh/.credentials.yaml`, which depends on no per-process state (since DSH 0.1.7 the launch token lives only in memory — the one in the old logs belongs to a previous process and only yields a 401). A value here is honoured first if you set one |
| `dsh.authHeader` / `dsh.authPrefix` | Legacy fields kept for compatibility; the current path uses Cookie auth and does not send this header |
| `snowluma.wsUrl` | SnowLuma OneBot **WebSocket** URL (e.g. `ws://127.0.0.1:3001`) |
| `snowluma.accessToken` | OneBot access token, leave empty if not configured |
| `snowluma.httpUrl` | OneBot **HTTP API** URL (e.g. `http://127.0.0.1:3000`); do not point this at the WebSocket port or you will get HTTP 426 |
| `ownerQQ` | Administrator QQ (highest privilege) |
| `allow.private` / `allow.groups` | Whitelist of QQ/group IDs |
| `consolePort` | Local console port, default `3100` |

Start:

```bash
npm start
```

Or double-click `start.bat` on Windows (guard mode with auto-restart).

## DSH Setup on Another Device

The bridge and console can run without extra DSH setup, but the two DSH chat presets (`qq-chat` and `qq-chat-v2`) and the MCP servers must be installed into DSH once per machine:

```bash
node scripts/setup-dsh.mjs
```

By default it installs into **all profiles** (`web`, `desktop`, and any other existing profile under `~/.dsh/profiles`), so both the DSH desktop app and `dsh web` are covered.

This installs:

- the `qq-agent-presets` bundle, which generates the two `@deepseek-ai/dsh-agent-preset` rows (`qq-chat`, `qq-chat-v2`) plus the shared `qq-tool-restrict` safety guard
- MCP entries in `~/.dsh/profiles/web/cordis.patch.yml`
- `qq-mode-console` and `qq-agent-presets` in the profile `package.json` (`bundles` + `link:` dependencies)
- Default DSH mode set to `reserved2` (second-generation simulation), with a local `state/mode.json` fallback

Then restart DSH. See [docs/guides/DSH_SETUP.md](docs/guides/DSH_SETUP.md) for details.

## Security Notes

- `config.json` and `state/` are **never committed**; the repository only ships `config.example.json`. Both are ACL-hardened to the owner / SYSTEM / Administrators (`npm run harden-acl`).
- MCP send tools enforce whitelist checks and reject CQ-code injection.
- Local paths, credentials, tokens and other sensitive patterns are filtered by the audit layer.
- Simulation sessions get **no local execution tools at all**: the preset's `qq-tool-restrict` row hides them from the tool schema at registration time and a runtime allowlist rejects anything outside the QQ MCP namespaces (`npm run scan:tool-names` re-checks that list against the installed DSH).
- The console uses a generated token when none is configured.

## Repository Layout

```
qq-bridge/
  config.example.json   # sanitized config template (real config.json is not in repo)
  docs/
    README.md           # documentation index (current docs only)
    FOLDER_MAP.md       # current folder layout and scripts/ naming conventions
    ROADMAP.md          # public sanitized roadmap
    BEGINNER_GUIDE.md   # public sanitized beginner guide
    guides/             # DSH_SETUP / DSH_020_ADAPTATION / SECURITY_BASELINE / PRIVACY /
                        # CROSS_GROUP_AND_TASKS / MULTIMODAL_AND_OST / TOKEN_USAGE_CONSOLE / CONSOLE-UI-TESTING
  dsh/                  # DSH preset sources
  plugins/              # DSH plugins (QQ mode / agent presets)
  src/                  # bridge core, MCP servers and feature modules
  public/
    console.html        # local web console
  roles/                # persona cards
  osts/                 # per-character OST memory
  life-profiles/        # life profiles
  assets/               # images (the intro video ships as a release asset, not in the repo)
  scripts/              # tests and helper scripts
  state/                # runtime data (not in repo)
```

The standalone **voice sender tool** is optional and not part of the bridge runtime. If it is not present on
this machine, text/image/sticker flows are unaffected.

## Testing

`npm run test:audit` runs isolated regression tests without production credentials, DSH, or QQ messages. User-visible changes are tracked in [CHANGELOG.md](CHANGELOG.md); current docs are indexed in [docs/README.md](docs/README.md).

After upgrading, legacy QQ session mappings without permission metadata are recreated once. Mode or preset changes also retire the old mapping and recreate the session on the next message; DSH history is retained.

```bash
npm run self-test       # DSH-side link test, no QQ/SnowLuma required
npm run test-md
npm run test-wait
npm run test-vision
npm run test-forward
npm run test-slang
npm run test-stickers
```

## License

Starting with **v0.3.0**, this project uses a **proprietary, all-rights-reserved license — it is not open source**. See [LICENSE](LICENSE) for the binding terms (Chinese text controls; an English summary is included).

- ✅ Authorized users may: install and use the software free of charge on their own devices for personal, non-commercial purposes, and receive official updates; reading the source and making private local modifications is allowed for those granted source access.
- ❌ Without prior written permission you may not: redistribute the source or installers, publish them publicly, use them commercially, remove notices, reverse engineer, or use them for AI model training.
- The source repository is **private and invite-only**; installers and the update manifest live in a public release repository and are meant for authorized users only — please do not forward them.
- Versions released **up to v0.2.1-r1** remain under the MIT License for their recipients.

Contact the author (GitHub: [Derpyu520](https://github.com/Derpyu520)) for authorization.

## Compliance

SnowLuma is an independent third-party project and is not affiliated with Tencent/QQ. This project is for learning and technical research only; please follow the relevant terms and the QQ User Agreement.
